import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.publictak.app',
  appName: 'Public Tak App',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
