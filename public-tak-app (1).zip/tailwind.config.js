/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Tiro Devanagari Hindi"', 'Poppins', 'Mukta', 'sans-serif'],
        hindi: ['"Tiro Devanagari Hindi"', 'Mukta', 'serif'],
        tiro: ['"Tiro Devanagari Hindi"', 'serif'],
        serif: ['"Tiro Devanagari Hindi"', '"Noto Serif Devanagari"', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
}
