import express from "express";
import { createServer as createViteServer, ViteDevServer } from "vite";
import path from "path";
import fs from "fs";
import admin from "firebase-admin";
import Razorpay from "razorpay";
import crypto from "crypto";
import { GoogleGenAI, Type } from "@google/genai";

// Initialize Firebase Admin (it will use default credentials on Cloud Run/Firebase)
if (!admin.apps.length) {
  try {
    admin.initializeApp();
  } catch (e) {
    console.warn("Firebase Admin failed to initialize. Dynamic meta tags will not work locally.", e);
  }
}

const db = admin.apps.length ? admin.firestore() : null;

// Razorpay Instance
const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_Sfov0bF3zEHs4X',
    key_secret: process.env.RAZORPAY_KEY_SECRET || '', 
});

// Firebase config for REST queries (bypasses Cloud Run permission issues)
const FIREBASE_API_KEY = "AIzaSyBcVMGPppCWHy9sGacwXXf_gmg4kb0Dd0Y";
const FIREBASE_PROJECT_ID = "public-tak-app";

interface CacheEntry {
  data: any;
  expiry: number;
}
const docCache = new Map<string, CacheEntry>();

function getCachedDoc(key: string): any | null {
  const entry = docCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiry) {
    docCache.delete(key);
    return null;
  }
  return entry.data;
}

function setCachedDoc(key: string, data: any, ttlMs = 5 * 60 * 1000) {
  if (docCache.size > 1000) {
    const oldestKey = docCache.keys().next().value;
    if (oldestKey) docCache.delete(oldestKey);
  }
  docCache.set(key, { data, expiry: Date.now() + ttlMs });
}

function parseFirestoreValue(val: any): any {
  if (!val) return null;
  if ("stringValue" in val) return val.stringValue;
  if ("integerValue" in val) return parseInt(val.integerValue, 10);
  if ("doubleValue" in val) return parseFloat(val.doubleValue);
  if ("booleanValue" in val) return val.booleanValue;
  if ("timestampValue" in val) return val.timestampValue;
  if ("mapValue" in val) {
    const res: any = {};
    for (const k in val.mapValue.fields || {}) {
      res[k] = parseFirestoreValue(val.mapValue.fields[k]);
    }
    return res;
  }
  if ("arrayValue" in val) {
    return (val.arrayValue.values || []).map(parseFirestoreValue);
  }
  return null;
}

function parseFirestoreDoc(doc: any): any {
  if (!doc || !doc.fields) return null;
  const res: any = { id: (doc.name || "").split("/").pop() };
  for (const k in doc.fields) {
    res[k] = parseFirestoreValue(doc.fields[k]);
  }
  return res;
}

async function fetchFirestoreDocument(collection: string, docId: string): Promise<any | null> {
  if (!docId) return null;
  const cacheKey = `${collection}_${docId}`;
  const cached = getCachedDoc(cacheKey);
  if (cached) return cached;

  // 1. Try Firestore REST API using Client Key (fast, direct, works everywhere)
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${collection}/${encodeURIComponent(docId)}?key=${FIREBASE_API_KEY}`;
    const resp = await fetch(url, { signal: AbortSignal.timeout(4000) });
    if (resp.ok) {
      const json = await resp.json();
      const parsed = parseFirestoreDoc(json);
      if (parsed) {
        setCachedDoc(cacheKey, parsed);
        return parsed;
      }
    }
  } catch (err) {
    // silently proceed to fallback
  }

  // 2. Fallback to Firebase Admin SDK if available
  if (db) {
    try {
      const docSnap = await db.collection(collection).doc(docId).get();
      if (docSnap.exists) {
        const data = { id: docSnap.id, ...docSnap.data() };
        setCachedDoc(cacheKey, data);
        return data;
      }
    } catch (_) {
      // ignore
    }
  }

  return null;
}

function escapeHtml(str: string): string {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function getImageMimeType(url: string): string {
  const lower = (url || "").toLowerCase();
  if (lower.includes(".png")) return "image/png";
  if (lower.includes(".webp")) return "image/webp";
  if (lower.includes(".gif")) return "image/gif";
  if (lower.includes(".svg")) return "image/svg+xml";
  return "image/jpeg";
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  let vite: ViteDevServer | null = null;

  app.use(express.json());

  // Content Safety Check API using GoogleGenAI on server-side
  app.post("/api/safety-check", async (req, res) => {
    try {
      const { title, content, description, type = 'article', category: postCat } = req.body;
      const apiKey = (process.env.GEMINI_API_KEY || process.env.API_KEY || "").trim();

      if (!apiKey || apiKey === "your_api_key_here" || apiKey === "your_api_key" || apiKey.startsWith("your-")) {
        console.warn("GEMINI_API_KEY is not set or placeholder. Bypassing safety check.");
        return res.json({ isViolated: false, reason: "", category: "General", severity: "low" });
      }

      const ai = new GoogleGenAI({ 
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      const prompt = `You are an AI Safety & Content Moderation system for a local news and social platform.
      Analyze the following content (${type}) for violations of Community Guidelines:
      - Hate Speech, violence, discrimination, or hate propaganda
      - Severe Harassment, Bullying, or Personal Attacks
      - Sexually Explicit, Pornographic, or Adult Content
      - Dangerous, Violent, Criminal, or Self-Harm Encouragement
      - Scams, Fraud, Fake News, or Dangerous Misinformation

      Return a JSON object with:
      1. "isViolated": boolean (true ONLY if harmful/violating content is detected)
      2. "reason": string (a concise explanation in both Hindi and English detailing why it violates guidelines, e.g. "कम्युनिटी गाइडलाइन्स का उल्लंघन: यह पोस्ट नफ़रत फैलाने या हिंसा भड़काने वाली भाषा का प्रयोग करती है। (Hate speech / Incitement detected)")
      3. "category": string ("Hate Speech", "Violence", "Harassment", "Explicit Content", "Dangerous Content", "Misinformation", "Other")
      4. "severity": string ("high", "medium", "low")

      Content Details:
      Type: ${type}
      Title: ${title || ""}
      Category: ${postCat || ""}
      Body / Description: ${content || description || ""}`;

      const checkPromise = ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              isViolated: { type: Type.BOOLEAN },
              reason: { type: Type.STRING },
              category: { type: Type.STRING },
              severity: { type: Type.STRING }
            },
            required: ["isViolated", "reason", "category", "severity"]
          }
        }
      });

      const timeoutPromise = new Promise<any>((_, reject) =>
        setTimeout(() => reject(new Error("Timeout")), 5000)
      );

      const response = await Promise.race([checkPromise, timeoutPromise]);
      const result = JSON.parse(response.text || '{"isViolated": false, "reason": "", "category": "General", "severity": "low"}');
      return res.json(result);
    } catch (error: any) {
      const errorMsg = error?.message || (typeof error === 'object' ? JSON.stringify(error) : String(error));
      if (errorMsg.includes("API key not valid") || errorMsg.includes("API_KEY_INVALID") || errorMsg.includes("INVALID_ARGUMENT")) {
        console.warn("Gemini API key is invalid or unauthorized. Content safety check bypassed safely.");
      } else {
        console.warn("Safety check bypassed due to error:", errorMsg);
      }
      return res.json({ isViolated: false, reason: "", category: "General", severity: "low" });
    }
  });

  // Google Translate API endpoint for news translation
  app.post("/api/translate", async (req, res) => {
    try {
      const { title = "", content = "", targetLang = "hi", targetLangName = "Hindi" } = req.body;

      if (!title && !content) {
        return res.status(400).json({ error: "Title or content required for translation" });
      }

      const translateTextWithGoogle = async (text: string, targetLanguage: string): Promise<string> => {
        if (!text || text.trim() === "") return "";
        
        // Single chunk for short/medium text
        if (text.length <= 1500) {
          const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(targetLanguage)}&dt=t&q=${encodeURIComponent(text)}`;
          const response = await fetch(url, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
              "Accept": "*/*"
            }
          });
          if (!response.ok) throw new Error(`Google Translate error: ${response.statusText}`);
          const data = await response.json();
          if (Array.isArray(data) && Array.isArray(data[0])) {
            return data[0].map((item: any) => (Array.isArray(item) ? item[0] : "")).join("");
          }
          return text;
        }

        // For long text/HTML, split by paragraph or newline breaks
        const parts = text.split(/(<\/p>|\n{2,})/gi);
        const translatedParts: string[] = [];
        let currentBatch = "";

        for (const part of parts) {
          if ((currentBatch + part).length > 1200 && currentBatch.trim().length > 0) {
            const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(targetLanguage)}&dt=t&q=${encodeURIComponent(currentBatch)}`;
            const resp = await fetch(url, {
              headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
            });
            if (resp.ok) {
              const data = await resp.json();
              if (Array.isArray(data) && Array.isArray(data[0])) {
                translatedParts.push(data[0].map((item: any) => (Array.isArray(item) ? item[0] : "")).join(""));
              } else {
                translatedParts.push(currentBatch);
              }
            } else {
              translatedParts.push(currentBatch);
            }
            currentBatch = part;
          } else {
            currentBatch += part;
          }
        }

        if (currentBatch.trim().length > 0) {
          const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(targetLanguage)}&dt=t&q=${encodeURIComponent(currentBatch)}`;
          const resp = await fetch(url, {
            headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
          });
          if (resp.ok) {
            const data = await resp.json();
            if (Array.isArray(data) && Array.isArray(data[0])) {
              translatedParts.push(data[0].map((item: any) => (Array.isArray(item) ? item[0] : "")).join(""));
            } else {
              translatedParts.push(currentBatch);
            }
          } else {
            translatedParts.push(currentBatch);
          }
        }

        return translatedParts.join("");
      };

      const [translatedTitle, translatedContent] = await Promise.all([
        title ? translateTextWithGoogle(title, targetLang) : Promise.resolve(""),
        content ? translateTextWithGoogle(content, targetLang) : Promise.resolve("")
      ]);

      return res.json({
        success: true,
        title: translatedTitle || title,
        content: translatedContent || content,
        targetLang,
        targetLangName
      });
    } catch (error: any) {
      console.error("Translation API error:", error);
      return res.status(500).json({ 
        error: error?.message || "Translation failed",
        success: false 
      });
    }
  });

  // Image Proxy Route to avoid CORS issues when compiling PDFs in client browser
  app.get("/api/proxy-image", async (req, res) => {
    try {
      const imageUrl = req.query.url as string;
      if (!imageUrl) {
        return res.status(400).send("URL parameter is required");
      }

      const response = await fetch(imageUrl);
      if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
      }

      const buffer = await response.arrayBuffer();
      const contentType = response.headers.get("content-type") || "image/jpeg";
      
      res.set("Content-Type", contentType);
      res.set("Access-Control-Allow-Origin", "*");
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error("Error proxying image:", error);
      res.status(500).send("Error proxying image");
    }
  });

  // Transparent Firebase Auth handler proxy for Cloud Run & custom environments
  app.use("/__/auth", async (req, res) => {
    try {
      const targetUrl = `https://public-tak-app.firebaseapp.com/__/auth${req.url}`;
      const response = await fetch(targetUrl, {
        method: req.method,
        headers: {
          "Accept": (req.headers["accept"] as string) || "*/*",
          "User-Agent": (req.headers["user-agent"] as string) || "",
        }
      });
      res.status(response.status);
      response.headers.forEach((value, name) => {
        if (name.toLowerCase() !== 'content-encoding' && name.toLowerCase() !== 'content-length') {
          res.setHeader(name, value);
        }
      });
      const buffer = Buffer.from(await response.arrayBuffer());
      res.send(buffer);
    } catch (err) {
      console.warn("Auth proxy fallback redirect:", err);
      res.redirect(`https://public-tak-app.firebaseapp.com/__/auth${req.url}`);
    }
  });

  // Robots.txt for Google Search Console & Crawlers
  app.get("/robots.txt", (req, res) => {
    res.type("text/plain");
    res.send(`User-agent: *
Allow: /
Sitemap: https://publictak.app/sitemap.xml
`);
  });

  // Dynamic XML Sitemap for Google Search Console & SEO
  app.get("/sitemap.xml", async (req, res) => {
    res.header("Content-Type", "application/xml");
    try {
      const urls: Array<{ 
        loc: string; 
        lastmod?: string; 
        changefreq: string; 
        priority: string;
        newsTitle?: string;
        newsPubDate?: string;
      }> = [
        { loc: "https://publictak.app/", changefreq: "always", priority: "1.0" },
        { loc: "https://publictak.app/?page=video", changefreq: "always", priority: "0.9" },
        { loc: "https://publictak.app/?page=epaper", changefreq: "daily", priority: "0.9" },
        { loc: "https://publictak.app/?page=about", changefreq: "weekly", priority: "0.6" },
        { loc: "https://publictak.app/?page=privacy", changefreq: "monthly", priority: "0.4" },
        { loc: "https://publictak.app/?page=terms", changefreq: "monthly", priority: "0.4" },
        { loc: "https://publictak.app/?page=contact", changefreq: "monthly", priority: "0.5" },
      ];

      if (db) {
        // 1. Fetch live news articles (posts)
        try {
          const postsSnapshot = await db.collection("posts")
            .orderBy("createdAt", "desc")
            .limit(1000)
            .get();

          const twoDaysAgo = Date.now() - (48 * 60 * 60 * 1000);

          postsSnapshot.forEach(doc => {
            const post = doc.data();
            let dateStr: string | undefined = undefined;
            let rawDate: Date | null = null;
            if (post.createdAt) {
              try {
                rawDate = post.createdAt.toDate ? post.createdAt.toDate() : new Date(post.createdAt);
                dateStr = rawDate.toISOString().split('T')[0];
              } catch (e) {
                // Ignore date parsing errors
              }
            }

            const isRecentNews = rawDate && rawDate.getTime() > twoDaysAgo;

            urls.push({
              loc: `https://publictak.app/?postId=${doc.id}`,
              lastmod: dateStr,
              changefreq: "daily",
              priority: "0.9",
              newsTitle: isRecentNews ? (post.title || "").substring(0, 100) : undefined,
              newsPubDate: isRecentNews && rawDate ? rawDate.toISOString() : undefined
            });
          });
        } catch (e) {
          console.error("Error adding posts to sitemap:", e);
        }

        // 2. Fetch live video/reels posts
        try {
          const videosSnapshot = await db.collection("videos")
            .orderBy("createdAt", "desc")
            .limit(500)
            .get();

          videosSnapshot.forEach(doc => {
            const video = doc.data();
            let dateStr: string | undefined = undefined;
            if (video.createdAt) {
              try {
                const date = video.createdAt.toDate ? video.createdAt.toDate() : new Date(video.createdAt);
                dateStr = date.toISOString().split('T')[0];
              } catch (e) {
                // Ignore date parsing errors
              }
            }
            urls.push({
              loc: `https://publictak.app/?videoId=${doc.id}`,
              lastmod: dateStr,
              changefreq: "daily",
              priority: "0.8"
            });
          });
        } catch (e) {
          console.error("Error adding videos to sitemap:", e);
        }

        // 3. Fetch active public user profiles (creators)
        try {
          const usersSnapshot = await db.collection("users")
            .where("isPublic", "==", true)
            .limit(150)
            .get();

          usersSnapshot.forEach(doc => {
            urls.push({
              loc: `https://publictak.app/?userId=${doc.id}`,
              changefreq: "weekly",
              priority: "0.6"
            });
          });
        } catch (e) {
          console.error("Error adding users to sitemap:", e);
        }
      }

      const urlTags = urls.map(url => {
        let newsTag = '';
        if (url.newsTitle && url.newsPubDate) {
          const safeTitle = url.newsTitle.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
          newsTag = `\n    <news:news>\n      <news:publication>\n        <news:name>Public Tak App</news:name>\n        <news:language>hi</news:language>\n      </news:publication>\n      <news:publication_date>${url.newsPubDate}</news:publication_date>\n      <news:title>${safeTitle}</news:title>\n    </news:news>`;
        }

        return `  <url>
    <loc>${url.loc}</loc>${url.lastmod ? `\n    <lastmod>${url.lastmod}</lastmod>` : ''}
    <changefreq>${url.changefreq}</changefreq>
    <priority>${url.priority}</priority>${newsTag}
  </url>`;
      }).join("\n");

      const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">
${urlTags}
</urlset>`;

      res.status(200).send(xml);
    } catch (error) {
      console.error("Error generating dynamic sitemap:", error);
      const fallbackXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://publictak.app/</loc>
    <changefreq>always</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>`;
      res.status(500).send(fallbackXml);
    }
  });

  // Razorpay API Routes
  app.post("/api/payment/order", async (req, res) => {
    try {
        const { amount, currency = "INR" } = req.body;
        
        const options = {
            amount: amount * 100, // Amount in paise
            currency,
            receipt: `verification_${Date.now()}`,
        };

        const order = await razorpay.orders.create(options);
        res.json(order);
    } catch (error) {
        console.error("Razorpay Order Error:", error);
        res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.post("/api/payment/verify", async (req, res) => {
    try {
        const { 
            razorpay_order_id, 
            razorpay_payment_id, 
            razorpay_signature,
            userId
        } = req.body;

        const sign = razorpay_order_id + "|" + razorpay_payment_id;
        const expectedSign = crypto
            .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET || "")
            .update(sign.toString())
            .digest("hex");

        if (razorpay_signature === expectedSign) {
            // Payment verified - Update User in Firestore
            if (db && userId) {
                await db.collection("users").doc(userId).update({
                    isVerified: true,
                    verificationDate: admin.firestore.FieldValue.serverTimestamp(),
                    lastPaymentId: razorpay_payment_id
                });
                return res.json({ success: true, message: "Payment verified successfully" });
            }
            return res.status(400).json({ error: "User ID missing or DB error" });
        } else {
            return res.status(400).json({ error: "Invalid signature" });
        }
    } catch (error) {
        console.error("Razorpay Verification Error:", error);
        res.status(500).json({ error: "Verification failed" });
    }
  });

  // --- Push Notification & Analytics API ---

  app.post("/api/notify-followers", async (req, res) => {
    try {
      const { 
        publisherId, 
        postId, 
        videoId, 
        type, 
        title, 
        description, 
        thumbnailUrl, 
        publisherName, 
        publisherProfilePicUrl 
      } = req.body;

      if (!db) {
        return res.status(500).json({ error: "Firestore is not initialized" });
      }

      // 1. Verify Publisher exists and is verified
      const publisherDoc = await db.collection("users").doc(publisherId).get();
      if (!publisherDoc.exists) {
        return res.status(404).json({ error: "Publisher not found" });
      }
      
      const publisherData = publisherDoc.data() || {};
      
      // Allow all publishers to notify their followers
      const publisherNameFinal = publisherName || publisherData.name || "A Creator";

      // Rate limit check: Prevent publisher from spamming (max 1 notification every 10 seconds)
      const lastNotifQuery = await db.collection("notification_history")
        .where("publisherId", "==", publisherId)
        .orderBy("createdAt", "desc")
        .limit(1)
        .get();
        
      if (!lastNotifQuery.empty) {
        const lastNotif = lastNotifQuery.docs[0].data();
        const lastNotifTime = lastNotif.createdAt ? (lastNotif.createdAt.toDate ? lastNotif.createdAt.toDate().getTime() : new Date(lastNotif.createdAt).getTime()) : 0;
        const timeDiff = Date.now() - lastNotifTime;
        if (timeDiff < 10000) { // 10 seconds rate limit
          return res.status(429).json({ error: "Rate limit exceeded. Please wait 10 seconds before sending another notification." });
        }
      }

      // 2. Fetch Followers
      const followersSnapshot = await db.collection("users").doc(publisherId).collection("followers").get();
      if (followersSnapshot.empty) {
        return res.json({ success: true, message: "No followers to notify", recipientCount: 0 });
      }

      const followerIds = followersSnapshot.docs.map(doc => doc.id);

      // 3. Grouping logic: If publisher published other content in the last 5 minutes
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const recentPostsQuery = await db.collection("notification_history")
        .where("publisherId", "==", publisherId)
        .where("createdAt", ">=", fiveMinutesAgo)
        .get();

      const recentCount = recentPostsQuery.size;
      
      let finalTitle = title;
      let finalBody = description || "";
      
      // Limit description/body to 100 characters and title to 70 characters
      if (finalTitle.length > 70) finalTitle = finalTitle.substring(0, 67) + "...";
      if (finalBody.length > 100) finalBody = finalBody.substring(0, 97) + "...";

      if (recentCount > 0) {
        // Grouped Notification
        const count = recentCount + 1;
        finalTitle = `${publisherName} published ${count} new updates`;
        finalBody = `Tap to view the latest articles and videos from ${publisherName}.`;
      } else {
        // Standard Notification
        finalTitle = `${publisherName} published a new ${type === 'video' ? 'video' : 'article'}`;
        finalBody = `${title}: ${finalBody}`;
      }

      // Create a unique notification history document
      const notifHistoryRef = db.collection("notification_history").doc();
      const notificationId = notifHistoryRef.id;

      // 4. Retrieve FCM tokens for followers who are logged in & have allowed notifications
      const tokens: string[] = [];
      const userDocPromises = followerIds.map(id => db!.collection("users").doc(id).get());
      const userDocs = await Promise.all(userDocPromises);

      userDocs.forEach(doc => {
        if (doc.exists) {
          const u = doc.data() || {};
          // Check if notification is enabled (defaults to true)
          const isNotifEnabled = u.notificationsEnabled !== false;
          if (isNotifEnabled && Array.isArray(u.fcmTokens)) {
            u.fcmTokens.forEach((tok: string) => {
              if (tok && !tokens.includes(tok)) {
                tokens.push(tok);
              }
            });
          }
        }
      });

      if (tokens.length === 0) {
        // No FCM tokens found. Still save in history as delivered: 0
        await notifHistoryRef.set({
          id: notificationId,
          publisherId,
          publisherName,
          publisherProfilePicUrl: publisherProfilePicUrl || publisherData.profilePicUrl || "",
          postId: postId || null,
          videoId: videoId || null,
          type,
          title: finalTitle,
          body: finalBody,
          thumbnailUrl: thumbnailUrl || "",
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          recipientCount: 0,
          stats: { delivered: 0, opened: 0, clicked: 0, failed: 0, dismissed: 0 }
        });
        return res.json({ success: true, message: "No active device tokens found for followers", recipientCount: 0 });
      }

      // 5. Send FCM Notifications
      let deliveredCount = 0;
      let failedCount = 0;

      const fcmPayload = {
        notification: {
          title: finalTitle,
          body: finalBody,
          image: thumbnailUrl || undefined,
        },
        data: {
          notificationId,
          postId: postId || "",
          videoId: videoId || "",
          type,
          publisher: publisherName,
          url: type === 'video' ? `/?videoId=${videoId}&notifId=${notificationId}` : `/?postId=${postId}&notifId=${notificationId}`
        },
        android: {
          priority: "high" as const,
          notification: {
            sound: "publictak_notification.mp3",
            channelId: "public_tak_news_alerts",
            clickAction: "FLUTTER_NOTIFICATION_CLICK"
          }
        },
        apns: {
          payload: {
            aps: {
              sound: "publictak_notification.mp3",
              badge: 1
            }
          }
        }
      };

      // Send to devices
      try {
        const messages = tokens.map(token => ({
          ...fcmPayload,
          token
        }));

        // Send messages using sendEach
        const response = await admin.messaging().sendEach(messages);
        
        response.responses.forEach((resp) => {
          if (resp.success) {
            deliveredCount++;
          } else {
            failedCount++;
            console.warn("FCM Token failed sending:", resp.error?.message);
          }
        });
      } catch (fcmError: any) {
        console.error("Error sending bulk FCM:", fcmError);
      }

      // Save notification in history with initial delivery stats
      await notifHistoryRef.set({
        id: notificationId,
        publisherId,
        publisherName,
        publisherProfilePicUrl: publisherProfilePicUrl || publisherData.profilePicUrl || "",
        postId: postId || null,
        videoId: videoId || null,
        type,
        title: finalTitle,
        body: finalBody,
        thumbnailUrl: thumbnailUrl || "",
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        recipientCount: tokens.length,
        stats: {
          delivered: deliveredCount,
          opened: 0,
          clicked: 0,
          failed: failedCount,
          dismissed: 0
        }
      });

      return res.json({
        success: true,
        message: `Successfully processed push notifications for ${tokens.length} tokens`,
        recipientCount: tokens.length,
        delivered: deliveredCount,
        failed: failedCount,
        notificationId
      });
    } catch (error: any) {
      console.error("Error in notify-followers API:", error);
      return res.status(500).json({ error: error?.message || "Internal server error" });
    }
  });

  // Analytics tracking: Delivered
  app.post("/api/notifications/track-delivered", async (req, res) => {
    try {
      const { notificationId } = req.body;
      if (!db || !notificationId) return res.status(400).send("Missing parameters");

      const docRef = db.collection("notification_history").doc(notificationId);
      await db.runTransaction(async (transaction) => {
        const doc = await transaction.get(docRef);
        if (doc.exists) {
          const stats = doc.data()?.stats || { delivered: 0, opened: 0, clicked: 0, failed: 0, dismissed: 0 };
          stats.delivered = (stats.delivered || 0) + 1;
          transaction.update(docRef, { stats });
        }
      });
      return res.json({ success: true });
    } catch (e: any) {
      console.error("Delivered track failed:", e);
      return res.status(500).json({ error: e.message });
    }
  });

  // Analytics tracking: Opened/Clicked
  app.post("/api/notifications/track-opened", async (req, res) => {
    try {
      const { notificationId } = req.body;
      if (!db || !notificationId) return res.status(400).send("Missing parameters");

      const docRef = db.collection("notification_history").doc(notificationId);
      await db.runTransaction(async (transaction) => {
        const doc = await transaction.get(docRef);
        if (doc.exists) {
          const stats = doc.data()?.stats || { delivered: 0, opened: 0, clicked: 0, failed: 0, dismissed: 0 };
          stats.opened = (stats.opened || 0) + 1;
          stats.clicked = (stats.clicked || 0) + 1; // Clicked count tracks along with opened
          transaction.update(docRef, { stats });
        }
      });
      return res.json({ success: true });
    } catch (e: any) {
      console.error("Opened track failed:", e);
      return res.status(500).json({ error: e.message });
    }
  });

  // Analytics tracking: Dismissed
  app.post("/api/notifications/track-dismissed", async (req, res) => {
    try {
      const { notificationId } = req.body;
      if (!db || !notificationId) return res.status(400).send("Missing parameters");

      const docRef = db.collection("notification_history").doc(notificationId);
      await db.runTransaction(async (transaction) => {
        const doc = await transaction.get(docRef);
        if (doc.exists) {
          const stats = doc.data()?.stats || { delivered: 0, opened: 0, clicked: 0, failed: 0, dismissed: 0 };
          stats.dismissed = (stats.dismissed || 0) + 1;
          transaction.update(docRef, { stats });
        }
      });
      return res.json({ success: true });
    } catch (e: any) {
      console.error("Dismissed track failed:", e);
      return res.status(500).json({ error: e.message });
    }
  });

  const isProd = process.env.NODE_ENV === "production" && fs.existsSync(path.resolve(process.cwd(), "dist/index.html"));

  if (!isProd) {
    vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
  }

  // Middleware for injecting dynamic meta tags and social media crawlers
  app.use(async (req, res, next) => {
    if (req.method !== "GET") {
      return next();
    }

    const reqPath = req.path || "/";

    // Never intercept Vite internal modules, source files, node_modules, or API endpoints
    if (
      reqPath.startsWith("/@") ||
      reqPath.startsWith("/src/") ||
      reqPath.startsWith("/node_modules/") ||
      reqPath.startsWith("/api/") ||
      reqPath.startsWith("/__vite") ||
      reqPath.startsWith("/favicon.ico")
    ) {
      return next();
    }

    // Skip any path that has a file extension other than .html (e.g., .js, .ts, .tsx, .css, .png, etc.)
    if (/\.[a-zA-Z0-9]+$/i.test(reqPath) && !reqPath.endsWith(".html")) {
      return next();
    }

    // Detect social media and search engine crawlers
    const userAgent = (req.headers["user-agent"] || "").toLowerCase();
    const isSocialBot = /facebookexternalhit|facebot|whatsapp|twitterbot|telegrambot|linkedinbot|pinterest|slackbot|discordbot|googlebot|bingbot|applebot|yandex|duckduckbot|baiduspider|skypeuripreview|meta-externalagent|vkshare|w3c_validator/i.test(userAgent);

    let { postId, videoId, userId, page } = req.query as Record<string, string>;

    // Also support friendly URL paths: /p/:id, /post/:id, /v/:id, /video/:id, /user/:id
    if (!postId && reqPath.startsWith("/p/")) {
      postId = reqPath.replace("/p/", "").split("/")[0].split("?")[0];
    }
    if (!postId && reqPath.startsWith("/post/")) {
      postId = reqPath.replace("/post/", "").split("/")[0].split("?")[0];
    }
    if (!videoId && reqPath.startsWith("/v/")) {
      videoId = reqPath.replace("/v/", "").split("/")[0].split("?")[0];
    }
    if (!videoId && reqPath.startsWith("/video/")) {
      videoId = reqPath.replace("/video/", "").split("/")[0].split("?")[0];
    }
    if (!userId && reqPath.startsWith("/user/")) {
      userId = reqPath.replace("/user/", "").split("/")[0].split("?")[0];
    }

    const isExplicitPage = reqPath === "/" || reqPath.endsWith(".html") || Boolean(postId || videoId || userId || page);
    const acceptsHtml = req.headers.accept ? req.headers.accept.includes("text/html") : false;

    // Only proceed if it is a social bot OR an explicit HTML page request
    if (!isSocialBot && !isExplicitPage && !acceptsHtml) {
      return next();
    }

    try {
      const host = req.get("x-forwarded-host") || req.get("host") || "publictak.app";
      const proto = req.get("x-forwarded-proto") || (req.secure ? "https" : "http");
      const origin = `${proto}://${host}`;

      let title = "Public Tak App | Local News, Video Reels & Daily Hindi E-Paper";
      let description = "Public Tak App par paayein apne shehar aur rajya ki sabse tez evam taza khabrein, video reels, verified reporter updates aur daily e-paper. Desh, Bihar, Jharkhand ki har khabar sabse pehle!";
      let image = `${origin}/icon-512.png`;
      let postUrl = `${origin}/`;
      let ogType = "website";
      let authorName = "Public Tak Reporter";
      let publishedDate = new Date().toISOString();
      let category = "News";
      let schemaJson = "";

      if (postId && typeof postId === "string") {
        const post = await fetchFirestoreDocument("posts", postId);
        if (post) {
          const rawTitle = (post.title || "Taza Khabar").trim();
          title = `${rawTitle} | Public Tak News`;
          const rawContent = (post.content || "").replace(/<[^>]*>?/gm, " ").replace(/\s+/g, " ").trim();
          description = rawContent.substring(0, 160) || "Puri khabar padhne ke liye Public Tak App par click karein.";
          if (post.thumbnailUrl && typeof post.thumbnailUrl === "string") {
            image = post.thumbnailUrl.trim();
          }
          postUrl = `${origin}/?postId=${encodeURIComponent(postId)}`;
          ogType = "article";
          authorName = post.authorName || "Public Tak Verified Reporter";
          category = post.category || "News";

          if (post.createdAt) {
            try {
              const d = post.createdAt.toDate ? post.createdAt.toDate() : new Date(post.createdAt);
              publishedDate = d.toISOString();
            } catch (e) {}
          }

          schemaJson = JSON.stringify({
            "@context": "https://schema.org",
            "@type": "NewsArticle",
            "mainEntityOfPage": { "@type": "WebPage", "@id": postUrl },
            "headline": rawTitle,
            "description": description,
            "image": [image],
            "datePublished": publishedDate,
            "author": [{ "@type": "Person", "name": authorName }],
            "publisher": {
              "@type": "NewsMediaOrganization",
              "name": "Public Tak App",
              "url": origin,
              "logo": { "@type": "ImageObject", "url": `${origin}/icon-512.png` }
            }
          });
        }
      } else if (videoId && typeof videoId === "string") {
        const video = await fetchFirestoreDocument("videos", videoId);
        if (video) {
          const rawTitle = (video.title || "Video Bulletin").trim();
          title = `🎥 ${rawTitle} | Public Tak Video News`;
          const rawDesc = (video.description || "").replace(/<[^>]*>?/gm, " ").replace(/\s+/g, " ").trim();
          description = rawDesc.substring(0, 160) || "Watch this latest breaking video report on Public Tak App.";
          if (video.thumbnailUrl && typeof video.thumbnailUrl === "string") {
            image = video.thumbnailUrl.trim();
          }
          postUrl = `${origin}/?videoId=${encodeURIComponent(videoId)}`;
          ogType = "video.other";
          authorName = video.authorName || "Public Tak Reporter";

          if (video.createdAt) {
            try {
              const d = video.createdAt.toDate ? video.createdAt.toDate() : new Date(video.createdAt);
              publishedDate = d.toISOString();
            } catch (e) {}
          }

          schemaJson = JSON.stringify({
            "@context": "https://schema.org",
            "@type": "VideoObject",
            "name": rawTitle,
            "description": description,
            "thumbnailUrl": [image],
            "uploadDate": publishedDate,
            "contentUrl": postUrl,
            "embedUrl": postUrl,
            "publisher": {
              "@type": "Organization",
              "name": "Public Tak App",
              "logo": { "@type": "ImageObject", "url": `${origin}/icon-512.png` }
            }
          });
        }
      } else if (userId && typeof userId === "string") {
        const user = await fetchFirestoreDocument("users", userId);
        if (user) {
          title = `👤 ${user.name || "Public Reporter"} | Public Tak App`;
          description = user.bio || `Read verified news reports, breaking news, and video bulletins by ${user.name || "Public Reporter"} on Public Tak App.`;
          if (user.profilePicUrl && typeof user.profilePicUrl === "string") {
            image = user.profilePicUrl.trim();
          }
          postUrl = `${origin}/?userId=${encodeURIComponent(userId)}`;
          ogType = "profile";

          schemaJson = JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ProfilePage",
            "mainEntity": {
              "@type": "Person",
              "name": user.name || "Public Reporter",
              "description": description,
              "image": image
            }
          });
        }
      } else if (page === 'epaper') {
        title = "🗞️ Daily Hindi E-Paper | Public Tak Digital Newspaper";
        description = "Public Tak ka aaj ka digital hindi e-paper online padhein. Apne shehar aur kshetra ki sabhi pramukh khabrein digital akhbar format me.";
        postUrl = `${origin}/?page=epaper`;
      } else if (page === 'video') {
        title = "🎥 Local Video Bulletins & Reels | Public Tak App";
        description = "Apne kshetra aur rajya ki tazatareen video khabrein, Ground Zero reports aur video reels dekhein.";
        postUrl = `${origin}/?page=video`;
      }

      if (!schemaJson) {
        schemaJson = JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "NewsMediaOrganization",
              "@id": `${origin}/#organization`,
              "name": "Public Tak App",
              "url": origin,
              "logo": { "@type": "ImageObject", "url": `${origin}/icon-512.png` }
            },
            {
              "@type": "WebSite",
              "@id": `${origin}/#website`,
              "url": origin,
              "name": "Public Tak App",
              "description": description,
              "publisher": { "@id": `${origin}/#organization` }
            }
          ]
        });
      }

      const safeTitle = escapeHtml(title);
      const safeDesc = escapeHtml(description);
      const safeImage = escapeHtml(image);
      const safeUrl = escapeHtml(postUrl);
      const safeAuthor = escapeHtml(authorName);
      const safeCategory = escapeHtml(category);
      const imageMimeType = getImageMimeType(image);

      const dynamicMetaTags = `
    <!-- Dynamic Primary Meta Tags -->
    <title>${safeTitle}</title>
    <meta name="title" content="${safeTitle}">
    <meta name="description" content="${safeDesc}">
    <link rel="canonical" href="${safeUrl}">
    <link rel="image_src" href="${safeImage}">

    <!-- Dynamic Open Graph / Facebook / WhatsApp -->
    <meta property="og:site_name" content="Public Tak App">
    <meta property="og:type" content="${ogType}">
    <meta property="og:url" content="${safeUrl}">
    <meta property="og:title" content="${safeTitle}">
    <meta property="og:description" content="${safeDesc}">
    <meta property="og:image" content="${safeImage}">
    <meta property="og:image:secure_url" content="${safeImage}">
    <meta property="og:image:type" content="${imageMimeType}">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="${safeTitle}">
    <meta property="og:locale" content="hi_IN">
    <meta property="article:published_time" content="${publishedDate}">
    <meta property="article:author" content="${safeAuthor}">
    <meta property="article:section" content="${safeCategory}">

    <!-- Dynamic Twitter / X Cards -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@PublicTakApp">
    <meta name="twitter:title" content="${safeTitle}">
    <meta name="twitter:description" content="${safeDesc}">
    <meta name="twitter:image" content="${safeImage}">
    <meta name="twitter:image:src" content="${safeImage}">
    <meta name="twitter:image:alt" content="${safeTitle}">

    <!-- Schema.org JSON-LD -->
    <script type="application/ld+json">${schemaJson}</script>`;

      // If requested by a social media bot (WhatsApp, Facebook, Twitter, Telegram, etc.)
      // serve an ultra-fast, standalone HTML page designed specifically for scrapers
      if (isSocialBot) {
        const botHtml = `<!DOCTYPE html>
<html lang="hi" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  ${dynamicMetaTags}
</head>
<body style="font-family: system-ui, -apple-system, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; line-height: 1.6; color: #111;">
  <article>
    <header>
      <h1 style="font-size: 24px; font-weight: bold; margin-bottom: 12px;">${safeTitle}</h1>
      <p style="color: #666; font-size: 14px;">द्वारा: ${safeAuthor} | Public Tak News Network</p>
    </header>
    <div style="margin: 16px 0;">
      <img src="${safeImage}" alt="${safeTitle}" width="1200" height="630" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);" />
    </div>
    <p style="font-size: 16px;">${safeDesc}</p>
    <div style="margin-top: 24px;">
      <a href="${safeUrl}" style="display: inline-block; background-color: #dc2626; color: #ffffff; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold;">
        पूरी खबर यहाँ पढ़ें &raquo;
      </a>
    </div>
  </article>
</body>
</html>`;
        return res.status(200)
          .set({
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "public, max-age=300, s-maxage=600"
          })
          .end(botHtml);
      }

      // For standard browser users: inject into single-page application entry HTML
      let templatePath = path.resolve(process.cwd(), isProd ? "dist/index.html" : "index.html");
      if (fs.existsSync(templatePath)) {
        let html = fs.readFileSync(templatePath, "utf-8");

        // Strip default/static meta tags cleanly
        html = html.replace(/<title>[\s\S]*?<\/title>/gi, "");
        html = html.replace(/<meta\s+name=["']title["'][\s\S]*?>/gi, "");
        html = html.replace(/<meta\s+name=["']description["'][\s\S]*?>/gi, "");
        html = html.replace(/<link\s+rel=["']canonical["'][\s\S]*?>/gi, "");
        html = html.replace(/<link\s+rel=["']image_src["'][\s\S]*?>/gi, "");
        html = html.replace(/<meta\s+property=["']og:[\s\S]*?>/gi, "");
        html = html.replace(/<meta\s+name=["']twitter:[\s\S]*?>/gi, "");
        html = html.replace(/<meta\s+property=["']twitter:[\s\S]*?>/gi, "");
        html = html.replace(/<script\s+type=["']application\/ld\+json["']>[\s\S]*?<\/script>/gi, "");

        // Inject dynamic tags into <head>
        html = html.replace("</head>", `${dynamicMetaTags}\n</head>`);

        if (vite) {
          html = await vite.transformIndexHtml(req.originalUrl, html);
        }

        return res.status(200)
          .set({
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "public, max-age=180"
          })
          .end(html);
      }
    } catch (error) {
      console.error("Error serving dynamic SEO HTML:", error);
    }
    next();
  });

  // Vite middleware for development
  if (vite) {
    app.use(vite.middlewares);
  } else {
    // Production serving
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
