
import React, { useState, useEffect } from 'react';
import { db, serverTimestamp, firebase, increment } from '../firebaseConfig';
import { User } from '../types';
import { useToast } from '../contexts/ToastContext';
import UserAvatar from './UserAvatar';
import { appCacheService } from '../services/appCacheService';

interface UserListModalProps {
    userId: string;
    currentUser: User | null;
    type: 'followers' | 'following';
    onClose: () => void;
    onViewUser: (userId: string) => void;
}

const UserListModal: React.FC<UserListModalProps> = ({ userId, currentUser, type, onClose, onViewUser }) => {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [followingIds, setFollowingIds] = useState<Set<string>>(() => currentUser ? appCacheService.getFollowingSet(currentUser.uid) : new Set());
    const [followerIds, setFollowerIds] = useState<Set<string>>(new Set());
    const { showToast } = useToast();

    useEffect(() => {
        if (!currentUser) return;
        const cached = appCacheService.getFollowingSet(currentUser.uid);
        if (cached.size > 0) {
            setFollowingIds(cached);
        }
        const unsubFollowing = db.collection('users').doc(currentUser.uid).collection('following').onSnapshot(snap => {
            const ids = snap.docs.map(doc => doc.id);
            setFollowingIds(new Set(ids));
            appCacheService.setFollowingList(currentUser.uid, ids);
        });
        const unsubFollowers = db.collection('users').doc(currentUser.uid).collection('followers').onSnapshot(snap => {
            setFollowerIds(new Set(snap.docs.map(doc => doc.id)));
        });
        return () => {
            unsubFollowing();
            unsubFollowers();
        };
    }, [currentUser?.uid]);

    const handleFollowToggle = async (e: React.MouseEvent, targetUser: User) => {
        e.stopPropagation();
        if (!currentUser) return;

        const isFollowing = followingIds.has(targetUser.uid);
        const followsMe = followerIds.has(targetUser.uid);

        // Optimistic UI Update
        if (isFollowing) {
            appCacheService.removeFollow(currentUser.uid, targetUser.uid);
        } else {
            appCacheService.addFollow(currentUser.uid, targetUser.uid);
        }
        setFollowingIds(prev => {
            const next = new Set(prev);
            if (isFollowing) next.delete(targetUser.uid);
            else next.add(targetUser.uid);
            return next;
        });

        const currentUserRef = db.collection('users').doc(currentUser.uid);
        const targetUserRef = db.collection('users').doc(targetUser.uid);
        const followRef = currentUserRef.collection('following').doc(targetUser.uid);
        const followerRef = targetUserRef.collection('followers').doc(currentUser.uid);

        try {
            if (isFollowing) {
                await Promise.allSettled([
                    followRef.delete(),
                    followerRef.delete(),
                    currentUserRef.update({ followingCount: increment(-1) }),
                    targetUserRef.update({ followerCount: increment(-1) })
                ]);
                showToast(`Unfollowed ${targetUser.name}`, "info");
            } else {
                await Promise.allSettled([
                    followRef.set({ followedAt: serverTimestamp() }),
                    followerRef.set({ 
                        followedAt: serverTimestamp(),
                        followerId: currentUser.uid,
                        followerName: currentUser.name || '',
                        followerProfilePicUrl: currentUser.profilePicUrl || ''
                    }),
                    currentUserRef.update({ followingCount: increment(1) }),
                    targetUserRef.update({ followerCount: increment(1) }),
                    targetUserRef.collection('notifications').add({
                        type: 'new_follower',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name,
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        fromUserIsVerified: currentUser.isVerified || false,
                        createdAt: serverTimestamp(),
                        read: false
                    })
                ]);
                showToast(followsMe ? `Followed back ${targetUser.name}` : `Following ${targetUser.name}`, "success");
            }
        } catch (error) {
            console.error("Follow toggle error:", error);
        }
    };

    useEffect(() => {
        const fetchUsers = async () => {
            setLoading(true);
            try {
                // 1. Get the list of IDs from the subcollection
                const collectionRef = db.collection('users').doc(userId).collection(type);
                const snapshot = await collectionRef.get();
                
                if (snapshot.empty) {
                    setUsers([]);
                    setLoading(false);
                    return;
                }

                const userIds = snapshot.docs.map(doc => doc.id);

                // 2. Fetch user details for each ID
                // Firestore 'in' query supports up to 10 items. For robustness with larger lists,
                // we fetch individually or use batches. Here we use Promise.all for simplicity 
                // assuming reasonable list size for viewing, or we could paginate.
                // For a better UX in large apps, we'd paginate this.
                
                const userPromises = userIds.map(uid => db.collection('users').doc(uid).get());
                const userSnapshots = await Promise.all(userPromises);
                
                const fetchedUsers = userSnapshots
                    .filter(doc => doc.exists)
                    .map(doc => ({
                        uid: doc.id,
                        ...doc.data()
                    } as User));

                setUsers(fetchedUsers);
            } catch (error) {
                console.error("Error fetching user list:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchUsers();
    }, [userId, type]);

    return (
        <div 
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200"
            onClick={onClose}
        >
            <div 
                className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-200"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-white sticky top-0 z-10">
                    <h3 className="text-lg font-bold text-gray-800 capitalize">{type}</h3>
                    <button 
                        onClick={onClose}
                        className="p-2 rounded-full hover:bg-gray-100 text-gray-500 transition-colors"
                    >
                        <span className="material-symbols-outlined text-xl">close</span>
                    </button>
                </div>

                {/* List */}
                <div className="overflow-y-auto flex-1 p-2">
                    {loading ? (
                        // Loading Skeletons
                        <div className="space-y-3 p-2">
                            {[1, 2, 3, 4, 5].map(i => (
                                <div key={i} className="flex items-center gap-3 animate-pulse">
                                    <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                                    <div className="flex-1 space-y-2">
                                        <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                                        <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : users.length > 0 ? (
                        <div className="space-y-1">
                            {users.map(user => (
                                <div 
                                    key={user.uid}
                                    onClick={() => {
                                        onViewUser(user.uid);
                                        onClose();
                                    }}
                                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-all group"
                                >
                                    <UserAvatar 
                                        userId={user.uid}
                                        src={user.profilePicUrl}
                                        name={user.name}
                                        currentUser={currentUser}
                                        className="w-12 h-12 rounded-full object-cover ring-2 ring-gray-100 group-hover:ring-blue-100 transition-all"
                                    />
                                    <div className="flex-1 min-w-0">
                                        <h4 className="font-bold text-gray-900 truncate group-hover:text-blue-600 transition-colors">{user.name}</h4>
                                        <p className="text-sm text-gray-500 truncate">@{user.username}</p>
                                    </div>
                                    
                                    {currentUser && currentUser.uid !== user.uid && (
                                        <button 
                                            onClick={(e) => handleFollowToggle(e, user)}
                                            className={`px-4 py-1.5 rounded-full text-xs font-black transition-all shadow-sm active:scale-95 flex items-center gap-1 ${
                                                followingIds.has(user.uid)
                                                    ? 'bg-gray-100 text-gray-700 hover:bg-red-50 hover:text-red-600 border border-gray-200 hover:border-red-200'
                                                    : followerIds.has(user.uid)
                                                        ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white border border-blue-500 animate-follow-back-blink shadow-md shadow-blue-500/30'
                                                        : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border border-red-500 animate-follow-blink shadow-md shadow-red-500/30'
                                            }`}
                                        >
                                            {followingIds.has(user.uid) ? (
                                                <>
                                                    <span className="material-symbols-outlined text-sm font-bold">done</span>
                                                    <span>Following</span>
                                                </>
                                            ) : followerIds.has(user.uid) ? (
                                                <>
                                                    <span className="material-symbols-outlined text-sm font-black">person_add</span>
                                                    <span>Follow Back</span>
                                                </>
                                            ) : (
                                                <>
                                                    <span className="material-symbols-outlined text-sm font-black">person_add</span>
                                                    <span>Follow</span>
                                                </>
                                            )}
                                        </button>
                                    )}

                                    <span className="material-symbols-outlined text-gray-300 group-hover:text-blue-400 group-hover:translate-x-1 transition-all">chevron_right</span>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-center">
                            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-3">
                                <span className="material-symbols-outlined text-3xl text-gray-300">group_off</span>
                            </div>
                            <p className="text-gray-500 font-medium">No users found.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default UserListModal;
