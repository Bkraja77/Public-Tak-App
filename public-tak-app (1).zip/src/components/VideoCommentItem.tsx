import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Comment, User } from '../types';
import { db, serverTimestamp } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'framer-motion';
import UserAvatar from './UserAvatar';

interface VideoCommentItemProps {
    comment: Comment;
    videoId: string;
    currentUser: User | null;
    onLogin: () => void;
    onViewUser: (userId: string) => void;
    videoAuthorId: string;
    onDeleteComment: (commentId: string) => void;
}

interface VideoReply {
    id: string;
    content: string;
    authorId: string;
    authorName: string;
    authorProfilePicUrl: string;
    createdAt: Date;
    authorIsVerified?: boolean;
}

const VideoReplyItem: React.FC<{
    reply: VideoReply;
    videoId: string;
    commentId: string;
    currentUser: User | null;
    isVideoAuthor: boolean;
    onViewUser: (id: string) => void;
    showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
    onDeleteReply: (replyId: string) => void;
    canDelete: boolean;
}> = ({ reply, videoId, commentId, currentUser, isVideoAuthor, onViewUser, showToast, onDeleteReply, canDelete }) => {
    const isCurrentUserReply = currentUser && currentUser.uid === reply.authorId;
    
    const timeAgo = useMemo(() => {
        if (!reply.createdAt) return 'now';
        const now = new Date();
        const seconds = Math.floor((now.getTime() - reply.createdAt.getTime()) / 1000);
        
        let interval = seconds / 31536000;
        if (interval > 1) return `${Math.floor(interval)}y`;
        
        interval = seconds / 2592000;
        if (interval > 1) return `${Math.floor(interval)}mo`;
        
        interval = seconds / 86400;
        if (interval > 1) return `${Math.floor(interval)}d`;
        
        interval = seconds / 3600;
        if (interval > 1) return `${Math.floor(interval)}h`;
        
        interval = seconds / 60;
        if (interval > 1) return `${Math.floor(interval)}m`;
        
        return `${Math.max(1, Math.floor(seconds))}s`;
    }, [reply.createdAt]);

    const authorProfilePic = (currentUser && currentUser.uid === reply.authorId)
        ? currentUser.profilePicUrl
        : (reply.authorProfilePicUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(reply.authorName)}`);

    return (
        <div className="flex gap-2.5 items-start justify-between py-1 px-1 rounded-lg hover:bg-gray-50/50 group/reply select-none">
            <div className="flex gap-2.5 items-start flex-1 min-w-0">
                <UserAvatar
                    userId={reply.authorId}
                    src={reply.authorProfilePicUrl}
                    name={reply.authorName}
                    currentUser={currentUser}
                    onClick={(e) => {
                        e.stopPropagation();
                        onViewUser(reply.authorId);
                    }}
                    className="w-6 h-6 rounded-full object-cover cursor-pointer ring-1 ring-black/5 shrink-0"
                />
                <div className="flex flex-col min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                        <span 
                            onClick={(e) => {
                                e.stopPropagation();
                                onViewUser(reply.authorId);
                            }}
                            className="font-bold text-gray-800 text-[11px] cursor-pointer hover:underline"
                        >
                            {reply.authorName.replace(/\s+/g, '_').toLowerCase()}
                        </span>
                        
                        {isVideoAuthor && (
                            <span className="flex items-center gap-0.5 bg-red-600 text-white text-[7px] px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider shadow-sm scale-90">
                                <span className="material-symbols-outlined text-[8px]" style={{ fontVariationSettings: "'FILL' 1" }}>verified</span>
                                Author
                            </span>
                        )}

                        <span className="text-[9px] text-gray-400 font-semibold">{timeAgo}</span>
                        {reply.authorIsVerified && (
                            <span className="material-symbols-outlined text-blue-500 text-[9px] font-black shrink-0">verified</span>
                        )}
                    </div>
                    <p className="text-gray-700 text-xs font-normal mt-0.5 leading-relaxed break-words">
                        {reply.content}
                    </p>
                </div>
            </div>

            {/* Delete reply if owner or video author */}
            {canDelete && (
                <button
                    onClick={() => onDeleteReply(reply.id)}
                    className="text-gray-300 hover:text-red-500 p-1 rounded-full opacity-0 group-hover/reply:opacity-100 transition-opacity duration-150 shrink-0"
                    title="Delete reply"
                >
                    <span className="material-symbols-outlined text-[15px]">delete</span>
                </button>
            )}
        </div>
    );
};

const VideoCommentItem: React.FC<VideoCommentItemProps> = React.memo(({
    comment,
    videoId,
    currentUser,
    onLogin,
    onViewUser,
    videoAuthorId,
    onDeleteComment
}) => {
    const [likeCount, setLikeCount] = useState(0);
    const [isLiked, setIsLiked] = useState(false);
    const [showOptionsModal, setShowOptionsModal] = useState(false);
    const { showToast } = useToast();
    
    // Reply states
    const [serverReplies, setServerReplies] = useState<VideoReply[]>([]);
    const [localReplies, setLocalReplies] = useState<VideoReply[]>([]);
    const [isReplying, setIsReplying] = useState(false);
    const [replyText, setReplyText] = useState('');
    const [isSubmittingReply, setIsSubmittingReply] = useState(false);

    const displayReplies = useMemo(() => {
        const combined = [...serverReplies, ...localReplies];
        const uniqueIds = new Set();
        return combined.filter(item => {
            if (!uniqueIds.has(item.id)) {
                uniqueIds.add(item.id);
                return true;
            }
            return false;
        }).sort((a, b) => (a.createdAt?.getTime() || 0) - (b.createdAt?.getTime() || 0));
    }, [serverReplies, localReplies]);
    
    const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (!comment.id || !videoId) return;

        // Sync likes for this comment in real-time
        const likesRef = db.collection('videos')
            .doc(videoId)
            .collection('comments')
            .doc(comment.id)
            .collection('likes');

        const unsubscribeLikes = likesRef.onSnapshot((snapshot) => {
            setLikeCount(snapshot.size);
            if (currentUser) {
                setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid));
            } else {
                setIsLiked(false);
            }
        }, (error) => {
            console.error("Error loading comment likes:", error);
        });

        // Sync replies for this comment in real-time
        const repliesRef = db.collection('videos')
            .doc(videoId)
            .collection('comments')
            .doc(comment.id)
            .collection('replies');

        const unsubscribeReplies = repliesRef.orderBy('createdAt', 'asc').onSnapshot((snapshot) => {
            const fetched = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
                createdAt: doc.data().createdAt?.toDate ? doc.data().createdAt.toDate() : new Date()
            } as VideoReply));
            setServerReplies(fetched);
            setLocalReplies(prev => prev.filter(l => !fetched.some(s => s.authorId === l.authorId && s.content === l.content)));
        }, (error) => {
            console.error("Error loading comment replies:", error);
        });

        return () => {
            unsubscribeLikes();
            unsubscribeReplies();
        };
    }, [comment.id, videoId, currentUser]);

    const handleLike = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        if (!currentUser) {
            onLogin();
            return;
        }

        const likeRef = db.collection('videos')
            .doc(videoId)
            .collection('comments')
            .doc(comment.id)
            .collection('likes')
            .doc(currentUser.uid);

        try {
            if (isLiked) {
                await likeRef.delete();
            } else {
                await likeRef.set({
                    likedAt: serverTimestamp(),
                    userId: currentUser.uid
                });
            }
        } catch (error) {
            console.error("Error toggling comment like:", error);
        }
    };

    const handlePinComment = async () => {
        if (!comment.id || !videoId) return;
        try {
            const commentRef = db.collection('videos').doc(videoId).collection('comments').doc(comment.id);
            const isCurrentlyPinned = !!comment.isPinned;
            
            if (!isCurrentlyPinned) {
                const pinnedCommentsSnap = await db.collection('videos')
                    .doc(videoId)
                    .collection('comments')
                    .where('isPinned', '==', true)
                    .get();
                
                const batch = db.batch();
                pinnedCommentsSnap.docs.forEach(doc => {
                    batch.update(doc.ref, { isPinned: false });
                });
                batch.update(commentRef, { isPinned: true });
                await batch.commit();
                showToast("Comment pinned to top!", "success");
            } else {
                await commentRef.update({ isPinned: false });
                showToast("Comment unpinned!", "success");
            }
            setShowOptionsModal(false);
        } catch (e) {
            console.error("Error toggling video comment pin:", e);
            showToast("Failed to update pin status", "error");
        }
    };

    const handlePressStart = () => {
        if (currentUser?.uid !== videoAuthorId) return;
        longPressTimerRef.current = setTimeout(() => {
            setShowOptionsModal(true);
            if (navigator.vibrate) navigator.vibrate(50);
        }, 600);
    };

    const handlePressEnd = () => {
        if (longPressTimerRef.current) {
            clearTimeout(longPressTimerRef.current);
            longPressTimerRef.current = null;
        }
    };

    const timeAgo = useMemo(() => {
        if (!comment.createdAt) return 'now';
        const now = new Date();
        const seconds = Math.floor((now.getTime() - comment.createdAt.getTime()) / 1000);
        
        let interval = seconds / 31536000;
        if (interval > 1) return `${Math.floor(interval)}y`;
        
        interval = seconds / 2592000;
        if (interval > 1) return `${Math.floor(interval)}mo`;
        
        interval = seconds / 86400;
        if (interval > 1) return `${Math.floor(interval)}d`;
        
        interval = seconds / 3600;
        if (interval > 1) return `${Math.floor(interval)}h`;
        
        interval = seconds / 60;
        if (interval > 1) return `${Math.floor(interval)}m`;
        
        return `${Math.max(1, Math.floor(seconds))}s`;
    }, [comment.createdAt]);

    const handleReplySubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!replyText.trim() || !currentUser) return;
        setIsSubmittingReply(true);
        const tempId = 'local-' + Date.now();
        const newReply: VideoReply = {
            id: tempId,
            content: replyText.trim(),
            authorId: currentUser.uid,
            authorName: currentUser.name || '',
            authorProfilePicUrl: currentUser.profilePicUrl || '',
            createdAt: new Date(),
            authorIsVerified: currentUser.isVerified || false
        };
        setLocalReplies(prev => [...prev, newReply]);
        const textToSubmit = replyText.trim();
        setIsReplying(false);
        setReplyText('');
        try {
            const repliesCol = db.collection('videos')
                .doc(videoId)
                .collection('comments')
                .doc(comment.id)
                .collection('replies');
            
            await repliesCol.add({
                content: textToSubmit,
                authorId: currentUser.uid,
                authorName: currentUser.name || '',
                authorProfilePicUrl: currentUser.profilePicUrl || '',
                createdAt: serverTimestamp(),
                authorIsVerified: currentUser.isVerified || false
            });

            // Create notification for comment author
            if (currentUser.uid !== comment.authorId) {
                await db.collection('users')
                    .doc(comment.authorId)
                    .collection('notifications')
                    .add({
                        type: 'new_comment',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name || '',
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        fromUserIsVerified: currentUser.isVerified || false,
                        postId: videoId, // Use videoId for navigation
                        videoId: videoId,
                        postTitle: `your video comment: "${comment.content.substring(0, 20)}..."`,
                        commentText: textToSubmit.substring(0, 80),
                        createdAt: serverTimestamp(),
                        read: false
                    });
            }
            showToast("Reply posted!", "success");
        } catch (error) {
            console.error("Error submitting reply:", error);
            setLocalReplies(p => p.filter(r => r.id !== tempId));
            showToast("Failed to reply", "error");
        } finally {
            setIsSubmittingReply(false);
        }
    };

    const handleDeleteReply = async (replyId: string) => {
        if (!currentUser) return;
        if (window.confirm("Delete this reply?")) {
            try {
                await db.collection('videos')
                    .doc(videoId)
                    .collection('comments')
                    .doc(comment.id)
                    .collection('replies')
                    .doc(replyId)
                    .delete();
                showToast("Reply deleted", "success");
            } catch (error) {
                console.error("Error deleting reply:", error);
                showToast("Failed to delete reply", "error");
            }
        }
    };

    const authorProfilePic = (currentUser && currentUser.uid === comment.authorId)
        ? currentUser.profilePicUrl
        : (comment.authorProfilePicUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(comment.authorName)}`);

    return (
        <div 
            className={`flex gap-3 items-start justify-between py-2.5 px-2 group rounded-xl transition-all select-none ${comment.isPinned ? 'bg-red-50/25 border-l-2 border-red-500' : 'hover:bg-gray-50'}`}
            onTouchStart={handlePressStart}
            onTouchEnd={handlePressEnd}
            onMouseDown={handlePressStart}
            onMouseUp={handlePressEnd}
            onMouseLeave={handlePressEnd}
        >
            {/* Left: Avatar & Text */}
            <div className="flex gap-3 items-start flex-1 min-w-0">
                <UserAvatar
                    userId={comment.authorId}
                    src={comment.authorProfilePicUrl}
                    name={comment.authorName}
                    currentUser={currentUser}
                    onClick={(e) => {
                        e.stopPropagation();
                        onViewUser(comment.authorId);
                    }}
                    className="w-9 h-9 rounded-full object-cover cursor-pointer ring-1 ring-black/10 shrink-0"
                />
                <div className="flex flex-col min-w-0">
                    {comment.isPinned && (
                        <div className="flex items-center gap-1 text-red-600 font-extrabold text-[9px] uppercase tracking-wider mb-0.5">
                            <span className="material-symbols-outlined text-[10px] font-black" style={{ fontVariationSettings: "'FILL' 1" }}>push_pin</span>
                            Pinned by Author
                        </div>
                    )}
                    <div className="flex items-center gap-1.5 flex-wrap">
                        <span 
                            onClick={(e) => {
                                e.stopPropagation();
                                onViewUser(comment.authorId);
                            }}
                            className="font-bold text-gray-900 text-xs cursor-pointer hover:underline"
                        >
                            {comment.authorName.replace(/\s+/g, '_').toLowerCase()}
                        </span>
                        
                        {/* Render "Author" badge if comment author is video author */}
                        {comment.authorId === videoAuthorId && (
                            <span className="flex items-center gap-0.5 bg-red-600 text-white text-[8px] px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider shadow-sm">
                                <span className="material-symbols-outlined text-[9px]" style={{ fontVariationSettings: "'FILL' 1" }}>verified</span>
                                Author
                            </span>
                        )}

                        <span className="text-[10px] text-gray-400 font-semibold">{timeAgo}</span>
                        {comment.authorIsVerified && (
                            <span className="material-symbols-outlined text-blue-500 text-[10px] font-black shrink-0">verified</span>
                        )}
                    </div>
                    <p className="text-gray-800 text-xs font-normal mt-1 leading-relaxed break-words">
                        {comment.content}
                    </p>
                    {/* Reply button & replies list */}
                    <div className="flex flex-col mt-1.5 w-full">
                        <div className="flex items-center gap-4">
                            <button 
                                onClick={() => {
                                    if (!currentUser) {
                                        onLogin();
                                        return;
                                    }
                                    setIsReplying(!isReplying);
                                }}
                                className="text-[10px] text-gray-400 font-extrabold tracking-wide uppercase hover:text-gray-600 transition-colors"
                            >
                                {isReplying ? 'Cancel' : 'Reply'}
                            </button>
                            {displayReplies.length > 0 && (
                                <span className="text-[10px] text-gray-400 font-bold">
                                    {displayReplies.length} {displayReplies.length === 1 ? 'reply' : 'replies'}
                                </span>
                            )}
                        </div>

                        {/* Reply Input Box */}
                        {isReplying && (
                            <form onSubmit={handleReplySubmit} className="mt-2 flex gap-2 items-center w-full max-w-md">
                                <input
                                    type="text"
                                    value={replyText}
                                    onChange={(e) => setReplyText(e.target.value)}
                                    placeholder={`Reply to ${comment.authorName.replace(/\s+/g, '_').toLowerCase()}...`}
                                    className="flex-grow bg-gray-50 border border-gray-200 rounded-full py-1.5 px-3 text-[11px] font-medium text-gray-800 outline-none placeholder-gray-400 focus:border-red-500 focus:bg-white transition-all"
                                    autoFocus
                                />
                                <button
                                    type="submit"
                                    disabled={isSubmittingReply || !replyText.trim()}
                                    className="p-1 text-red-600 hover:text-red-500 disabled:opacity-30 transition-all flex items-center justify-center shrink-0"
                                >
                                    <span className="material-symbols-outlined text-lg">send</span>
                                </button>
                            </form>
                        )}

                        {/* Nested Replies List */}
                        {displayReplies.length > 0 && (
                            <div className="mt-2.5 space-y-2 pl-3 border-l-2 border-gray-100">
                                {displayReplies.map((reply) => (
                                    <VideoReplyItem
                                        key={reply.id}
                                        reply={reply}
                                        videoId={videoId}
                                        commentId={comment.id}
                                        currentUser={currentUser}
                                        isVideoAuthor={videoAuthorId === reply.authorId}
                                        onViewUser={onViewUser}
                                        showToast={showToast}
                                        onDeleteReply={handleDeleteReply}
                                        canDelete={!!currentUser && (currentUser.uid === reply.authorId || currentUser.uid === videoAuthorId)}
                                    />
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Right: Comment Like Button & Count */}
            <div className="flex flex-col items-center gap-0.5 select-none shrink-0 pl-2">
                <button 
                    onClick={handleLike}
                    className={`p-1 hover:scale-110 active:scale-95 transition-transform ${isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-400'}`}
                >
                    <span 
                        className="material-symbols-outlined text-sm font-black"
                        style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}` }}
                    >
                        favorite
                    </span>
                </button>
                {likeCount > 0 && (
                    <span className="text-[9px] text-gray-500 font-semibold">
                        {likeCount}
                    </span>
                )}
            </div>

            {/* Premium Long Press Option Menu for Video comments */}
            <AnimatePresence>
                {showOptionsModal && (
                    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[150] flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setShowOptionsModal(false)}>
                        <motion.div 
                            initial={{ y: "100%", opacity: 0.5 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: "100%", opacity: 0.5 }}
                            transition={{ type: "spring", damping: 25, stiffness: 220 }}
                            className="bg-white dark:bg-slate-900 w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50 dark:bg-slate-850">
                                <h4 className="text-sm font-black uppercase tracking-wider text-gray-500 flex items-center gap-2">
                                    <span className="material-symbols-outlined text-lg">movie</span>
                                    Comment Options
                                </h4>
                                <button onClick={() => setShowOptionsModal(false)} className="w-8 h-8 rounded-full bg-gray-200/50 hover:bg-gray-200 flex items-center justify-center text-gray-700">
                                    <span className="material-symbols-outlined text-lg">close</span>
                                </button>
                            </div>
                            <div className="p-3 space-y-1.5">
                                <button 
                                    onClick={handlePinComment}
                                    className="w-full flex items-center gap-3.5 px-4 py-3.5 text-sm font-bold text-gray-700 hover:bg-red-50 hover:text-red-600 rounded-2xl transition-all"
                                >
                                    <span className="material-symbols-outlined text-red-500">push_pin</span>
                                    {comment.isPinned ? 'Unpin this Comment' : 'Pin Comment to Top'}
                                </button>
                                <button 
                                    onClick={() => { setShowOptionsModal(false); onDeleteComment(comment.id || ''); }}
                                    className="w-full flex items-center gap-3.5 px-4 py-3.5 text-sm font-bold text-red-600 hover:bg-red-50 rounded-2xl transition-all"
                                >
                                    <span className="material-symbols-outlined text-red-600">delete</span>
                                    Delete Comment permanently
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
});

export default VideoCommentItem;
