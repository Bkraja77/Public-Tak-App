import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ReporterDetails, View } from '../types';
import { APP_LOGO_URL } from '../utils/constants';

interface ReporterIdCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  reporter: ReporterDetails | null;
  reportersList?: ReporterDetails[];
  onSelectReporter?: (reporter: ReporterDetails) => void;
  onNavigate?: (view: View, params?: any) => void;
  onApprove?: (reporter: ReporterDetails) => Promise<void> | void;
}

export const ReporterIdCardModal: React.FC<ReporterIdCardModalProps> = ({
  isOpen,
  onClose,
  reporter,
  reportersList = [],
  onSelectReporter,
  onNavigate,
  onApprove,
}) => {
  const [activeSide, setActiveSide] = useState<'both' | 'front' | 'back'>('both');
  const [approving, setApproving] = useState<boolean>(false);

  const frontCardRef = useRef<HTMLDivElement | null>(null);
  const backCardRef = useRef<HTMLDivElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  if (!isOpen || !reporter) return null;

  // Find index of current reporter in the list
  const currentIndex = reportersList.findIndex((r) => r.id === reporter.id || r.userId === reporter.userId);
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex >= 0 && currentIndex < reportersList.length - 1;

  const handlePrev = () => {
    if (hasPrev && onSelectReporter) {
      onSelectReporter(reportersList[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (hasNext && onSelectReporter) {
      onSelectReporter(reportersList[currentIndex + 1]);
    }
  };

  const handlePrint = async () => {
    try {
      if ((document as any).fonts && (document as any).fonts.ready) {
        await (document as any).fonts.ready;
      }
    } catch (_) {}
    window.print();
  };

  const handleApproveAction = async () => {
    if (!onApprove) return;
    setApproving(true);
    try {
      await onApprove(reporter);
    } finally {
      setApproving(false);
    }
  };

  const isApproved = reporter.status === 'approved';

  return (
    <AnimatePresence>
      <div className="id-card-modal-backdrop fixed inset-0 z-[120] flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto print:p-0 print:bg-transparent print:static">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: 'spring', duration: 0.3 }}
          className="id-card-modal-content bg-slate-900 border border-slate-700 text-white rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[96vh] print:max-h-none print:shadow-none print:border-0 print:bg-transparent print:overflow-visible"
        >
          {/* Header Bar */}
          <div className="id-card-no-print p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border-b border-slate-800 flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
                <span className="material-symbols-outlined text-2xl">badge</span>
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-blue-400 uppercase tracking-wider">
                    Digital Media ID Card Preview
                  </span>
                  <span
                    className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                      isApproved
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {isApproved ? 'Approved ✓' : 'Draft / Pending Review'}
                  </span>
                </div>
                <h3 className="text-lg font-black text-white mt-0.5 truncate max-w-sm sm:max-w-md">
                  {reporter.fullName}
                  <span className="text-xs font-mono font-normal text-slate-400 ml-2">
                    ({reporter.reporterIdNumber})
                  </span>
                </h3>
              </div>
            </div>

            {/* Top Controls & Close */}
            <div className="flex items-center gap-2">
              {/* Previous / Next buttons if in a list */}
              {reportersList.length > 1 && (
                <div className="flex items-center bg-slate-800 border border-slate-700 rounded-2xl p-1 text-xs">
                  <button
                    onClick={handlePrev}
                    disabled={!hasPrev}
                    className="p-1.5 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-transparent rounded-xl transition-colors"
                    title="पिछला रिपोर्टर (Previous)"
                  >
                    <span className="material-symbols-outlined text-base">chevron_left</span>
                  </button>
                  <span className="px-2 font-mono font-bold text-[11px] text-slate-300">
                    {currentIndex + 1} / {reportersList.length}
                  </span>
                  <button
                    onClick={handleNext}
                    disabled={!hasNext}
                    className="p-1.5 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-transparent rounded-xl transition-colors"
                    title="अगला रिपोर्टर (Next)"
                  >
                    <span className="material-symbols-outlined text-base">chevron_right</span>
                  </button>
                </div>
              )}

              <button
                onClick={onClose}
                className="w-9 h-9 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors border border-slate-700"
                title="Close Modal"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
          </div>

          {/* Sub-toolbar: Side Switcher & Action Buttons */}
          <div className="id-card-no-print px-4 py-2.5 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
            {/* View Side Segment */}
            <div className="flex bg-slate-800 p-1 rounded-xl border border-slate-700">
              <button
                onClick={() => setActiveSide('both')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeSide === 'both' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                दोनों साइड (Both)
              </button>
              <button
                onClick={() => setActiveSide('front')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeSide === 'front' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                आगे (Front)
              </button>
              <button
                onClick={() => setActiveSide('back')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeSide === 'back' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                पीछे (Back)
              </button>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 flex-wrap">
              {!isApproved && onApprove && (
                <button
                  onClick={handleApproveAction}
                  disabled={approving}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/30 transition-all disabled:opacity-50"
                >
                  {approving ? (
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <span className="material-symbols-outlined text-sm">verified</span>
                  )}
                  <span>Approve & Issue ID</span>
                </button>
              )}

              <button
                onClick={handlePrint}
                className="px-4 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black rounded-xl flex items-center gap-1.5 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
                title="Print ID Card (Front & Back)"
              >
                <span className="material-symbols-outlined text-sm">print</span>
                <span>ID Card प्रिंट करें</span>
              </button>

              {onNavigate && (
                <button
                  onClick={() => {
                    onClose();
                    onNavigate(View.ReporterIdCard, { reporterId: reporter.userId });
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-blue-300 font-bold rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
                  title="Open in Dedicated Full Page"
                >
                  <span className="material-symbols-outlined text-sm">open_in_new</span>
                  <span>Full Page</span>
                </button>
              )}
            </div>
          </div>

          {/* Cards Canvas Container */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-950 flex items-center justify-center">
            <div
              ref={containerRef}
              id="printable-id-card-sheet"
              className="printable-id-card-sheet p-4 sm:p-8 bg-slate-900 rounded-3xl border border-slate-800 shadow-inner flex flex-wrap items-center justify-center gap-8"
            >
              {/* ========================================================================= */}
              {/* CARD 1: FRONT SIDE (PREMIUM DIGITAL MEDIA IDENTITY CARD) */}
              {/* ========================================================================= */}
              <div
                ref={frontCardRef}
                className={`id-card-item w-[338px] h-[538px] bg-white rounded-3xl shadow-2xl border-2 border-slate-300 relative flex-col justify-between overflow-hidden text-gray-900 select-none font-sans shrink-0 ${
                  activeSide === 'back' ? 'hidden print:flex' : 'flex'
                }`}
                style={{
                  boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(0, 0, 0, 0.1)',
                  boxSizing: 'border-box',
                  WebkitPrintColorAdjust: 'exact',
                  printColorAdjust: 'exact',
                }}
              >
                  {/* Top Lanyard Slot Simulation */}
                  <div className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-2 bg-gray-300 rounded-full border border-gray-400 shadow-inner z-30 opacity-90"></div>

                  {/* Header */}
                  <div
                    className="pt-6 pb-2 px-3 text-white relative text-center flex flex-col items-center"
                    style={{
                      background: 'linear-gradient(180deg, #1e3a8a 0%, #172554 50%, #1e3a8a 100%)',
                      WebkitPrintColorAdjust: 'exact',
                      printColorAdjust: 'exact',
                    }}
                  >
                    {/* Holographic Top Stripe */}
                    <div
                      className="h-1.5 w-full rounded-full mb-2 shadow-sm"
                      style={{
                        background: 'linear-gradient(90deg, #fbbf24 0%, #fef08a 50%, #f59e0b 100%)',
                        WebkitPrintColorAdjust: 'exact',
                        printColorAdjust: 'exact',
                      }}
                    ></div>

                    {/* Logo & Header Titles */}
                    <div className="flex flex-col items-center justify-center text-center w-full">
                      <div className="flex items-center justify-center gap-2 mb-0.5">
                        <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-amber-300 shadow-md bg-white shrink-0 flex items-center justify-center">
                          <img
                            src={reporter.organizationLogo || APP_LOGO_URL}
                            alt="Logo"
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="text-center">
                          <h3
                            className="text-[12.5px] font-black uppercase tracking-wider text-amber-300 m-0 p-0 block text-center"
                            style={{ lineHeight: '15px' }}
                          >
                            PUBLIC TAK APP
                          </h3>
                          <h4
                            className="text-[13px] font-black uppercase tracking-wide text-white drop-shadow-sm truncate max-w-[200px] m-0 p-0 block mt-0.5 text-center"
                            style={{ lineHeight: '16px' }}
                          >
                            {reporter.organizationName || 'डिजिटल मीडिया नेटवर्क'}
                          </h4>
                        </div>
                      </div>

                      <p
                        className="text-[8.5px] text-blue-200 font-bold tracking-tight m-0 p-0 block text-center mt-0.5"
                        style={{ lineHeight: '12px' }}
                      >
                        पब्लिक तक डिजिटल मीडिया रिपोर्टर
                      </p>
                    </div>

                    {/* Red Digital Media Badge */}
                    <div className="mt-1.5 w-full bg-red-600 text-white text-center py-0.5 rounded-lg shadow-sm border border-red-400/40">
                      <span
                        className="text-[10px] font-black uppercase tracking-wider block m-0 p-0 text-center"
                        style={{ lineHeight: '14px' }}
                      >
                        DIGITAL MEDIA IDENTITY CARD
                      </span>
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="px-3.5 py-1.5 flex-1 flex flex-col justify-between relative overflow-hidden">
                    {/* Watermark */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                      <img src={APP_LOGO_URL} alt="Watermark" className="w-40 h-40 object-contain grayscale" />
                    </div>

                    {/* Photo & ID Badges */}
                    <div className="flex items-center justify-center gap-3 relative z-10 my-0.5">
                      <div className="w-24 h-32 rounded-2xl overflow-hidden border-2 border-blue-900 shadow-lg bg-gray-100 relative shrink-0">
                        <img
                          src={reporter.photoUrl || APP_LOGO_URL}
                          alt={reporter.fullName}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div
                          className="absolute bottom-0 inset-x-0 bg-blue-900/90 text-white text-[8px] font-black text-center py-0.5 uppercase tracking-wider"
                          style={{ lineHeight: '11px' }}
                        >
                          e-KYC VERIFIED
                        </div>
                      </div>

                      <div className="space-y-1.5 text-left flex-1 min-w-0">
                        <div className="bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-xl">
                          <span className="text-[8px] font-bold text-gray-500 uppercase block">Reporter ID:</span>
                          <span className="text-[11px] font-mono font-black text-blue-900 block truncate">
                            {reporter.reporterIdNumber}
                          </span>
                        </div>

                        <div className="bg-red-50 border border-red-200 px-2.5 py-1 rounded-xl">
                          <span className="text-[8px] font-bold text-gray-500 uppercase block">Blood Group:</span>
                          <span className="text-[11px] font-black text-red-700 block">
                            {reporter.bloodGroup || 'O+'}
                          </span>
                        </div>

                        <div className="bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-xl">
                          <span className="text-[8px] font-bold text-gray-500 uppercase block">Valid Till:</span>
                          <span className="text-[11px] font-mono font-black text-emerald-800 block">
                            {reporter.validTill || '2028-12-31'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Reporter Name & Designation */}
                    <div className="text-center relative z-10 my-0.5">
                      <h2
                        className="text-[15px] font-black text-gray-950 uppercase tracking-tight truncate px-2 m-0 p-0 block"
                        style={{ lineHeight: '19px' }}
                      >
                        {reporter.fullName}
                      </h2>
                      <div className="inline-block mt-0.5 px-3 py-0.5 bg-gradient-to-r from-blue-700 to-indigo-800 text-white text-[10px] font-black uppercase rounded-full shadow-sm">
                        <span className="block" style={{ lineHeight: '13px' }}>
                          {reporter.designation}
                        </span>
                      </div>
                    </div>

                    {/* Details Grid */}
                    <div className="bg-gray-50 border border-gray-200 rounded-xl p-2 space-y-1 relative z-10 text-[9.5px]">
                      <div className="flex justify-between items-center border-b border-gray-200/60 pb-0.5">
                        <span className="font-bold text-gray-500">Jurisdiction (क्षेत्र):</span>
                        <span className="font-extrabold text-gray-900 text-right truncate max-w-[160px]">
                          {reporter.district}, {reporter.state}
                        </span>
                      </div>

                      <div className="flex justify-between items-center border-b border-gray-200/60 pb-0.5">
                        <span className="font-bold text-gray-500">Beat / Category:</span>
                        <span className="font-extrabold text-gray-900 truncate max-w-[160px] text-right">
                          {reporter.beat}
                        </span>
                      </div>

                      <div className="flex justify-between items-center">
                        <span className="font-bold text-gray-500">Mobile / संपर्क:</span>
                        <span className="font-mono font-extrabold text-gray-900">{reporter.mobile}</span>
                      </div>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="px-3.5 py-1.5 bg-gradient-to-r from-slate-100 via-gray-50 to-slate-100 border-t border-gray-200 flex items-center justify-between">
                    {/* Reporter Signature */}
                    <div className="text-center">
                      <div className="h-5 w-18 flex items-center justify-center">
                        {reporter.signatureUrl ? (
                          <img src={reporter.signatureUrl} alt="Signature" className="max-h-full max-w-full object-contain" />
                        ) : (
                          <span className="font-serif italic text-[11px] font-bold text-blue-900">
                            {reporter.fullName.split(' ')[0]}
                          </span>
                        )}
                      </div>
                      <span className="text-[7.5px] font-black uppercase tracking-wider text-gray-500 border-t border-gray-300 pt-0.5 block">
                        Card Holder Sign
                      </span>
                    </div>

                    {/* Digital Seal */}
                    <div className="w-9 h-9 rounded-full border border-dashed border-red-600 bg-red-50 flex flex-col items-center justify-center text-red-700 shadow-sm leading-none p-0.5 text-center shrink-0">
                      <span className="text-[5.5px] font-black uppercase tracking-tighter">DIGITAL MEDIA</span>
                      <span className="material-symbols-outlined text-[11px]">verified</span>
                      <span className="text-[5.5px] font-black uppercase tracking-tighter">VERIFIED</span>
                    </div>

                    {/* Authorized Signatory */}
                    <div className="text-center">
                      <div className="h-5 w-20 flex items-center justify-center">
                        <span className="font-serif italic text-[11px] font-black text-indigo-900">Editor-in-Chief</span>
                      </div>
                      <span className="text-[7.5px] font-black uppercase tracking-wider text-gray-500 border-t border-gray-300 pt-0.5 block">
                        Authorized Signatory
                      </span>
                    </div>
                  </div>
                </div>

              {/* ========================================================================= */}
              {/* CARD 2: BACK SIDE (TERMS, QR CODE & AADHAAR e-KYC VERIFICATION) */}
              {/* ========================================================================= */}
              <div
                ref={backCardRef}
                className={`id-card-item w-[338px] h-[538px] bg-white rounded-3xl shadow-2xl border-2 border-slate-300 relative flex-col justify-between overflow-hidden text-gray-900 select-none font-sans shrink-0 ${
                  activeSide === 'front' ? 'hidden print:flex' : 'flex'
                }`}
                style={{
                  boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(0, 0, 0, 0.1)',
                  boxSizing: 'border-box',
                  WebkitPrintColorAdjust: 'exact',
                  printColorAdjust: 'exact',
                }}
              >
                {/* Top Lanyard Slot Simulation */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-2 bg-gray-300 rounded-full border border-gray-400 shadow-inner z-30 opacity-90"></div>

                {/* Header */}
                <div
                  className="pt-6 pb-2 px-3.5 text-white text-center id-card-back-header-gradient"
                  style={{
                    background: 'linear-gradient(180deg, #0f172a 0%, #111827 50%, #0f172a 100%)',
                    WebkitPrintColorAdjust: 'exact',
                    printColorAdjust: 'exact',
                  }}
                >
                  <div
                    className="h-1.5 w-full rounded-full mb-2 shadow-sm"
                    style={{
                      background: 'linear-gradient(90deg, #ef4444 0%, #fbbf24 50%, #ef4444 100%)',
                      WebkitPrintColorAdjust: 'exact',
                      printColorAdjust: 'exact',
                    }}
                  ></div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-amber-300 block m-0 p-0">
                    PUBLIC TAK APP
                  </h3>
                  <p className="text-[8.5px] text-gray-300 font-bold uppercase tracking-wider block m-0 p-0 mt-0.5">
                    Accreditation Terms & Emergency Contact
                  </p>
                </div>

                  {/* Back Content */}
                  <div className="px-3.5 py-1.5 flex-1 flex flex-col justify-between space-y-1.5 text-[9.5px]">
                    {/* Address & Personal Details */}
                    <div className="bg-gray-50 border border-gray-200 rounded-xl p-2.5 space-y-1">
                      <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                        <span className="font-bold text-gray-500">Father/Husband:</span>
                        <span className="font-extrabold text-gray-900">{reporter.fatherOrHusbandName}</span>
                      </div>

                      <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                        <span className="font-bold text-gray-500">Date of Birth:</span>
                        <span className="font-mono font-extrabold text-gray-900">{reporter.dob}</span>
                      </div>

                      <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                        <span className="font-bold text-gray-500">Aadhaar (Masked):</span>
                        <span className="font-mono font-extrabold text-emerald-700 flex items-center gap-1">
                          <span className="material-symbols-outlined text-[11px]">verified</span>
                          {reporter.aadhaarNumber}
                        </span>
                      </div>

                      <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                        <span className="font-bold text-gray-500">Emergency Phone:</span>
                        <span className="font-mono font-extrabold text-red-600">
                          {reporter.emergencyContact || reporter.mobile}
                        </span>
                      </div>

                      <div className="pt-0.5">
                        <span className="font-bold text-gray-500 block">Residential Address:</span>
                        <span className="font-medium text-gray-800 text-[9px] block mt-0.5 leading-snug">
                          {reporter.fullAddress} (PIN: {reporter.pincode})
                        </span>
                      </div>
                    </div>

                    {/* QR Code */}
                    <div className="flex items-center gap-2.5 bg-blue-50/80 border border-blue-200 p-2 rounded-xl">
                      <div className="w-14 h-14 bg-white p-0.5 rounded-lg border border-gray-300 shadow-sm flex-shrink-0 flex items-center justify-center">
                        <img
                          src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(
                            `https://publictak.app/?reporterVerify=${reporter.userId}&id=${reporter.reporterIdNumber}`
                          )}`}
                          alt="QR Code"
                          className="w-full h-full object-contain"
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <span className="bg-blue-600 text-white text-[7.5px] font-black uppercase px-2 py-0.5 rounded-full inline-block">
                          SCAN TO VERIFY
                        </span>
                        <p className="text-[8.5px] font-bold text-gray-900 mt-0.5">
                          स्कैन करके लाइव रिपोर्टर प्रोफाइल व सत्यापन देखें
                        </p>
                        <p className="text-[7.5px] font-mono text-gray-500 mt-0.5 truncate">
                          publictak.app/verify/{reporter.reporterIdNumber}
                        </p>
                      </div>
                    </div>

                    {/* Terms */}
                    <div className="bg-gray-50 p-2 rounded-xl border border-gray-200 text-[8px] text-gray-600 space-y-0.5">
                      <p className="font-bold text-gray-900 uppercase">
                        निर्देश व नियम (Terms & Instructions):
                      </p>
                      <p>
                        1. यह पहचान पत्र <b>Public Tak App</b> द्वारा डिजिटल समाचार संकलन एवं इलेक्ट्रॉनिक पत्रकारिता हेतु जारी किया गया है।
                      </p>
                      <p>
                        2. यह कार्ड अहस्तांतरणीय (Non-Transferable) है और डिजिटल मीडिया आचार संहिता के अनुपालन हेतु बाध्यकारी है।
                      </p>
                      <p>
                        3. कार्ड खोने या पूछताछ के संदर्भ में तुरंत <b>support@publictak.app</b> पर संपर्क करें।
                      </p>
                    </div>
                  </div>

                  {/* Back Footer */}
                  <div className="px-3.5 py-1.5 bg-gray-900 text-white text-center text-[8.5px] font-medium flex items-center justify-between">
                    <span>Public Tak App</span>
                    <span className="text-amber-400 font-bold">www.publictak.app</span>
                    <span>Govt. Reg. Digital Media</span>
                  </div>
                </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ReporterIdCardModal;
