import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Video } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface SuggestedReelsProps {
  videos: Video[];
  onPlayVideo: (videoId: string) => void;
  currentVideoId?: string;
}

const SuggestedReels: React.FC<SuggestedReelsProps> = ({
  videos,
  onPlayVideo,
  currentVideoId,
}) => {
  const { language } = useLanguage();
  const isHindi = language === 'hi';

  const [suggested, setSuggested] = useState<Video[]>([]);
  const [hiddenVideoIds, setHiddenVideoIds] = useState<string[]>([]);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const texts = {
    suggestedReels: isHindi ? 'सुझाए गए न्यूज़' : 'Suggest News',
    moreVideos: isHindi ? 'और वीडियो देखें' : 'Watch more videos',
  };

  useEffect(() => {
    if (!videos || videos.length === 0) return;

    // Filter out the active video to avoid suggesting the same one
    const eligibleVideos = videos.filter(v => v.id !== currentVideoId);

    if (eligibleVideos.length === 0) return;

    // Shuffle and pick exactly 7 random videos
    const shuffle = <T,>(array: T[]): T[] => {
      const arr = [...array];
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    };

    const shuffled = shuffle(eligibleVideos);
    setSuggested(shuffled.slice(0, 7));
    // Reset hidden list on mount/refresh
    setHiddenVideoIds([]);
    setActiveMenuId(null);
  }, [videos, currentVideoId]);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 280;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  const handleHideVideo = (id: string) => {
    setHiddenVideoIds((prev) => [...prev, id]);
    setActiveMenuId(null);
  };

  const handleUnhideVideo = (id: string) => {
    setHiddenVideoIds((prev) => prev.filter((itemId) => itemId !== id));
  };

  if (suggested.length === 0) {
    return null;
  }

  return (
    <div className="w-full bg-white py-5 border-y border-gray-150 my-4 relative group/reels-carousel">
      {/* Header Row */}
      <div className="flex justify-between items-center px-4 mb-4">
        <h3 className="text-sm font-extrabold text-gray-900 tracking-tight flex items-center gap-1.5 uppercase">
          <span className="w-1.5 h-4 bg-red-600 rounded-full"></span>
          {texts.suggestedReels}
        </h3>
        <div className="flex items-center gap-2">
          <span className="material-symbols-outlined text-gray-500 cursor-pointer hover:text-gray-900 transition-colors">
            more_vert
          </span>
        </div>
      </div>

      {/* Carousel Wrapper */}
      <div className="relative w-full">
        {/* Left Scroll Button */}
        <button
          onClick={() => handleScroll('left')}
          className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-gray-200 flex items-center justify-center shadow-md hover:bg-white hover:scale-110 active:scale-95 text-gray-800 transition-all opacity-0 group-hover/reels-carousel:opacity-100 hidden md:flex"
        >
          <span className="material-symbols-outlined text-lg">chevron_left</span>
        </button>

        {/* Right Scroll Button */}
        <button
          onClick={() => handleScroll('right')}
          className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-gray-200 flex items-center justify-center shadow-md hover:bg-white hover:scale-110 active:scale-95 text-gray-800 transition-all opacity-0 group-hover/reels-carousel:opacity-100 hidden md:flex"
        >
          <span className="material-symbols-outlined text-lg">chevron_right</span>
        </button>

        {/* Horizontal scroll container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-3 overflow-x-auto px-4 pb-2 scroll-smooth scrollbar-hide snap-x snap-mandatory"
        >
          {suggested.map((video) => {
            const isHidden = hiddenVideoIds.includes(video.id);
            const isMenuOpen = activeMenuId === video.id;

            if (isHidden) {
              return (
                <motion.div
                  key={`suggested-reel-hidden-${video.id}`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex-shrink-0 w-[140px] xs:w-[150px] aspect-[9/16] bg-gray-50 rounded-3xl overflow-hidden relative border border-dashed border-gray-300 flex flex-col items-center justify-center p-3 text-center transition-all snap-start shadow-inner"
                >
                  <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mb-2">
                    <span className="material-symbols-outlined text-gray-500 text-lg">visibility_off</span>
                  </div>
                  <p className="text-[11px] font-bold text-gray-600 mb-3.5 leading-tight">
                    {isHindi ? 'वीडियो छिपाया गया' : 'Video Hidden'}
                  </p>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUnhideVideo(video.id);
                    }}
                    className="flex items-center justify-center gap-1 px-3 py-1.5 rounded-full bg-gray-900 hover:bg-gray-800 text-white text-[10px] font-black transition-all shadow-sm active:scale-95"
                  >
                    <span className="material-symbols-outlined text-xs">visibility</span>
                    {isHindi ? 'दिखाएं' : 'Unhide'}
                  </button>
                </motion.div>
              );
            }

            return (
              <motion.div
                key={`suggested-reel-${video.id}`}
                whileTap={{ scale: 0.97 }}
                onClick={() => onPlayVideo(video.id)}
                className="flex-shrink-0 w-[140px] xs:w-[150px] aspect-[9/16] bg-slate-900 rounded-3xl overflow-hidden relative border border-gray-100 hover:border-gray-300 transition-all cursor-pointer shadow-md group/item snap-start"
              >
                {/* Autoplay Muted Video Preview */}
                <video
                  src={video.videoUrl}
                  poster={video.thumbnailUrl}
                  muted
                  loop
                  playsInline
                  autoPlay
                  className="w-full h-full object-cover transition-transform duration-500 group-hover/item:scale-105 pointer-events-none"
                />

                {/* Top translucent title overlay/pill if video has description/title */}
                <div className="absolute top-3 left-3 right-3 z-10">
                  <div className="bg-black/45 backdrop-blur-md px-2 py-1 rounded-lg border border-white/5 inline-block max-w-full">
                    <p className="text-[10px] md:text-[11px] font-semibold text-white truncate text-left select-none">
                      {video.title}
                    </p>
                  </div>
                </div>

                {/* Three dots indicator on top-right */}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenuId(isMenuOpen ? null : video.id);
                  }}
                  className="absolute top-3 right-3 z-25 p-1 rounded-full bg-black/30 hover:bg-black/60 text-white/90 transition-all opacity-100 md:opacity-0 md:group-hover/item:opacity-100"
                >
                  <span className="material-symbols-outlined text-sm font-semibold">more_vert</span>
                </button>

                {/* Popover overlay menu for 3 dots */}
                {isMenuOpen && (
                  <div 
                    className="absolute inset-0 bg-black/75 backdrop-blur-xs z-30 flex flex-col justify-end p-2.5"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuId(null);
                    }}
                  >
                    <div className="bg-slate-900/95 backdrop-blur-md rounded-2xl p-1.5 border border-white/10 space-y-1 shadow-xl animate-in fade-in zoom-in-95 duration-150">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleHideVideo(video.id);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-left text-red-400 hover:bg-white/5 active:bg-white/10 transition-all text-[11px] font-bold"
                      >
                        <span className="material-symbols-outlined text-xs">visibility_off</span>
                        {isHindi ? 'छिपाएं' : 'Hide'}
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveMenuId(null);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-xl text-left text-white/70 hover:bg-white/5 active:bg-white/10 transition-all text-[10px] font-medium"
                      >
                        <span className="material-symbols-outlined text-xs">close</span>
                        {isHindi ? 'रद्द' : 'Cancel'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Bottom details (gradient overlay + author) */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent p-3 flex flex-col justify-end">
                  <div className="flex items-center gap-1.5">
                    <img
                      src={video.authorProfilePicUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                      alt={video.authorName}
                      className="w-5 h-5 rounded-full object-cover border border-white/20"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[10px] font-bold text-white/90 truncate">
                        @{video.authorName.toLowerCase().replace(/\s+/g, '')}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SuggestedReels;
