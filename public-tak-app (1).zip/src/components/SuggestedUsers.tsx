import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { db } from '../firebaseConfig';
import { User } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import UserAvatar from './UserAvatar';

interface SuggestedUsersProps {
  currentUser: User | null;
  followingList: string[];
  handleFollowToggle: (targetUserId: string, targetUserName: string, targetUserProfilePicUrl: string) => Promise<void>;
  onViewUser: (userId: string) => void;
  onLogin: () => void;
}

const SuggestedUsers: React.FC<SuggestedUsersProps> = ({
  currentUser,
  followingList,
  handleFollowToggle,
  onViewUser,
  onLogin,
}) => {
  const { language } = useLanguage();
  const isHindi = language === 'hi';

  const [suggestedUsers, setSuggestedUsers] = useState<User[]>([]);
  const [popularUsers, setPopularUsers] = useState<User[]>([]);
  const [followerIds, setFollowerIds] = useState<Set<string>>(new Set());
  const [dismissedUserIds, setDismissedUserIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState<boolean>(true);
  const [showAllModal, setShowAllModal] = useState<boolean>(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Fetch current user's followers to know if we can "Follow Back"
  useEffect(() => {
    if (!currentUser) {
      setFollowerIds(new Set());
      return;
    }
    const unsubscribe = db
      .collection('users')
      .doc(currentUser.uid)
      .collection('followers')
      .onSnapshot(
        (snapshot) => {
          setFollowerIds(new Set(snapshot.docs.map((doc) => doc.id)));
        },
        (error) => {
          console.warn('Error listening to user followers in SuggestedUsers:', error);
        }
      );
    return () => unsubscribe();
  }, [currentUser?.uid]);

  // Localization Dictionary
  const texts = {
    suggestedForYou: isHindi ? 'आपके लिए सुझाव' : 'Suggested for you',
    seeAll: isHindi ? 'सभी देखें' : 'See all',
    follow: isHindi ? 'फ़ॉलो करें' : 'Follow',
    following: isHindi ? 'फ़ॉलो किया' : 'Following',
    mutual: isHindi ? '1 कॉमन फ़ॉलोअर' : '1 mutual',
    suggestedSub: isHindi ? 'आपके लिए सुझाव' : 'Suggested for you',
    popularReporter: isHindi ? 'लोकप्रिय पत्रकार' : 'Popular reporter',
    localReporter: isHindi ? 'स्थानीय पत्रकार' : 'Local reporter',
    discoverPeople: isHindi ? 'लोगों को खोजें' : 'Discover people',
    popularAccounts: isHindi ? 'लोकप्रिय खाते' : 'Popular accounts',
    followBack: isHindi ? 'वापस फ़ॉलो करें' : 'Follow back',
    moreSuggestions: isHindi ? 'और अधिक सुझाव' : 'More suggestions',
    noMoreSuggestions: isHindi ? 'कोई और सुझाव नहीं है।' : 'No more suggestions available.',
  };

  // Helper to get realistic subtitle for suggestions
  const getSubText = (user: User, index: number): string => {
    if (currentUser) {
      if (user.preferredState && user.preferredState === currentUser.preferredState) {
        return texts.localReporter;
      }
    }
    if (user.isVerified) {
      return texts.popularReporter;
    }
    const types = [texts.suggestedSub, texts.mutual, texts.popularReporter];
    return types[index % types.length];
  };

  useEffect(() => {
    let isMounted = true;

    const fetchSuggestions = async () => {
      setLoading(true);
      try {
        // Fetch users from db once using get() instead of onSnapshot for stability
        const snapshot = await db.collection('users').limit(100).get();
        if (!isMounted) return;

        const fetchedUsers = snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            uid: doc.id,
            name: data.name || '',
            username: data.username || '',
            bio: data.bio || '',
            profilePicUrl: data.profilePicUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
            role: data.role || 'user',
            isVerified: data.isVerified || false,
            followerCount: data.followerCount || 0,
            preferredState: data.preferredState || '',
            preferredDistrict: data.preferredDistrict || '',
            preferredBlock: data.preferredBlock || '',
          } as User;
        });

        // Filter out current user and already followed users on initial load
        const filtered = fetchedUsers.filter((user) => {
          if (currentUser && user.uid === currentUser.uid) return false;
          return !followingList.includes(user.uid);
        });

        // Shuffle helper function to randomize user listings on every refresh
        const shuffle = <T,>(array: T[]): T[] => {
          const arr = [...array];
          for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
          }
          return arr;
        };

        const randomizedFiltered = shuffle(filtered);
        const verifiedUsers = fetchedUsers.filter(u => u.isVerified && (!currentUser || u.uid !== currentUser.uid));
        const randomizedPopular = shuffle(verifiedUsers);

        // Split into "suggested" and "popular" for rich sections in Discover page
        setSuggestedUsers(randomizedFiltered.slice(0, 20));
        setPopularUsers(randomizedPopular.slice(0, 15));
        setLoading(false);
      } catch (error) {
        console.error('Error fetching suggestions:', error);
        if (isMounted) setLoading(false);
      }
    };

    fetchSuggestions();
    return () => {
      isMounted = false;
    };
  }, [currentUser?.uid]);

  // Handle mobile bottom/physical back button press to close the modal
  useEffect(() => {
    if (!showAllModal) return;

    // Push state when opened
    window.history.pushState({ modal: 'discover-people' }, '');

    const handlePopState = (event: PopStateEvent) => {
      setShowAllModal(false);
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      // Clean up the history state if the modal is closed by UI button click
      if (window.history.state?.modal === 'discover-people') {
        window.history.back();
      }
    };
  }, [showAllModal]);

  const handleDismissUser = (e: React.MouseEvent, uid: string) => {
    e.stopPropagation();
    setDismissedUserIds((prev) => {
      const updated = new Set(prev);
      updated.add(uid);
      return updated;
    });
  };

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 300;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  // Filter out dismissed suggestions and already followed users dynamically in real time
  const activeSuggestions = suggestedUsers.filter(u => !dismissedUserIds.has(u.uid) && !followingList.includes(u.uid));

  // Filter out popular users who are already followed
  const activePopularUsers = popularUsers.filter(u => !followingList.includes(u.uid));

  if (loading) {
    return (
      <div className="w-full bg-white py-6 border-y border-gray-100/80 my-4 animate-pulse">
        <div className="flex justify-between items-center px-4 mb-4">
          <div className="h-5 bg-gray-200 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 rounded w-12"></div>
        </div>
        <div className="flex gap-4 overflow-x-auto px-4 scrollbar-hide">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex-shrink-0 w-[150px] h-[200px] bg-gray-100 rounded-2xl border border-gray-100"></div>
          ))}
        </div>
      </div>
    );
  }

  if (activeSuggestions.length === 0) {
    return null; // Return nothing if no suggestions are available
  }

  return (
    <div className="w-full bg-gradient-to-r from-red-50/20 via-white to-red-50/10 py-6 border-y border-red-100/40 my-4 relative group/carousel">
      {/* Header Row */}
      <div className="flex justify-between items-center px-4 mb-4">
        <h3 className="text-[15px] font-extrabold text-gray-900 tracking-tight flex items-center gap-1.5">
          <span className="w-1.5 h-4 bg-red-600 rounded-full"></span>
          {texts.suggestedForYou}
        </h3>
        <button
          onClick={() => setShowAllModal(true)}
          className="text-xs font-black text-red-600 hover:text-red-700 bg-red-50 px-3 py-1.5 rounded-full transition-all active:scale-95"
        >
          {texts.seeAll}
        </button>
      </div>

      {/* Carousel Wrapper */}
      <div className="relative w-full">
        {/* Left Arrow Button (Desktop hover only) */}
        <button
          onClick={() => handleScroll('left')}
          className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-gray-100 flex items-center justify-center shadow-md hover:bg-white hover:scale-110 active:scale-95 text-gray-700 transition-all opacity-0 group-hover/carousel:opacity-100 hidden md:flex"
        >
          <span className="material-symbols-outlined text-xl">chevron_left</span>
        </button>

        {/* Right Arrow Button (Desktop hover only) */}
        <button
          onClick={() => handleScroll('right')}
          className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm border border-gray-100 flex items-center justify-center shadow-md hover:bg-white hover:scale-110 active:scale-95 text-gray-700 transition-all opacity-0 group-hover/carousel:opacity-100 hidden md:flex"
        >
          <span className="material-symbols-outlined text-xl">chevron_right</span>
        </button>

        {/* Horizontal scroll container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-3.5 overflow-x-auto px-4 pb-2 scroll-smooth scrollbar-hide"
        >
          <AnimatePresence initial={false}>
            {activeSuggestions.slice(0, 20).map((user, idx) => {
              const isFollowing = followingList.includes(user.uid);
              return (
                <motion.div
                  key={user.uid}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.25 }}
                  className="flex-shrink-0 w-[160px] bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow relative p-4 flex flex-col items-center justify-between text-center group"
                >
                  {/* Close button */}
                  <button
                    onClick={(e) => handleDismissUser(e, user.uid)}
                    className="absolute top-2 right-2 p-1 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100/80 transition-all opacity-100 md:opacity-0 md:group-hover:opacity-100"
                  >
                    <span className="material-symbols-outlined text-base">close</span>
                  </button>

                  {/* Profile Pic Clickable */}
                  <div 
                    onClick={() => onViewUser(user.uid)}
                    className="cursor-pointer relative mt-1 flex flex-col items-center"
                  >
                    <div className="w-[76px] h-[76px] rounded-full p-[3px] bg-gradient-to-tr from-red-600 via-pink-500 to-amber-400">
                      <UserAvatar
                        userId={user.uid}
                        src={user.profilePicUrl}
                        name={user.name}
                        currentUser={currentUser}
                        className="w-full h-full rounded-full object-cover border-2 border-white bg-gray-50"
                      />
                    </div>
                    {user.isVerified && (
                      <span className="material-symbols-outlined text-blue-500 text-[15px] absolute bottom-10 right-0 bg-white rounded-full p-0.5 shadow-sm border border-gray-100 select-none flex items-center justify-center" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">
                        verified
                      </span>
                    )}

                    {/* Name & Handle */}
                    <h4 className="font-extrabold text-[13px] text-gray-900 mt-3 truncate max-w-[130px] line-clamp-1 hover:text-red-600 transition-colors flex items-center justify-center gap-1">
                      <span className="truncate">{user.name}</span>
                      {user.isVerified && (
                        <span className="material-symbols-outlined text-blue-500 text-[14px] shrink-0" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                      )}
                    </h4>
                    <p className="text-[10px] text-gray-400 truncate max-w-[130px] font-medium leading-none mt-1">
                      @{user.username}
                    </p>
                  </div>

                  {/* Subtitle context (Mutual/Location/Popular) */}
                  <p className="text-[10.5px] font-bold text-gray-500 mt-2 mb-3 bg-gray-50 px-2 py-0.5 rounded-full border border-gray-100/50 max-w-full truncate">
                    {getSubText(user, idx)}
                  </p>

                  {/* Follow / Follow Back button */}
                  <button
                    onClick={() => {
                      if (!currentUser) {
                        onLogin();
                      } else {
                        handleFollowToggle(user.uid, user.name, user.profilePicUrl);
                      }
                    }}
                    className={`w-full py-1.5 px-3 rounded-xl text-xs font-black transition-all active:scale-95 shadow-sm border flex items-center justify-center gap-1 ${
                      isFollowing
                        ? 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-200'
                        : followerIds.has(user.uid)
                          ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white border-blue-500 animate-follow-back-blink shadow-md shadow-blue-500/30'
                          : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border-red-500 animate-follow-blink shadow-md shadow-red-500/30'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <span className="material-symbols-outlined text-[13px] font-bold">done</span>
                        <span>{texts.following}</span>
                      </>
                    ) : followerIds.has(user.uid) ? (
                      <>
                        <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                        <span>{texts.followBack}</span>
                      </>
                    ) : (
                      <>
                        <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                        <span>{texts.follow}</span>
                      </>
                    )}
                  </button>
                </motion.div>
              );
            })}

            {/* See All Card at the end */}
            <motion.div
              layout
              className="flex-shrink-0 w-[140px] bg-gray-50/50 rounded-2xl border border-dashed border-gray-200 flex flex-col items-center justify-center p-4 text-center cursor-pointer hover:bg-red-50/20 hover:border-red-200 transition-all group"
              onClick={() => setShowAllModal(true)}
            >
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-2xl font-bold">arrow_forward</span>
              </div>
              <p className="text-xs font-extrabold text-gray-800 leading-tight">
                {texts.seeAll}
              </p>
              <p className="text-[10px] text-gray-400 font-bold mt-1 uppercase tracking-wide">
                {texts.discoverPeople}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Discover People Full Screen Modal Overlay */}
      <AnimatePresence>
        {showAllModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-md flex items-center justify-center p-0 md:p-4"
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="bg-white w-full h-full md:max-w-xl md:h-[90vh] md:rounded-3xl shadow-2xl overflow-hidden flex flex-col"
            >
              {/* Modal Header */}
              <div className="flex items-center px-4 py-4 border-b border-gray-100 flex-shrink-0">
                <button
                  onClick={() => setShowAllModal(false)}
                  className="p-2 -ml-2 rounded-full text-gray-700 hover:bg-gray-100 transition-all"
                >
                  <span className="material-symbols-outlined font-black">arrow_back</span>
                </button>
                <h2 className="text-lg font-black text-gray-900 ml-2">
                  {texts.discoverPeople}
                </h2>
              </div>

              {/* Modal Content Scrollable Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide pb-32">
                {/* 1. Suggested For You Vertical Section */}
                <div>
                  <h3 className="text-sm font-black text-gray-900 mb-3 uppercase tracking-wider text-gray-400">
                    {texts.suggestedForYou}
                  </h3>
                  <div className="space-y-3.5">
                    {activeSuggestions.length > 0 ? (
                      activeSuggestions.map((user, idx) => {
                        const isFollowing = followingList.includes(user.uid);
                        return (
                          <div
                            key={user.uid}
                            className="flex items-center justify-between gap-3 p-2 rounded-2xl hover:bg-gray-50 transition-all"
                          >
                            <div
                              onClick={() => {
                                setShowAllModal(false);
                                onViewUser(user.uid);
                              }}
                              className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                            >
                              <UserAvatar
                                userId={user.uid}
                                src={user.profilePicUrl}
                                name={user.name}
                                currentUser={currentUser}
                                className="w-12 h-12 rounded-full object-cover border border-gray-100"
                              />
                              <div className="min-w-0">
                                <h4 className="font-extrabold text-sm text-gray-900 truncate flex items-center gap-1">
                                  <span className="truncate">{user.name}</span>
                                  {user.isVerified && (
                                    <span className="material-symbols-outlined text-blue-500 text-sm shrink-0" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                                  )}
                                </h4>
                                <p className="text-xs text-gray-500 truncate leading-none mt-0.5">@{user.username}</p>
                                <p className="text-[10px] text-gray-400 font-bold mt-1">{getSubText(user, idx)}</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => {
                                  if (!currentUser) {
                                    setShowAllModal(false);
                                    onLogin();
                                  } else {
                                    handleFollowToggle(user.uid, user.name, user.profilePicUrl);
                                  }
                                }}
                                className={`py-1.5 px-3.5 rounded-xl text-xs font-black transition-all active:scale-95 shadow-sm border flex items-center gap-1 ${
                                  isFollowing
                                    ? 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-200'
                                    : followerIds.has(user.uid)
                                      ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white border-blue-500 animate-follow-back-blink shadow-md shadow-blue-500/30'
                                      : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border-red-500 animate-follow-blink shadow-md shadow-red-500/30'
                                }`}
                              >
                                {isFollowing ? (
                                  <>
                                    <span className="material-symbols-outlined text-[13px] font-bold">done</span>
                                    <span>{texts.following}</span>
                                  </>
                                ) : followerIds.has(user.uid) ? (
                                  <>
                                    <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                                    <span>{texts.followBack}</span>
                                  </>
                                ) : (
                                  <>
                                    <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                                    <span>{texts.follow}</span>
                                  </>
                                )}
                              </button>
                              <button
                                onClick={(e) => handleDismissUser(e, user.uid)}
                                className="p-1 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-all"
                              >
                                <span className="material-symbols-outlined text-base">close</span>
                              </button>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <p className="text-xs text-gray-400 text-center py-4">{texts.noMoreSuggestions}</p>
                    )}
                  </div>
                </div>

                {/* 2. Popular Accounts Section (If any) */}
                {activePopularUsers.length > 0 && (
                  <div className="pt-4 border-t border-gray-50">
                    <h3 className="text-sm font-black text-gray-900 mb-3 uppercase tracking-wider text-gray-400">
                      {texts.popularAccounts}
                    </h3>
                    <div className="space-y-3.5">
                      {activePopularUsers.map((user, idx) => {
                        const isFollowing = followingList.includes(user.uid);
                        return (
                          <div
                            key={`popular-${user.uid}`}
                            className="flex items-center justify-between gap-3 p-2 rounded-2xl hover:bg-gray-50 transition-all"
                          >
                            <div
                              onClick={() => {
                                setShowAllModal(false);
                                onViewUser(user.uid);
                              }}
                              className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                            >
                              <UserAvatar
                                userId={user.uid}
                                src={user.profilePicUrl}
                                name={user.name}
                                currentUser={currentUser}
                                className="w-12 h-12 rounded-full object-cover border border-gray-100"
                              />
                              <div className="min-w-0">
                                <h4 className="font-extrabold text-sm text-gray-900 truncate flex items-center gap-1">
                                  <span className="truncate">{user.name}</span>
                                  <span className="material-symbols-outlined text-blue-500 text-sm shrink-0" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                                </h4>
                                <p className="text-xs text-gray-500 truncate leading-none mt-0.5">@{user.username}</p>
                                <p className="text-[10px] text-gray-400 font-bold mt-1">{texts.popularReporter}</p>
                              </div>
                            </div>

                            <button
                              onClick={() => {
                                if (!currentUser) {
                                  setShowAllModal(false);
                                  onLogin();
                                } else {
                                  handleFollowToggle(user.uid, user.name, user.profilePicUrl);
                                }
                              }}
                              className={`py-1.5 px-3.5 rounded-xl text-xs font-black transition-all active:scale-95 shadow-sm border flex items-center gap-1 ${
                                isFollowing
                                  ? 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-200'
                                  : followerIds.has(user.uid)
                                    ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white border-blue-500 animate-follow-back-blink shadow-md shadow-blue-500/30'
                                    : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border-red-500 animate-follow-blink shadow-md shadow-red-500/30'
                              }`}
                            >
                              {isFollowing ? (
                                <>
                                  <span className="material-symbols-outlined text-[13px] font-bold">done</span>
                                  <span>{texts.following}</span>
                                </>
                              ) : followerIds.has(user.uid) ? (
                                <>
                                  <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                                  <span>{texts.followBack}</span>
                                </>
                              ) : (
                                <>
                                  <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                                  <span>{texts.follow}</span>
                                </>
                              )}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SuggestedUsers;
