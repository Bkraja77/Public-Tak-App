
import React, { useState } from 'react';
import { Post, Video, User } from '../types';
import { db, serverTimestamp } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';

interface ReportModalProps {
    post?: Post;
    video?: Video;
    user: User;
    onClose: () => void;
    onSuccess: () => void;
}

const REPORT_REASONS = [
    { label: 'भ्रामक या फर्जी खबर (Fake / Misleading News)', value: 'भ्रामक या फर्जी खबर (Fake / Misleading News)' },
    { label: 'आपत्तिजनक या अभद्र भाषा (Abusive / Hate Speech)', value: 'आपत्तिजनक या अभद्र भाषा (Abusive / Hate Speech)' },
    { label: 'हिंसा या खतरनाक सामग्री (Violence / Harmful Content)', value: 'हिंसा या खतरनाक सामग्री (Violence / Harmful Content)' },
    { label: 'कॉपीराइट या साहित्यिक चोरी (Copyright Infringement)', value: 'कॉपीराइट या साहित्यिक चोरी (Copyright Infringement)' },
    { label: 'स्पैम या धोखाधड़ी (Spam / Scam)', value: 'स्पैम या धोखाधड़ी (Spam / Scam)' },
    { label: 'अन्य कारण (Other Reason)', value: 'अन्य कारण (Other Reason)' },
];

const ReportModal: React.FC<ReportModalProps> = ({ post, video, user, onClose, onSuccess }) => {
    const [selectedCategory, setSelectedCategory] = useState<string>(REPORT_REASONS[0].value);
    const [customDetails, setCustomDetails] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { showToast } = useToast();

    const targetTitle = post ? post.title : (video ? video.title : '');
    const targetId = post ? post.id : (video ? video.id : '');
    const contentType = post ? 'post' : 'video';
    const targetThumbnail = post ? post.thumbnailUrl : (video ? (video.thumbnailUrl || '') : '');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        const combinedReason = customDetails.trim() 
            ? `${selectedCategory} - ${customDetails.trim()}`
            : selectedCategory;

        if (!combinedReason.trim()) {
            showToast("कृपया रिपोर्ट का कारण बताएं। (Please select or provide a reason)", "error");
            return;
        }

        setIsSubmitting(true);
        try {
            // 1. Resolve authorId and authorName (check props first, then DB fallback)
            let authorId = post?.authorId || (post as any)?.userId || video?.authorId || (video as any)?.userId || '';
            let authorName = post?.authorName || (post as any)?.author || video?.authorName || (video as any)?.userName || '';
            let resolvedThumbnail = targetThumbnail;
            let resolvedTitle = targetTitle;

            if ((!authorId || !resolvedTitle) && targetId) {
                try {
                    const colName = contentType === 'video' ? 'videos' : 'posts';
                    const docSnap = await db.collection(colName).doc(targetId).get();
                    if (docSnap.exists) {
                        const data = docSnap.data();
                        authorId = authorId || data?.authorId || data?.userId || '';
                        authorName = authorName || data?.authorName || data?.author || data?.userName || '';
                        resolvedTitle = resolvedTitle || data?.title || 'शीर्षकहीन सामग्री';
                        resolvedThumbnail = resolvedThumbnail || data?.thumbnailUrl || '';
                    }
                } catch (fetchErr) {
                    console.warn("Could not query post document for authorId:", fetchErr);
                }
            }

            // 2. Add entry to global 'reports' collection for Admins
            await db.collection("reports").add({
                postId: targetId,
                postTitle: resolvedTitle,
                contentType: contentType,
                thumbnailUrl: resolvedThumbnail || '',
                reporterId: user.uid,
                reporterName: user.name || 'पब्लिक यूजर',
                reporterProfilePicUrl: user.profilePicUrl || '',
                authorId: authorId || '',
                authorName: authorName || '',
                reason: combinedReason,
                category: selectedCategory,
                details: customDetails.trim(),
                status: 'pending',
                createdAt: serverTimestamp(),
            });

            // 3. Immediately send Report Notification to the author whose post/video was reported
            if (authorId) {
                try {
                    await db.collection('users').doc(authorId).collection('notifications').add({
                        type: 'post_reported',
                        title: '⚠️ आपकी पोस्ट रिपोर्ट की गई / Post Reported',
                        body: `आपकी पोस्ट "${resolvedTitle}" को किसी यूजर द्वारा रिपोर्ट किया गया है। कारण: "${combinedReason}". एडमिन व मॉडरेशन टीम इसकी समीक्षा कर रही है।`,
                        fromUserId: user.uid,
                        fromUserName: user.name || 'एक पाठक/यूजर',
                        fromUserProfilePicUrl: user.profilePicUrl || '',
                        fromUserIsVerified: !!user.isVerified,
                        postId: contentType === 'post' ? targetId : undefined,
                        videoId: contentType === 'video' ? targetId : undefined,
                        postTitle: resolvedTitle,
                        postThumbnailUrl: resolvedThumbnail || '',
                        thumbnailUrl: resolvedThumbnail || '',
                        postType: contentType,
                        contentType: contentType,
                        reportReason: combinedReason,
                        read: false,
                        createdAt: serverTimestamp(),
                    });
                } catch (notifErr) {
                    console.error("Error sending notification to post author:", notifErr);
                }
            }

            showToast("रिपोर्ट सफलतापूर्वक दर्ज की गई और संबंधित यूजर को सूचित कर दिया गया है।", "success");
            onSuccess();
        } catch (error) {
            console.error("Error submitting report:", error);
            showToast("रिपोर्ट दर्ज करने में समस्या आई। कृपया पुनः प्रयास करें।", "error");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[100000] p-4 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="glass-card p-6 w-full max-w-lg transform transition-all bg-white rounded-3xl shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
                    <h2 className="text-lg font-black text-gray-900 flex items-center gap-2">
                        <span className="material-symbols-outlined text-red-600 font-bold">report_problem</span>
                        <span>सामग्री रिपोर्ट करें (Report Content)</span>
                    </h2>
                    <button 
                        type="button" 
                        onClick={onClose}
                        className="p-1 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
                    >
                        <span className="material-symbols-outlined text-xl">close</span>
                    </button>
                </div>

                <p className="text-xs text-gray-500 font-bold mb-1.5 uppercase tracking-wide">
                    आप इस {contentType === 'video' ? 'वीडियो' : 'पोस्ट'} की शिकायत कर रहे हैं:
                </p>
                <div className="flex items-center gap-3 bg-gray-50 p-3 rounded-2xl border border-gray-200/80 mb-4">
                    {targetThumbnail && (
                        <img 
                            src={targetThumbnail} 
                            alt={targetTitle} 
                            className="w-12 h-12 rounded-xl object-cover flex-shrink-0 border border-gray-200" 
                        />
                    )}
                    <p className="font-bold text-gray-800 text-xs md:text-sm line-clamp-2">
                        "{targetTitle || 'शीर्षकहीन सामग्री'}"
                    </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-2">
                            शिकायत की श्रेणी चुनें (Select Issue) *
                        </label>
                        <div className="grid grid-cols-1 gap-2">
                            {REPORT_REASONS.map((r) => (
                                <button
                                    key={r.value}
                                    type="button"
                                    onClick={() => setSelectedCategory(r.value)}
                                    className={`text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all border flex items-center justify-between ${
                                        selectedCategory === r.value
                                            ? 'bg-red-50 border-red-500 text-red-700 shadow-sm'
                                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                                    }`}
                                >
                                    <span>{r.label}</span>
                                    {selectedCategory === r.value && (
                                        <span className="material-symbols-outlined text-sm text-red-600 font-black">check_circle</span>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label htmlFor="customDetails" className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1.5">
                            अतिरिक्त विवरण (Optional Details)
                        </label>
                        <textarea
                            id="customDetails"
                            value={customDetails}
                            onChange={(e) => setCustomDetails(e.target.value)}
                            className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none bg-gray-50 text-gray-900 transition-all text-xs font-medium resize-none"
                            rows={3}
                            placeholder="कृपया अतिरिक्त जानकारी दें कि यह सामग्री नियमों का उल्लंघन कैसे करती है..."
                        />
                    </div>

                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2.5 text-amber-900 text-xs">
                        <span className="material-symbols-outlined text-amber-600 text-base shrink-0 mt-0.5">notifications_active</span>
                        <p className="leading-relaxed">
                            इस पोस्ट के लेखक को तुरंत एक <strong>रिपोर्ट नोटिफिकेशन</strong> भेजा जाएगा ताकि वे अपनी पोस्ट की समीक्षा कर सकें और एडमिन टीम इस पर उचित कार्रवाई कर सके।
                        </p>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="flex-1 py-3 bg-gray-100 text-gray-700 font-bold text-xs rounded-xl hover:bg-gray-200 transition-all active:scale-95"
                        >
                            रद्द करें (Cancel)
                        </button>
                        <button 
                            type="submit" 
                            disabled={isSubmitting} 
                            className="flex-1 py-3 bg-red-600 text-white font-bold text-xs rounded-xl hover:bg-red-700 disabled:opacity-50 transition-all active:scale-95 shadow-md hover:shadow-lg flex items-center justify-center gap-1.5"
                        >
                            {isSubmitting ? (
                                <>
                                    <span className="animate-spin material-symbols-outlined text-sm">progress_activity</span>
                                    <span>भेजा जा रहा है...</span>
                                </>
                            ) : (
                                <>
                                    <span className="material-symbols-outlined text-sm">send</span>
                                    <span>रिपोर्ट सबमिट करें</span>
                                </>
                            )}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ReportModal;
