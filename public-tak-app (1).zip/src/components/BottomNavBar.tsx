import React from 'react';
import { View, User } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import UserAvatar from './UserAvatar';

interface BottomNavBarProps {
  onNavigate: (view: View) => void;
  currentUser: User | null;
  currentView: View;
  unreadCount: number;
}

const views: View[] = [View.Main, View.VideoHome, View.CreatePost, View.Notifications, View.User];
const icons: { [key in View]?: string } = {
  [View.Main]: "home",
  [View.VideoHome]: "smart_display",
  [View.CreatePost]: "add",
  [View.Notifications]: "notifications",
  [View.User]: "person",
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ onNavigate, currentUser, currentView, unreadCount }) => {
  const { t } = useLanguage();

  const labels: { [key in View]?: string } = {
    [View.Main]: t('home') || 'Home',
    [View.VideoHome]: t('video') || 'Video',
    [View.CreatePost]: t('post') || 'Post',
    [View.Notifications]: t('alerts') || 'Alerts',
    [View.User]: currentUser ? (currentUser.name ? currentUser.name.split(' ')[0] : 'You') : (t('profile') || 'Profile'),
  };

  const handleProtectedNav = (view: View) => {
    if (currentUser || view === View.Main || view === View.VideoHome) {
      onNavigate(view);
    } else {
      onNavigate(View.Login);
    }
  };

  return (
    <nav 
      id="bottom-navbar"
      aria-label="Mobile Bottom Navigation" 
      className="md:hidden fixed bottom-0 inset-x-0 w-full z-50 select-none bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-t border-gray-200/90 dark:border-slate-800 shadow-[0_-8px_30px_rgba(0,0,0,0.08)] pb-[max(env(safe-area-inset-bottom,0px),4px)]"
    >
      {/* Full-width responsive 5-column navigation strip */}
      <div className="w-full max-w-lg mx-auto grid grid-cols-5 h-16 items-center px-1">
        {views.map((view) => {
          const isActive = view === currentView;
          const needsAuth = view === View.CreatePost || view === View.Notifications || view === View.User;
          const hasBadge = view === View.Notifications && unreadCount > 0;
          const labelText = labels[view];

          // Center Elevated Post Button
          if (view === View.CreatePost) {
            return (
              <div key={view} className="relative flex items-center justify-center h-full">
                <button
                  id="bottom-nav-post-button"
                  type="button"
                  onClick={() => needsAuth ? handleProtectedNav(view) : onNavigate(view)}
                  className="relative -top-3.5 flex flex-col items-center justify-center group focus:outline-none cursor-pointer active:scale-90 transition-transform duration-200"
                  title={labelText}
                  aria-label={labelText}
                >
                  {/* Floating Action Button */}
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white shadow-[0_6px_20px_rgba(239,68,68,0.45)] transition-all duration-300 border-2 border-white dark:border-slate-900 ${
                    isActive 
                      ? 'bg-gradient-to-tr from-red-600 via-rose-600 to-red-500 ring-2 ring-red-500 ring-offset-2 ring-offset-white dark:ring-offset-slate-900' 
                      : 'bg-gradient-to-tr from-red-600 via-rose-600 to-red-500 hover:from-red-500 hover:to-rose-500'
                  }`}>
                    <span className="material-symbols-outlined text-[28px] font-bold leading-none select-none transition-transform duration-300 group-hover:rotate-90">
                      add
                    </span>
                  </div>
                  
                  {/* Label under floating button */}
                  <span className={`mt-0.5 text-[10px] font-bold tracking-tight transition-colors duration-150 ${
                    isActive ? 'text-red-600 dark:text-red-400 font-extrabold' : 'text-gray-700 dark:text-gray-300'
                  }`}>
                    {labelText}
                  </span>
                </button>
              </div>
            );
          }

          // Standard Navigation Tabs
          const isUserTab = view === View.User;

          return (
            <button 
              key={view}
              id={`bottom-nav-${view.toLowerCase()}-button`}
              type="button"
              onClick={() => needsAuth ? handleProtectedNav(view) : onNavigate(view)} 
              className="relative flex flex-col items-center justify-center w-full h-full py-1 text-center transition-all duration-150 group focus:outline-none select-none active:scale-95 cursor-pointer"
              title={labelText}
              aria-label={labelText}
            >
              {/* Notification Badge */}
              {hasBadge && (
                <span className="absolute top-1.5 right-1/2 translate-x-4 bg-red-600 text-white text-[9px] font-black rounded-full min-w-[16px] h-[16px] flex items-center justify-center px-1 border-2 border-white dark:border-slate-900 z-20 shadow-xs animate-pulse">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
              
              {/* Icon / User Avatar Container */}
              <div className="relative flex items-center justify-center w-7 h-7">
                {isUserTab && currentUser ? (
                  <UserAvatar 
                    userId={currentUser.uid}
                    src={currentUser.profilePicUrl} 
                    name={currentUser.name}
                    currentUser={currentUser}
                    className={`w-6 h-6 rounded-full object-cover ring-2 transition-all duration-200 ${
                      isActive 
                        ? 'ring-red-600 scale-110 shadow-xs' 
                        : 'ring-gray-300 dark:ring-slate-700 group-hover:ring-red-400'
                    }`}
                  />
                ) : (
                  <span 
                    className={`material-symbols-outlined text-[24px] transition-all duration-200 ${
                      isActive 
                        ? 'text-red-600 dark:text-red-500 scale-110' 
                        : 'text-gray-500 dark:text-gray-400 group-hover:text-gray-800 dark:group-hover:text-gray-200'
                    }`} 
                    style={{ fontVariationSettings: `'FILL' ${isActive ? 1 : 0}` }}
                  >
                    {icons[view]}
                  </span>
                )}

                {/* Subtle active indicator dot */}
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-red-600 dark:bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]" />
                )}
              </div>
              
              {/* Tab Label */}
              <span className={`mt-1 text-[10px] sm:text-[11px] tracking-tight transition-colors duration-150 truncate max-w-[64px] px-0.5 leading-tight ${
                isActive 
                  ? 'text-red-600 dark:text-red-500 font-bold' 
                  : 'text-gray-500 dark:text-gray-400 font-medium group-hover:text-gray-700 dark:group-hover:text-gray-300'
              }`}>
                {labelText}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNavBar;
