import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { APP_LOGO_URL } from '../utils/constants';

export interface PushNotificationData {
  id?: string;
  title: string;
  body?: string;
  image?: string | null;
  thumbnailUrl?: string | null;
  postThumbnailUrl?: string | null;
  postTitle?: string | null;
  fromUserName?: string | null;
  fromUserProfilePicUrl?: string | null;
  fromUserIsVerified?: boolean;
  postId?: string | null;
  videoId?: string | null;
  userId?: string | null;
  category?: string | null;
  type?: string;
}

interface PushNotificationToastProps {
  notification: PushNotificationData;
  onClose: () => void;
  onSelectPost: (postId: string) => void;
  onSelectVideo?: (videoId: string) => void;
  onSelectUser?: (userId: string) => void;
}

export const PushNotificationToast: React.FC<PushNotificationToastProps> = ({
  notification,
  onClose,
  onSelectPost,
  onSelectVideo,
  onSelectUser,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Extract thumbnail image URL
  const thumbnail =
    notification.image ||
    notification.thumbnailUrl ||
    notification.postThumbnailUrl ||
    null;

  // Extract post title
  const postTitle =
    notification.postTitle || notification.title || 'नई खबर';

  // Extract description/body text
  const bodyText = notification.body || notification.title || '';

  // Handle card click
  const handleCardClick = (e: React.MouseEvent) => {
    // If user clicks action button or expand toggle, handle standard behavior
    if (notification.postId) {
      onSelectPost(notification.postId);
      onClose();
    } else if (notification.videoId && onSelectVideo) {
      onSelectVideo(notification.videoId);
      onClose();
    } else if (notification.userId && onSelectUser) {
      onSelectUser(notification.userId);
      onClose();
    }
  };

  const toggleExpand = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsExpanded((prev) => !prev);
  };

  return (
    <div className="fixed top-4 md:top-6 left-1/2 transform -translate-x-1/2 z-[100000] w-full max-w-lg px-3 md:px-4 pointer-events-none">
      <motion.div
        layout
        initial={{ opacity: 0, y: -40, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -30, scale: 0.95 }}
        transition={{ type: 'spring', stiffness: 450, damping: 30 }}
        className="pointer-events-auto bg-white text-gray-900 border border-gray-200/90 shadow-2xl shadow-black/20 rounded-2xl md:rounded-3xl p-3.5 md:p-4 ring-1 ring-black/5 overflow-hidden transition-all"
      >
        {/* Top Bar / Header */}
        <div className="flex items-center justify-between gap-2 border-b border-gray-100 pb-2 mb-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            {/* Publisher / Logo Avatar */}
            <div className="w-8 h-8 rounded-full overflow-hidden border border-gray-200 flex-shrink-0 bg-gray-100 shadow-sm">
              <img
                src={notification.fromUserProfilePicUrl || APP_LOGO_URL}
                alt="Publisher"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-gray-900 truncate">
                  {notification.fromUserName || 'पब्लिक तक ऐप'}
                </span>
                {notification.fromUserIsVerified && (
                  <span className="material-symbols-outlined text-[14px] text-blue-600 fill-1">
                    verified
                  </span>
                )}
                {notification.type === 'post_reported' || notification.type === 'content_reported' ? (
                  <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ml-1 flex items-center gap-1">
                    <span className="material-symbols-outlined text-[11px] text-amber-700">report_problem</span>
                    रिपोर्ट अलर्ट
                  </span>
                ) : (
                  <span className="bg-red-100 text-red-700 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ml-1">
                    न्यूज़ अलर्ट
                  </span>
                )}
              </div>
              <span className="text-[11px] font-bold text-gray-400">
                अभी-अभी (Just now)
              </span>
            </div>
          </div>

          {/* Action Icons: Expand Up/Down Arrow & Dismiss Close Button */}
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={toggleExpand}
              className="p-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 hover:text-black transition-colors flex items-center justify-center active:scale-95 border border-gray-200/60"
              title={isExpanded ? 'कम करें (Collapse)' : 'पूरा देखें (Expand)'}
              aria-label={isExpanded ? 'Collapse Notification' : 'Expand Notification'}
            >
              <span className="material-symbols-outlined text-xl font-bold">
                {isExpanded ? 'keyboard_arrow_up' : 'keyboard_arrow_down'}
              </span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="p-1.5 rounded-xl hover:bg-gray-100 text-gray-400 hover:text-gray-800 transition-colors active:scale-95 ml-0.5"
              title="बंद करें"
              aria-label="Dismiss Notification"
            >
              <span className="material-symbols-outlined text-lg">close</span>
            </button>
          </div>
        </div>

        {/* Notification Main Content Container */}
        <AnimatePresence mode="wait">
          {!isExpanded ? (
            /* COMPACT VIEW (Default) */
            <motion.div
              key="compact"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-3 cursor-pointer group"
              onClick={handleCardClick}
            >
              <div className="flex-1 min-w-0">
                <h4 className="text-sm md:text-base font-extrabold text-black group-hover:text-red-600 transition-colors leading-snug line-clamp-2">
                  {postTitle}
                </h4>
                {bodyText && bodyText !== postTitle && (
                  <p className="text-xs text-gray-600 truncate mt-0.5 font-medium">
                    {bodyText}
                  </p>
                )}
              </div>

              {/* Compact Thumbnail Image */}
              {thumbnail && (
                <div className="w-14 h-14 md:w-16 md:h-16 min-w-[56px] min-h-[56px] rounded-xl overflow-hidden shrink-0 border border-gray-200 bg-gray-50 shadow-sm relative group-hover:ring-2 ring-red-500/30 transition-all">
                  <img
                    src={thumbnail}
                    alt="Article Thumbnail"
                    className="w-full h-full object-cover aspect-square"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}
            </motion.div>
          ) : (
            /* EXPANDED VIEW (When Down Arrow is Clicked) */
            <motion.div
              key="expanded"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="space-y-3 pt-1"
            >
              {/* Full Article Title */}
              <h3 className="text-base md:text-lg font-black text-black leading-snug tracking-tight">
                {postTitle}
              </h3>

              {/* Responsive Full-Width Thumbnail Image */}
              {thumbnail && (
                <div className="w-full aspect-video max-h-52 sm:max-h-60 rounded-2xl overflow-hidden border border-gray-200 bg-gray-900 shadow-md relative group">
                  <img
                    src={thumbnail}
                    alt="Full Post Thumbnail"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}

              {/* Full Description / Summary Text */}
              {bodyText && (
                <p className="text-xs md:text-sm font-medium text-gray-700 leading-relaxed bg-gray-50/80 p-3 rounded-xl border border-gray-100">
                  {bodyText}
                </p>
              )}

              {/* Action Button: Read Full Article */}
              <div className="pt-1 flex items-center justify-between gap-2">
                <button
                  onClick={handleCardClick}
                  className="flex-1 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white text-xs md:text-sm font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.98] transition-all"
                >
                  <span className="material-symbols-outlined text-lg">
                    menu_book
                  </span>
                  <span>पूरा आर्टिकल पढ़ें</span>
                  <span className="material-symbols-outlined text-lg ml-auto">
                    arrow_forward
                  </span>
                </button>

                <button
                  onClick={toggleExpand}
                  className="px-3 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-gray-600 hover:text-black hover:bg-gray-100 transition-colors flex items-center gap-1"
                  title="कम करें"
                >
                  <span className="material-symbols-outlined text-base">
                    keyboard_arrow_up
                  </span>
                  <span>कम करें</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default PushNotificationToast;
