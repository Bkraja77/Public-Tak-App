
import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Post, User, View } from '../types';
import { db, serverTimestamp, increment, storage } from '../firebaseConfig';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from './ConfirmationModal';
import UserAvatar from './UserAvatar';
import { formatCount } from '../utils/formatters';
import { sharePost, hasUserSharedLocally } from '../utils/shareUtils';
import { appCacheService } from '../services/appCacheService';

interface PostCardProps {
    post: Post;
    currentUser: User | null;
    onLogin: () => void;
    onReport: (post: Post) => void;
    onViewPost: (postId: string) => void;
    onViewUser: (userId: string) => void;
    isFollowing: boolean;
    handleFollowToggle: (targetUserId: string, targetUserName: string, targetUserProfilePicUrl: string) => void;
    onNavigate: (view: View, params?: any) => void;
    onEditPost?: (postId: string) => void;
}

const PostCard: React.FC<PostCardProps> = React.memo(({ post, currentUser, onLogin, onReport, onViewPost, onViewUser, isFollowing, handleFollowToggle, onNavigate, onEditPost }) => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [likeCount, setLikeCount] = useState(0);
    const [commentCount, setCommentCount] = useState(0);
    const [shareCount, setShareCount] = useState(post.shareCount || 0);
    const [isLiked, setIsLiked] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const { t } = useLanguage();
    const { showToast } = useToast();
    
    useEffect(() => {
        setShareCount(post.shareCount || 0);
    }, [post.shareCount]);

    useEffect(() => {
        const likesRef = db.collection('posts').doc(post.id).collection('likes');
        const unsubLikes = likesRef.onSnapshot((snapshot) => {
            setLikeCount(snapshot.size);
            if (currentUser) {
                setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid));
            } else {
                setIsLiked(false);
            }
        });

        const commentsRef = db.collection('posts').doc(post.id).collection('comments');
        const unsubComments = commentsRef.onSnapshot((snapshot) => {
            setCommentCount(snapshot.size);
        });

        const sharesRef = db.collection('posts').doc(post.id).collection('shares');
        const unsubShares = sharesRef.onSnapshot((snapshot) => {
            setShareCount(prev => Math.max(prev, snapshot.size, post.shareCount || 0));
        }, () => {});

        return () => {
            unsubLikes();
            unsubComments();
            unsubShares();
        };
    }, [post.id, currentUser]);

    const [isAuthorVerified, setIsAuthorVerified] = useState<boolean>(
        Boolean(post.authorIsVerified || (currentUser && currentUser.uid === post.authorId && currentUser.isVerified))
    );

    useEffect(() => {
        if (post.authorIsVerified || (currentUser && currentUser.uid === post.authorId && currentUser.isVerified)) {
            setIsAuthorVerified(true);
            return;
        }
        if (post.authorId) {
            const unsubAuthor = db.collection('users').doc(post.authorId).onSnapshot((doc) => {
                if (doc.exists && doc.data()?.isVerified) {
                    setIsAuthorVerified(true);
                }
            }, () => {});
            return () => unsubAuthor();
        }
    }, [post.authorId, post.authorIsVerified, currentUser]);

    const isCurrentUserPost = currentUser && currentUser.uid === post.authorId;
    const isAdmin = currentUser?.role === 'admin';
    const authorName = isCurrentUserPost ? currentUser.name : post.authorName;
    const authorProfilePicUrl = (isCurrentUserPost ? currentUser.profilePicUrl : post.authorProfilePicUrl) 
        || `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(authorName)}`;

    const handleLike = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (!currentUser) {
            showToast("Please log in to like posts.", "info");
            onLogin();
            return;
        }
        
        const likeRef = db.collection('posts').doc(post.id).collection('likes').doc(currentUser.uid);
        const postAuthorId = post.authorId;
        
        try {
            if (isLiked) {
                await likeRef.delete();
            } else {
                const batch = db.batch();
                batch.set(likeRef, { likedAt: serverTimestamp() });
                
                if (currentUser.uid !== postAuthorId) {
                    const notificationRef = db.collection('users').doc(postAuthorId).collection('notifications').doc();
                    batch.set(notificationRef, {
                        type: 'new_like',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name,
                        fromUserProfilePicUrl: currentUser.profilePicUrl,
                        fromUserIsVerified: currentUser.isVerified || false,
                        postId: post.id,
                        postTitle: post.title,
                        createdAt: serverTimestamp(),
                        read: false
                    });
                }
                
                await batch.commit();
            }
        } catch (error) {
            console.error("Error liking post:", error);
            showToast("Could not like post.", "error");
        }
    };
    
    const handleFollowClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        handleFollowToggle(post.authorId, post.authorName, post.authorProfilePicUrl);
    };
    
    const displayContent = useMemo(() => {
        if (!post.content) return '';
        return post.content.replace(/<[^>]*>?/gm, '');
    }, [post.content]);

    const handleShare = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }

        const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
        if (!alreadyShared) {
            setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
        }

        const isNewShare = await sharePost({
            post,
            currentUser,
            showToast,
        });

        if (!isNewShare && !alreadyShared) {
            setShareCount(post.shareCount || 0);
        }
    };

    const handleReportClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsMenuOpen(false);
        onReport(post);
    };

    const handleEditClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsMenuOpen(false);
        if (onEditPost) {
            onEditPost(post.id);
        }
    };

    const handleDeleteClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsMenuOpen(false);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        try {
            await db.collection("posts").doc(post.id).delete();
            if (post.thumbnailUrl && post.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                try {
                    const storageRef = storage.refFromURL(post.thumbnailUrl);
                    await storageRef.delete();
                } catch (storageErr) {
                    console.warn("Post deleted, but thumbnail image cleanup failed:", storageErr);
                }
            }
            showToast("Post deleted successfully.", "success");
        } catch (error: any) {
            console.error("Error deleting post:", error);
            showToast(`Failed to delete post: ${error.message || "Unknown error"}`, "error");
        } finally {
            setIsDeleteModalOpen(false);
        }
    };

    const timeAgo = useMemo(() => {
        if (!post.createdAt) return 'N/A';
        const now = new Date();
        const seconds = Math.floor((now.getTime() - post.createdAt.getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + "y ago";
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + "mo ago";
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + "d ago";
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + "h ago";
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + "m ago";
        return Math.floor(seconds) + "s ago";
    }, [post.createdAt]);
    
    return (
        <>
            <motion.div 
                onClick={() => {
                    appCacheService.setPost(post);
                    onViewPost(post.id);
                }} 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ 
                    y: -10, 
                    scale: 1.02,
                    boxShadow: "0 25px 50px -12px rgba(220, 38, 38, 0.15), 0 10px 10px -5px rgba(220, 38, 38, 0.04)",
                    borderColor: "rgba(239, 68, 68, 0.3)",
                    transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } 
                }}
                className="glass-card overflow-hidden transition-all duration-500 cursor-pointer flex flex-col h-full group border border-gray-100 relative bg-white/80 backdrop-blur-md hover:bg-white"
            >
                <div className="p-3 flex items-start gap-2 border-b border-gray-50/50 group-hover:border-red-100/50 transition-colors">
                    <UserAvatar 
                        userId={post.authorId}
                        src={post.authorProfilePicUrl}
                        name={authorName}
                        currentUser={currentUser}
                        onClick={(e) => { e.stopPropagation(); onViewUser(post.authorId); }} 
                        className="w-10 h-10 rounded-full object-cover cursor-pointer ring-2 ring-white shadow-md relative z-20 transition-transform group-hover:scale-110 active:scale-90 shrink-0" 
                    />
                    <div className="flex-grow min-w-0 relative z-20 pt-0.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                            <p onClick={(e) => { e.stopPropagation(); onViewUser(post.authorId); }} className="font-black text-gray-900 cursor-pointer group-hover:text-red-600 text-sm transition-colors break-words">
                                {authorName}
                            </p>
                            {(isAuthorVerified || post.authorIsVerified || (isCurrentUserPost && currentUser?.isVerified)) && (
                                <span className="material-symbols-outlined text-blue-500 text-[16px] font-bold shrink-0 align-middle inline-flex items-center" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                            )}
                            
                            {(!currentUser || currentUser.uid !== post.authorId) && (
                                <motion.button 
                                    whileHover={{ scale: 1.08 }}
                                    whileTap={{ scale: 0.92 }}
                                    onClick={handleFollowClick} 
                                    className={`
                                        px-3 py-1 text-[9px] font-black uppercase tracking-widest rounded-full transition-all duration-300 shadow-sm z-30 border inline-flex items-center gap-1
                                        ${isFollowing 
                                            ? 'bg-gray-100 text-gray-500 border-gray-200' 
                                            : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border-red-500 animate-follow-blink shadow-md shadow-red-500/30'}
                                    `}
                                >
                                    {isFollowing ? (
                                        <>
                                            <span className="material-symbols-outlined text-[12px] font-black">done</span>
                                            {t('following')}
                                        </>
                                    ) : (
                                        <>
                                            <span className="material-symbols-outlined text-[12px] font-black">person_add</span>
                                            {t('follow')}
                                        </>
                                    )}
                                </motion.button>
                            )}
                        </div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter mt-0.5">{timeAgo}</p>
                    </div>
                </div>
                
                <div className="w-full aspect-[16/10] bg-gray-50 overflow-hidden relative flex items-center justify-center">
                     {post.thumbnailUrl ? (
                        <>
                            {/* Ambient blurred backdrop to eliminate empty space around different aspect ratio images */}
                            <div 
                                className="absolute inset-0 bg-cover bg-center blur-md opacity-25 scale-105 pointer-events-none"
                                style={{ backgroundImage: `url(${post.thumbnailUrl})` }}
                            />
                            <img 
                                src={post.thumbnailUrl} 
                                alt={post.title} 
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover relative z-10 transition-all duration-500 group-hover:scale-105" 
                            />
                        </>
                    ) : (
                        <div className="flex flex-col items-center justify-center absolute inset-0 text-gray-300">
                            <span className="material-symbols-outlined text-4xl">image</span>
                        </div>
                    )}
                </div>

                <div className="p-4 flex flex-col flex-grow">
                    <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2 leading-snug group-hover:text-red-600 transition-colors">{post.title}</h3>
                    <p className="text-gray-500 line-clamp-2 text-sm leading-relaxed">{displayContent}</p>
                </div>
                
                 <div className="px-4 py-2 border-t border-gray-50 flex justify-between items-center text-gray-400 bg-white mt-auto relative z-20">
                    <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1 p-2" title="Views">
                            <span className="material-symbols-outlined text-lg">visibility</span>
                            <span className="text-xs font-semibold">{formatCount(post.viewCount || 0)}</span>
                        </div>
                        <button 
                            onClick={handleLike} 
                            className={`flex items-center gap-1 transition-colors group/like p-2 rounded-full hover:bg-red-50 relative z-30 ${isLiked ? 'text-red-500' : 'hover:text-red-500'}`} 
                            title="Likes"
                        >
                            <span 
                                className="material-symbols-outlined text-lg transition-all"
                                style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}`}}
                            >
                                favorite
                            </span>
                            <span className="text-xs font-semibold">{formatCount(likeCount)}</span>
                        </button>
                        <button 
                            onClick={(e) => { 
                                e.preventDefault();
                                e.stopPropagation(); 
                                onNavigate(View.PostDetail, { postId: post.id, focusComment: true }); 
                            }}
                            className="flex items-center gap-1 hover:text-blue-600 transition-colors p-2 rounded-full hover:bg-blue-50 relative z-30" 
                            title="Comments"
                        >
                            <span className="material-symbols-outlined text-lg">chat_bubble</span>
                            <span className="text-xs font-semibold">{formatCount(commentCount)}</span>
                        </button>
                         <button 
                            onClick={handleShare} 
                            className="flex items-center gap-1 text-blue-600 hover:text-blue-700 transition-colors p-2 rounded-full hover:bg-blue-50 relative z-30" 
                            title="Share"
                        >
                            <span className="material-symbols-outlined text-lg">share</span>
                            <span className="text-xs font-semibold">{formatCount(shareCount)}</span>
                        </button>
                    </div>
                     <div className="relative z-30">
                        <button onClick={(e) => { e.stopPropagation(); setIsMenuOpen(v => !v); }} className="p-2 rounded-full hover:bg-gray-100 text-gray-400"><span className="material-symbols-outlined text-lg">more_vert</span></button>
                         {isMenuOpen && (
                            <div className="absolute bottom-full right-0 mb-1 w-32 bg-white rounded-lg shadow-xl border border-gray-100 overflow-hidden z-40">
                                {(isCurrentUserPost || isAdmin) && (
                                    <>
                                        <button onClick={handleEditClick} className="flex items-center gap-2 w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors">
                                            <span className="material-symbols-outlined text-sm">edit</span>
                                            {t('edit')}
                                        </button>
                                        <button onClick={handleDeleteClick} className="flex items-center gap-2 w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 transition-colors">
                                            <span className="material-symbols-outlined text-sm">delete</span>
                                            {t('delete')}
                                        </button>
                                        <div className="border-b border-gray-100 my-1"></div>
                                    </>
                                )}
                                <button onClick={handleReportClick} className="flex items-center gap-2 w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 transition-colors">
                                    <span className="material-symbols-outlined text-sm">flag</span>
                                    {t('report')}
                                </button>
                            </div>
                         )}
                    </div>
                 </div>
            </motion.div>
            
            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="Delete Post"
                message="Are you sure you want to delete this post? This action cannot be undone."
                confirmButtonText="Delete"
                confirmButtonColor="bg-red-600 hover:bg-red-700"
            />
        </>
    );
}, (prevProps, nextProps) => {
    return (
        prevProps.post.id === nextProps.post.id &&
        prevProps.post.title === nextProps.post.title &&
        prevProps.post.thumbnailUrl === nextProps.post.thumbnailUrl &&
        prevProps.post.viewCount === nextProps.post.viewCount &&
        prevProps.post.shareCount === nextProps.post.shareCount &&
        prevProps.post.content === nextProps.post.content &&
        prevProps.isFollowing === nextProps.isFollowing &&
        prevProps.currentUser?.uid === nextProps.currentUser?.uid
    );
});

export default PostCard;
