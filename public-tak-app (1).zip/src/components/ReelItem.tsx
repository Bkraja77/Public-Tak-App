import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Video, User } from '../types';
import { db, serverTimestamp, increment } from '../firebaseConfig';
import { formatCount } from '../utils/formatters';
import { useToast } from '../contexts/ToastContext';
import ReportModal from './ReportModal';
import UserAvatar from './UserAvatar';

interface ReelItemProps {
    video: Video;
    currentUser: User | null;
    isActive: boolean;
    isMuted: boolean;
    isFollowing: boolean;
    onMuteToggle: () => void;
    onFollowToggle: (authorId: string, authorName: string) => void;
    onCommentBoxClick: () => void;
    onShareClick: () => void;
    onViewUser: (userId: string) => void;
    onLogin: () => void;
    onVideoEnded?: () => void;
    onVideoDeleted?: (videoId: string) => void;
    onVideoUpdated?: (updatedVideo: Video) => void;
}

const ReelItem: React.FC<ReelItemProps> = React.memo(({
    video,
    currentUser,
    isActive,
    isMuted,
    isFollowing,
    onMuteToggle,
    onFollowToggle,
    onCommentBoxClick,
    onShareClick,
    onViewUser,
    onLogin,
    onVideoEnded,
    onVideoDeleted,
    onVideoUpdated
}) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const progressBarRef = useRef<HTMLDivElement>(null);
    const [likeCount, setLikeCount] = useState(video.likeCount || 0);
    const [commentCount, setCommentCount] = useState(video.commentCount || 0);
    const [shareCount, setShareCount] = useState(video.shareCount || 0);
    const [isLiked, setIsLiked] = useState(false);
    const [isAuthorVerified, setIsAuthorVerified] = useState<boolean>(
        Boolean(video.authorIsVerified || (currentUser && currentUser.uid === video.authorId && currentUser.isVerified))
    );

    useEffect(() => {
        if (video.authorIsVerified || (currentUser && currentUser.uid === video.authorId && currentUser.isVerified)) {
            setIsAuthorVerified(true);
            return;
        }
        if (video.authorId) {
            const unsubAuthor = db.collection('users').doc(video.authorId).onSnapshot((doc) => {
                if (doc.exists && doc.data()?.isVerified) {
                    setIsAuthorVerified(true);
                }
            }, () => {});
            return () => unsubAuthor();
        }
    }, [video.authorId, video.authorIsVerified, currentUser]);
    const [isPlaying, setIsPlaying] = useState(true);
    const [showVolumeBadge, setShowVolumeBadge] = useState(false);
    const [progress, setProgress] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [isDragging, setIsDragging] = useState(false);

    const [showMoreMenu, setShowMoreMenu] = useState(false);
    const [isAutoScroll, setIsAutoScroll] = useState(() => localStorage.getItem('reel_auto_scroll') === 'true');
    const { showToast } = useToast();

    // Expanded Title / See More state
    const [isExpanded, setIsExpanded] = useState(false);

    // Edit Video details modal state
    const [showEditModal, setShowEditModal] = useState(false);
    const [editTitle, setEditTitle] = useState(video.title);
    const [editDescription, setEditDescription] = useState(video.description || '');
    const [editCategory, setEditCategory] = useState(video.category);
    const [isSavingEdit, setIsSavingEdit] = useState(false);

    // Delete Video confirmation state
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    // Report modal state
    const [showReportModal, setShowReportModal] = useState(false);

    // Double tap to like heart animation states
    const lastTapRef = useRef<number>(0);
    const [heartAnimations, setHeartAnimations] = useState<{ id: number; x: number; y: number; targetX: number; targetY: number }[]>([]);
    const [pulseLike, setPulseLike] = useState(false);

    // Sync state when video prop changes (e.g. edited details)
    useEffect(() => {
        setEditTitle(video.title);
        setEditDescription(video.description || '');
        setEditCategory(video.category);
        setIsExpanded(false);
    }, [video]);

    const handleSaveEdit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!editTitle.trim()) {
            showToast("Title is required", "error");
            return;
        }
        setIsSavingEdit(true);
        try {
            await db.collection('videos').doc(video.id).update({
                title: editTitle.trim(),
                description: editDescription.trim(),
                category: editCategory
            });
            showToast("Video updated successfully!", "success");
            setShowEditModal(false);
            if (onVideoUpdated) {
                onVideoUpdated({
                    ...video,
                    title: editTitle.trim(),
                    description: editDescription.trim(),
                    category: editCategory
                });
            }
        } catch (err) {
            console.error("Error updating video:", err);
            showToast("Failed to update video", "error");
        } finally {
            setIsSavingEdit(false);
        }
    };

    const handleDeleteConfirm = async () => {
        setIsDeleting(true);
        try {
            await db.collection('videos').doc(video.id).delete();
            showToast("Video deleted successfully", "success");
            setShowDeleteConfirm(false);
            if (onVideoDeleted) {
                onVideoDeleted(video.id);
            }
        } catch (err) {
            console.error("Error deleting video:", err);
            showToast("Failed to delete video", "error");
        } finally {
            setIsDeleting(false);
        }
    };

    const toggleAutoScroll = () => {
        const newValue = !isAutoScroll;
        setIsAutoScroll(newValue);
        localStorage.setItem('reel_auto_scroll', String(newValue));
    };

    const handleVideoEnded = () => {
        const autoScroll = localStorage.getItem('reel_auto_scroll') === 'true';
        if (autoScroll && onVideoEnded) {
            onVideoEnded();
        }
    };

    // Sync play/pause with active state
    useEffect(() => {
        if (videoRef.current) {
            if (isActive) {
                videoRef.current.play()
                    .then(() => setIsPlaying(true))
                    .catch(() => setIsPlaying(false));
            } else {
                videoRef.current.pause();
                videoRef.current.currentTime = 0;
                setIsPlaying(false);
                setProgress(0);
            }
        }
    }, [isActive]);

    // Handle volume properties
    useEffect(() => {
        if (videoRef.current) {
            videoRef.current.muted = isMuted;
        }
    }, [isMuted]);

    useEffect(() => {
        setShareCount(video.shareCount || 0);
    }, [video.shareCount]);

    // Listen to real-time likes, comments & shares count for this video
    useEffect(() => {
        if (!video.id) return;

        const likesRef = db.collection('videos').doc(video.id).collection('likes');
        const unsubLikes = likesRef.onSnapshot((snapshot) => {
            setLikeCount(snapshot.size);
            if (currentUser) {
                setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid));
            } else {
                setIsLiked(false);
            }
        });

        const commentsRef = db.collection('videos').doc(video.id).collection('comments');
        const unsubComments = commentsRef.onSnapshot((snapshot) => {
            setCommentCount(snapshot.size);
        });

        const sharesRef = db.collection('videos').doc(video.id).collection('shares');
        const unsubShares = sharesRef.onSnapshot((snapshot) => {
            setShareCount(prev => Math.max(prev, snapshot.size, video.shareCount || 0));
        }, () => {});

        return () => {
            unsubLikes();
            unsubComments();
            unsubShares();
        };
    }, [video.id, currentUser]);

    // Progress bar update
    const handleTimeUpdate = () => {
        if (videoRef.current && !isDragging) {
            const current = videoRef.current.currentTime;
            const dur = videoRef.current.duration || 0;
            setCurrentTime(current);
            setDuration(dur);
            setProgress(dur > 0 ? (current / dur) * 100 : 0);
        }
    };

    const handleLoadedMetadata = () => {
        if (videoRef.current) {
            setDuration(videoRef.current.duration || 0);
        }
    };

    const formatTime = (seconds: number) => {
        if (isNaN(seconds) || seconds === Infinity) return '0:00';
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    };

    const handleSeek = (clientX: number) => {
        if (progressBarRef.current && videoRef.current) {
            const rect = progressBarRef.current.getBoundingClientRect();
            const clickX = clientX - rect.left;
            const width = rect.width;
            let percentage = clickX / width;
            if (percentage < 0) percentage = 0;
            if (percentage > 1) percentage = 1;
            
            const dur = videoRef.current.duration;
            if (dur) {
                const targetTime = percentage * dur;
                videoRef.current.currentTime = targetTime;
                setCurrentTime(targetTime);
                setProgress(percentage * 100);
            }
        }
    };

    const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
        e.stopPropagation();
        setIsDragging(true);
        handleSeek(e.clientX);
        
        const handleMouseMove = (moveEvent: MouseEvent) => {
            handleSeek(moveEvent.clientX);
        };
        
        const handleMouseUp = () => {
            setIsDragging(false);
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
        
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    };

    const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
        e.stopPropagation();
        setIsDragging(true);
        if (e.touches[0]) {
            handleSeek(e.touches[0].clientX);
        }
        
        const handleTouchMove = (moveEvent: TouchEvent) => {
            if (moveEvent.touches[0]) {
                handleSeek(moveEvent.touches[0].clientX);
            }
        };
        
        const handleTouchEnd = () => {
            setIsDragging(false);
            document.removeEventListener('touchmove', handleTouchMove);
            document.removeEventListener('touchend', handleTouchEnd);
        };
        
        document.addEventListener('touchmove', handleTouchMove, { passive: true });
        document.addEventListener('touchend', handleTouchEnd);
    };

    const handleVideoClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        const now = Date.now();
        const DOUBLE_TAP_DELAY = 300;

        if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
            // Double Tap Event!
            handleDoubleTap(e);
        } else {
            // Single Tap Event - toggle play/pause immediately
            if (videoRef.current) {
                if (isPlaying) {
                    videoRef.current.pause();
                    setIsPlaying(false);
                } else {
                    videoRef.current.play().catch(() => {});
                    setIsPlaying(true);
                }
            }
        }
        lastTapRef.current = now;
    };

    const handleDoubleTap = async (e: React.MouseEvent) => {
        // Calculate coordinate relative to container
        const rect = e.currentTarget.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const clickY = e.clientY - rect.top;

        // Calculate approximate position of the floating like button
        const targetX = rect.width - 40;
        const targetY = rect.height - 290;

        const newHeart = { id: Date.now(), x: clickX, y: clickY, targetX, targetY };
        setHeartAnimations(prev => [...prev, newHeart]);

        // Trigger haptic vibration if supported
        if (navigator.vibrate) {
            navigator.vibrate(40);
        }

        // Like the video if not liked already
        if (!isLiked) {
            await handleLikeToggle(e);
        }

        // Keep playing video
        if (videoRef.current && !isPlaying) {
            videoRef.current.play().catch(() => {});
            setIsPlaying(true);
        }
    };

    const handleMuteBtnClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        onMuteToggle();
        setShowVolumeBadge(true);
        setTimeout(() => setShowVolumeBadge(false), 800);
    };

    const handleLikeToggle = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (!currentUser) {
            onLogin();
            return;
        }

        const likeRef = db.collection('videos').doc(video.id).collection('likes').doc(currentUser.uid);
        const videoDocRef = db.collection('videos').doc(video.id);
        const videoAuthorId = video.authorId;

        try {
            if (isLiked) {
                await likeRef.delete();
                await videoDocRef.update({ likeCount: increment(-1) });
            } else {
                const batch = db.batch();
                batch.set(likeRef, { likedAt: serverTimestamp(), userId: currentUser.uid });
                batch.update(videoDocRef, { likeCount: increment(1) });

                // Send notification
                if (currentUser.uid !== videoAuthorId) {
                    const notificationRef = db.collection('users').doc(videoAuthorId).collection('notifications').doc();
                    batch.set(notificationRef, {
                        type: 'new_like',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name,
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        fromUserIsVerified: currentUser.isVerified || false,
                        postId: video.id,
                        videoId: video.id,
                        postType: 'video',
                        postTitle: `your video: "${video.title.substring(0, 20)}..."`,
                        postThumbnailUrl: video.thumbnailUrl || '',
                        createdAt: serverTimestamp(),
                        read: false
                    });
                }
                await batch.commit();
            }
        } catch (error) {
            console.error("Error liking video in reel:", error);
        }
    };

    const authorProfilePic = (currentUser && currentUser.uid === video.authorId)
        ? currentUser.profilePicUrl
        : (video.authorProfilePicUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(video.authorName)}`);

    return (
        <div 
            className="w-full h-full relative flex items-center justify-center bg-black select-none"
            onClick={handleVideoClick}
        >
            {/* Double Tap Floating/Flying Heart Animations */}
            <AnimatePresence>
                {heartAnimations.map((heart) => (
                    <motion.div
                        key={heart.id}
                        initial={{ scale: 0, opacity: 0, x: 0, y: 0, rotate: -15 }}
                        animate={{
                            scale: [0, 1.8, 1.4, 1.2, 0.15],
                            opacity: [0, 1, 1, 0.95, 0],
                            x: [0, 0, 0, (heart.targetX - heart.x) * 0.5, heart.targetX - heart.x],
                            y: [0, 0, 0, (heart.targetY - heart.y) * 0.5, heart.targetY - heart.y],
                            rotate: [-15, 15, -10, 0, 15]
                        }}
                        transition={{
                            duration: 0.9,
                            times: [0, 0.2, 0.45, 0.75, 1.0],
                            ease: [0.16, 1, 0.3, 1]
                        }}
                        onAnimationComplete={() => {
                            setHeartAnimations(prev => prev.filter(h => h.id !== heart.id));
                            setPulseLike(true);
                            setTimeout(() => setPulseLike(false), 400);
                        }}
                        className="absolute pointer-events-none z-50 text-red-500 flex items-center justify-center"
                        style={{
                            left: heart.x,
                            top: heart.y,
                            transform: 'translate(-50%, -50%)',
                        }}
                    >
                        <span className="material-symbols-outlined text-7xl font-black fill-current drop-shadow-[0_4px_20px_rgba(239,68,68,0.8)]">
                            favorite
                        </span>
                    </motion.div>
                ))}
            </AnimatePresence>
            {/* Centered White Options Modal for the 3-dot menu */}
            {showMoreMenu && (
                <div 
                    className="absolute inset-0 z-50 bg-black/70 flex items-center justify-center p-4 backdrop-blur-md" 
                    onClick={(e) => {
                        e.stopPropagation();
                        setShowMoreMenu(false);
                    }}
                >
                    {/* Centered Modal */}
                    <div 
                        className="bg-white rounded-[32px] w-full max-w-[420px] mx-4 shadow-2xl overflow-hidden border border-gray-100/50 animate-scale-up"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Modal Header */}
                        <div className="px-6 pt-6 pb-4 border-b border-gray-100 flex items-center justify-between">
                            <span className="font-extrabold text-gray-900 text-base tracking-wide">Options (विकल्प)</span>
                            <button
                                onClick={() => setShowMoreMenu(false)}
                                className="w-9 h-9 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700 transition-colors"
                            >
                                <span className="material-symbols-outlined text-lg">close</span>
                            </button>
                        </div>

                        {/* Modal Actions */}
                        <div className="p-6 flex flex-col gap-3">
                            {/* Auto Scroll Option */}
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    toggleAutoScroll();
                                    setShowMoreMenu(false);
                                }}
                                className="flex items-center justify-between px-5 py-4 bg-gray-50 hover:bg-gray-100 active:scale-[0.99] rounded-2xl text-gray-800 text-sm font-bold transition-all text-left w-full border border-gray-100"
                            >
                                <span className="flex items-center gap-4">
                                    <span className="material-symbols-outlined text-2xl text-red-600">
                                        {isAutoScroll ? 'sync' : 'sync_disabled'}
                                    </span>
                                    <div>
                                        <p className="font-extrabold text-gray-900 text-sm">Auto Scroll</p>
                                        <p className="text-xs text-gray-500 font-normal mt-0.5">स्वचालित रूप से अगला वीडियो चलाएं</p>
                                    </div>
                                </span>
                                <span className={`text-xs px-3.5 py-1.5 rounded-full font-black tracking-wider uppercase ${isAutoScroll ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-200 text-gray-600'}`}>
                                    {isAutoScroll ? 'ON' : 'OFF'}
                                </span>
                            </button>

                            {/* Report Option */}
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setShowMoreMenu(false);
                                    if (!currentUser) {
                                        onLogin();
                                        return;
                                    }
                                    setShowReportModal(true);
                                }}
                                className="flex items-center gap-4 px-5 py-4 bg-red-50/50 hover:bg-red-50 active:scale-[0.99] rounded-2xl text-red-600 text-sm font-bold transition-all text-left w-full border border-red-100/50"
                            >
                                <span className="material-symbols-outlined text-2xl text-red-600">flag</span>
                                <div>
                                    <p className="font-extrabold text-gray-900 text-sm">Report (रिपोर्ट करें)</p>
                                    <p className="text-xs text-red-500 font-normal mt-0.5">इस वीडियो के खिलाफ शिकायत दर्ज करें</p>
                                </div>
                            </button>

                            {/* CONDITIONAL EDIT/DELETE FOR VIDEO OWNER */}
                            {currentUser && currentUser.uid === video.authorId && (
                                <>
                                    {/* Edit Option */}
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setShowMoreMenu(false);
                                            setShowEditModal(true);
                                        }}
                                        className="flex items-center gap-4 px-5 py-4 bg-blue-50/50 hover:bg-blue-50 active:scale-[0.99] rounded-2xl text-blue-600 text-sm font-bold transition-all text-left w-full border border-blue-100/50"
                                    >
                                        <span className="material-symbols-outlined text-2xl text-blue-600">edit</span>
                                        <div>
                                            <p className="font-extrabold text-gray-900 text-sm">Edit Video (वीडियो बदलें)</p>
                                            <p className="text-xs text-blue-500 font-normal mt-0.5">शीर्षक और विवरण संपादित करें</p>
                                        </div>
                                    </button>

                                    {/* Delete Option */}
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setShowMoreMenu(false);
                                            setShowDeleteConfirm(true);
                                        }}
                                        className="flex items-center gap-4 px-5 py-4 bg-red-50/50 hover:bg-red-100 active:scale-[0.99] rounded-2xl text-red-600 text-sm font-bold transition-all text-left w-full border border-red-100/50"
                                    >
                                        <span className="material-symbols-outlined text-2xl text-red-600">delete</span>
                                        <div>
                                            <p className="font-extrabold text-gray-900 text-sm">Delete Video (वीडियो हटाएं)</p>
                                            <p className="text-xs text-red-500 font-normal mt-0.5">इस वीडियो को हमेशा के लिए हटा दें</p>
                                        </div>
                                    </button>
                                </>
                            )}
                        </div>

                        {/* Modal Footer */}
                        <div className="px-6 pb-6 pt-2">
                            <button
                                onClick={() => setShowMoreMenu(false)}
                                className="w-full py-4 bg-gray-100 hover:bg-gray-200 active:scale-[0.99] text-gray-800 rounded-2xl text-sm font-black text-center transition-all"
                            >
                                Cancel (रद्द करें)
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Edit Video Modal Overlay */}
            {showEditModal && (
                <div 
                    className="absolute inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-md"
                    onClick={(e) => {
                        e.stopPropagation();
                        setShowEditModal(false);
                    }}
                >
                    <div 
                        className="bg-white rounded-[32px] w-full max-w-[420px] mx-4 shadow-2xl overflow-hidden border border-gray-100 flex flex-col p-6 animate-scale-up text-gray-900"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                            <span className="font-extrabold text-gray-900 text-lg tracking-wide">Edit Video (वीडियो बदलें)</span>
                            <button
                                onClick={() => setShowEditModal(false)}
                                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700 transition-colors"
                            >
                                <span className="material-symbols-outlined text-sm">close</span>
                            </button>
                        </div>

                        <form onSubmit={handleSaveEdit} className="mt-4 space-y-4 text-left">
                            <div>
                                <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1">Title (शीर्षक) *</label>
                                <input
                                    type="text"
                                    value={editTitle}
                                    onChange={(e) => setEditTitle(e.target.value)}
                                    maxLength={150}
                                    required
                                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm text-gray-800 font-medium"
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1">Description (विवरण)</label>
                                <textarea
                                    value={editDescription}
                                    onChange={(e) => setEditDescription(e.target.value)}
                                    rows={4}
                                    maxLength={500}
                                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm text-gray-800 font-medium resize-none"
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-black text-gray-700 uppercase tracking-wider mb-1">Category (श्रेणी)</label>
                                <select
                                    value={editCategory}
                                    onChange={(e) => setEditCategory(e.target.value)}
                                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm text-gray-800 font-semibold"
                                >
                                    {['Politics', 'Crime', 'Sports', 'Entertainment', 'Business', 'Technology', 'Health', 'World', 'General'].map(cat => (
                                        <option key={cat} value={cat}>{cat}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="flex gap-3 pt-4 border-t border-gray-100">
                                <button
                                    type="button"
                                    onClick={() => setShowEditModal(false)}
                                    className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-black text-center transition-all"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={isSavingEdit}
                                    className="flex-1 py-3 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-xl text-xs font-black text-center shadow-md hover:shadow-lg transition-all active:scale-95 disabled:opacity-50"
                                >
                                    {isSavingEdit ? 'Saving...' : 'Save'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Delete Confirmation Modal Overlay */}
            {showDeleteConfirm && (
                <div 
                    className="absolute inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-md"
                    onClick={(e) => {
                        e.stopPropagation();
                        setShowDeleteConfirm(false);
                    }}
                >
                    <div 
                        className="bg-white rounded-[32px] w-full max-w-[360px] mx-4 shadow-2xl overflow-hidden border border-gray-100 flex flex-col p-6 animate-scale-up text-gray-900"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="text-center space-y-3">
                            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto border-2 border-red-100 text-red-500">
                                <span className="material-symbols-outlined text-3xl font-bold">delete</span>
                            </div>
                            <h3 className="font-extrabold text-gray-900 text-lg">Delete Video Bulletin?</h3>
                            <p className="text-sm text-gray-500">
                                Are you sure you want to delete this video? This action cannot be undone.
                            </p>
                        </div>

                        <div className="flex gap-3 mt-6">
                            <button
                                onClick={() => setShowDeleteConfirm(false)}
                                className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-black text-center transition-all"
                            >
                                Keep
                            </button>
                            <button
                                onClick={handleDeleteConfirm}
                                disabled={isDeleting}
                                className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black text-center shadow-md hover:shadow-lg transition-all active:scale-95 disabled:opacity-50"
                            >
                                {isDeleting ? 'Deleting...' : 'Delete'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* HTML5 Video Element */}
            <video
                ref={videoRef}
                src={video.videoUrl}
                loop={!isAutoScroll}
                muted={isMuted}
                playsInline
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={handleVideoEnded}
                className="w-full h-full object-cover md:object-contain bg-black"
                preload="auto"
            />

            {/* Play/Pause icon indicator overlay */}
            {!isPlaying && (
                <div className="absolute inset-0 bg-black/10 flex items-center justify-center pointer-events-none z-10">
                    <div className="w-16 h-16 rounded-full bg-black/50 text-white flex items-center justify-center animate-pulse">
                        <span className="material-symbols-outlined text-4xl">play_arrow</span>
                    </div>
                </div>
            )}

            {/* Volume feedback badge overlay */}
            {showVolumeBadge && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                    <div className="px-4 py-2 rounded-xl bg-black/75 text-white flex items-center gap-2 text-xs font-bold animate-fade-in">
                        <span className="material-symbols-outlined text-base">
                            {isMuted ? 'volume_off' : 'volume_up'}
                        </span>
                        {isMuted ? 'Muted' : 'Unmuted'}
                    </div>
                </div>
            )}

            {/* Top Bar for header styling */}
            <div className="absolute top-0 inset-x-0 h-20 bg-gradient-to-b from-black/60 to-transparent pointer-events-none z-10" />

            {/* Floating Mute/Unmute button top right */}
            <button
                onClick={handleMuteBtnClick}
                className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-sm transition-transform active:scale-90"
            >
                <span className="material-symbols-outlined text-xl">
                    {isMuted ? 'volume_off' : 'volume_up'}
                </span>
            </button>

            {/* Bottom Gradient overlay */}
            <div className="absolute bottom-0 inset-x-0 h-48 bg-gradient-to-t from-black/80 via-black/40 to-transparent pointer-events-none z-10" />

            {/* RIGHT SIDE FLOATING BUTTONS - NO OVERLAYS OR SHADOW BLOCKS - PURE PREMIUM FLOATING PNG/SVG LOOK */}
            <div className="absolute right-4 bottom-24 flex flex-col items-center gap-5 z-20">
                {/* Like Button */}
                <motion.button
                    onClick={handleLikeToggle}
                    animate={pulseLike ? { scale: [1, 1.4, 0.85, 1.15, 1] } : {}}
                    transition={{ duration: 0.45, ease: "easeInOut" }}
                    className="flex flex-col items-center group active:scale-110 transition-transform cursor-pointer"
                >
                    <div className="w-12 h-12 text-white flex items-center justify-center">
                        <span 
                            className={`material-symbols-outlined text-[30px] transition-all duration-200 ${
                                isLiked ? 'text-red-500 font-black scale-110' : 'text-white hover:text-red-400'
                            }`}
                            style={{ 
                                fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}`,
                                filter: 'drop-shadow(0px 1px 3px rgba(0,0,0,0.8))'
                            }}
                        >
                            favorite
                        </span>
                    </div>
                    <span className="text-xs text-white font-extrabold mt-0.5" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
                        {formatCount(likeCount)}
                    </span>
                </motion.button>

                {/* Comment Button */}
                <button
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        onCommentBoxClick();
                    }}
                    className="flex flex-col items-center active:scale-110 transition-transform"
                >
                    <div className="w-12 h-12 text-white flex items-center justify-center">
                        <span 
                            className="material-symbols-outlined text-[30px] hover:text-white/85"
                            style={{ filter: 'drop-shadow(0px 1px 3px rgba(0,0,0,0.8))' }}
                        >
                            chat_bubble
                        </span>
                    </div>
                    <span className="text-xs text-white font-extrabold mt-0.5" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
                        {formatCount(commentCount)}
                    </span>
                </button>

                {/* Universal Share Button */}
                <button
                    onClick={(e) => {
                        e.stopPropagation();
                        onShareClick();
                    }}
                    className="flex flex-col items-center hover:scale-110 active:scale-95 transition-transform"
                    title="Share"
                >
                    <div className="w-12 h-12 text-white flex items-center justify-center">
                        <span 
                            className="material-symbols-outlined text-3xl"
                            style={{ filter: 'drop-shadow(0px 1px 3px rgba(0,0,0,0.8))' }}
                        >
                            share
                        </span>
                    </div>
                    <span className="text-xs text-white font-extrabold mt-0.5" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
                        {formatCount(shareCount)}
                    </span>
                </button>

                {/* More vertical options button (3-dot) */}
                <div className="relative">
                    <button
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setShowMoreMenu(prev => !prev);
                        }}
                        className="flex flex-col items-center active:scale-110 transition-transform"
                    >
                        <div className="w-12 h-12 text-white flex items-center justify-center">
                            <span 
                                className="material-symbols-outlined text-[30px] hover:text-white/80"
                                style={{ filter: 'drop-shadow(0px 1px 3px rgba(0,0,0,0.8))' }}
                            >
                                more_vert
                            </span>
                        </div>
                    </button>
                </div>
            </div>

            {/* BOTTOM LEFT OVERLAYS & CAPTIONS - AS PER SCREENSHOT 1 */}
            <div className="absolute bottom-20 left-4 right-18 z-20 text-white text-shadow flex flex-col gap-2.5 pointer-events-none">
                {/* Author Info & Follow Button */}
                <div className="flex items-center gap-2.5 pointer-events-auto">
                    <UserAvatar
                        userId={video.authorId}
                        src={video.authorProfilePicUrl}
                        name={video.authorName}
                        currentUser={currentUser}
                        className="w-10 h-10 rounded-full object-cover border-2 border-white ring-1 ring-black/20 shadow-md cursor-pointer hover:scale-105 transition-transform"
                        onClick={(e) => {
                            e.stopPropagation();
                            onViewUser(video.authorId);
                        }}
                    />
                    <div className="flex flex-col">
                        <div className="flex items-center gap-1.5 flex-wrap">
                            <span 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onViewUser(video.authorId);
                                }}
                                className="font-bold text-sm tracking-wide cursor-pointer hover:underline"
                            >
                                {video.authorName.replace(/\s+/g, '_').toLowerCase()}
                            </span>
                            {(isAuthorVerified || video.authorIsVerified || (currentUser && currentUser.uid === video.authorId && currentUser.isVerified)) && (
                                <span className="material-symbols-outlined text-blue-400 text-sm font-black shrink-0" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                            )}

                            {(!currentUser || currentUser.uid !== video.authorId) && !isFollowing && (
                                <button
                                    onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        onFollowToggle(video.authorId, video.authorName);
                                    }}
                                    className="ml-2 px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border border-white/50 animate-follow-blink shadow-lg shadow-red-600/50 hover:scale-105 active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
                                    title="Follow Creator"
                                >
                                    <span className="material-symbols-outlined text-[13px] font-black">person_add</span>
                                    <span>Follow</span>
                                </button>
                            )}
                        </div>
                        {/* Audio track label simulation */}
                        <div className="flex items-center gap-1 text-[10px] text-gray-300 font-bold mt-0.5 uppercase tracking-wider">
                            <span className="material-symbols-outlined text-xs">music_note</span>
                            <span>{video.authorName} • Original Audio</span>
                        </div>
                    </div>
                </div>

                {/* Video Caption Description */}
                <div className="pointer-events-auto max-w-xs">
                    <p className="text-sm font-medium leading-relaxed break-words" style={{ textShadow: '0 1px 4px rgba(0,0,0,0.9)' }}>
                        {isExpanded ? (
                            <>
                                {video.title}
                                {video.description && (
                                    <span className="block mt-1.5 text-xs text-gray-200 font-normal leading-relaxed">
                                        {video.description}
                                    </span>
                                )}
                                <button 
                                    onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setIsExpanded(false);
                                    }}
                                    className="ml-1 text-red-400 hover:text-red-300 font-bold text-xs cursor-pointer select-none"
                                >
                                    See Less
                                </button>
                            </>
                        ) : (
                            <>
                                {video.title.length > 75 ? (
                                    <>
                                        {video.title.substring(0, 75)}...
                                        <button 
                                            onClick={(e) => {
                                                e.preventDefault();
                                                e.stopPropagation();
                                                setIsExpanded(true);
                                            }}
                                            className="ml-1 text-red-400 hover:text-red-300 font-extrabold text-xs cursor-pointer select-none hover:underline"
                                        >
                                            See More
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        {video.title}
                                        {video.description && (
                                            <button 
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    e.stopPropagation();
                                                    setIsExpanded(true);
                                                }}
                                                className="ml-1 text-red-400 hover:text-red-300 font-extrabold text-xs cursor-pointer select-none hover:underline"
                                            >
                                                See More
                                            </button>
                                        )}
                                    </>
                                )}
                            </>
                        )}
                    </p>
                </div>
            </div>

            {/* EXPLICIT COMMENT BOX INPUT "Add comment..." - AS PER SCREENSHOT 1 */}
            <div className="absolute bottom-4 inset-x-4 z-20 flex gap-2 items-center">
                <div 
                    onClick={(e) => {
                        e.stopPropagation();
                        onCommentBoxClick();
                    }}
                    className="flex-1 bg-black/40 hover:bg-black/60 border border-white/20 hover:border-white/40 p-3 px-4 rounded-full text-xs text-white/70 font-semibold cursor-pointer select-none backdrop-blur-md transition-all flex items-center gap-2"
                >
                    <span className="material-symbols-outlined text-base">chat_bubble_outline</span>
                    <span>Add comment...</span>
                </div>
            </div>

            {/* Playback sleek bottom interactive seek bar */}
            <div 
                ref={progressBarRef}
                onMouseDown={handleMouseDown}
                onTouchStart={handleTouchStart}
                className="absolute bottom-0 inset-x-0 h-6 flex items-end cursor-pointer z-30 group/timeline select-none"
            >
                <div className="w-full bg-white/20 h-1.5 group-hover/timeline:h-2.5 transition-all relative overflow-visible">
                    {/* Red active track */}
                    <div 
                        className="h-full bg-red-600"
                        style={{ width: `${progress}%` }}
                    />
                    
                    {/* Circle thumb that expands on hover or dragging */}
                    <div 
                        className="absolute w-3.5 h-3.5 group-hover/timeline:w-4.5 group-hover/timeline:h-4.5 bg-white rounded-full shadow-lg border-2 border-red-600 top-1/2 -translate-y-1/2 -ml-1.5 group-hover/timeline:-ml-2 transition-all pointer-events-none"
                        style={{ left: `${progress}%` }}
                    />

                    {/* Hover time indicator */}
                    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black/90 text-white text-[11px] font-black px-2.5 py-1 rounded-full opacity-0 group-hover/timeline:opacity-100 transition-opacity pointer-events-none shadow-xl border border-white/10 flex items-center gap-1.5 select-none font-mono">
                        <span className="text-red-500">{formatTime(currentTime)}</span>
                        <span className="text-white/30">/</span>
                        <span className="text-white/80">{formatTime(duration)}</span>
                    </div>
                </div>
            </div>

            {/* Video Report Form Modal */}
            {showReportModal && currentUser && (
                <ReportModal
                    video={video}
                    user={currentUser}
                    onClose={() => setShowReportModal(false)}
                    onSuccess={() => setShowReportModal(false)}
                />
            )}
        </div>
    );
});

export default ReelItem;
