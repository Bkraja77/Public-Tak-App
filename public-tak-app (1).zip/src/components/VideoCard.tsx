import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion } from 'framer-motion';
import { Video, User } from '../types';
import { db, serverTimestamp, increment } from '../firebaseConfig';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { formatCount } from '../utils/formatters';
import ConfirmationModal from './ConfirmationModal';
import UserAvatar from './UserAvatar';

interface VideoCardProps {
    video: Video;
    currentUser: User | null;
    onLogin: () => void;
    onViewUser: (userId: string) => void;
    isFollowing: boolean;
    onFollowToggle: (authorId: string, authorName: string) => void;
    onPlay: () => void;
    onCommentClick: () => void;
    onShareClick: () => void;
    onReport: (video: Video) => void;
    isMobile?: boolean;
    isActive?: boolean;
    reelsActive?: boolean;
}

const VideoCard: React.FC<VideoCardProps> = React.memo(({
    video,
    currentUser,
    onLogin,
    onViewUser,
    isFollowing,
    onFollowToggle,
    onPlay,
    onCommentClick,
    onShareClick,
    onReport,
    isMobile = false,
    isActive = false,
    reelsActive = false
}) => {
    const [isMuted, setIsMuted] = useState(true);
    const [localMuted, setLocalMuted] = useState<boolean | null>(null);
    const [isHovered, setIsHovered] = useState(false);
    const videoRef = useRef<HTMLVideoElement>(null);
    const [likeCount, setLikeCount] = useState(video.likeCount || 0);
    const [commentCount, setCommentCount] = useState(video.commentCount || 0);
    const [shareCount, setShareCount] = useState(video.shareCount || 0);
    const [isLiked, setIsLiked] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const { t } = useLanguage();
    const { showToast } = useToast();

    useEffect(() => {
        setShareCount(video.shareCount || 0);
    }, [video.shareCount]);

    useEffect(() => {
        const likesRef = db.collection('videos').doc(video.id).collection('likes');
        const unsubLikes = likesRef.onSnapshot((snapshot) => {
            setLikeCount(snapshot.size);
            if (currentUser) {
                setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid));
            } else {
                setIsLiked(false);
            }
        });

        const commentsRef = db.collection('videos').doc(video.id).collection('comments');
        const unsubComments = commentsRef.onSnapshot((snapshot) => {
            setCommentCount(snapshot.size);
        });

        const sharesRef = db.collection('videos').doc(video.id).collection('shares');
        const unsubShares = sharesRef.onSnapshot((snapshot) => {
            setShareCount(prev => Math.max(prev, snapshot.size, video.shareCount || 0));
        }, () => {});

        return () => {
            unsubLikes();
            unsubComments();
            unsubShares();
        };
    }, [video.id, currentUser]);

    const [isAuthorVerified, setIsAuthorVerified] = useState<boolean>(
        Boolean(video.authorIsVerified || (currentUser && currentUser.uid === video.authorId && currentUser.isVerified))
    );

    useEffect(() => {
        if (video.authorIsVerified || (currentUser && currentUser.uid === video.authorId && currentUser.isVerified)) {
            setIsAuthorVerified(true);
            return;
        }
        if (video.authorId) {
            const unsubAuthor = db.collection('users').doc(video.authorId).onSnapshot((doc) => {
                if (doc.exists && doc.data()?.isVerified) {
                    setIsAuthorVerified(true);
                }
            }, () => {});
            return () => unsubAuthor();
        }
    }, [video.authorId, video.authorIsVerified, currentUser]);

    const isCurrentUserVideo = currentUser && currentUser.uid === video.authorId;
    const authorName = video.authorName;
    const authorProfilePicUrl = (isCurrentUserVideo && currentUser)
        ? currentUser.profilePicUrl
        : (video.authorProfilePicUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(authorName)}`);

    const handleLike = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (!currentUser) {
            showToast("Please log in to like videos.", "info");
            onLogin();
            return;
        }

        const likeRef = db.collection('videos').doc(video.id).collection('likes').doc(currentUser.uid);
        const videoAuthorId = video.authorId;
        const videoDocRef = db.collection('videos').doc(video.id);

        try {
            if (isLiked) {
                await likeRef.delete();
                await videoDocRef.update({ likeCount: increment(-1) });
            } else {
                const batch = db.batch();
                batch.set(likeRef, { likedAt: serverTimestamp(), userId: currentUser.uid });
                batch.update(videoDocRef, { likeCount: increment(1) });

                if (currentUser.uid !== videoAuthorId) {
                    const notificationRef = db.collection('users').doc(videoAuthorId).collection('notifications').doc();
                    batch.set(notificationRef, {
                        type: 'new_like',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name,
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        fromUserIsVerified: currentUser.isVerified || false,
                        postId: video.id,
                        videoId: video.id,
                        postType: 'video',
                        postTitle: `your video: "${video.title.substring(0, 20)}..."`,
                        postThumbnailUrl: video.thumbnailUrl || '',
                        createdAt: serverTimestamp(),
                        read: false
                    });
                }

                await batch.commit();
            }
        } catch (error) {
            console.error("Error liking video:", error);
            showToast("Could not like video.", "error");
        }
    };

    const handleFollowClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        onFollowToggle(video.authorId, video.authorName);
    };

    const finalMuted = useMemo(() => {
        if (reelsActive) return true;
        if (isMobile) {
            if (localMuted !== null) return localMuted;
            return !isActive;
        }
        if (isHovered) return false;
        return isMuted;
    }, [reelsActive, isMobile, isActive, isMuted, localMuted, isHovered]);

    // Reset local override when active state changes
    useEffect(() => {
        setLocalMuted(null);
    }, [isActive]);

    // Sync volume/muted properties reactively
    useEffect(() => {
        if (videoRef.current) {
            videoRef.current.muted = finalMuted;
        }
    }, [finalMuted]);

    // Control video playback based on active screen visibility on mobile or reel modal active
    useEffect(() => {
        if (videoRef.current) {
            if (reelsActive) {
                videoRef.current.pause();
            } else if (isMobile) {
                if (isActive) {
                    videoRef.current.play().catch(err => {
                        console.warn("Autoplay blocked or failed:", err);
                    });
                } else {
                    videoRef.current.pause();
                }
            } else {
                if (isHovered) {
                    videoRef.current.play().catch(() => {});
                }
            }
        }
    }, [reelsActive, isMobile, isActive, isHovered]);

    const handleMuteToggle = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (isMobile) {
            setLocalMuted(!finalMuted);
        } else {
            setIsMuted(!isMuted);
        }
    };

    const handleReportClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsMenuOpen(false);
        onReport(video);
    };

    const handleDeleteClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsMenuOpen(false);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        try {
            await db.collection("videos").doc(video.id).delete();
            showToast("Video deleted successfully.", "success");
        } catch (error: any) {
            console.error("Error deleting video:", error);
            showToast(`Failed to delete video: ${error.message || "Unknown error"}`, "error");
        } finally {
            setIsDeleteModalOpen(false);
        }
    };

    const timeAgo = useMemo(() => {
        if (!video.createdAt) return 'N/A';
        const now = new Date();
        const seconds = Math.floor((now.getTime() - video.createdAt.getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + "y ago";
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + "mo ago";
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + "d ago";
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + "h ago";
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + "m ago";
        return Math.floor(seconds) + "s ago";
    }, [video.createdAt]);

    return (
        <motion.div
            onClick={onPlay}
            onMouseEnter={() => {
                if (!isMobile) {
                    setIsHovered(true);
                }
            }}
            onMouseLeave={() => {
                if (!isMobile) {
                    setIsHovered(false);
                }
            }}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ 
                y: -10, 
                scale: 1.02,
                boxShadow: "0 25px 50px -12px rgba(220, 38, 38, 0.15), 0 10px 10px -5px rgba(220, 38, 38, 0.04)",
                borderColor: "rgba(239, 68, 68, 0.3)",
                transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } 
            }}
            className="glass-card overflow-hidden bg-white dark:bg-slate-900/80 border border-gray-100 dark:border-slate-800/80 cursor-pointer transition-all flex flex-col h-full rounded-2xl group relative shadow-sm"
        >
            {/* Header: Author Info */}
            <div className="p-3 flex items-start gap-2 border-b border-gray-50/50 dark:border-slate-800/50 group-hover:border-red-100/50 transition-colors">
                <UserAvatar
                    userId={video.authorId}
                    src={video.authorProfilePicUrl}
                    name={authorName}
                    currentUser={currentUser}
                    onClick={(e) => { e.stopPropagation(); onViewUser(video.authorId); }}
                    className="w-10 h-10 rounded-full object-cover cursor-pointer ring-2 ring-white dark:ring-slate-800 shadow-md relative z-20 transition-transform group-hover:scale-110 active:scale-90 shrink-0"
                />
                <div className="flex-grow min-w-0 relative z-20 pt-0.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                        <p onClick={(e) => { e.stopPropagation(); onViewUser(video.authorId); }} className="font-black text-gray-900 dark:text-gray-100 cursor-pointer group-hover:text-red-600 text-sm transition-colors break-words">
                            {authorName}
                        </p>
                        {(isAuthorVerified || video.authorIsVerified || (isCurrentUserVideo && currentUser?.isVerified)) && (
                            <span className="material-symbols-outlined text-blue-500 text-[16px] font-bold shrink-0 align-middle inline-flex items-center" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                        )}

                        {!isCurrentUserVideo && (
                            <motion.button
                                whileHover={{ scale: 1.08 }}
                                whileTap={{ scale: 0.92 }}
                                onClick={handleFollowClick}
                                className={`
                                    px-3 py-1 text-[9px] font-black uppercase tracking-widest rounded-full transition-all duration-300 shadow-sm z-30 border inline-flex items-center gap-1
                                    ${isFollowing
                                        ? 'bg-gray-100 dark:bg-slate-800 text-gray-500 border-gray-200 dark:border-slate-700'
                                        : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border-red-500 animate-follow-blink shadow-md shadow-red-500/30'}
                                `}
                            >
                                {isFollowing ? (
                                    <>
                                        <span className="material-symbols-outlined text-[12px] font-black">done</span>
                                        {t('following') || 'Following'}
                                    </>
                                ) : (
                                    <>
                                        <span className="material-symbols-outlined text-[12px] font-black">person_add</span>
                                        {t('follow') || 'Follow'}
                                    </>
                                )}
                            </motion.button>
                        )}
                    </div>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter mt-0.5">{timeAgo}</p>
                </div>
            </div>

            {/* Thumbnail / Cover Area */}
            <div className="relative w-full aspect-video sm:h-44 overflow-hidden bg-slate-950 flex-shrink-0">
                {video.videoUrl ? (
                    <video
                        ref={videoRef}
                        src={video.videoUrl}
                        poster={video.thumbnailUrl || "https://images.unsplash.com/photo-1495020689067-958852a6565d?auto=format&fit=crop&q=80&w=600"}
                        className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500"
                        autoPlay
                        loop
                        muted={finalMuted}
                        playsInline
                        preload="metadata"
                    />
                ) : (
                    <img
                        src={video.thumbnailUrl || "https://images.unsplash.com/photo-1495020689067-958852a6565d?auto=format&fit=crop&q=80&w=600"}
                        alt={video.title}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500"
                    />
                )}

                {/* Category overlay */}
                <span className="absolute top-3 left-3 bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm z-10">
                    {video.category}
                </span>

                {/* Mute/Unmute Control button */}
                {video.videoUrl && (
                    <button
                        onClick={handleMuteToggle}
                        className="absolute top-3 right-3 bg-black/60 hover:bg-black/80 text-white p-1.5 rounded-full z-30 flex items-center justify-center transition-colors shadow-md border border-white/10"
                        title={finalMuted ? "Unmute" : "Mute"}
                    >
                        <span className="material-symbols-outlined text-sm font-black select-none">
                            {finalMuted ? "volume_off" : "volume_up"}
                        </span>
                    </button>
                )}

                {/* Location Info Banner overlay */}
                {(video.block || video.district || video.state) && (
                    <div className="absolute bottom-2 left-2 bg-black/70 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 backdrop-blur-sm shadow-sm z-10">
                        <span className="material-symbols-outlined text-xs">location_on</span>
                        <span className="truncate max-w-[150px]">
                            {video.block || video.district || video.state}
                        </span>
                    </div>
                )}
            </div>

            {/* Content Area */}
            <div className="p-4 flex-grow flex flex-col justify-between">
                <div>
                    <h3 className="font-bold text-sm text-gray-900 dark:text-white line-clamp-2 leading-snug group-hover:text-red-600 transition-colors">
                        {video.title}
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                        {video.description || 'कोई अतिरिक्त विवरण उपलब्ध नहीं है।'}
                    </p>
                </div>
            </div>

            {/* Footer Interactive Icons (Like, Comment, Share, Views) */}
            <div className="px-4 py-2 border-t border-gray-50 dark:border-slate-800/80 flex justify-between items-center text-gray-400 bg-white dark:bg-slate-900/95 mt-auto relative z-20">
                <div className="flex items-center gap-2">
                    {/* Views */}
                    <div className="flex items-center gap-1 p-2" title="Views">
                        <span className="material-symbols-outlined text-lg">visibility</span>
                        <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">{formatCount(video.viewCount || 0)}</span>
                    </div>

                    {/* Likes */}
                    <button
                        onClick={handleLike}
                        className={`flex items-center gap-1 transition-colors group/like p-2 rounded-full hover:bg-red-50 dark:hover:bg-red-950/30 relative z-30 ${isLiked ? 'text-red-500' : 'hover:text-red-500'}`}
                        title="Likes"
                    >
                        <span
                            className="material-symbols-outlined text-lg transition-all"
                            style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}` }}
                        >
                            favorite
                        </span>
                        <span className="text-xs font-semibold">{formatCount(likeCount)}</span>
                    </button>

                    {/* Comments */}
                    <button
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onCommentClick();
                        }}
                        className="flex items-center gap-1 hover:text-blue-600 dark:hover:text-blue-400 transition-colors p-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/30 relative z-30"
                        title="Comments"
                    >
                        <span className="material-symbols-outlined text-lg">chat_bubble</span>
                        <span className="text-xs font-semibold">{formatCount(commentCount)}</span>
                    </button>

                    {/* Share Button */}
                    <button
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onShareClick();
                        }}
                        className="flex items-center gap-1 text-blue-600 hover:text-blue-700 transition-colors p-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-950/30 relative z-30"
                        title="Share"
                    >
                        <span className="material-symbols-outlined text-lg">share</span>
                        <span className="text-xs font-semibold">{formatCount(shareCount)}</span>
                    </button>
                </div>

                {/* 3-dot menu */}
                <div className="relative z-30">
                    <button 
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setIsMenuOpen(v => !v); }} 
                        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-400"
                        title="More options"
                    >
                        <span className="material-symbols-outlined text-lg">more_vert</span>
                    </button>
                    {isMenuOpen && (
                        <div className="absolute bottom-full right-0 mb-1 w-32 bg-white dark:bg-slate-900 rounded-lg shadow-xl border border-gray-100 dark:border-slate-800 overflow-hidden z-40">
                            {(isCurrentUserVideo || currentUser?.role === 'admin') && (
                                <button 
                                    onClick={handleDeleteClick} 
                                    className="flex items-center gap-2 w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                                >
                                    <span className="material-symbols-outlined text-sm">delete</span>
                                    {t('delete') || 'Delete'}
                                </button>
                            )}
                            <button 
                                onClick={handleReportClick} 
                                className="flex items-center gap-2 w-full text-left px-3 py-2 text-xs text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors"
                            >
                                <span className="material-symbols-outlined text-sm">flag</span>
                                {t('report') || 'Report'}
                            </button>
                        </div>
                    )}
                </div>
            </div>

            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="Delete Video"
                message="Are you sure you want to delete this video? This action cannot be undone."
                confirmButtonText="Delete"
                confirmButtonColor="bg-red-600 hover:bg-red-700"
            />
        </motion.div>
    );
});

export default VideoCard;
