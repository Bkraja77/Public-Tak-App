import React, { useState, useEffect } from 'react';
import { useUserAvatar } from '../services/userProfileCache';
import { User } from '../types';

export interface UserAvatarProps {
  userId?: string | null;
  src?: string | null;
  name?: string | null;
  alt?: string;
  className?: string;
  currentUser?: User | null;
  onClick?: (e: React.MouseEvent<HTMLImageElement>) => void;
  loading?: 'lazy' | 'eager';
  title?: string;
}

export const UserAvatar: React.FC<UserAvatarProps> = ({
  userId,
  src,
  name,
  alt = '',
  className = 'w-10 h-10 rounded-full object-cover aspect-square',
  currentUser,
  onClick,
  loading = 'lazy',
  title,
}) => {
  const resolvedUrl = useUserAvatar(userId, src, name, currentUser);
  const [hasError, setHasError] = useState(false);

  // Reset error state whenever the URL changes (e.g. user updated avatar)
  useEffect(() => {
    setHasError(false);
  }, [resolvedUrl]);

  const defaultAvatar = `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(name || 'User')}`;
  const displaySrc = hasError || !resolvedUrl ? defaultAvatar : resolvedUrl;

  return (
    <img
      src={displaySrc}
      alt={alt || name || 'Profile'}
      title={title || name || ''}
      className={className}
      loading={loading}
      onClick={onClick}
      onError={() => {
        if (!hasError) {
          setHasError(true);
        }
      }}
    />
  );
};

export default UserAvatar;
