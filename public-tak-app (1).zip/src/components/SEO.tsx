
import * as React from 'react';
import { APP_LOGO_URL } from '../utils/constants';

interface SEOProps {
  title: string;
  description: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'video' | 'profile' | 'epaper';
  publishedAt?: string;
  author?: string;
  keywords?: string;
  videoUrl?: string;
}

const DEFAULT_KEYWORDS = "Public Tak App, Public Tak News, Hindi News App, Local News Reporter, Bihar Local News, Jharkhand Local News, Breaking News India, Daily EPaper, Video News Bulletin, Crime News, Politics News";

const SEO: React.FC<SEOProps> = ({ 
  title, 
  description, 
  image = APP_LOGO_URL, 
  url = typeof window !== 'undefined' ? window.location.href : 'https://publictak.app/', 
  type = 'website',
  publishedAt,
  author,
  keywords = DEFAULT_KEYWORDS,
  videoUrl
}) => {
  React.useEffect(() => {
    try {
      const siteTitle = 'Public Tak App';
      const cleanTitle = typeof title === 'string' ? title.replace(/<[^>]*>?/gm, '').trim() : 'Public Tak App';
      const displayTitle = cleanTitle === siteTitle || cleanTitle === 'Home' || !cleanTitle 
        ? `${siteTitle} | Taza Khabar, Local News Reporter & E-Paper` 
        : cleanTitle.includes(siteTitle) ? cleanTitle : `${cleanTitle} | ${siteTitle}`;
      
      document.title = displayTitle;

      const cleanDescription = typeof description === 'string' 
        ? description.replace(/<[^>]*>?/gm, '').substring(0, 160).trim() 
        : 'Public Tak App par paayein apne kshetra aur rajya ki sabse tez evam taza khabrein, video reels, reporter updates aur daily e-paper online.';
      
      // Ensure absolute image URL
      let absoluteImage = image || APP_LOGO_URL;
      if (absoluteImage && typeof absoluteImage === 'string' && !absoluteImage.startsWith('http')) {
          const origin = typeof window !== 'undefined' ? window.location.origin : 'https://publictak.app';
          absoluteImage = `${origin}${absoluteImage.startsWith('/') ? '' : '/'}${absoluteImage}`;
      }

      const setMetaTag = (attrName: string, attrValue: string, contentValue: string) => {
        if (!contentValue || typeof contentValue !== 'string') return;
        let element = document.querySelector(`meta[${attrName}="${attrValue}"]`);
        if (!element) {
          element = document.createElement('meta');
          element.setAttribute(attrName, attrValue);
          document.head.appendChild(element);
        }
        element.setAttribute('content', contentValue);
      };

      setMetaTag('name', 'description', cleanDescription);
      setMetaTag('name', 'keywords', keywords);
      setMetaTag('name', 'robots', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
      
      const ogType = type === 'article' ? 'article' : type === 'video' ? 'video.other' : 'website';
      setMetaTag('property', 'og:type', ogType);
      setMetaTag('property', 'og:url', url);
      setMetaTag('property', 'og:title', cleanTitle || displayTitle);
      setMetaTag('property', 'og:description', cleanDescription);
      setMetaTag('property', 'og:image', absoluteImage);
      setMetaTag('property', 'og:image:secure_url', absoluteImage);
      setMetaTag('property', 'og:image:width', '1200');
      setMetaTag('property', 'og:image:height', '630');
      setMetaTag('property', 'og:site_name', siteTitle);
      setMetaTag('property', 'og:locale', 'hi_IN');
      
      setMetaTag('name', 'twitter:card', 'summary_large_image');
      setMetaTag('name', 'twitter:title', cleanTitle || displayTitle);
      setMetaTag('name', 'twitter:description', cleanDescription);
      setMetaTag('name', 'twitter:image', absoluteImage);

      let canonical = document.querySelector('link[rel="canonical"]');
      if (!canonical) {
          canonical = document.createElement('link');
          canonical.setAttribute('rel', 'canonical');
          document.head.appendChild(canonical);
      }
      canonical.setAttribute('href', url);

      // JSON-LD for Search Engines
      let script = document.querySelector('script[type="application/ld+json"]');
      if (!script) {
          script = document.createElement('script');
          script.setAttribute('type', 'application/ld+json');
          document.head.appendChild(script);
      }

      let schemaData: any = {};

      if (type === 'article') {
        schemaData = {
          "@context": "https://schema.org",
          "@type": "NewsArticle",
          "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": url
          },
          "headline": cleanTitle,
          "description": cleanDescription,
          "image": [absoluteImage],
          "datePublished": publishedAt || new Date().toISOString(),
          "dateModified": publishedAt || new Date().toISOString(),
          "author": [{
            "@type": "Person",
            "name": author || "Public Tak Verified Reporter"
          }],
          "publisher": {
            "@type": "NewsMediaOrganization",
            "name": "Public Tak App",
            "url": "https://publictak.app/",
            "logo": {
              "@type": "ImageObject",
              "url": absoluteImage
            }
          }
        };
      } else if (type === 'video') {
        schemaData = {
          "@context": "https://schema.org",
          "@type": "VideoObject",
          "name": cleanTitle,
          "description": cleanDescription,
          "thumbnailUrl": [absoluteImage],
          "uploadDate": publishedAt || new Date().toISOString(),
          "contentUrl": videoUrl || url,
          "embedUrl": url,
          "publisher": {
            "@type": "Organization",
            "name": "Public Tak App",
            "logo": {
              "@type": "ImageObject",
              "url": absoluteImage
            }
          }
        };
      } else if (type === 'profile') {
        schemaData = {
          "@context": "https://schema.org",
          "@type": "ProfilePage",
          "mainEntity": {
            "@type": "Person",
            "name": author || cleanTitle,
            "description": cleanDescription,
            "image": absoluteImage
          }
        };
      } else {
        schemaData = {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "NewsMediaOrganization",
              "@id": "https://publictak.app/#organization",
              "name": "Public Tak App",
              "url": "https://publictak.app/",
              "logo": {
                "@type": "ImageObject",
                "url": absoluteImage
              },
              "sameAs": [
                "https://facebook.com/publictakapp",
                "https://twitter.com/publictakapp"
              ]
            },
            {
              "@type": "WebSite",
              "@id": "https://publictak.app/#website",
              "url": "https://publictak.app/",
              "name": "Public Tak App",
              "description": cleanDescription,
              "publisher": {
                "@id": "https://publictak.app/#organization"
              },
              "potentialAction": {
                "@type": "SearchAction",
                "target": "https://publictak.app/?search={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            }
          ]
        };
      }

      script.textContent = JSON.stringify(schemaData);
    } catch (err) {
      console.warn("SEO Component error (likely non-string props):", err);
    }
  }, [title, description, image, url, type, publishedAt, author, keywords, videoUrl]);

  return null;
};

export default SEO;

