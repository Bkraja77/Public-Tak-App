
import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { View, User } from './types';
import HomePage from './pages/HomePage';
import VideoHomePage from './pages/VideoHomePage';
import SettingsPage from './pages/SettingsPage';
import FeedbackPage from './pages/FeedbackPage';
import PrivacyPage from './pages/PrivacyPage';
import TermsPage from './pages/TermsPage';
import AboutPage from './pages/AboutPage';
import AdminPage from './pages/AdminPage';
import UserPage from './pages/UserPage';
import LoginPage from './pages/LoginPage';
import CreatePostPage from './pages/CreatePostPage';
import EditPostPage from './pages/EditPostPage';
import EditProfilePage from './pages/EditProfilePage';
import ManageUsersPage from './pages/ManageUsersPage';
import AnalyticsPage from './pages/AnalyticsPage';
import ModerateContentPage from './pages/ModerateContentPage';
import NotificationsPage from './pages/NotificationsPage';
import SiteSettingsPage from './pages/SiteSettingsPage';
import SearchPage from './pages/SearchPage';
import BottomNavBar from './components/BottomNavBar';
import PostDetailPage from './pages/PostDetailPage';
import { auth, db, messaging, serverTimestamp, firebase, increment } from './firebaseConfig';
import PublicProfilePage from './pages/PublicProfilePage';
import AdminEditUserPage from './pages/AdminEditUserPage';
import ManageAccountPage from './pages/ManageAccountPage';
import ChangePasswordPage from './pages/ChangePasswordPage';
import ManageAdsPage from './pages/ManageAdsPage';
import ViewFeedbackPage from './pages/ViewFeedbackPage';
import CreatorDashboard from './pages/CreatorDashboard';
import MonetizationPage from './pages/MonetizationPage';
import ManageMonetizationPage from './pages/ManageMonetizationPage';
import Leaderboard from './pages/Leaderboard';
import ReferralPage from './pages/ReferralPage';
import WithdrawalPage from './pages/WithdrawalPage';
import VerificationPage from './pages/VerificationPage';
import KYCPage from './pages/KYCPage';
import ManageKYCPage from './pages/ManageKYCPage';
import ManageWithdrawalsPage from './pages/ManageWithdrawalsPage';
import EPaperPage from './pages/EPaperPage';
import ReporterRegistrationPage from './pages/ReporterRegistrationPage';
import ReporterIdCardPage from './pages/ReporterIdCardPage';
import ManageReportersPage from './pages/ManageReportersPage';
import OfflinePage from './pages/OfflinePage';
import ErrorBoundary from './components/ErrorBoundary';
import { LanguageProvider } from './contexts/LanguageContext';
import { ToastProvider, useToast } from './contexts/ToastContext';
import Sidebar from './components/Sidebar';
import { PushNotificationToast } from './components/PushNotificationToast';
import { APP_LOGO_URL, VAPID_KEY } from './utils/constants';
import appCacheService from './services/appCacheService';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';

// Sound effect for foreground notifications
const NOTIFICATION_SOUND_URL = '/publictak_notification.mp3'; // Custom mp3 file provided by the user

// Helper to synchronously parse incoming deep links at mount time (prevents home-page flash)
function getInitialDeepLink(): {
  view: View;
  postId: string | null;
  videoId: string | null;
  userId: string | null;
  reporterId: string | null;
  page: string | null;
  isDeepLink: boolean;
} {
  if (typeof window === 'undefined') {
    return { view: View.Main, postId: null, videoId: null, userId: null, reporterId: null, page: null, isDeepLink: false };
  }
  try {
    const params = new URLSearchParams(window.location.search);
    let postId = params.get('postId');
    let userId = params.get('userId');
    let videoId = params.get('videoId');
    let page = params.get('page');
    const reporterVerify = params.get('reporterVerify');
    const pathname = window.location.pathname || '';

    // Support clean URL paths as well: /p/:id, /post/:id, /v/:id, /video/:id, /user/:id, /u/:id
    if (!postId && pathname.startsWith('/p/')) {
      postId = pathname.replace('/p/', '').split('/')[0].split('?')[0];
    }
    if (!postId && pathname.startsWith('/post/')) {
      postId = pathname.replace('/post/', '').split('/')[0].split('?')[0];
    }
    if (!videoId && pathname.startsWith('/v/')) {
      videoId = pathname.replace('/v/', '').split('/')[0].split('?')[0];
    }
    if (!videoId && pathname.startsWith('/video/')) {
      videoId = pathname.replace('/video/', '').split('/')[0].split('?')[0];
    }
    if (!userId && (pathname.startsWith('/user/') || pathname.startsWith('/u/'))) {
      userId = pathname.replace(/^\/(?:user|u)\//, '').split('/')[0].split('?')[0];
    }

    if (postId) {
      const cleanPostId = decodeURIComponent(postId).trim().replace(/[/?#].*$/, '');
      if (cleanPostId) {
        return { view: View.PostDetail, postId: cleanPostId, videoId: null, userId: null, reporterId: null, page: null, isDeepLink: true };
      }
    }
    if (videoId) {
      const cleanVideoId = decodeURIComponent(videoId).trim().replace(/[/?#].*$/, '');
      if (cleanVideoId) {
        return { view: View.VideoHome, videoId: cleanVideoId, postId: null, userId: null, reporterId: null, page: null, isDeepLink: true };
      }
    }
    if (reporterVerify) {
      return { view: View.ReporterIdCard, reporterId: reporterVerify.trim(), postId: null, videoId: null, userId: null, page: null, isDeepLink: true };
    }
    if (userId) {
      const cleanUserId = decodeURIComponent(userId).trim().replace(/[/?#].*$/, '');
      if (cleanUserId) {
        return { view: View.PublicProfile, userId: cleanUserId, postId: null, videoId: null, reporterId: null, page: null, isDeepLink: true };
      }
    }
    if (page) {
      let v = View.Main;
      if (page === 'about') v = View.About;
      else if (page === 'privacy') v = View.Privacy;
      else if (page === 'terms') v = View.Terms;
      else if (page === 'contact') v = View.Feedback;
      else if (page === 'login') {
        const cachedUser = appCacheService.getCachedCurrentUser();
        v = cachedUser ? View.Main : View.Login;
      }
      else if (page === 'offline') v = View.Offline;
      else if (page === 'epaper') v = View.EPaper;
      else if (page === 'video') v = View.VideoHome;
      return { view: v, postId: null, videoId: null, userId: null, reporterId: null, page, isDeepLink: v !== View.Main };
    }
  } catch (e) {
    console.warn("Failed to parse initial deep link:", e);
  }
  return { view: View.Main, postId: null, videoId: null, userId: null, reporterId: null, page: null, isDeepLink: false };
}

const AppContent: React.FC = () => {
  const { showToast } = useToast();

  const initialNav = React.useMemo(() => getInitialDeepLink(), []);

  const [currentView, setCurrentView] = React.useState<View>(() => initialNav.view);
  const [previousView, setPreviousView] = React.useState<View | null>(null);
  const [currentUser, setCurrentUser] = React.useState<User | null>(() => appCacheService.getCachedCurrentUser());
  const [isAuthLoading, setIsAuthLoading] = React.useState(() => !appCacheService.getCachedCurrentUser());
  const [showSplash, setShowSplash] = React.useState(() => !initialNav.isDeepLink);
  const [activeNotification, setActiveNotification] = React.useState<any | null>(null);
  const [selectedPostId, setSelectedPostId] = React.useState<string | null>(() => initialNav.postId);
  const [selectedUserId, setSelectedUserId] = React.useState<string | null>(() => initialNav.userId);
  const [selectedUserIdForAdmin, setSelectedUserIdForAdmin] = React.useState<string | null>(null);
  const [selectedDraftId, setSelectedDraftId] = React.useState<string | null>(null);
  const [unreadNotificationsCount, setUnreadNotificationsCount] = React.useState(0);
  const [shouldFocusComment, setShouldFocusComment] = React.useState(false);
  const [userPageInitialTab, setUserPageInitialTab] = React.useState<'posts' | 'drafts'>('posts');
  const [selectedVideoId, setSelectedVideoId] = React.useState<string | null>(() => initialNav.videoId);
  const [selectedReporterId, setSelectedReporterId] = React.useState<string | null>(() => initialNav.reporterId);
  const [searchType, setSearchType] = React.useState<'all' | 'video'>('all');

  const shownNotifIdsRef = React.useRef<Set<string>>(new Set());
  const initialLoadTimeRef = React.useRef<number>(Date.now());

  // Auto-dismiss in-app notification drawer after 8 seconds
  React.useEffect(() => {
    if (activeNotification) {
      const timer = setTimeout(() => {
        setActiveNotification(null);
      }, 8000);
      return () => clearTimeout(timer);
    }
  }, [activeNotification]);

  // Splash Screen Speed Optimization: Limit to max 1000ms
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 1000);

    if (!isAuthLoading) {
      setShowSplash(false);
    }

    return () => clearTimeout(timer);
  }, [isAuthLoading]);

  // Theme Initialization
  React.useEffect(() => {
    // Apply saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, []);

  // Referral Redirect Handler
  React.useEffect(() => {
    if (!isAuthLoading && !currentUser) {
        const params = new URLSearchParams(window.location.search);
        const ref = params.get('ref');
        if (ref) {
            navigateTo(View.Login);
            showToast("You've been invited! Sign up to continue.", "info");
        }
    }
  }, [isAuthLoading, currentUser]);

  // Deep Link & History Init Handler
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    const notifId = params.get('notifId');
    
    if (ref) {
      localStorage.setItem('referralCode', ref);
    }

    if (notifId) {
      fetch('/api/notifications/track-opened', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId: notifId })
      }).catch(err => console.error("Error tracking notification open:", err));
    }

    // Set initial window history state based on resolved deep link
    const currentPath = window.location.pathname + window.location.search;
    if (initialNav.isDeepLink) {
      window.history.replaceState({
        view: initialNav.view,
        postId: initialNav.postId,
        videoId: initialNav.videoId,
        userId: initialNav.userId,
        reporterId: initialNav.reporterId,
      }, '', currentPath);
    } else {
      window.history.replaceState({ view: View.Main }, '', currentPath);
    }
  }, [initialNav]);

  // Back Button / PopState Listener
  React.useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.view) {
        const { view, postId, userId, adminUserId, draftId, initialTab, videoId, reporterId } = event.state;
        
        // Restore context data if present
        if (postId) setSelectedPostId(postId);
        if (userId) setSelectedUserId(userId);
        if (adminUserId) setSelectedUserIdForAdmin(adminUserId);
        if (draftId) setSelectedDraftId(draftId); else setSelectedDraftId(null);
        if (initialTab) setUserPageInitialTab(initialTab);
        if (videoId) setSelectedVideoId(videoId); else setSelectedVideoId(null);
        if (reporterId) setSelectedReporterId(reporterId); else setSelectedReporterId(null);
        
        setCurrentView(view);
        // Reset focus comment when navigating via history
        setShouldFocusComment(false);
      } else {
        // Fallback if no state is present (e.g. very start of history)
        setCurrentView(View.Main);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Device Online / Offline Detection
  const [isDeviceOnline, setIsDeviceOnline] = React.useState<boolean>(() => typeof navigator !== 'undefined' ? navigator.onLine : true);

  React.useEffect(() => {
    const handleOnline = () => {
      setIsDeviceOnline(true);
      showToast('इंटरनेट कनेक्शन पुनः कनेक्ट हो गया!', 'success');
    };
    const handleOffline = () => {
      setIsDeviceOnline(false);
      showToast('आप ऑफ़लाइन हैं। सहेजी गई खबरें पढ़ने के लिए ऑफ़लाइन मोड खोलें।', 'info');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [showToast]);

  // --- Push Notification Setup ---
  React.useEffect(() => {
    if (currentUser && messaging) {
        const requestPermission = async () => {
            try {
                const permission = await Notification.requestPermission();
                if (permission === 'granted') {
                    const token = await messaging.getToken({ vapidKey: VAPID_KEY });
                    
                    if (token) {
                        const userRef = db.collection('users').doc(currentUser.uid);
                        await userRef.update({
                            fcmTokens: firebase.firestore.FieldValue.arrayUnion(token)
                        });

                        // Trigger a Good-looking "Permission Enabled" notification locally
                        if ('serviceWorker' in navigator) {
                            const registration = await navigator.serviceWorker.getRegistration();
                            if (registration) {
                                // Fix: Use 'as any' to bypass TS error on 'image' property which is valid in SW notifications
                                registration.showNotification("Notifications Enabled!", {
                                    body: "You'll now receive hyper-local news alerts from Public Tak App directly in your notification scroll.",
                                    icon: APP_LOGO_URL,
                                    badge: APP_LOGO_URL,
                                    image: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=1000&q=80',
                                    vibrate: [200, 100, 200],
                                    tag: 'welcome-notif'
                                } as any);
                            }
                        }
                    }
                }
            } catch (error) {
                console.error("Notification permission error:", error);
            }
        };

        requestPermission();

                // Handle foreground messages
        const unsubscribeOnMessage = messaging.onMessage((payload: any) => {
            const { title, body, image } = payload.notification;
            
            // Play Sound
            const audio = new Audio(NOTIFICATION_SOUND_URL);
            audio.play().catch(e => console.log("Audio play failed", e));

            // Set active notification for premium slide-down pull drawer
            setActiveNotification({
                title: title || "न्यूज़ अपडेट (Public Tak App)",
                body: body || "",
                image: image || payload.data?.image || null,
                postId: payload.data?.postId || null,
                videoId: payload.data?.videoId || null,
                userId: payload.data?.userId || null,
                type: payload.data?.type || 'fcm_foreground'
            });

            // Also show system notification if possible even in foreground for consistency
            if (Notification.permission === 'granted') {
                navigator.serviceWorker.getRegistration().then(reg => {
                    // Fix: Use 'as any' to bypass TS error on 'image' property which is valid in SW notifications
                    reg?.showNotification(title, {
                        body: body,
                        icon: APP_LOGO_URL,
                        image: image || null,
                        badge: APP_LOGO_URL,
                        data: payload.data
                    } as any);
                });
            }
        });

        return () => {
            if (unsubscribeOnMessage) unsubscribeOnMessage();
        }
    }
  }, [currentUser, showToast]);

  React.useEffect(() => {
    let unsubscribeFirestore: (() => void) | null = null;
    let unsubscribeFollowing: (() => void) | null = null;

    const unsubscribeAuth = auth.onAuthStateChanged((firebaseUser) => {
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
        unsubscribeFirestore = null;
      }
      if (unsubscribeFollowing) {
        unsubscribeFollowing();
        unsubscribeFollowing = null;
      }

      if (firebaseUser) {
        const isEmailPasswordProvider = firebaseUser.providerData.some(
          (provider) => provider.providerId === 'password'
        );

        if (isEmailPasswordProvider && !firebaseUser.emailVerified) {
          auth.signOut();
          return;
        }

        // Instant optimistic/cached user activation (0 delay)
        const cachedUser = appCacheService.getCachedCurrentUser();
        if (cachedUser && cachedUser.uid === firebaseUser.uid) {
          setCurrentUser(cachedUser);
          setIsAuthLoading(false);
        } else {
          // Instant baseline user from auth token while snapshot syncs
          const defaultUsername = firebaseUser.email ? firebaseUser.email.split('@')[0] : `user${Date.now()}`;
          const quickUser: User = {
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || defaultUsername,
            username: defaultUsername,
            email: firebaseUser.email,
            profilePicUrl: firebaseUser.photoURL || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(firebaseUser.email || firebaseUser.uid)}`,
            role: 'user',
            followerCount: 0,
            followingCount: 0,
            bio: '',
            isVerified: false,
          };
          setCurrentUser(quickUser);
          appCacheService.setCachedCurrentUser(quickUser);
          setIsAuthLoading(false);
        }

        const userDocRef = db.collection('users').doc(firebaseUser.uid);

        // Root-level following list real-time synchronization to cache
        unsubscribeFollowing = userDocRef.collection('following').onSnapshot((snap) => {
          const ids = snap.docs.map(d => d.id);
          appCacheService.setFollowingList(firebaseUser.uid, ids);
        }, (err) => {
          console.warn("Error listening to following list:", err);
        });

        // Attach userDoc listener immediately without blocking network waits
        unsubscribeFirestore = userDocRef.onSnapshot(async (userDocSnap) => {
          const defaultUsername = firebaseUser.email ? firebaseUser.email.split('@')[0] : `user${Date.now()}`;
          const adminEmails = ['bikash512singh@gmail.com', 'publictakapp@gmail.com'];
          const isAdmin = firebaseUser.email && adminEmails.includes(firebaseUser.email);

          if (userDocSnap.exists) {
            const userData = userDocSnap.data() || {};
            const userObj: User = {
              uid: firebaseUser.uid,
              name: userData.name || firebaseUser.displayName || defaultUsername,
              username: userData.username || defaultUsername,
              bio: userData.bio || '',
              email: firebaseUser.email,
              profilePicUrl: userData.profilePicUrl || firebaseUser.photoURL || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(firebaseUser.email || firebaseUser.uid)}`,
              role: (isAdmin && userData.role !== 'admin') ? 'admin' : (userData.role || 'user'),
              preferredState: userData.preferredState || '',
              preferredDistrict: userData.preferredDistrict || '',
              preferredBlock: userData.preferredBlock || '',
              referralCode: userData.referralCode || '',
              referralCount: userData.referralCount || 0,
              walletBalance: userData.walletBalance || 0,
              totalEarnings: userData.totalEarnings || 0,
              followerCount: userData.followerCount || 0,
              followingCount: userData.followingCount || 0,
              isMonetized: userData.isMonetized || false,
              monetizationStatus: userData.monetizationStatus || 'none',
              totalViews: userData.totalViews || 0,
              asteriskCount: userData.asteriskCount || 0,
              isBanned: userData.isBanned || false,
              banReason: userData.banReason || '',
              bannedAt: userData.bannedAt || null,
              bannedBy: userData.bannedBy || '',
              reporterStatus: userData.reporterStatus || 'none',
              reporterIdNumber: userData.reporterIdNumber || '',
              reporterDesignation: userData.reporterDesignation || '',
              phone: userData.phone || '',
              isVerified: userData.isVerified || false,
            };

            setCurrentUser(userObj);
            appCacheService.setCachedCurrentUser(userObj);
            setIsAuthLoading(false);

            // Background async migration / admin update (non-blocking)
            if (isAdmin && userData.role !== 'admin') {
              userDocRef.update({ role: 'admin' }).catch(() => {});
              db.collection('admins').doc(firebaseUser.uid).set({
                uid: firebaseUser.uid,
                email: firebaseUser.email || '',
                name: userData.name || firebaseUser.displayName || '',
                role: 'admin',
                lastActiveAt: new Date()
              }, { merge: true }).catch(() => {});
            }
          } else {
            // New user registration in background
            try {
              const username = firebaseUser.email ? firebaseUser.email.split('@')[0] : `user${Date.now()}`;
              const referralCode = firebaseUser.uid.substring(0, 8).toUpperCase();
              const storedRef = localStorage.getItem('referralCode');
              let referredBy = null;

              if (storedRef && storedRef !== referralCode) {
                try {
                  const referrerQuery = await db.collection('users').where('referralCode', '==', storedRef).get();
                  if (!referrerQuery.empty) {
                    const referrerDoc = referrerQuery.docs[0];
                    referredBy = referrerDoc.id;
                    const referrerData = referrerDoc.data();
                    const newReferralCount = (referrerData.referralCount || 0) + 1;
                    const isMilestone = newReferralCount > 0 && newReferralCount % 10 === 0;
                    const bonusAmount = isMilestone ? 2 + 10 : 2;

                    await referrerDoc.ref.update({
                      walletBalance: increment(bonusAmount),
                      totalEarnings: increment(bonusAmount),
                      referralCount: increment(1)
                    });

                    await referrerDoc.ref.collection('referrals').add({
                      newUserId: firebaseUser.uid,
                      newUserName: firebaseUser.displayName || 'New User',
                      newUserPic: firebaseUser.photoURL || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(firebaseUser.email || firebaseUser.uid)}`,
                      amount: bonusAmount,
                      type: isMilestone ? 'join_with_milestone' : 'join',
                      timestamp: serverTimestamp()
                    });

                    await referrerDoc.ref.collection('notifications').add({
                      title: isMilestone ? "Milestone Bonus! 🏆" : "New Referral Reward! 🎁",
                      body: isMilestone 
                        ? `10th referral complete! You earned ₹2 + ₹10 Extra Bonus.`
                        : `A new user joined using your link. ₹2 has been added to your wallet.`,
                      read: false,
                      timestamp: serverTimestamp(),
                      type: 'referral'
                    });

                    showToast(isMilestone ? `Referral Milestone Reached! ₹12 credited.` : `Referral applied! ₹2 bonus sent to referrer.`, "success");
                  }
                } catch (e) {
                  console.error("Referral processing error:", e);
                }
                localStorage.removeItem('referralCode');
              }

              await userDocRef.set({
                uid: firebaseUser.uid,
                name: firebaseUser.displayName || 'New User',
                email: firebaseUser.email,
                username: username,
                bio: '',
                profilePicUrl: firebaseUser.photoURL || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(firebaseUser.email || firebaseUser.uid)}`,
                role: isAdmin ? 'admin' : 'user',
                createdAt: serverTimestamp(),
                isPublic: true,
                isVerified: false,
                walletBalance: 0,
                totalEarnings: 0,
                followerCount: 0,
                followingCount: 0,
                referralCode: referralCode,
                referredBy: referredBy,
                referralCount: 0,
                hasPostedFirstNews: false,
                milestoneCount: 0
              });
            } catch (err) {
              console.error("Error creating user profile:", err);
            }
          }
        }, (error) => {
          console.error("Error listening to user document:", error);
          setIsAuthLoading(false);
        });

      } else {
        setCurrentUser(null);
        appCacheService.setCachedCurrentUser(null);
        setIsAuthLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeFirestore) {
        unsubscribeFirestore();
      }
      if (unsubscribeFollowing) {
        unsubscribeFollowing();
      }
    };
  }, []);
  
  const navigateTo = (view: View, params: { postId?: string, userId?: string, adminUserId?: string, draftId?: string, focusComment?: boolean, initialTab?: 'posts' | 'drafts', videoId?: string, searchType?: 'all' | 'video', reporterId?: string } = {}) => {
    if (typeof view !== 'string') return;

    // --- Authentication Guard ---
    const PUBLIC_VIEWS: View[] = [
        View.Main,
        View.PostDetail,
        View.About,
        View.Privacy,
        View.Terms,
        View.Feedback,
        View.Login
    ];

    if (!currentUser && !PUBLIC_VIEWS.includes(view)) {
        showToast("Access Restricted: Please login to use this service", "info");
        setCurrentView(View.Login);
        window.history.pushState({ view: View.Login }, '', '?page=login');
        return;
    }

    const safeParams: any = {};
    if (params && typeof params === 'object' && params !== null) {
        if (!('preventDefault' in params || 'target' in params || 'nativeEvent' in params)) {
            if (params.postId && typeof params.postId === 'string') safeParams.postId = params.postId;
            if (params.userId && typeof params.userId === 'string') safeParams.userId = params.userId;
            if (params.adminUserId && typeof params.adminUserId === 'string') safeParams.adminUserId = params.adminUserId;
            if (params.draftId && typeof params.draftId === 'string') safeParams.draftId = params.draftId;
            if (typeof params.focusComment === 'boolean') safeParams.focusComment = params.focusComment;
            if (params.initialTab === 'posts' || params.initialTab === 'drafts' || params.initialTab === 'videos') safeParams.initialTab = params.initialTab;
            if (params.videoId && typeof params.videoId === 'string') safeParams.videoId = params.videoId;
            if (params.searchType && typeof params.searchType === 'string') safeParams.searchType = params.searchType;
            if (params.reporterId && typeof params.reporterId === 'string') safeParams.reporterId = params.reporterId;
        }
    }

    setPreviousView(currentView);
    setCurrentView(view);
    
    if (safeParams.searchType) {
        setSearchType(safeParams.searchType);
    } else if (view !== View.Search) {
        setSearchType('all');
    }
    
    if (safeParams.draftId) {
        setSelectedDraftId(safeParams.draftId);
    } else if (view === View.CreatePost) {
        setSelectedDraftId(null);
    }

    if (safeParams.initialTab) {
        setUserPageInitialTab(safeParams.initialTab);
    } else if (view !== View.User) {
        // Reset to default when moving away from User page if not explicitly set
        setUserPageInitialTab('posts');
    }

    if (safeParams.videoId) {
        setSelectedVideoId(safeParams.videoId);
    } else if (view !== View.VideoHome) {
        setSelectedVideoId(null);
    }

    if (safeParams.reporterId) {
        setSelectedReporterId(safeParams.reporterId);
    } else if (view !== View.ReporterIdCard) {
        setSelectedReporterId(null);
    }

    setShouldFocusComment(!!safeParams.focusComment);

    let url = window.location.pathname;
    const state: any = { view, ...safeParams };

    if (view === View.Main) {
        url = '/';
    } else if (view === View.PostDetail && safeParams.postId) {
        url = `?postId=${safeParams.postId}`;
    } else if (view === View.PublicProfile && safeParams.userId) {
        url = `?userId=${safeParams.userId}`;
    } else if (view === View.ReporterIdCard && safeParams.reporterId) {
        url = `?reporterVerify=${safeParams.reporterId}`;
    } else if (view === View.About) {
        url = '?page=about';
    } else if (view === View.Privacy) {
        url = '?page=privacy';
    } else if (view === View.Terms) {
        url = '?page=terms';
    } else if (view === View.Feedback) {
        url = '?page=contact';
    } else if (view === View.Login) {
        url = '?page=login';
    } else if (view === View.VideoHome && safeParams.videoId) {
        url = `?videoId=${safeParams.videoId}`;
    }
    
    window.history.pushState(state, '', url);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  React.useEffect(() => {
    if (currentUser && currentView === View.Login) {
      navigateTo(View.Main);
    }
  }, [currentUser, currentView]);

  // Native Android hardware back-button and status bar customization
  React.useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    StatusBar.setStyle({ style: Style.Light }).catch(() => {});
    StatusBar.setBackgroundColor({ color: '#1e3a8a' }).catch(() => {});

    let lastBackPress = 0;
    const backListenerPromise = CapApp.addListener('backButton', () => {
      if (currentView !== View.Main) {
        handleBack();
      } else {
        const now = Date.now();
        if (now - lastBackPress < 2000) {
          CapApp.exitApp();
        } else {
          lastBackPress = now;
          showToast("ऐप बंद करने के लिए दोबारा बैक दबाएं", "info");
        }
      }
    });

    return () => {
      backListenerPromise.then(handle => handle.remove()).catch(() => {});
    };
  }, [currentView]);

  React.useEffect(() => {
    if (currentUser) {
      const notificationsRef = db.collection('users').doc(currentUser.uid).collection('notifications');
      
      // 1. Keep track of unread count
      const unsubscribeCount = notificationsRef.where('read', '==', false).onSnapshot((snapshot) => {
        setUnreadNotificationsCount(snapshot.size);
      });

      // 2. Real-time alert listener for newly added notifications
      const unsubscribeAlerts = notificationsRef
        .orderBy('createdAt', 'desc')
        .limit(3)
        .onSnapshot((snapshot) => {
          if (!snapshot || snapshot.empty) return;
          
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const notifId = change.doc.id;
              const notif = change.doc.data();

              // Avoid duplicates and initial historical notifications
              if (!shownNotifIdsRef.current.has(notifId)) {
                shownNotifIdsRef.current.add(notifId);

                let isNew = false;
                if (notif.createdAt) {
                  const createdAtMs = notif.createdAt.toDate ? notif.createdAt.toDate().getTime() : new Date(notif.createdAt).getTime();
                  if (createdAtMs > initialLoadTimeRef.current - 5000) {
                    isNew = true;
                  }
                } else {
                  // If server timestamp is null, it means it's newly created on client side locally
                  isNew = true;
                }

                if (isNew && !notif.read) {
                  // Play Sound!
                  try {
                    const audio = new Audio(NOTIFICATION_SOUND_URL);
                    audio.play().catch(e => console.log("Sound autoplay blocked:", e));
                  } catch (err) {
                    console.error("Audio playback error:", err);
                  }

                  // Customize title and body
                  let title = "पब्लिक तक न्यूज़ अपडेट";
                  let body = "आपके लिए एक नया अपडेट आया है।";
                  
                  if (notif.type === 'new_like') {
                    title = "नया लाइक! ❤️";
                    body = `${notif.fromUserName || 'किसी यूजर'} ने आपकी पोस्ट "${notif.postTitle || 'शीर्षकहीन'}" को लाइक किया।`;
                  } else if (notif.type === 'new_comment') {
                    title = "नई टिप्पणी! 💬";
                    body = `${notif.fromUserName || 'کسی यूजर'} ने आपकी पोस्ट "${notif.postTitle || 'शीर्षकहीन'}" पर कमेंट किया।`;
                  } else if (notif.type === 'new_follower') {
                    title = "नया फॉलोअर! 👤";
                    body = `${notif.fromUserName || 'किसी यूजर'} ने आपको फॉलो करना शुरू किया।`;
                  } else if (notif.type === 'new_post') {
                    title = notif.postTitle || "नई पोस्ट! 📰";
                    body = `${notif.fromUserName || 'किसी यूजर'} ने नई पोस्ट पब्लिश की।`;
                  } else if (notif.type === 'post_reported' || notif.type === 'content_reported') {
                    title = "⚠️ आपकी पोस्ट रिपोर्ट की गई!";
                    body = `${notif.fromUserName ? notif.fromUserName + ' द्वारा' : 'किसी यूजर द्वारा'} आपकी पोस्ट "${notif.postTitle || 'पोस्ट'}" को रिपोर्ट किया गया है: "${notif.reportReason || notif.body || 'सामग्री उल्लंघन'}".`;
                  } else if (notif.title || notif.body) {
                    title = notif.title || title;
                    body = notif.body || body;
                  }

                  setActiveNotification({
                    id: notifId,
                    title,
                    body,
                    postTitle: notif.postTitle || notif.title || title,
                    image: notif.postThumbnailUrl || notif.thumbnailUrl || notif.imageUrl || notif.fromUserProfilePicUrl || null,
                    thumbnailUrl: notif.postThumbnailUrl || notif.thumbnailUrl || null,
                    fromUserName: notif.fromUserName || null,
                    fromUserProfilePicUrl: notif.fromUserProfilePicUrl || null,
                    fromUserIsVerified: notif.fromUserIsVerified || false,
                    postId: notif.postId || null,
                    videoId: notif.videoId || null,
                    userId: notif.fromUserId || null,
                    type: notif.type || 'db_notification'
                  });
                }
              }
            }
          });
        }, (error) => {
          console.error("Alerts listener error:", error);
        });

      return () => {
        unsubscribeCount();
        unsubscribeAlerts();
      };
    } else {
      setUnreadNotificationsCount(0);
    }
  }, [currentUser]);

  const handleEditPost = (postId: string) => {
    setSelectedPostId(postId);
    navigateTo(View.EditPost, { postId });
  };
  
  const handleViewPost = (postId: string) => {
    setSelectedPostId(postId);
    navigateTo(View.PostDetail, { postId });
  };

  const handleViewVideo = (videoId: string) => {
    setSelectedVideoId(videoId);
    navigateTo(View.VideoHome, { videoId });
  };

  const handleViewUser = (userId: string) => {
    if (currentUser && userId === currentUser.uid) {
        navigateTo(View.User);
    } else {
        setSelectedUserId(userId);
        navigateTo(View.PublicProfile, { userId });
    }
  };

  const handleAdminEditUser = (userId: string) => {
    setSelectedUserIdForAdmin(userId);
    navigateTo(View.AdminEditUser, { adminUserId: userId });
  };

  const handleLogin = () => {
    navigateTo(View.Login);
  };

  const handleLoginSuccess = () => {
    navigateTo(View.Main);
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      appCacheService.setCachedCurrentUser(null);
      setCurrentUser(null);
      showToast("Logged out successfully", "success");
      navigateTo(View.Main);
    } catch (error) {
      console.error("Error signing out: ", error);
    }
  };

  const handleProfileUpdate = (updatedData: Partial<User>) => {
    if (currentUser) {
        setCurrentUser(prevUser => ({
            ...prevUser!,
            ...updatedData
        }));
    }
  };

  const handleBack = () => {
    if (window.history.length > 1 && window.history.state && window.history.state.view && window.history.state.view !== currentView) {
      window.history.back();
    } else {
      navigateTo(View.Main);
    }
  };

  const isAccountBanned = !!(currentUser?.isBanned && currentUser.role !== 'admin');

  const renderView = () => {
    if (isAccountBanned && currentUser) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[85vh] p-4 md:p-8 text-center bg-gray-50/50">
            <div className="w-full max-w-lg bg-white rounded-3xl p-6 md:p-8 shadow-2xl border border-red-200 relative overflow-hidden text-center">
                {/* Top red header stripe */}
                <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-red-600 via-rose-600 to-orange-600"></div>

                <div className="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-5 shadow-inner ring-8 ring-red-50">
                    <span className="material-symbols-outlined text-5xl">gavel</span>
                </div>

                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-100 text-red-800 text-xs font-black uppercase tracking-wider mb-2">
                    <span className="material-symbols-outlined text-sm">block</span>
                    खाता प्रतिबंधित (Account Banned)
                </span>

                <h1 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight">
                    आपका खाता सस्पेंड कर दिया गया है
                </h1>

                <p className="mt-2.5 text-xs md:text-sm text-gray-600 font-medium leading-relaxed max-w-md mx-auto">
                    सामुदायिक दिशानिर्देशों अथवा सेवा नियमों के उल्लंघन के कारण एडमिनिस्ट्रेशन द्वारा आपका खाता प्रतिबंधित किया गया है। प्रतिबंध अवधि के दौरान आप कोई भी पोस्ट, कमेंट या गतिविधि नहीं कर सकेंगे।
                </p>

                {/* User Info & Ban Reason Card */}
                <div className="mt-6 p-4 bg-gray-50 rounded-2xl border border-gray-200/80 text-left space-y-3">
                    <div className="flex items-center gap-3 pb-3 border-b border-gray-200">
                        <img 
                            src={currentUser.profilePicUrl || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(currentUser.email || currentUser.uid)}`} 
                            alt={currentUser.name} 
                            className="w-11 h-11 rounded-full object-cover ring-2 ring-red-300 shrink-0"
                        />
                        <div className="min-w-0">
                            <p className="font-extrabold text-sm text-gray-900 truncate">{currentUser.name}</p>
                            <p className="text-xs text-gray-500 truncate">{currentUser.email || currentUser.phone || 'पब्लिक तक यूजर'}</p>
                            <p className="text-[10px] text-gray-400 font-mono">UID: {currentUser.uid}</p>
                        </div>
                    </div>

                    <div>
                        <p className="text-[11px] font-black uppercase tracking-wider text-red-700">प्रतिबंध का कारण (Ban Reason):</p>
                        <p className="text-xs font-bold text-gray-900 mt-1 bg-red-50 border border-red-200 p-3 rounded-xl leading-relaxed">
                            "{currentUser.banReason || 'सार्वजनिक नीति, समुदाय सुरक्षा अथवा सामग्री दिशानिर्देशों का उल्लंघन'}"
                        </p>
                    </div>

                    <p className="text-[11px] text-gray-500 font-medium">
                        यदि आपको लगता है कि यह प्रतिबंध त्रुटिवश हुआ है, तो नीचे दिए गए बटन से सहायता टीम को ईमेल भेजकर अपील कर सकते हैं।
                    </p>
                </div>

                {/* Action Buttons */}
                <div className="mt-6 flex flex-col sm:flex-row gap-3">
                    <a
                        href={`mailto:publictakapp@gmail.com?subject=Account%20Ban%20Appeal%20-%20${encodeURIComponent(currentUser.name || '')}%20(${currentUser.uid})&body=नमस्ते%20एडमिन%20टीम,%0A%0Aमेरा%20खाता%20(UID:%20${currentUser.uid})%20प्रतिबंधित%20कर%20दिया%20गया%20है।%20कृपया%20इसकी%20समीक्षा%20करें।`}
                        className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
                    >
                        <span className="material-symbols-outlined text-base">support_agent</span>
                        <span>अपील / संपर्क करें (Appeal)</span>
                    </a>

                    <button 
                        onClick={handleLogout}
                        className="flex-1 py-3 px-4 bg-gray-900 hover:bg-black text-white font-black text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
                    >
                        <span className="material-symbols-outlined text-base">logout</span>
                        <span>लॉग आउट करें (Log Out)</span>
                    </button>
                </div>
            </div>
        </div>
      );
    }

    switch (currentView) {
        case View.Main:
            return (
                <HomePage
                    onNavigate={navigateTo}
                    currentUser={currentUser}
                    onLogin={handleLogin}
                    onLogout={handleLogout}
                    onViewPost={handleViewPost}
                    onViewUser={handleViewUser}
                    onEditPost={handleEditPost}
                />
            );
        case View.VideoHome:
            return (
                <VideoHomePage
                    onNavigate={navigateTo}
                    currentUser={currentUser}
                    onLogin={handleLogin}
                    onLogout={handleLogout}
                    onViewUser={handleViewUser}
                    selectedVideoId={selectedVideoId}
                    onClearSelectedVideo={() => setSelectedVideoId(null)}
                />
            );
        case View.Admin:
            return (
                <AdminPage 
                    onBack={handleBack} 
                    currentUser={currentUser} 
                    onLogin={handleLogin} 
                    onLogout={handleLogout} 
                    onNavigate={navigateTo} 
                    unreadNotificationsCount={unreadNotificationsCount} 
                />
            );
        case View.ViewFeedback:
            return <ViewFeedbackPage onBack={handleBack} currentUser={currentUser} />;
        case View.ManageAds:
            return <ManageAdsPage onBack={handleBack} currentUser={currentUser} />;
        case View.AdminEditUser:
            return selectedUserIdForAdmin ? (
                <AdminEditUserPage 
                    userId={selectedUserIdForAdmin} 
                    onBack={handleBack} 
                    onEditPost={handleEditPost}
                    onViewPost={handleViewPost}
                />
            ) : null;
        case View.Settings:
            return <SettingsPage onBack={handleBack} currentUser={currentUser} onLogout={handleLogout} onNavigate={navigateTo} />;
        case View.ManageUsers:
            return <ManageUsersPage onBack={handleBack} currentUser={currentUser} onEditUser={handleAdminEditUser} />;
        case View.Analytics:
            return currentUser ? <AnalyticsPage onBack={handleBack} currentUser={currentUser} onViewPost={handleViewPost} onNavigate={navigateTo} /> : null;
        case View.ModerateContent:
            return <ModerateContentPage onBack={handleBack} currentUser={currentUser} />;
        case View.Notifications:
            return (
                <NotificationsPage 
                    onBack={handleBack} 
                    currentUser={currentUser} 
                    onViewPost={handleViewPost} 
                    onViewUser={handleViewUser} 
                    onViewVideo={handleViewVideo}
                />
            );
        case View.SiteSettings:
            return <SiteSettingsPage onBack={handleBack} />;
        case View.Search:
            return <SearchPage onNavigate={navigateTo} onViewPost={handleViewPost} currentUser={currentUser} onViewUser={handleViewUser} searchType={searchType} />;
        case View.User:
            return (
                <UserPage
                    onBack={handleBack}
                    currentUser={currentUser}
                    onLogout={handleLogout}
                    onNavigate={navigateTo}
                    onEditPost={handleEditPost}
                    onViewPost={handleViewPost}
                    onViewUser={handleViewUser}
                    initialTab={userPageInitialTab}
                />
            );
        case View.CreatePost:
            return (
                <CreatePostPage
                    onBack={handleBack}
                    currentUser={currentUser}
                    draftId={selectedDraftId}
                    onNavigate={navigateTo}
                />
            );
        case View.EditPost:
            return selectedPostId && currentUser ? (
                <EditPostPage
                    onBack={handleBack}
                    currentUser={currentUser}
                    postId={selectedPostId}
                />
            ) : null;
        case View.EditProfile:
            return currentUser ? (
                <EditProfilePage
                    onBack={handleBack}
                    currentUser={currentUser}
                    onProfileUpdate={handleProfileUpdate}
                />
            ) : null;
        case View.PostDetail:
            return selectedPostId ? (
                <PostDetailPage
                    key={selectedPostId}
                    postId={selectedPostId}
                    currentUser={currentUser}
                    onBack={handleBack}
                    onLogin={handleLogin}
                    onNavigate={navigateTo}
                    onViewUser={handleViewUser}
                    onViewPost={handleViewPost}
                    onEditPost={handleEditPost}
                    focusComment={shouldFocusComment}
                />
            ) : null;
        case View.PublicProfile:
            return selectedUserId ? (
                <PublicProfilePage
                    userId={selectedUserId}
                    currentUser={currentUser}
                    onBack={handleBack}
                    onViewPost={handleViewPost}
                    onViewUser={handleViewUser}
                    onLogin={handleLogin}
                    onNavigate={navigateTo}
                    onAdminEditUser={handleAdminEditUser}
                />
            ) : null;
        case View.Feedback:
            return <FeedbackPage onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} />;
        case View.Privacy:
            return <PrivacyPage onBack={handleBack} />;
        case View.Terms:
            return <TermsPage onBack={handleBack} />;
        case View.About:
            return <AboutPage onBack={handleBack} />;
        case View.CreatorDashboard:
            return <CreatorDashboard onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} />;
        case View.Monetization:
            return currentUser ? <MonetizationPage onBack={handleBack} currentUser={currentUser} /> : null;
        case View.ManageMonetization:
            return <ManageMonetizationPage onBack={handleBack} />;
        case View.Leaderboard:
            return <Leaderboard onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} />;
        case View.Referral:
            return <ReferralPage onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} />;
        case View.Withdrawal:
            return <WithdrawalPage onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} />;
        case View.Verification:
            return <VerificationPage onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} />;
        case View.ManageAccount:
            return currentUser ? <ManageAccountPage onBack={handleBack} currentUser={currentUser} onNavigate={navigateTo} /> : null;
        case View.ChangePassword:
            return <ChangePasswordPage onBack={handleBack} />;
        case View.Login:
            return <LoginPage onBack={handleBack} onLoginSuccess={handleLoginSuccess} />;
        case View.Offline:
            return (
                <OfflinePage 
                    onBack={handleBack}
                    onNavigateHome={() => navigateTo(View.Main)}
                    onSelectPost={(post) => {
                        setSelectedPostId(post.id);
                        navigateTo(View.PostDetail, { postId: post.id });
                    }}
                />
            );
        case View.KYC:
            return <KYCPage onBack={handleBack} currentUser={currentUser} />;
        case View.ManageKYC:
            return <ManageKYCPage onBack={handleBack} />;
        case View.ManageWithdrawals:
            return <ManageWithdrawalsPage onBack={handleBack} />;
        case View.EPaper:
            return <EPaperPage onBack={handleBack} currentUser={currentUser} />;
        case View.ReporterRegistration:
            return (
                <ReporterRegistrationPage
                    onBack={handleBack}
                    currentUser={currentUser}
                    onNavigate={navigateTo}
                />
            );
        case View.ReporterIdCard:
            return (
                <ReporterIdCardPage
                    onBack={handleBack}
                    currentUser={currentUser}
                    onNavigate={navigateTo}
                    reporterIdFromQuery={selectedReporterId || undefined}
                />
            );
        case View.ManageReporters:
            return (
                <ManageReportersPage
                    onBack={handleBack}
                    currentUser={currentUser}
                    onNavigate={navigateTo}
                />
            );
        default:
            return null;
    }
  };

  return (
    <div className="font-sans text-gray-800 bg-gray-100 min-h-screen flex">
        <AnimatePresence mode="wait">
            {showSplash ? (
              <motion.div 
                key="splash"
                initial={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="fixed inset-0 bg-white flex flex-col items-center justify-center z-[9999]"
              >
                <motion.div
                  initial={{ scale: 0.9, opacity: 0, y: 10 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                  className="flex flex-col items-center"
                >
                  <div className="relative w-28 h-28 mb-8">
                     <div className="absolute inset-0 border-2 border-red-50 rounded-full scale-125 opacity-50"></div>
                     <motion.div 
                       animate={{ rotate: 360 }}
                       transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                       className="absolute inset-0 border-4 border-red-600 border-t-transparent rounded-full shadow-lg shadow-red-200"
                     />
                     <motion.div
                       animate={{ scale: [1, 1.03, 1] }}
                       transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                       className="absolute inset-0 flex items-center justify-center"
                     >
                        <img src={APP_LOGO_URL} alt="Logo" className="w-20 h-20 rounded-full object-cover shadow-2xl bg-white border-2 border-white ring-4 ring-red-50" />
                     </motion.div>
                  </div>
                  <motion.h2 
                    initial={{ opacity: 0, letterSpacing: "-0.05em" }}
                    animate={{ opacity: 1, letterSpacing: "-0.02em" }}
                    transition={{ delay: 0.1, duration: 0.3 }}
                    className="text-3xl font-black text-gray-900 tracking-tighter"
                  >
                    Public Tak <span className="text-red-600">App</span>
                  </motion.h2>
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: 140 }}
                    transition={{ delay: 0.2, duration: 0.5, ease: "easeInOut" }}
                    className="h-1 bg-gradient-to-r from-red-600 to-orange-400 mt-4 rounded-full"
                  />
                  <motion.p 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.6 }}
                    transition={{ delay: 0.3, duration: 0.3 }}
                    className="text-[10px] text-gray-500 mt-6 font-black uppercase tracking-[0.2em]"
                  >
                    Digital Bharat Ki Awaz
                  </motion.p>
                </motion.div>
              </motion.div>
            ) : null}
        </AnimatePresence>

        {!isAccountBanned && (
          <Sidebar 
              onNavigate={navigateTo} 
              currentUser={currentUser} 
              currentView={currentView} 
              unreadCount={unreadNotificationsCount}
              onLogout={handleLogout}
              onLogin={handleLogin}
          />
        )}
        
        <div className={`relative flex flex-col flex-1 h-full w-full overflow-hidden ${!isAccountBanned ? 'md:overflow-visible md:bg-gray-100' : 'bg-gray-50'}`}>
            {/* Top Offline Notification Strip */}
            {!isDeviceOnline && currentView !== View.Offline && (
              <div className="bg-amber-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-md z-40 shrink-0">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-base animate-pulse">cloud_off</span>
                  <span>आप ऑफ़लाइन हैं — सहेजी गई खबरें पढ़ें</span>
                </div>
                <button 
                  type="button"
                  onClick={() => navigateTo(View.Offline)}
                  className="bg-white hover:bg-amber-50 text-amber-900 px-3 py-1 rounded-lg text-xs font-black shadow-xs active:scale-95 transition-all cursor-pointer"
                >
                  Read Cached News
                </button>
              </div>
            )}

            <div className={`relative flex-1 w-full h-full overflow-hidden md:overflow-y-auto md:w-full md:flex md:flex-col ${!isAccountBanned ? 'pb-16 md:pb-0' : 'pb-0'}`}>
                <AnimatePresence mode="wait">
                    <motion.div 
                        key={currentView + (selectedPostId || '') + (selectedUserId || '')}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
                        className="w-full h-full flex flex-col"
                    >
                        {renderView()}
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* View container */}

            {!isAccountBanned && (
              <BottomNavBar
                  onNavigate={navigateTo}
                  currentUser={currentUser}
                  currentView={currentView}
                  unreadCount={unreadNotificationsCount}
              />
            )}
        </div>

        {/* Top-Center Mobile-Responsive Push Notification Toast Card */}
        <AnimatePresence>
          {activeNotification && (
            <PushNotificationToast
              notification={activeNotification}
              onClose={() => setActiveNotification(null)}
              onSelectPost={handleViewPost}
              onSelectVideo={handleViewVideo}
              onSelectUser={handleViewUser}
            />
          )}
        </AnimatePresence>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <LanguageProvider>
        <ToastProvider>
          <AppContent />
        </ToastProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
};

export default App;
