import { db, serverTimestamp, increment } from '../firebaseConfig';
import { Post, Video, User } from '../types';
import { Share } from '@capacitor/share';
import { Capacitor } from '@capacitor/core';

/**
 * Strips HTML tags and excessive whitespace from content to create a clean preview description.
 */
export const getCleanDescription = (content?: string, maxLength: number = 220): string => {
  if (!content) return '';
  const text = content
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();

  if (text.length > maxLength) {
    return text.substring(0, maxLength).trim() + '...';
  }
  return text;
};

/**
 * Generates an anonymous or persistent device ID for guest users
 * to ensure "One User One Share Count" even before logging in.
 */
export const getOrCreateGuestDeviceId = (): string => {
  const STORAGE_KEY = 'pt_device_guest_id';
  try {
    let id = localStorage.getItem(STORAGE_KEY);
    if (!id) {
      id = 'guest_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
      localStorage.setItem(STORAGE_KEY, id);
    }
    return id;
  } catch {
    return 'guest_anon_' + Date.now().toString(36);
  }
};

/**
 * Builds the exact share message requested by the user:
 * 
 * *Title*
 * 
 * Description
 * 
 * 👉 *पूरी खबर यहाँ पढ़ें:* Post Link
 * 
 * 📝 *नोट:* क्या आप ब्लॉक में छोटे न्यूज़ रिपोर्टर है, आपके पास वेबसाइट नहीं है? चिंता न करें! *Public Tak App* में अभी अपना Account बनाये।
 * 
 * *"आपकी खबर, आपकी पहचान – Public Tak News App"*
 * 
 * 📲 *अभी जुड़ें:* https://www.publictak.app/?page=login
 */
export const buildPostShareText = (post: { id: string; title: string; content?: string }): string => {
  const description = getCleanDescription(post.content);
  const cleanId = (post.id || '').trim();
  
  // Resolve base origin safely (supporting custom domain, web preview, or production)
  const baseOrigin = typeof window !== 'undefined' && window.location.origin && !window.location.hostname.includes('localhost') && !window.location.hostname.includes('run.app')
    ? 'https://www.publictak.app'
    : (typeof window !== 'undefined' && window.location.origin ? window.location.origin : 'https://www.publictak.app');

  const postLink = `${baseOrigin}/?postId=${encodeURIComponent(cleanId)}`;

  return `*${post.title}*

${description}

👉 *पूरी खबर यहाँ पढ़ें:* ${postLink}

📝 *नोट:* क्या आप ब्लॉक में छोटे न्यूज़ रिपोर्टर है, आपके पास वेबसाइट नहीं है? चिंता न करें! *Public Tak App* में अभी अपना Account बनाये।

*"आपकी खबर, आपकी पहचान – Public Tak News App"*

📲 *अभी जुड़ें:* ${baseOrigin}`;
};

/**
 * Builds the video share message following the exact same format
 */
export const buildVideoShareText = (video: { id: string; title: string; description?: string }): string => {
  const description = getCleanDescription(video.description || video.title);
  const cleanId = (video.id || '').trim();
  
  const baseOrigin = typeof window !== 'undefined' && window.location.origin && !window.location.hostname.includes('localhost') && !window.location.hostname.includes('run.app')
    ? 'https://www.publictak.app'
    : (typeof window !== 'undefined' && window.location.origin ? window.location.origin : 'https://www.publictak.app');

  const videoLink = `${baseOrigin}/?videoId=${encodeURIComponent(cleanId)}`;

  return `*${video.title}*

${description}

👉 *पूरा वीडियो यहाँ देखें:* ${videoLink}

📝 *नोट:* क्या आप ब्लॉक में छोटे न्यूज़ रिपोर्टर है, आपके पास वेबसाइट नहीं है? चिंता न करें! *Public Tak App* में अभी अपना Account बनाये।

*"आपकी खबर, आपकी पहचान – Public Tak News App"*

📲 *अभी जुड़ें:* ${baseOrigin}`;
};

/**
 * Safely copies text to the clipboard with fallbacks
 */
export const copyTextToClipboard = async (text: string): Promise<boolean> => {
  if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback
    }
  }

  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.opacity = '0';
    textArea.style.left = '-9999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch {
    return false;
  }
};

/**
 * Checks if a user has already shared a given item (post or video)
 */
export const hasUserShared = async (
  collectionName: 'posts' | 'videos',
  itemId: string,
  currentUser: User | null
): Promise<boolean> => {
  const userIdentifier = currentUser ? currentUser.uid : getOrCreateGuestDeviceId();
  const localKey = `pt_shared_${collectionName}_${itemId}_${userIdentifier}`;

  try {
    if (localStorage.getItem(localKey) === 'true') {
      return true;
    }
  } catch {
    // localStorage not accessible
  }

  if (currentUser) {
    try {
      const shareDoc = await db
        .collection(collectionName)
        .doc(itemId)
        .collection('shares')
        .doc(currentUser.uid)
        .get();
      if (shareDoc.exists) {
        try {
          localStorage.setItem(localKey, 'true');
        } catch {}
        return true;
      }
    } catch (e) {
      console.warn("Could not check share status from Firestore:", e);
    }
  }

  return false;
};

/**
 * Synchronously checks if current user or device has already shared this item locally
 */
export const hasUserSharedLocally = (
  collectionName: 'posts' | 'videos',
  itemId: string,
  currentUser: User | null
): boolean => {
  if (!itemId) return false;
  const userIdentifier = currentUser?.uid ? currentUser.uid : getOrCreateGuestDeviceId();
  const localKey = `pt_shared_${collectionName}_${itemId}_${userIdentifier}`;
  try {
    return localStorage.getItem(localKey) === 'true';
  } catch {
    return false;
  }
};

// In-flight locks to prevent rapid multi-click race conditions
const inFlightShares = new Set<string>();

/**
 * Increments share count strictly ONCE per user (One User One Share Count)
 */
export const recordShareCountOnce = async (
  collectionName: 'posts' | 'videos',
  itemId: string,
  currentUser: User | null
): Promise<boolean> => {
  if (!itemId) return false;

  const userIdentifier = currentUser?.uid ? currentUser.uid : getOrCreateGuestDeviceId();
  const localKey = `pt_shared_${collectionName}_${itemId}_${userIdentifier}`;

  // 1. Check in-flight lock (prevents double-tap race condition)
  if (inFlightShares.has(localKey)) {
    return false;
  }

  // 2. Check local storage cache first
  try {
    if (localStorage.getItem(localKey) === 'true') {
      return false; // Already shared by this user/device
    }
  } catch {}

  inFlightShares.add(localKey);

  try {
    const shareRef = db
      .collection(collectionName)
      .doc(itemId)
      .collection('shares')
      .doc(userIdentifier);

    // 3. Verify in Firestore if this user ID has already shared
    const existingDoc = await shareRef.get().catch(() => null);
    if (existingDoc && existingDoc.exists) {
      try {
        localStorage.setItem(localKey, 'true');
      } catch {}
      return false; // Already recorded in Firestore
    }

    // 4. Record new unique share for this user ID and atomically increment count
    const itemRef = db.collection(collectionName).doc(itemId);
    const batch = db.batch();

    batch.set(shareRef, {
      userId: userIdentifier,
      userName: currentUser?.name || (currentUser ? 'User' : 'Guest'),
      userProfilePicUrl: currentUser?.profilePicUrl || '',
      isGuest: !currentUser?.uid,
      sharedAt: serverTimestamp(),
    });

    batch.update(itemRef, {
      shareCount: increment(1),
    });

    try {
      await batch.commit();
    } catch (batchErr) {
      console.warn("Batch share update failed, trying fallback update:", batchErr);
      // Fallback: write share doc and set shareCount with merge
      await shareRef.set({
        userId: userIdentifier,
        userName: currentUser?.name || (currentUser ? 'User' : 'Guest'),
        userProfilePicUrl: currentUser?.profilePicUrl || '',
        isGuest: !currentUser?.uid,
        sharedAt: serverTimestamp(),
      }).catch(() => {});
      await itemRef.set({
        shareCount: increment(1),
      }, { merge: true }).catch(() => {});
    }

    try {
      localStorage.setItem(localKey, 'true');
    } catch {}

    return true; // Successfully counted for the first time
  } catch (err) {
    console.warn("Share count record error:", err);
    try {
      localStorage.setItem(localKey, 'true');
    } catch {}
    return false;
  } finally {
    inFlightShares.delete(localKey);
  }
};

/**
 * Handles full share flow for a Post:
 * - Formats the message according to specifications
 * - Increments shareCount strictly ONCE per user ID
 * - Opens Native Share Sheet or WhatsApp fallback with Clipboard copy
 * - Returns boolean indicating if a new unique share was registered
 */
export const sharePost = async ({
  post,
  currentUser,
  showToast,
}: {
  post: { id: string; title: string; content?: string; shareCount?: number };
  currentUser: User | null;
  showToast?: (msg: string, type?: 'success' | 'info' | 'error') => void;
}): Promise<boolean> => {
  const shareText = buildPostShareText(post);

  // Enforce "One User One Share Count" in background
  const isNewSharePromise = recordShareCountOnce('posts', post.id, currentUser);

  // 1. Prioritize Capacitor Native Share on Mobile / Android
  if (Capacitor.isNativePlatform()) {
    try {
      await Share.share({
        title: post.title,
        text: shareText,
        dialogTitle: 'Share News - Public Tak App',
      });
      return await isNewSharePromise;
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return await isNewSharePromise;
      }
    }
  }

  // 2. Web fallback: navigator.share
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: post.title,
        text: shareText,
      });
      return await isNewSharePromise;
    } catch (err: any) {
      if (err?.name !== 'AbortError') {
        await copyTextToClipboard(shareText);
        if (showToast) {
          showToast("शेयर संदेश क्लिपबोर्ड पर कॉपी हो गया है!", "success");
        }
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
      }
    }
  } else {
    await copyTextToClipboard(shareText);
    if (showToast) {
      showToast("शेयर संदेश क्लिपबोर्ड पर कॉपी हो गया है!", "success");
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
  }

  return await isNewSharePromise;
};

/**
 * Handles full share flow for a Video with 1 user 1 share count rule
 * - Returns boolean indicating if a new unique share was registered
 */
export const shareVideo = async ({
  video,
  currentUser,
  showToast,
}: {
  video: { id: string; title: string; description?: string; shareCount?: number };
  currentUser: User | null;
  showToast?: (msg: string, type?: 'success' | 'info' | 'error') => void;
}): Promise<boolean> => {
  const shareText = buildVideoShareText(video);

  // Enforce "One User One Share Count"
  const isNewSharePromise = recordShareCountOnce('videos', video.id, currentUser);

  // 1. Prioritize Capacitor Native Share on Mobile / Android
  if (Capacitor.isNativePlatform()) {
    try {
      await Share.share({
        title: video.title,
        text: shareText,
        dialogTitle: 'Share Video - Public Tak App',
      });
      return await isNewSharePromise;
    } catch (err: any) {
      if (err?.name === 'AbortError') {
        return await isNewSharePromise;
      }
    }
  }

  // 2. Web fallback: navigator.share
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      await navigator.share({
        title: video.title,
        text: shareText,
      });
      return await isNewSharePromise;
    } catch (err: any) {
      if (err?.name !== 'AbortError') {
        await copyTextToClipboard(shareText);
        if (showToast) {
          showToast("शेयर संदेश क्लिपबोर्ड पर कॉपी हो गया है!", "success");
        }
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
      }
    }
  } else {
    await copyTextToClipboard(shareText);
    if (showToast) {
      showToast("शेयर संदेश क्लिपबोर्ड पर कॉपी हो गया है!", "success");
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
  }

  return await isNewSharePromise;
};
