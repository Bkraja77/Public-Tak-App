
export const APP_LOGO_URL = "/icon-512.png";
export const APP_NAME = "Public Tak App";
export const VAPID_KEY = "BBBJi8aX5na1f3dCbUI3384YMgd1UcgICxzdegqH1HXWYfC2Ma1aCW-PKOGngD84E7rd5ErU5AcwfE_Oo_8ZJX8";
