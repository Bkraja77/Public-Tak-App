import { db } from '../firebaseConfig';
import { appCacheService } from '../services/appCacheService';

export const DEFAULT_NEWS_CATEGORIES = [
  'Politics',
  'Crime',
  'Sports',
  'Entertainment',
  'Business',
  'Technology',
  'Health',
  'Education',
  'Jobs',
  'World',
  'General'
];

export const DEFAULT_VIDEO_CATEGORIES = [
  'Politics',
  'Crime',
  'Sports',
  'Entertainment',
  'Business',
  'Technology',
  'Health',
  'Education',
  'Jobs',
  'World',
  'General'
];

export interface CategoriesData {
  newsCategories: string[];
  videoCategories: string[];
}

/**
 * Subscribes to categories stored in Firestore settings/categories doc.
 * Falls back to default categories if the doc doesn't exist or fails.
 */
export const subscribeCategories = (
  callback: (data: CategoriesData) => void
): (() => void) => {
  // Immediately serve from fast local cache to eliminate initial category delay
  const cached = appCacheService.getCachedCategories();
  if (cached && cached.newsCategories && cached.videoCategories) {
    callback(cached);
  }

  return db.collection('settings')
    .doc('categories')
    .onSnapshot(
      (doc) => {
        if (doc.exists) {
          const data = doc.data();
          const rawNews = data?.newsCategories || DEFAULT_NEWS_CATEGORIES;
          const rawVideo = data?.videoCategories || DEFAULT_VIDEO_CATEGORIES;
          
          const newsSet = new Set<string>(rawNews);
          const videoSet = new Set<string>(rawVideo);
          
          if (!newsSet.has('Education')) newsSet.add('Education');
          if (!newsSet.has('Jobs')) newsSet.add('Jobs');
          if (!videoSet.has('Education')) videoSet.add('Education');
          if (!videoSet.has('Jobs')) videoSet.add('Jobs');

          const finalData: CategoriesData = {
            newsCategories: Array.from(newsSet),
            videoCategories: Array.from(videoSet)
          };

          appCacheService.setCachedCategories(finalData);
          callback(finalData);
        } else {
          const fallbackData: CategoriesData = {
            newsCategories: DEFAULT_NEWS_CATEGORIES,
            videoCategories: DEFAULT_VIDEO_CATEGORIES
          };
          appCacheService.setCachedCategories(fallbackData);
          callback(fallbackData);
        }
      },
      (error) => {
        console.warn('Using default categories due to fetch error:', error?.message || error);
        const fallbackData: CategoriesData = {
          newsCategories: DEFAULT_NEWS_CATEGORIES,
          videoCategories: DEFAULT_VIDEO_CATEGORIES
        };
        callback(fallbackData);
      }
    );
};

/**
 * Saves the updated categories lists to Firestore.
 */
export const saveCategories = async (news: string[], video: string[]) => {
  await db.collection('settings').doc('categories').set({
    newsCategories: [...new Set(news)],
    videoCategories: [...new Set(video)]
  }, { merge: true });
};
