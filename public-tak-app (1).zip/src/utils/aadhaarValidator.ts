// UIDAI Verhoeff Algorithm for Aadhaar Validation
const d: number[][] = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
  [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
  [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
  [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
  [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
  [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
  [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
  [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
  [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
];

const p: number[][] = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
  [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
  [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
  [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
  [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
  [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
  [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
];

/**
 * Validates an Aadhaar number using length, digit restrictions and Verhoeff algorithm.
 */
export function validateAadhaarChecksum(aadhaarString: string): { isValid: boolean; error?: string } {
  const clean = aadhaarString.replace(/\s+/g, '').replace(/-/g, '');

  if (!clean) {
    return { isValid: false, error: 'कृपया 12 अंकों का आधार नंबर दर्ज करें।' };
  }

  if (!/^\d{12}$/.test(clean)) {
    return { isValid: false, error: 'आधार नंबर केवल 12 अंकों का होना चाहिए।' };
  }

  // Aadhaar numbers never start with 0 or 1
  if (clean[0] === '0' || clean[0] === '1') {
    return { isValid: false, error: 'अमान्य आधार नंबर! UIDAI नियमानुसार आधार 0 या 1 से शुरू नहीं होता।' };
  }

  // Repeated identical digits e.g. 222222222222, 999999999999 are fake
  if (/^(\d)\1{11}$/.test(clean)) {
    return { isValid: false, error: 'अमान्य/फेक आधार नंबर! सभी 12 अंक एक जैसे नहीं हो सकते।' };
  }

  // Sequential digits like 123456789012 or 987654321098
  if (clean === '123456789012' || clean === '987654321098' || clean === '234567890123') {
    return { isValid: false, error: 'अमान्य आधार नंबर! फर्जी या काल्पनिक नंबर मान्य नहीं है।' };
  }

  // Verhoeff algorithm checksum validation
  let c = 0;
  const reversedArray = clean.split('').map(Number).reverse();
  for (let i = 0; i < reversedArray.length; i++) {
    c = d[c][p[i % 8][reversedArray[i]]];
  }

  if (c !== 0) {
    return {
      isValid: false,
      error: 'अमान्य आधार नंबर! UIDAI चेकसम एल्गोरिदम विफल रहा (Fake/Invalid Aadhaar)। कृपया अपना असली आधार नंबर दर्ज करें।'
    };
  }

  return { isValid: true };
}
