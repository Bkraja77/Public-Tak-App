export interface SafetyCheckResult {
    isViolated: boolean;
    reason: string;
    category?: string;
    severity?: 'high' | 'medium' | 'low' | string;
}

export const checkContentSafety = async (
    title: string, 
    content: string, 
    type: 'article' | 'video' = 'article',
    category?: string
): Promise<SafetyCheckResult> => {
    try {
        const response = await fetch("/api/safety-check", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ title, content, description: content, type, category })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        return {
            isViolated: !!result.isViolated,
            reason: result.reason || "",
            category: result.category || "General",
            severity: result.severity || "medium"
        };
    } catch (error) {
        console.error("Safety check client request failed:", error);
        // Fail-safe default: allow publishing if the API fails
        return { isViolated: false, reason: "", category: "General", severity: "low" };
    }
};
