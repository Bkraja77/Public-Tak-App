import { useState, useEffect, useRef } from 'react';
import { db, firebase } from '../firebaseConfig';
import { User } from '../types';

export interface CachedUserProfile {
  uid: string;
  name?: string;
  username?: string;
  profilePicUrl?: string;
  isVerified?: boolean;
  role?: string;
  updatedAt: number;
}

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes cache TTL
const PROFILE_UPDATED_EVENT = 'publictak_profile_pic_updated';

class UserProfileCacheManager {
  private cache: Map<string, CachedUserProfile> = new Map();
  private subscribers: Map<string, Set<(profile: CachedUserProfile) => void>> = new Map();
  private pendingUids: Set<string> = new Set();
  private batchTimer: any = null;
  private inflightBatch: Promise<void> | null = null;

  constructor() {
    // Try to load cached profiles from sessionStorage if available
    try {
      if (typeof window !== 'undefined' && window.sessionStorage) {
        const stored = window.sessionStorage.getItem('pt_user_profiles_cache');
        if (stored) {
          const parsed = JSON.parse(stored);
          const now = Date.now();
          for (const key in parsed) {
            // Only keep if younger than TTL
            if (now - parsed[key].updatedAt < CACHE_TTL_MS) {
              this.cache.set(key, parsed[key]);
            }
          }
        }
      }
    } catch (e) {
      // Ignore storage errors
    }

    // Listen to profile update broadcast across tabs or window
    if (typeof window !== 'undefined') {
      window.addEventListener(PROFILE_UPDATED_EVENT, (event: any) => {
        const detail = event.detail;
        if (detail && detail.uid) {
          this.updateUser(detail.uid, detail);
        }
      });
    }
  }

  private persistSession() {
    try {
      if (typeof window !== 'undefined' && window.sessionStorage) {
        const obj: Record<string, CachedUserProfile> = {};
        // Store only top 100 recent entries to save space
        let count = 0;
        for (const [k, v] of this.cache.entries()) {
          if (count++ > 100) break;
          obj[k] = v;
        }
        window.sessionStorage.setItem('pt_user_profiles_cache', JSON.stringify(obj));
      }
    } catch (e) {
      // Ignore storage quota errors
    }
  }

  public get(uid: string): CachedUserProfile | undefined {
    return this.cache.get(uid);
  }

  /**
   * Immediately updates the cache for a user and alerts all subscribed UI components
   */
  public updateUser(uid: string, data: Partial<CachedUserProfile>, broadcast = true): void {
    if (!uid) return;
    const existing = this.cache.get(uid) || { uid, updatedAt: Date.now() };
    const updated: CachedUserProfile = {
      ...existing,
      ...data,
      uid,
      updatedAt: Date.now(),
    };
    this.cache.set(uid, updated);
    this.persistSession();

    // Notify all active React hook listeners
    const subs = this.subscribers.get(uid);
    if (subs) {
      subs.forEach((cb) => {
        try {
          cb(updated);
        } catch (err) {
          console.error("Error in profile subscriber callback:", err);
        }
      });
    }

    // Broadcast event across the application
    if (broadcast && typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(PROFILE_UPDATED_EVENT, {
          detail: updated,
        })
      );
    }
  }

  /**
   * Subscribe to live profile changes for a specific user ID
   */
  public subscribe(uid: string, callback: (profile: CachedUserProfile) => void): () => void {
    if (!this.subscribers.has(uid)) {
      this.subscribers.set(uid, new Set());
    }
    this.subscribers.get(uid)!.add(callback);

    return () => {
      const subs = this.subscribers.get(uid);
      if (subs) {
        subs.delete(callback);
        if (subs.size === 0) {
          this.subscribers.delete(uid);
        }
      }
    };
  }

  /**
   * Request a user's profile with debounced batch fetching
   */
  public request(uid: string): void {
    if (!uid) return;
    const cached = this.cache.get(uid);
    const isFresh = cached && Date.now() - cached.updatedAt < CACHE_TTL_MS;
    if (isFresh) return;

    this.pendingUids.add(uid);
    if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.batchTimer = null;
        this.flushPending();
      }, 40); // 40ms debounce to bundle queries together
    }
  }

  private async flushPending(): Promise<void> {
    if (this.pendingUids.size === 0) return;

    const uidsToFetch = Array.from(this.pendingUids).slice(0, 30); // Max 30 in 'in' query
    for (const id of uidsToFetch) {
      this.pendingUids.delete(id);
    }

    try {
      if (uidsToFetch.length === 1) {
        // Single doc fetch
        const uid = uidsToFetch[0];
        const docSnap = await db.collection('users').doc(uid).get();
        if (docSnap.exists) {
          const data = docSnap.data() || {};
          this.updateUser(
            uid,
            {
              name: data.name,
              username: data.username,
              profilePicUrl: data.profilePicUrl,
              isVerified: data.isVerified,
              role: data.role,
            },
            false
          );
        }
      } else if (uidsToFetch.length > 1) {
        // Batched query using documentId 'in'
        const snapshot = await db
          .collection('users')
          .where(firebase.firestore.FieldPath.documentId(), 'in', uidsToFetch)
          .get();

        snapshot.forEach((doc: any) => {
          const data = doc.data() || {};
          this.updateUser(
            doc.id,
            {
              name: data.name,
              username: data.username,
              profilePicUrl: data.profilePicUrl,
              isVerified: data.isVerified,
              role: data.role,
            },
            false
          );
        });
      }
    } catch (error) {
      // Fallback: individually try to fetch single docs silently if batch fails
      for (const uid of uidsToFetch) {
        try {
          const docSnap = await db.collection('users').doc(uid).get();
          if (docSnap.exists) {
            const data = docSnap.data() || {};
            this.updateUser(
              uid,
              {
                name: data.name,
                username: data.username,
                profilePicUrl: data.profilePicUrl,
                isVerified: data.isVerified,
                role: data.role,
              },
              false
            );
          }
        } catch (e) {
          // ignore individual fetch failure
        }
      }
    }

    // If there are more pending, trigger next batch
    if (this.pendingUids.size > 0) {
      setTimeout(() => this.flushPending(), 50);
    }
  }
}

export const userProfileCache = new UserProfileCacheManager();

/**
 * Custom React Hook that guarantees the latest profile picture for any user ID:
 * - If user is currentUser, it returns currentUser.profilePicUrl immediately.
 * - For any other user, it resolves from cache or fetches from users collection.
 * - Reacts immediately whenever a profile picture changes anywhere in the app!
 */
export function useUserAvatar(
  userId?: string | null,
  fallbackUrl?: string | null,
  userName?: string | null,
  currentUser?: User | null
): string {
  const isCurrentUser = Boolean(userId && currentUser && userId === currentUser.uid);

  // Default dicebear avatar fallback
  const getDefaultAvatar = () => {
    return `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(userName || 'User')}`;
  };

  const computeCurrentUrl = (): string => {
    if (isCurrentUser && currentUser?.profilePicUrl) {
      return currentUser.profilePicUrl;
    }
    if (userId) {
      const cached = userProfileCache.get(userId);
      if (cached && cached.profilePicUrl) {
        return cached.profilePicUrl;
      }
    }
    return fallbackUrl || getDefaultAvatar();
  };

  const [avatarUrl, setAvatarUrl] = useState<string>(computeCurrentUrl);

  useEffect(() => {
    // If it's currentUser, update directly when currentUser.profilePicUrl changes
    if (isCurrentUser) {
      if (currentUser?.profilePicUrl) {
        setAvatarUrl(currentUser.profilePicUrl);
        // Also ensure cache is up to date
        userProfileCache.updateUser(currentUser.uid, {
          profilePicUrl: currentUser.profilePicUrl,
          name: currentUser.name,
        }, false);
      } else if (fallbackUrl) {
        setAvatarUrl(fallbackUrl);
      }
      return;
    }

    if (!userId) {
      setAvatarUrl(fallbackUrl || getDefaultAvatar());
      return;
    }

    // Check cache
    const cached = userProfileCache.get(userId);
    if (cached && cached.profilePicUrl) {
      setAvatarUrl(cached.profilePicUrl);
    } else {
      if (fallbackUrl) {
        setAvatarUrl(fallbackUrl);
      }
      // Request latest profile from Firestore
      userProfileCache.request(userId);
    }

    // Subscribe to live changes
    const unsubscribe = userProfileCache.subscribe(userId, (updatedProfile) => {
      if (updatedProfile.profilePicUrl) {
        setAvatarUrl(updatedProfile.profilePicUrl);
      }
    });

    return () => unsubscribe();
  }, [userId, currentUser?.uid, currentUser?.profilePicUrl, fallbackUrl, isCurrentUser]);

  return avatarUrl || getDefaultAvatar();
}

/**
 * Hook to retrieve full user profile data (name, avatar, verification) with automatic updates
 */
export function useUserProfile(userId?: string | null, currentUser?: User | null) {
  const isCurrentUser = Boolean(userId && currentUser && userId === currentUser.uid);

  const [profile, setProfile] = useState<{
    name?: string;
    profilePicUrl?: string;
    isVerified?: boolean;
    username?: string;
  }>(() => {
    if (isCurrentUser && currentUser) {
      return {
        name: currentUser.name,
        profilePicUrl: currentUser.profilePicUrl,
        isVerified: currentUser.isVerified,
        username: currentUser.username,
      };
    }
    if (userId) {
      const cached = userProfileCache.get(userId);
      if (cached) {
        return {
          name: cached.name,
          profilePicUrl: cached.profilePicUrl,
          isVerified: cached.isVerified,
          username: cached.username,
        };
      }
    }
    return {};
  });

  useEffect(() => {
    if (isCurrentUser && currentUser) {
      setProfile({
        name: currentUser.name,
        profilePicUrl: currentUser.profilePicUrl,
        isVerified: currentUser.isVerified,
        username: currentUser.username,
      });
      return;
    }

    if (!userId) return;

    const cached = userProfileCache.get(userId);
    if (cached) {
      setProfile({
        name: cached.name,
        profilePicUrl: cached.profilePicUrl,
        isVerified: cached.isVerified,
        username: cached.username,
      });
    } else {
      userProfileCache.request(userId);
    }

    const unsub = userProfileCache.subscribe(userId, (updated) => {
      setProfile({
        name: updated.name,
        profilePicUrl: updated.profilePicUrl,
        isVerified: updated.isVerified,
        username: updated.username,
      });
    });

    return () => unsub();
  }, [userId, currentUser?.uid, currentUser?.profilePicUrl, currentUser?.name, currentUser?.isVerified, isCurrentUser]);

  return profile;
}
