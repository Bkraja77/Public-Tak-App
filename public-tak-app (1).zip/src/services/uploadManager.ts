import { db, storage, serverTimestamp, increment } from '../firebaseConfig';
import { v4 as uuidv4 } from 'uuid';
import { checkContentSafety } from './geminiService';

export interface UploadingVideo {
  id: string;
  title: string;
  description: string;
  category: string;
  state: string;
  district: string;
  block: string;
  locationType: 'Overall' | 'State' | 'District' | 'Block';
  progress: number;
  stage: 'Safety' | 'Thumbnail' | 'Video' | 'Publishing' | 'Done' | 'Error';
  error: string | null;
  thumbnailUrl: string; // Used for local preview as well as final URL
  videoUrl?: string;
  createdAt: number;
}

type Listener = (uploads: UploadingVideo[]) => void;

class UploadManager {
  private uploads: UploadingVideo[] = [];
  private listeners: Set<Listener> = new Set();
  private activeUploadTasks: Map<string, any[]> = new Map();
  private cancelledUploads: Set<string> = new Set();

  constructor() {
    // Load existing/recent non-completed uploads or state if any from memory
  }

  getUploads(): UploadingVideo[] {
    return this.uploads;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    // Initial call
    listener(this.uploads);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => listener([...this.uploads]));
  }

  private uploadFileWithProgress(
    uploadId: string,
    file: File,
    path: string,
    contentType: string,
    onProgress: (percent: number) => void
  ): Promise<string> {
    return new Promise((resolve, reject) => {
      if (this.cancelledUploads.has(uploadId)) {
        reject(new Error("CANCELED"));
        return;
      }

      const fileRef = storage.ref(path);
      
      let currentPercent = 0;
      const fileSizeMB = file.size / (1024 * 1024);
      const estimatedTimeMs = Math.max(3000, Math.min(15000, fileSizeMB * 800)); // Enhanced/Optimized for fast uploads
      const intervalMs = 100;
      const totalSteps = estimatedTimeMs / intervalMs;
      const stepIncrement = 95 / totalSteps;
      
      const progressInterval = setInterval(() => {
        if (this.cancelledUploads.has(uploadId)) {
          clearInterval(progressInterval);
          reject(new Error("CANCELED"));
          return;
        }
        if (currentPercent < 95) {
          const remaining = 95 - currentPercent;
          const decayFactor = remaining / 95;
          currentPercent = Math.min(95, currentPercent + (stepIncrement * (0.2 + decayFactor * 0.8)));
          onProgress(currentPercent);
        }
      }, intervalMs);

      const uploadTask = fileRef.put(file, { contentType });
      
      // Keep track of tasks
      const tasks = this.activeUploadTasks.get(uploadId) || [];
      tasks.push(uploadTask);
      this.activeUploadTasks.set(uploadId, tasks);
      
      uploadTask.on('state_changed', 
        (snapshot) => {
          if (this.cancelledUploads.has(uploadId)) {
            clearInterval(progressInterval);
            try {
              uploadTask.cancel();
            } catch (e) {}
            reject(new Error("CANCELED"));
            return;
          }
          const realPercent = snapshot.totalBytes > 0 
            ? (snapshot.bytesTransferred / snapshot.totalBytes) * 100 
            : 0;
          if (realPercent > currentPercent) {
            currentPercent = Math.min(98, realPercent);
            onProgress(currentPercent);
          }
        },
        (error) => {
          clearInterval(progressInterval);
          // Remove task
          const currentTasks = this.activeUploadTasks.get(uploadId) || [];
          this.activeUploadTasks.set(uploadId, currentTasks.filter(t => t !== uploadTask));
          reject(error);
        },
        async () => {
          try {
            clearInterval(progressInterval);
            onProgress(100);
            const downloadUrl = await uploadTask.snapshot.ref.getDownloadURL();
            // Remove task
            const currentTasks = this.activeUploadTasks.get(uploadId) || [];
            this.activeUploadTasks.set(uploadId, currentTasks.filter(t => t !== uploadTask));
            resolve(downloadUrl);
          } catch (urlErr) {
            reject(urlErr);
          }
        }
      );
    });
  }

  async startUpload(params: {
    title: string;
    description: string;
    category: string;
    state: string;
    district: string;
    block: string;
    locationType: 'Overall' | 'State' | 'District' | 'Block';
    thumbnailFile: File;
    videoFile: File;
    currentUser: { uid: string; name: string; profilePicUrl?: string; isVerified?: boolean; role?: string };
    draftId?: string | null;
  }) {
    const uploadId = uuidv4();
    
    // Create local object URL for preview
    const localThumbnailUrl = URL.createObjectURL(params.thumbnailFile);

    const newUpload: UploadingVideo = {
      id: uploadId,
      title: params.title,
      description: params.description,
      category: params.category,
      state: params.state,
      district: params.district,
      block: params.block,
      locationType: params.locationType,
      progress: 0,
      stage: 'Safety',
      error: null,
      thumbnailUrl: localThumbnailUrl,
      createdAt: Date.now()
    };

    this.uploads.push(newUpload);
    this.notify();

    // Run actual upload process in the background
    this.processUpload(uploadId, params).catch((err) => {
      console.error("Background upload failed for ID:", uploadId, err);
    });

    return uploadId;
  }

  private async processUpload(
    uploadId: string,
    params: {
      title: string;
      description: string;
      category: string;
      state: string;
      district: string;
      block: string;
      locationType: 'Overall' | 'State' | 'District' | 'Block';
      thumbnailFile: File;
      videoFile: File;
      currentUser: { uid: string; name: string; profilePicUrl?: string; isVerified?: boolean; role?: string };
      draftId?: string | null;
    }
  ) {
    const updateLocalState = (fields: Partial<UploadingVideo>) => {
      const idx = this.uploads.findIndex((u) => u.id === uploadId);
      if (idx !== -1) {
        this.uploads[idx] = { ...this.uploads[idx], ...fields };
        this.notify();
      }
    };

    try {
      // 1. Content Safety Guard
      updateLocalState({ stage: 'Safety', progress: 5 });
      const safety = await checkContentSafety(params.title, params.description, 'video', params.category);
      
      if (this.cancelledUploads.has(uploadId)) throw new Error("CANCELED");

      const isViolated = safety.isViolated;
      const flaggedReason = safety.reason || "Violates community guidelines";
      const flaggedCategory = safety.category || "Harmful Content";
      const flaggedSeverity = safety.severity || "high";

      if (this.cancelledUploads.has(uploadId)) throw new Error("CANCELED");

      // 2. Upload Thumbnail
      updateLocalState({ stage: 'Thumbnail', progress: 15 });
      const thumbnailExt = params.thumbnailFile.name.split('.').pop() || 'jpg';
      let thumbnailContentType = params.thumbnailFile.type || 'image/jpeg';
      if (!thumbnailContentType.startsWith('image/')) {
        thumbnailContentType = 'image/jpeg';
      }

      const finalThumbnailUrl = await this.uploadFileWithProgress(
        uploadId,
        params.thumbnailFile,
        `thumbnails/${uuidv4()}.${thumbnailExt}`,
        thumbnailContentType,
        (percent) => {
          // Thumbnail accounts for 15% to 30% progress
          const overallPercent = 15 + Math.round((percent / 100) * 15);
          updateLocalState({ progress: overallPercent });
        }
      );

      if (this.cancelledUploads.has(uploadId)) throw new Error("CANCELED");

      // 3. Upload Video
      updateLocalState({ stage: 'Video', progress: 30, thumbnailUrl: finalThumbnailUrl });
      const videoExt = params.videoFile.name.split('.').pop() || 'mp4';
      let videoContentType = params.videoFile.type || 'video/mp4';
      if (!videoContentType.startsWith('video/')) {
        videoContentType = 'video/mp4';
      }

      const finalVideoUrl = await this.uploadFileWithProgress(
        uploadId,
        params.videoFile,
        `post-images/${uuidv4()}.${videoExt}`,
        videoContentType,
        (percent) => {
          // Video accounts for 30% to 90% progress
          const overallPercent = 30 + Math.round((percent / 100) * 60);
          updateLocalState({ progress: overallPercent });
        }
      );

      if (this.cancelledUploads.has(uploadId)) throw new Error("CANCELED");

      // 4. Save to Firestore
      updateLocalState({ stage: 'Publishing', progress: 90, videoUrl: finalVideoUrl });

      const newVideoRef = await db.collection("videos").add({
        title: params.title,
        description: params.description.trim(),
        videoUrl: finalVideoUrl,
        thumbnailUrl: finalThumbnailUrl,
        authorId: params.currentUser.uid,
        authorName: params.currentUser.name,
        authorProfilePicUrl: params.currentUser.profilePicUrl || '',
        authorIsVerified: params.currentUser.isVerified || false,
        viewCount: 0,
        likeCount: 0,
        commentCount: 0,
        shareCount: 0,
        category: params.category,
        createdAt: serverTimestamp(),
        locationType: params.locationType,
        state: params.state,
        district: params.district,
        block: params.block,
        flagged: isViolated,
        flaggedReason: isViolated ? flaggedReason : null,
        flaggedCategory: isViolated ? flaggedCategory : null,
        flaggedSeverity: isViolated ? flaggedSeverity : null,
        isHidden: isViolated,
        status: isViolated ? 'flagged' : 'published'
      });

      // If AI flagged as harmful content, add to Admin Reports & notify user & admins
      if (isViolated) {
        try {
          // 1. Add to Admin Reports collection
          await db.collection('reports').add({
            postId: newVideoRef.id,
            postTitle: params.title,
            contentType: 'video',
            reporterId: 'AI_SAFETY_GUARD',
            reporterName: '🤖 AI Safety Moderation Bot',
            reason: `[AI Flagged - ${flaggedCategory}]: ${flaggedReason}`,
            category: flaggedCategory,
            severity: flaggedSeverity,
            createdAt: serverTimestamp(),
            isAiFlagged: true,
            authorId: params.currentUser.uid,
            authorName: params.currentUser.name
          });

          // 2. Alert User via In-App Notification
          await db.collection('users').doc(params.currentUser.uid).collection('notifications').add({
            type: 'harmful_content_alert',
            title: '⚠️ AI सुरक्षा चेतावनी (Video Flagged)',
            body: `आपके वीडियो "${params.title}" में हानिकारक सामग्री पाई गई है: (${flaggedReason})। इसे एडमिन समीक्षा के लिए भेज दिया गया है और फ़ीड से छुपा दिया गया है।`,
            read: false,
            createdAt: serverTimestamp()
          });

          // 3. Notify Admins
          const admins = await db.collection('users').where('role', '==', 'admin').get();
          const batch = db.batch();
          admins.forEach((adminDoc) => {
            const noticeRef = db.collection('users').doc(adminDoc.id).collection('notifications').doc();
            batch.set(noticeRef, {
              type: 'harmful_content',
              title: "⚠️ AI Flagged Video for Review!",
              body: `${params.currentUser.name} posted video flagged by AI: "${params.title}". Reason: ${flaggedReason}`,
              read: false,
              createdAt: serverTimestamp(),
              fromUserId: params.currentUser.uid
            });
          });
          await batch.commit();
        } catch (alertErr) {
          console.error("Error creating AI moderation alert for video:", alertErr);
        }
      }

      // Delete draft if applicable
      if (params.draftId) {
        try {
          await db.collection('users').doc(params.currentUser.uid).collection('drafts').doc(params.draftId).delete();
        } catch (draftErr) {
          console.error("Draft deletion failed:", draftErr);
        }
      }

      // Referral Conditional Bonus (₹3 on first post)
      try {
        const userDoc = await db.collection('users').doc(params.currentUser.uid).get();
        const userData = userDoc.data();
        if (userData && !userData.hasPostedFirstNews && userData.referredBy) {
          const referrerId = userData.referredBy;
          const referrerRef = db.collection('users').doc(referrerId);
          
          await referrerRef.update({
            walletBalance: increment(3),
            totalEarnings: increment(3)
          });

          // Log the post bonus
          await referrerRef.collection('referrals').add({
            newUserId: params.currentUser.uid,
            amount: 3,
            type: 'post_bonus',
            timestamp: serverTimestamp()
          });

          // Notification for referrer
          await referrerRef.collection('notifications').add({
            title: "Referral Active! ✍️",
            body: `Your referral ${params.currentUser.name} posted their first news (video). ₹3 added to your wallet.`,
            read: false,
            timestamp: serverTimestamp(),
            type: 'referral'
          });

          // Update current user
          await db.collection('users').doc(params.currentUser.uid).update({
            hasPostedFirstNews: true
          });
        } else if (userData && !userData.hasPostedFirstNews) {
          await db.collection('users').doc(params.currentUser.uid).update({
            hasPostedFirstNews: true
          });
        }
      } catch (refError) {
        console.error("Error crediting referral post bonus in background:", refError);
      }

      // Notify Followers
      try {
        const followersSnapshot = await db.collection('users').doc(params.currentUser.uid).collection('followers').get();
        if (!followersSnapshot.empty) {
          const notificationBatch = db.batch();
          followersSnapshot.forEach(followerDoc => {
            const followerId = followerDoc.id;
            const notificationRef = db.collection('users').doc(followerId).collection('notifications').doc();
            notificationBatch.set(notificationRef, {
              type: 'new_post',
              fromUserId: params.currentUser.uid,
              fromUserName: params.currentUser.name,
              fromUserProfilePicUrl: params.currentUser.profilePicUrl || '',
              fromUserIsVerified: params.currentUser.isVerified || false,
              postId: newVideoRef.id,
              postTitle: params.title,
              postThumbnailUrl: finalThumbnailUrl || '',
              postType: 'video',
              createdAt: serverTimestamp(),
              read: false
            });
          });
          await notificationBatch.commit();
        }

        // Trigger Server FCM push notifications for video
        try {
          await fetch("/api/notify-followers", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              publisherId: params.currentUser.uid,
              videoId: newVideoRef.id,
              type: 'video',
              title: params.title,
              description: params.description || '',
              thumbnailUrl: finalThumbnailUrl || '',
              publisherName: params.currentUser.name,
              publisherProfilePicUrl: params.currentUser.profilePicUrl || ''
            })
          });
        } catch (pushErr) {
          console.error("FCM Video push notification trigger failed:", pushErr);
        }
      } catch (notifError) {
        console.error("Follower notifications failed in background:", notifError);
      }

      // Mark upload as done and clean up local ObjectURL
      updateLocalState({ stage: 'Done', progress: 100 });
      try {
        URL.revokeObjectURL(params.thumbnailFile as any);
      } catch (revErr) {
        console.error("Revoke object url failed:", revErr);
      }

      // Automatically remove from background upload list after 4 seconds of completion
      setTimeout(() => {
        this.removeUpload(uploadId);
      }, 4000);

    } catch (err: any) {
      if (err?.message === 'CANCELED') {
        console.log("Background processing canceled for ID:", uploadId);
        return;
      }
      console.error("Background processing failed:", err);
      updateLocalState({
        stage: 'Error',
        error: err?.message || "Uploading failed due to an unexpected error.",
        progress: 0
      });
    }
  }

  cancelUpload(uploadId: string) {
    this.cancelledUploads.add(uploadId);
    
    // 1. Cancel active upload tasks in Firebase Storage
    const tasks = this.activeUploadTasks.get(uploadId);
    if (tasks) {
      tasks.forEach((task) => {
        try {
          task.cancel();
        } catch (taskErr) {
          console.warn("Failed to cancel active upload task:", taskErr);
        }
      });
      this.activeUploadTasks.delete(uploadId);
    }
    
    // 2. Remove from uploads list immediately
    this.removeUpload(uploadId);
    
    // Clean up cancelled set entry after a brief delay
    setTimeout(() => {
      this.cancelledUploads.delete(uploadId);
    }, 5000);
  }

  removeUpload(uploadId: string) {
    this.uploads = this.uploads.filter((u) => u.id !== uploadId);
    this.notify();
  }
}

export const uploadManager = new UploadManager();

// React hook to use the uploads list
import { useState, useEffect } from 'react';

export function useUploadingVideos() {
  const [uploads, setUploads] = useState<UploadingVideo[]>([]);

  useEffect(() => {
    return uploadManager.subscribe((currentUploads) => {
      setUploads(currentUploads);
    });
  }, []);

  return uploads;
}
