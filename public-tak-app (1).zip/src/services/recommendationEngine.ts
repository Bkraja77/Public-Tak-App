import { Post, Video } from '../types';

/**
 * Public Tak App - Recommendation & Growth Engine
 * Type definitions and executable metrics scoring logic.
 */

export interface UserInterestProfile {
    userId: string;
    preferredCategories: Record<string, number>; // Category name -> preference score
    preferredCreators: Record<string, number>;    // Creator Id -> preference score
    recentInteractions: Array<{
        contentId: string;
        category: string;
        action: string;
        timestamp: Date;
    }>;
}

// Action Weights as specified in the platform's Growth Algorithm
export const RECOMMENDATION_WEIGHTS = {
    FOLLOW_CREATOR: 25,
    SHARE: 20,
    COMMENT: 18,
    SAVE: 16,
    VIDEO_COMPLETION: 15,
    READ_FULL_ARTICLE: 14,
    REWATCH: 12,
    LIKE: 8,
    FAST_SKIP: -10,
    HIDE_POST: -20,
    REPORT: -40
};

// Category and Creator score bounds
const SCORE_MIN = -100;
const SCORE_MAX = 1000;
const DECAY_FACTOR_PER_DAY = 0.05; // gamma = 0.05

/**
 * 1. Track atomic user behavior and update the interest scores dynamically.
 * Keeps category and creator interest scores up-to-date.
 */
export function trackUserInteraction(
    profile: UserInterestProfile,
    category: string,
    creatorId: string,
    action: keyof typeof RECOMMENDATION_WEIGHTS
): UserInterestProfile {
    const updatedProfile = { ...profile };
    const weight = RECOMMENDATION_WEIGHTS[action] || 0;

    // 1. Update Category interest
    if (category) {
        const currentCategoryScore = updatedProfile.preferredCategories[category] || 0;
        updatedProfile.preferredCategories[category] = Math.max(
            SCORE_MIN,
            Math.min(SCORE_MAX, currentCategoryScore + weight)
        );
    }

    // 2. Update Creator interest
    if (creatorId) {
        const currentCreatorScore = updatedProfile.preferredCreators[creatorId] || 0;
        updatedProfile.preferredCreators[creatorId] = Math.max(
            SCORE_MIN,
            Math.min(SCORE_MAX, currentCreatorScore + weight)
        );
    }

    // 3. Keep track of recent interactions history
    updatedProfile.recentInteractions = [
        {
            contentId: '', // populated at runtime if available
            category,
            action,
            timestamp: new Date()
        },
        ...updatedProfile.recentInteractions
    ].slice(0, 50); // Keep last 50 interactions

    return updatedProfile;
}

/**
 * 2. Apply decay to old preferences.
 * Call this periodically (e.g. overnight simulation or on sessions started > 24h later).
 */
export function applyCategoryDecay(
    profile: UserInterestProfile,
    daysElapsed: number
): UserInterestProfile {
    const updatedProfile = { ...profile };
    const multiplier = Math.exp(-DECAY_FACTOR_PER_DAY * daysElapsed);

    // Decay Category scores towards 0
    for (const cat in updatedProfile.preferredCategories) {
        updatedProfile.preferredCategories[cat] = Number(
            (updatedProfile.preferredCategories[cat] * multiplier).toFixed(2)
        );
    }

    // Decay Creator scores towards 0
    for (const creator in updatedProfile.preferredCreators) {
        updatedProfile.preferredCreators[creator] = Number(
            (updatedProfile.preferredCreators[creator] * multiplier).toFixed(2)
        );
    }

    return updatedProfile;
}

/**
 * 3. Calculate Trending Score with gravity decay.
 * Formula:
 * Trending Score = [ (Watch Time * 25%) * (Completion Rate * 20%) * (Comment Quality * 15%) * (Shares * 20%) * (Saves * 10%) * (New Followers * 5%) * (Recent Growth Velocity * 5%) ] * DecayFactor
 *
 * Safe defaults are provided for attributes that might be missing in basic schemas.
 */
export interface TrendingMetrics {
    watchTimeHours: number;       // total watch time in hours
    completionRatePercent: number;// percentage of views completed (0-100)
    commentQualityScore: number;  // weighted comments count
    sharesCount: number;          // total times shared
    savesCount: number;           // total times saved
    newFollowersCount: number;    // followers gained from this content
    growthVelocity: number;       // acceleration ratio (e.g. 1.0 is stable, >1.0 is accelerating)
}

export function calculateTrendingScore(
    metrics: TrendingMetrics,
    ageInHours: number,
    gravity: number = 1.8
): number {
    // 1. Calculate Core Engagement Score based on weighted metrics
    const watchFactor = metrics.watchTimeHours * 0.25;
    const completionFactor = (metrics.completionRatePercent / 100) * 0.20;
    const commentFactor = metrics.commentQualityScore * 0.15;
    const shareFactor = metrics.sharesCount * 0.20;
    const saveFactor = metrics.savesCount * 0.10;
    const followerFactor = metrics.newFollowersCount * 0.05;
    const velocityFactor = metrics.growthVelocity * 0.05;

    // Use addition of these relative factor products to avoid any zero-multipliers ruining the entire trend
    const baseScore = (watchFactor + completionFactor + commentFactor + shareFactor + saveFactor + followerFactor + velocityFactor) * 1000;

    // 2. Apply Time Gravity Decay: 1 / (T + 2)^G
    const decayFactor = 1 / Math.pow(ageInHours + 2, gravity);

    return Number((baseScore * decayFactor).toFixed(4));
}

/**
 * 4. Personalized Hybrid Recommendation Engine
 * Merges Collaborative preferences, Geographic Proximity, Freshness, and Trending scores.
 */
export function calculatePersonalizedScore(
    userProfile: UserInterestProfile,
    content: Post | Video,
    options: {
        distanceKm?: number;
        isBreakingNews?: boolean;
        ageInHours?: number;
    } = {}
): number {
    let score = 0;

    // A. Dynamic Interest preference score alignment (Category mapping)
    const categoryPreference = userProfile.preferredCategories[content.category] || 0;
    score += categoryPreference * 1.5; // weight = 1.5

    // B. Creator Affinity (Author preference matching)
    const creatorPreference = userProfile.preferredCreators[content.authorId] || 0;
    score += creatorPreference * 2.0; // weight = 2.0 (stronger signal)

    // C. Proximity Boost for Hyper-Local content (State, District, Block similarity)
    if (options.distanceKm !== undefined) {
        // Boost if within 50 km
        const proximityFactor = Math.max(0, 1 - options.distanceKm / 50);
        score += proximityFactor * 100; // up to +100 boost
    }

    // D. Breaking News priority override
    if (options.isBreakingNews || (content as any).isBreakingNews) {
        score += 300; // Immediate massive visibility boost
    }

    // E. Creator Verification trust boost
    if (content.authorIsVerified) {
        score += 30; // Small trust factor boost
    }

    // F. Age Decay (Freshness)
    if (options.ageInHours !== undefined) {
        const freshnessDecay = Math.exp(-0.02 * options.ageInHours); // lambda = 0.02
        score = score * freshnessDecay;
    }

    return Number(score.toFixed(2));
}

/**
 * 5. Anti-Spam Detection Algorithm
 * Detects engagement farming, bot-like comments, and duplicates.
 * Returns a safety and quality multiplier between 0.0 and 1.0.
 */
export interface SpamAnalysisInput {
    likesVelocityPerMin: number;
    hasDuplicateSignature: boolean;
    commentToLikeRatio: number; // typical ratio is 0.01 - 0.2, anomalies indicate farm
    reportRatio: number;        // reports divided by total views
}

export function calculateSpamQualityMultiplier(metrics: SpamAnalysisInput): number {
    let multiplier = 1.0;

    // A. Velocity Anomaly (Bot click farm detection)
    if (metrics.likesVelocityPerMin > 250) {
        multiplier *= 0.1; // extreme throttle
    } else if (metrics.likesVelocityPerMin > 50) {
        multiplier *= 0.5; // moderate warning
    }

    // B. Duplicate Video Perceptual hash clash
    if (metrics.hasDuplicateSignature) {
        multiplier *= 0.1; // demote reupload farms
    }

    // C. Extreme engagement farming (likes with absolutely zero comment correlation)
    if (metrics.commentToLikeRatio < 0.001) {
        multiplier *= 0.7; // minor penalty
    }

    // D. Report Rate penalty
    if (metrics.reportRatio > 0.05) {
        multiplier *= Math.max(0, 1 - (metrics.reportRatio * 10)); // heavy scale down
    }

    return Number(multiplier.toFixed(2));
}

/**
 * 6. Equal Opportunity Creator Growth Funnel
 * Allocates initial seed distribution to small/new creators.
 */
export function getCreatorGrowthBoost(
    isNewCreator: boolean,
    totalViews: number,
    tierEngagementRatio: number // Likes + comments + shares divided by views (0-1)
): number {
    if (!isNewCreator) return 1.0;

    // Funnel Stage 1: Seed distribution to first 100 users
    if (totalViews < 100) {
        return 2.5; // 2.5x visibility multiplier to easily reach the first 100 views
    }

    // Funnel Stage 2: Category expansion check
    if (totalViews >= 100 && totalViews < 2000) {
        if (tierEngagementRatio >= 0.15) {
            return 1.8; // Retain strong boost if above the 15% engagement threshold
        }
        return 1.0; // Return to standard organic reach
    }

    // Funnel Stage 3: Viral threshold check
    if (totalViews >= 2000 && totalViews < 10000) {
        if (tierEngagementRatio >= 0.35) {
            return 1.5; // Viral trigger continuation boost
        }
    }

    return 1.0;
}
