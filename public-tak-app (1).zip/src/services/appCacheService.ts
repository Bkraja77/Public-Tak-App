import { Post, Video, Draft } from '../types';

interface CachedItem<T> {
  data: T;
  timestamp: number;
}

const FEED_POSTS_KEY = 'pt_cache_feed_posts_v1';
const FEED_VIDEOS_KEY = 'pt_cache_feed_videos_v1';
const CATEGORIES_KEY = 'pt_cache_categories_v1';
const ADS_CONFIG_KEY = 'pt_cache_ads_config_v1';
const CURRENT_USER_KEY = 'pt_cached_current_user_v1';
const MAX_FEED_ITEMS = 60;
const CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days (refreshed seamlessly in background on sync)

class AppCacheService {
  // Fast L1 in-memory caches (0 delay instant access)
  private memoryPosts: Post[] | null = null;
  private memoryVideos: Video[] | null = null;
  private postMap: Map<string, Post> = new Map();
  private videoMap: Map<string, Video> = new Map();
  private categoriesData: { newsCategories: string[]; videoCategories: string[] } | null = null;
  private adConfigData: any = null;
  private userPostsMap: Map<string, Post[]> = new Map();
  private userVideosMap: Map<string, Video[]> = new Map();
  private userDraftsMap: Map<string, Draft[]> = new Map();
  private notificationsMap: Map<string, any[]> = new Map();
  private memoryCurrentUser: any = null;
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  constructor() {
    // Warm up memory cache from persistent storage on startup
    this.hydrateFromStorage();
  }

  private hydrateFromStorage() {
    try {
      if (typeof window === 'undefined') return;

      // 1. Current User
      const storedUser = localStorage.getItem(CURRENT_USER_KEY);
      if (storedUser) {
        try {
          this.memoryCurrentUser = JSON.parse(storedUser);
        } catch (e) {}
      }

      // 2. Posts Feed
      const storedPosts = localStorage.getItem(FEED_POSTS_KEY);
      if (storedPosts) {
        const parsed: CachedItem<any[]> = JSON.parse(storedPosts);
        if (Array.isArray(parsed.data)) {
          const restored = parsed.data.map(this.restorePostDates);
          this.memoryPosts = restored;
          restored.forEach(p => {
            if (p.id) this.postMap.set(p.id, p);
          });
        }
      }

      // 3. Videos Feed
      const storedVideos = localStorage.getItem(FEED_VIDEOS_KEY);
      if (storedVideos) {
        const parsed: CachedItem<any[]> = JSON.parse(storedVideos);
        if (Array.isArray(parsed.data)) {
          const restored = parsed.data.map(this.restoreVideoDates);
          this.memoryVideos = restored;
          restored.forEach(v => {
            if (v.id) this.videoMap.set(v.id, v);
          });
        }
      }

      // 4. Categories
      const storedCats = localStorage.getItem(CATEGORIES_KEY);
      if (storedCats) {
        const parsed = JSON.parse(storedCats);
        if (parsed && parsed.newsCategories) {
          this.categoriesData = parsed;
        }
      }

      // 5. Ads Config
      const storedAds = localStorage.getItem(ADS_CONFIG_KEY);
      if (storedAds) {
        this.adConfigData = JSON.parse(storedAds);
      }

      // Sync existing cached posts to IndexedDB in background, or warm up from IndexedDB
      if (this.memoryPosts && this.memoryPosts.length > 0) {
        this.savePostsToIndexedDB(this.memoryPosts).catch(() => {});
      } else {
        this.fetchCachedNewsFromIndexedDB().catch(() => {});
      }
    } catch (err) {
      console.warn('AppCacheService hydration error (handled):', err);
    }
  }

  // --- INDEXEDDB STORAGE FOR OFFLINE NEWS ---

  private getIndexedDB(): Promise<IDBDatabase | null> {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return Promise.resolve(null);
    }
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open('public_tak_offline_db', 1);
        request.onupgradeneeded = (event: any) => {
          const db = event.target.result as IDBDatabase;
          if (!db.objectStoreNames.contains('cached_posts')) {
            const store = db.createObjectStore('cached_posts', { keyPath: 'id' });
            store.createIndex('savedAt', 'savedAt', { unique: false });
          }
        };
        request.onsuccess = (event: any) => {
          resolve(event.target.result as IDBDatabase);
        };
        request.onerror = (err) => {
          console.warn('IndexedDB open error (handled):', err);
          resolve(null);
        };
      } catch (e) {
        console.warn('IndexedDB initialization error:', e);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  /**
   * Persists an array of posts into IndexedDB for offline access
   */
  public async savePostsToIndexedDB(posts: Post[]): Promise<void> {
    if (!Array.isArray(posts) || posts.length === 0) return;
    try {
      const db = await this.getIndexedDB();
      if (!db) return;

      const tx = db.transaction('cached_posts', 'readwrite');
      const store = tx.objectStore('cached_posts');
      const now = Date.now();

      for (const post of posts) {
        if (!post || !post.id) continue;
        const serialized = {
          id: post.id,
          data: {
            ...post,
            createdAt: post.createdAt instanceof Date ? post.createdAt.toISOString() : post.createdAt
          },
          savedAt: now
        };
        store.put(serialized);
      }

      return new Promise((resolve) => {
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      });
    } catch (err) {
      console.warn('IndexedDB savePosts error:', err);
    }
  }

  /**
   * Persists a single post into IndexedDB for offline access
   */
  public async savePostToIndexedDB(post: Post): Promise<void> {
    if (!post || !post.id) return;
    await this.savePostsToIndexedDB([post]);
  }

  /**
   * Fetches all cached news articles stored in IndexedDB.
   * Gracefully falls back to local feed cache if IndexedDB is empty or unavailable.
   */
  public async fetchCachedNewsFromIndexedDB(): Promise<Post[]> {
    try {
      const db = await this.getIndexedDB();
      if (db) {
        const tx = db.transaction('cached_posts', 'readonly');
        const store = tx.objectStore('cached_posts');
        const req = store.getAll();

        const records: any[] = await new Promise((resolve) => {
          req.onsuccess = () => resolve(req.result || []);
          req.onerror = () => resolve([]);
        });

        if (Array.isArray(records) && records.length > 0) {
          const restored = records
            .map(r => (r && r.data ? this.restorePostDates(r.data) : null))
            .filter((p): p is Post => p !== null && typeof p.id === 'string');

          if (restored.length > 0) {
            // Sort by createdAt descending
            restored.sort((a, b) => {
              const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
              const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
              return timeB - timeA;
            });

            // Update in-memory cache for instant subsequent hits
            restored.forEach(p => {
              if (p.id) this.postMap.set(p.id, p);
            });
            if (!this.memoryPosts || this.memoryPosts.length === 0) {
              this.memoryPosts = restored;
            }
            return restored;
          }
        }
      }
    } catch (e) {
      console.warn('IndexedDB read failed, falling back to storage:', e);
    }

    // Graceful fallback to memory/localStorage cached feed
    const fallback = this.getFeedPosts();
    if (fallback.length > 0) {
      this.savePostsToIndexedDB(fallback).catch(() => {});
      return fallback;
    }

    return [];
  }

  /**
   * Alias: fetches news stored in IndexedDB via appCacheService
   */
  public async getCachedPostsFromIndexedDB(): Promise<Post[]> {
    return this.fetchCachedNewsFromIndexedDB();
  }

  /**
   * Quick count of items cached in IndexedDB
   */
  public async getCachedNewsCount(): Promise<number> {
    try {
      const db = await this.getIndexedDB();
      if (db) {
        const tx = db.transaction('cached_posts', 'readonly');
        const store = tx.objectStore('cached_posts');
        const req = store.count();
        return new Promise((resolve) => {
          req.onsuccess = () => resolve(req.result || 0);
          req.onerror = () => resolve(this.getFeedPosts().length);
        });
      }
    } catch (e) {}
    return this.getFeedPosts().length;
  }

  private restorePostDates(item: any): Post {
    return {
      ...item,
      createdAt: item.createdAt ? new Date(item.createdAt) : null
    } as Post;
  }

  private restoreVideoDates(item: any): Video {
    return {
      ...item,
      createdAt: item.createdAt ? new Date(item.createdAt) : null
    } as Video;
  }

  // --- CURRENT USER ---

  public getCachedCurrentUser(): any | null {
    if (this.memoryCurrentUser) return this.memoryCurrentUser;
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem(CURRENT_USER_KEY);
        if (stored) {
          this.memoryCurrentUser = JSON.parse(stored);
          return this.memoryCurrentUser;
        }
      }
    } catch (e) {}
    return null;
  }

  public setCachedCurrentUser(user: any): void {
    this.memoryCurrentUser = user;
    try {
      if (typeof window !== 'undefined') {
        if (user) {
          localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
        } else {
          localStorage.removeItem(CURRENT_USER_KEY);
        }
      }
    } catch (e) {}
  }

  // --- POSTS ---

  public getFeedPosts(): Post[] {
    if (this.memoryPosts && this.memoryPosts.length > 0) {
      return this.memoryPosts;
    }
    return [];
  }

  public setFeedPosts(posts: Post[]): void {
    if (!Array.isArray(posts)) return;
    this.memoryPosts = posts;
    posts.forEach(p => {
      if (p.id) this.postMap.set(p.id, p);
    });

    try {
      if (typeof window !== 'undefined') {
        const toSave = posts.slice(0, MAX_FEED_ITEMS).map(p => ({
          ...p,
          createdAt: p.createdAt instanceof Date ? p.createdAt.toISOString() : p.createdAt
        }));
        const cached: CachedItem<any[]> = {
          data: toSave,
          timestamp: Date.now()
        };
        localStorage.setItem(FEED_POSTS_KEY, JSON.stringify(cached));
      }
    } catch (e) {
      // Handle quota exceeded gracefully
    }

    // Automatically synchronize into IndexedDB for persistent offline retrieval
    this.savePostsToIndexedDB(posts).catch(() => {});
  }

  public getPost(postId: string): Post | null {
    if (!postId) return null;
    // 1. Check direct map
    if (this.postMap.has(postId)) {
      return this.postMap.get(postId)!;
    }
    // 2. Check feed posts
    if (this.memoryPosts) {
      const found = this.memoryPosts.find(p => p.id === postId);
      if (found) {
        this.postMap.set(postId, found);
        return found;
      }
    }
    // 3. Check sessionStorage item
    try {
      if (typeof window !== 'undefined') {
        const single = sessionStorage.getItem(`pt_post_${postId}`);
        if (single) {
          const parsed = JSON.parse(single);
          const restored = this.restorePostDates(parsed);
          this.postMap.set(postId, restored);
          return restored;
        }
      }
    } catch (e) {}

    return null;
  }

  public setPost(post: Post): void {
    if (!post || !post.id) return;
    this.postMap.set(post.id, post);

    // Update in memory feed if exists
    if (this.memoryPosts) {
      this.memoryPosts = this.memoryPosts.map(p => (p.id === post.id ? post : p));
    }

    try {
      if (typeof window !== 'undefined') {
        const serialized = {
          ...post,
          createdAt: post.createdAt instanceof Date ? post.createdAt.toISOString() : post.createdAt
        };
        sessionStorage.setItem(`pt_post_${post.id}`, JSON.stringify(serialized));
      }
    } catch (e) {}

    // Persist to IndexedDB for offline reading
    this.savePostToIndexedDB(post).catch(() => {});
  }

  // --- VIDEOS ---

  public getFeedVideos(): Video[] {
    if (this.memoryVideos && this.memoryVideos.length > 0) {
      return this.memoryVideos;
    }
    return [];
  }

  public setFeedVideos(videos: Video[]): void {
    if (!Array.isArray(videos)) return;
    this.memoryVideos = videos;
    videos.forEach(v => {
      if (v.id) this.videoMap.set(v.id, v);
    });

    try {
      if (typeof window !== 'undefined') {
        const toSave = videos.slice(0, MAX_FEED_ITEMS).map(v => ({
          ...v,
          createdAt: v.createdAt instanceof Date ? v.createdAt.toISOString() : v.createdAt
        }));
        const cached: CachedItem<any[]> = {
          data: toSave,
          timestamp: Date.now()
        };
        localStorage.setItem(FEED_VIDEOS_KEY, JSON.stringify(cached));
      }
    } catch (e) {}
  }

  public getVideo(videoId: string): Video | null {
    if (!videoId) return null;
    if (this.videoMap.has(videoId)) {
      return this.videoMap.get(videoId)!;
    }
    if (this.memoryVideos) {
      const found = this.memoryVideos.find(v => v.id === videoId);
      if (found) {
        this.videoMap.set(videoId, found);
        return found;
      }
    }
    return null;
  }

  public setVideo(video: Video): void {
    if (!video || !video.id) return;
    this.videoMap.set(video.id, video);
    if (this.memoryVideos) {
      this.memoryVideos = this.memoryVideos.map(v => (v.id === video.id ? video : v));
    }
  }

  // --- USER SPECIFIC DATA (Posts, Videos, Drafts, Notifications) ---

  public getUserPosts(userId: string): Post[] {
    if (!userId) return [];
    if (this.userPostsMap.has(userId)) {
      return this.userPostsMap.get(userId)!;
    }
    try {
      if (typeof window !== 'undefined') {
        const stored = sessionStorage.getItem(`pt_user_posts_${userId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            const restored = parsed.map(this.restorePostDates);
            this.userPostsMap.set(userId, restored);
            return restored;
          }
        }
      }
    } catch (e) {}
    return [];
  }

  public setUserPosts(userId: string, posts: Post[]): void {
    if (!userId || !Array.isArray(posts)) return;
    this.userPostsMap.set(userId, posts);
    try {
      if (typeof window !== 'undefined') {
        const serialized = posts.slice(0, 30).map(p => ({
          ...p,
          createdAt: p.createdAt instanceof Date ? p.createdAt.toISOString() : p.createdAt
        }));
        sessionStorage.setItem(`pt_user_posts_${userId}`, JSON.stringify(serialized));
      }
    } catch (e) {}
  }

  public getUserVideos(userId: string): Video[] {
    if (!userId) return [];
    if (this.userVideosMap.has(userId)) {
      return this.userVideosMap.get(userId)!;
    }
    try {
      if (typeof window !== 'undefined') {
        const stored = sessionStorage.getItem(`pt_user_videos_${userId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            const restored = parsed.map(this.restoreVideoDates);
            this.userVideosMap.set(userId, restored);
            return restored;
          }
        }
      }
    } catch (e) {}
    return [];
  }

  public setUserVideos(userId: string, videos: Video[]): void {
    if (!userId || !Array.isArray(videos)) return;
    this.userVideosMap.set(userId, videos);
    try {
      if (typeof window !== 'undefined') {
        const serialized = videos.slice(0, 30).map(v => ({
          ...v,
          createdAt: v.createdAt instanceof Date ? v.createdAt.toISOString() : v.createdAt
        }));
        sessionStorage.setItem(`pt_user_videos_${userId}`, JSON.stringify(serialized));
      }
    } catch (e) {}
  }

  public getUserDrafts(userId: string): Draft[] {
    if (!userId) return [];
    if (this.userDraftsMap.has(userId)) {
      return this.userDraftsMap.get(userId)!;
    }
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem(`pt_drafts_${userId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            const restored = parsed.map(d => ({
              ...d,
              createdAt: d.createdAt ? new Date(d.createdAt) : null,
              updatedAt: d.updatedAt ? new Date(d.updatedAt) : null
            }));
            this.userDraftsMap.set(userId, restored);
            return restored;
          }
        }
      }
    } catch (e) {}
    return [];
  }

  public setUserDrafts(userId: string, drafts: Draft[]): void {
    if (!userId || !Array.isArray(drafts)) return;
    this.userDraftsMap.set(userId, drafts);
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(`pt_drafts_${userId}`, JSON.stringify(drafts));
      }
    } catch (e) {}
  }

  public getNotifications(userId: string): any[] {
    if (!userId) return [];
    if (this.notificationsMap.has(userId)) {
      return this.notificationsMap.get(userId)!;
    }
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem(`pt_notifications_${userId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            const restored = parsed.map(n => ({
              ...n,
              createdAt: n.createdAt ? new Date(n.createdAt) : new Date()
            }));
            this.notificationsMap.set(userId, restored);
            return restored;
          }
        }
      }
    } catch (e) {}
    return [];
  }

  public setNotifications(userId: string, notifs: any[]): void {
    if (!userId || !Array.isArray(notifs)) return;
    this.notificationsMap.set(userId, notifs);
    try {
      if (typeof window !== 'undefined') {
        const toSave = notifs.slice(0, 40).map(n => ({
          ...n,
          createdAt: n.createdAt instanceof Date ? n.createdAt.toISOString() : n.createdAt
        }));
        localStorage.setItem(`pt_notifications_${userId}`, JSON.stringify(toSave));
      }
    } catch (e) {}
  }

  // --- CATEGORIES ---

  public getCachedCategories(): { newsCategories: string[]; videoCategories: string[] } | null {
    return this.categoriesData;
  }

  public setCachedCategories(data: { newsCategories: string[]; videoCategories: string[] }): void {
    if (!data) return;
    this.categoriesData = data;
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(CATEGORIES_KEY, JSON.stringify(data));
      }
    } catch (e) {}
  }

  // --- ADS CONFIG ---

  public getCachedAdConfig(): any {
    return this.adConfigData;
  }

  public setCachedAdConfig(config: any): void {
    if (!config) return;
    this.adConfigData = config;
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(ADS_CONFIG_KEY, JSON.stringify(config));
      }
    } catch (e) {}
  }

  // --- FOLLOWING STATE (0-Delay Instant Sync) ---
  private followingMap: Map<string, Set<string>> = new Map();

  public getFollowingSet(userId: string): Set<string> {
    if (!userId) return new Set();
    if (this.followingMap.has(userId)) {
      return this.followingMap.get(userId)!;
    }
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem(`pt_following_${userId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            const set = new Set<string>(parsed);
            this.followingMap.set(userId, set);
            return set;
          }
        }
      }
    } catch (e) {}
    const emptySet = new Set<string>();
    this.followingMap.set(userId, emptySet);
    return emptySet;
  }

  public getFollowingList(userId: string): string[] {
    return Array.from(this.getFollowingSet(userId));
  }

  public isFollowing(userId: string, targetUserId: string): boolean {
    if (!userId || !targetUserId) return false;
    return this.getFollowingSet(userId).has(targetUserId);
  }

  public setFollowingList(userId: string, targetIds: string[]): void {
    if (!userId || !Array.isArray(targetIds)) return;
    const set = new Set<string>(targetIds);
    this.followingMap.set(userId, set);
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(`pt_following_${userId}`, JSON.stringify(targetIds));
      }
    } catch (e) {}
  }

  public addFollow(userId: string, targetUserId: string): void {
    if (!userId || !targetUserId) return;
    const set = this.getFollowingSet(userId);
    set.add(targetUserId);
    this.followingMap.set(userId, set);
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(`pt_following_${userId}`, JSON.stringify(Array.from(set)));
      }
    } catch (e) {}
  }

  public removeFollow(userId: string, targetUserId: string): void {
    if (!userId || !targetUserId) return;
    const set = this.getFollowingSet(userId);
    set.delete(targetUserId);
    this.followingMap.set(userId, set);
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(`pt_following_${userId}`, JSON.stringify(Array.from(set)));
      }
    } catch (e) {}
  }

  // --- USER PROFILES CACHE ---
  private userProfilesMap: Map<string, any> = new Map();

  public getUserProfile(userId: string): any | null {
    if (!userId) return null;
    if (this.userProfilesMap.has(userId)) {
      return this.userProfilesMap.get(userId);
    }
    try {
      if (typeof window !== 'undefined') {
        const stored = sessionStorage.getItem(`pt_user_profile_${userId}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          this.userProfilesMap.set(userId, parsed);
          return parsed;
        }
      }
    } catch (e) {}
    return null;
  }

  public setUserProfile(userId: string, profile: any): void {
    if (!userId || !profile) return;
    this.userProfilesMap.set(userId, profile);
    try {
      if (typeof window !== 'undefined') {
        sessionStorage.setItem(`pt_user_profile_${userId}`, JSON.stringify(profile));
      }
    } catch (e) {}
  }
}

export const appCacheService = new AppCacheService();
export default appCacheService;

