
// Import the functions you need from the SDKs you need
// We use the keys defined in index.html importmap to ensure consistent versions (10.12.2)
// Importing for side effects ensures the 'firebase' global is populated by the compat scripts.
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';
import 'firebase/compat/messaging';
import 'firebase/compat/analytics';

// Dynamically resolve authDomain:
// When running on the production domain (publictak.app or www.publictak.app),
// setting authDomain to 'publictak.app' leverages https://publictak.app/__/auth/handler directly,
// eliminating third-party cookie blocking on iOS/Safari, Android, PWA, and in-app webviews.
export const getResolvedAuthDomain = (): string => {
  if (typeof window !== 'undefined' && window.location.hostname) {
    const host = window.location.hostname.toLowerCase();
    if (host === 'publictak.app' || host === 'www.publictak.app') {
      return 'publictak.app';
    }
  }
  return "public-tak-app.firebaseapp.com";
};

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBcVMGPppCWHy9sGacwXXf_gmg4kb0Dd0Y",
  authDomain: getResolvedAuthDomain(),
  projectId: "public-tak-app",
  storageBucket: "public-tak-app.firebasestorage.app",
  messagingSenderId: "323471252789",
  appId: "1:323471252789:web:a017363ff24b1174be807c",
  measurementId: "G-7E42XPLLK2"
};

// Initialize Firebase
if (!firebase.apps.length) {
  try {
    firebase.initializeApp(firebaseConfig);
  } catch (error) {
    console.error("Firebase init failed:", error);
  }
}

// Get Firebase services safely
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// Configure Firestore settings first before starting persistence or queries.
// Setting experimentalForceLongPolling to true prevents WebChannel streaming connection timeouts
// ("Backend didn't respond within 10 seconds") in sandboxed iframes, Cloud Run, and reverse proxies.
try {
  db.settings({
    experimentalForceLongPolling: true,
    ignoreUndefinedProperties: true,
  });
} catch (e) {
  console.debug("Firestore settings already initialized:", e);
}

try {
  firebase.firestore.setLogLevel('error');
} catch (e) {}

// Enable Firestore offline persistence for instant cache & smooth offline-first experience
if (typeof window !== 'undefined') {
  db.enablePersistence({ synchronizeTabs: true }).catch((err: any) => {
    if (err?.code === 'failed-precondition') {
      // Multiple tabs open, persistence can only be active in one tab at a time
      console.debug('Firestore persistence active in another tab');
    } else if (err?.code === 'unimplemented') {
      console.debug('Firestore persistence not supported in this browser');
    } else {
      console.debug('Firestore persistence notice:', err?.message || err);
    }
  });
}

let messaging = null;
try {
  if (firebase.messaging.isSupported()) {
    messaging = firebase.messaging();
  }
} catch (e) {
  console.warn("Firebase Messaging initialization failed or not supported in this environment.", e);
}

let analytics = null;
try {
  if (firebase.analytics.isSupported()) {
    analytics = firebase.analytics();
  }
} catch (e) {
  console.warn("Firebase Analytics initialization failed.", e);
}
const serverTimestamp = firebase.firestore.FieldValue.serverTimestamp;
const increment = firebase.firestore.FieldValue.increment;

export { auth, db, storage, messaging, analytics, serverTimestamp, increment, firebase };
