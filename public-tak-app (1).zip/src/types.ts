
export enum View {
  Main = 'main',
  Search = 'search',
  Settings = 'settings',
  Feedback = 'feedback',
  Privacy = 'privacy',
  Terms = 'terms',
  About = 'about',
  Admin = 'admin',
  User = 'user',
  PublicProfile = 'publicProfile',
  Login = 'login',
  CreatePost = 'createPost',
  EditPost = 'editPost',
  EditProfile = 'editProfile',
  ManageUsers = 'manageUsers',
  Analytics = 'analytics',
  ModerateContent = 'moderateContent',
  Notifications = 'notifications',
  SiteSettings = 'siteSettings',
  PostDetail = 'postDetail',
  AdminEditUser = 'adminEditUser',
  ManageAccount = 'manageAccount',
  ChangePassword = 'changePassword',
  ManageAds = 'manageAds',
  ViewFeedback = 'viewFeedback',
  CreatorDashboard = 'creatorDashboard',
  Leaderboard = 'leaderboard',
  Referral = 'referral',
  Withdrawal = 'withdrawal',
  Verification = 'verification',
  KYC = 'kyc',
  ManageKYC = 'manageKYC',
  ManageWithdrawals = 'manageWithdrawals',
  Monetization = 'monetization',
  ManageMonetization = 'manageMonetization',
  Offline = 'offline',
  VideoHome = 'videoHome',
  EPaper = 'epaper',
  ReporterRegistration = 'reporterRegistration',
  ReporterIdCard = 'reporterIdCard',
  ManageReporters = 'manageReporters',
}

export interface ReporterDetails {
  id: string;
  userId: string;
  reporterIdNumber: string; // e.g. PT-DM-2026-0042
  fullName: string;
  fatherOrHusbandName: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string;
  mobile: string;
  email: string;
  emergencyContact: string;
  aadhaarNumber: string; // Stored masked/encrypted
  aadhaarVerified: boolean;
  aadhaarEkycMethod: 'aadhaar_otp' | 'digilocker';
  aadhaarRefId?: string;
  fullAddress: string;
  state: string;
  district: string;
  block: string;
  pincode: string;
  designation: string; // e.g. "District Bureau Chief", "Senior Digital Reporter", "Crime Reporter", "Digital Media Journalist"
  beat: string; // "Politics & Crime", "Rural & Development", "General Digital News"
  aadhaarFrontUrl?: string; // Aadhaar card front image
  aadhaarBackUrl?: string; // Aadhaar card back image
  panNumber?: string; // PAN card number
  panCardUrl?: string; // PAN card photo image
  photoUrl: string; // Reporter portrait photo
  signatureUrl?: string; // Reporter signature image / data URL
  organizationName: string; // "Public Tak Digital Media Network"
  organizationLogo?: string;
  authorizedSignatoryName: string; // e.g. "Editor-in-Chief / Director"
  authorizedSignatoryStampUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  submittedAt: any;
  approvedAt?: any;
  validFrom: string;
  validTill: string;
  qrCodeData?: string;
  adminNotes?: string;
}

export interface EPaper {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  state?: string;
  district?: string;
  pages: string[]; // Array of high-res image URLs
  uploadedBy: string;
  createdAt: any;
}

export interface BankDetails {
  upiId?: string;
  bankName?: string;
  accountNumber?: string;
  ifscCode?: string;
  accountHolderName?: string;
}

export interface User {
  uid: string;
  name: string;
  username: string;
  bio: string;
  email: string | null;
  profilePicUrl: string;
  role: 'user' | 'admin';
  isVerified?: boolean;
  walletBalance?: number;
  totalEarnings?: number;
  followerCount?: number;
  followingCount?: number;
  preferredState?: string;
  preferredDistrict?: string;
  preferredBlock?: string;
  gender?: 'Male' | 'Female' | 'Other';
  ageGroup?: '13-17' | '18-24' | '25-34' | '35-44' | '45-54' | '55+';
  referralCode?: string;
  referredBy?: string | null;
  referralCount?: number;
  hasPostedFirstNews?: boolean;
  milestoneCount?: number;
  kycStatus?: 'none' | 'pending' | 'verified' | 'rejected';
  panNumber?: string;
  panPhotoUrl?: string;
  bankDetails?: BankDetails;
  isMonetized?: boolean;
  monetizationStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  totalViews?: number;
  asteriskCount?: number;
  isBanned?: boolean;
  banReason?: string;
  bannedAt?: any;
  bannedBy?: string;
  reporterStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  reporterIdNumber?: string;
  reporterDesignation?: string;
  reporterValidTill?: string;
  reporterPhotoUrl?: string;
  phone?: string;
  mobile?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  status: 'pending' | 'completed' | 'rejected';
  bankDetails: BankDetails;
  requestedAt: any;
  processedAt?: any;
  remarks?: string;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  thumbnailUrl: string;
  authorId: string;
  authorName: string;
  authorProfilePicUrl: string;
  authorIsVerified?: boolean;
  viewCount: number;
  shareCount: number;
  likeCount?: number;
  category: string;
  createdAt: Date | null; // Firestore Timestamp converted to JS Date
  locationType: 'Overall' | 'State' | 'District' | 'Block';
  state?: string;
  district?: string;
  block?: string;
  safetyStatus?: 'safe' | 'harmful' | 'auto_deleted';
  moderationReason?: string;
  isPinned?: boolean;
}

export interface Video {
  id: string;
  title: string;
  description?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  authorId: string;
  authorName: string;
  authorProfilePicUrl: string;
  authorIsVerified?: boolean;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  shareCount: number;
  category: string;
  createdAt: Date | null;
  locationType: 'Overall' | 'State' | 'District' | 'Block';
  state?: string;
  district?: string;
  block?: string;
  isPinned?: boolean;
}

export interface Draft {
  id: string;
  title: string;
  content: string;
  category: string;
  thumbnailUrl: string;
  state?: string;
  district?: string;
  block?: string;
  createdAt: any; // Firestore Timestamp
  updatedAt?: any; // Firestore Timestamp
}

export interface Comment {
  id: string;
  content: string; // Renamed from 'text' to match Firestore rules
  authorId: string;
  authorName: string;
  authorProfilePicUrl: string;
  createdAt: Date;
  likeCount?: number;
  authorReply?: string;
  authorReplyCreatedAt?: Date;
  authorIsVerified?: boolean;
  isPinned?: boolean;
}

export interface Notification {
  id: string;
  type: 'new_follower' | 'new_like' | 'new_comment' | 'new_post' | 'reply' | 'post_reported' | 'content_reported' | string;
  fromUserId: string;
  fromUserName: string;
  fromUserProfilePicUrl: string;
  fromUserIsVerified?: boolean;
  createdAt: Date;
  read: boolean;
  postId?: string;
  videoId?: string;
  postTitle?: string;
  postThumbnailUrl?: string;
  thumbnailUrl?: string;
  postType?: 'article' | 'video' | string;
  contentType?: 'post' | 'video' | string;
  commentText?: string;
  replyText?: string;
  reportReason?: string;
  title?: string;
  body?: string;
}

export interface AdConfig {
  adsEnabled: boolean;
  adSenseClientId: string;
  adSenseSlotHome: string;
  adSenseSlotPost: string;
  adMobAppId: string;
  adMobBannerId: string;
}

export interface MonetizationRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  followerCount: number;
  totalViews: number;
  channelPhilosophy: string;
  socialLinks: string[];
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: any;
  reviewedAt?: any;
  adminRemarks?: string;
}
