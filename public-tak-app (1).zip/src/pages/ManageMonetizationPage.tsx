
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { MonetizationRequest } from '../types';
import { db } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';

interface ManageMonetizationPageProps {
    onBack: () => void;
}

const ManageMonetizationPage: React.FC<ManageMonetizationPageProps> = ({ onBack }) => {
    const { showToast } = useToast();
    const [requests, setRequests] = useState<MonetizationRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected'>('pending');
    
    // Action state
    const [isProcessing, setIsProcessing] = useState<string | null>(null);
    const [remarks, setRemarks] = useState<{ [key: string]: string }>({});

    useEffect(() => {
        setLoading(true);
        const unsubscribe = db.collection('monetizationRequests')
            .where('status', '==', filter)
            .onSnapshot(snapshot => {
                const reqs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MonetizationRequest));
                
                // Client-side sort: newest first
                reqs.sort((a, b) => {
                    const timeA = a.requestedAt?.toMillis ? a.requestedAt.toMillis() : 0;
                    const timeB = b.requestedAt?.toMillis ? b.requestedAt.toMillis() : 0;
                    return timeB - timeA;
                });

                setRequests(reqs);
                setLoading(false);
            }, error => {
                console.error("Error fetching requests:", error);
                showToast("Failed to load requests", "error");
                setLoading(false);
            });

        return () => unsubscribe();
    }, [filter]);

    const handleAction = async (request: MonetizationRequest, status: 'approved' | 'rejected') => {
        setIsProcessing(request.id);
        try {
            const adminRemarks = remarks[request.id] || '';

            await db.collection('monetizationRequests').doc(request.id).update({
                status,
                adminRemarks,
                reviewedAt: new Date()
            });

            // Update user status
            await db.collection('users').doc(request.userId).update({
                monetizationStatus: status,
                isMonetized: status === 'approved'
            });

            showToast(`Request ${status} successfully`, "success");
        } catch (error) {
            console.error(`Error ${status} request:`, error);
            showToast(`Failed to ${status} request`, "error");
        } finally {
            setIsProcessing(null);
        }
    };

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title="Manage Monetization" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-24">
                <div className="max-w-6xl mx-auto">
                    {/* Stats/Filter Header */}
                    <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
                        <div className="flex p-1 bg-gray-200 rounded-2xl w-full sm:w-auto">
                            {(['pending', 'approved', 'rejected'] as const).map(status => (
                                <button
                                    key={status}
                                    onClick={() => setFilter(status)}
                                    className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl text-sm font-black uppercase tracking-wider transition-all ${
                                        filter === status 
                                        ? 'bg-red-600 text-white shadow-lg scale-105' 
                                        : 'text-gray-500 hover:text-gray-700'
                                    }`}
                                >
                                    {status}
                                </button>
                            ))}
                        </div>
                        <div className="text-right">
                            <p className="text-sm font-bold text-gray-500 uppercase">Total {filter} Requests</p>
                            <p className="text-3xl font-black text-gray-900">{requests.length}</p>
                        </div>
                    </div>

                    <AnimatePresence mode='wait'>
                        {loading ? (
                            <motion.div 
                                key="loading"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                exit={{ opacity: 0 }}
                                className="flex justify-center py-20"
                            >
                                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
                            </motion.div>
                        ) : requests.length === 0 ? (
                            <motion.div 
                                key="empty"
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="text-center py-20 glass-card"
                            >
                                <span className="material-symbols-outlined text-6xl text-gray-300 mb-4">move_to_inbox</span>
                                <p className="text-gray-500 font-bold">No {filter} monetization requests found.</p>
                            </motion.div>
                        ) : (
                            <div className="space-y-6">
                                {requests.map(request => (
                                    <motion.div 
                                        key={request.id}
                                        layout
                                        initial={{ opacity: 0, scale: 0.95 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        className="glass-card overflow-hidden border-l-4 border-red-600"
                                    >
                                        <div className="p-6 md:p-8 flex flex-col lg:flex-row gap-8">
                                            {/* User Info */}
                                            <div className="lg:w-1/3 space-y-4">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-16 h-16 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-black text-2xl uppercase">
                                                        {request.userName.charAt(0)}
                                                    </div>
                                                    <div>
                                                        <h3 className="font-black text-xl leading-tight">{request.userName}</h3>
                                                        <p className="text-gray-500 font-medium text-sm">{request.userEmail}</p>
                                                    </div>
                                                </div>

                                                <div className="grid grid-cols-2 gap-3">
                                                    <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                                                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Followers</p>
                                                        <p className="text-xl font-black">{request.followerCount.toLocaleString()}</p>
                                                    </div>
                                                    <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                                                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Views</p>
                                                        <p className="text-xl font-black">{request.totalViews.toLocaleString()}</p>
                                                    </div>
                                                </div>

                                                <div className="space-y-2">
                                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Social Reference</p>
                                                    <div className="flex flex-wrap gap-2">
                                                        {request.socialLinks.length > 0 ? request.socialLinks.map((link, i) => (
                                                            <a key={i} href={link.startsWith('http') ? link : `https://${link}`} target="_blank" rel="noopener noreferrer" className="px-3 py-1 bg-blue-50 text-blue-600 text-xs font-bold rounded-lg truncate max-w-[150px] hover:bg-blue-100 transition-all border border-blue-100">
                                                                {link}
                                                            </a>
                                                        )) : <p className="text-xs text-gray-500 italic">No links provided</p>}
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Philosophy & Action */}
                                            <div className="lg:w-2/3 flex flex-col justify-between">
                                                <div>
                                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Creator Philosophy</p>
                                                    <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl text-slate-700 italic leading-relaxed text-sm">
                                                        "{request.channelPhilosophy}"
                                                    </div>
                                                </div>

                                                <div className="mt-6 flex flex-col sm:flex-row gap-4 items-end">
                                                    <div className="flex-grow w-full">
                                                        <label className="block text-[10px] font-black text-gray-400 uppercase mb-1 tracking-widest">Admin Remarks</label>
                                                        <textarea 
                                                            placeholder="Why are you approving/rejecting this?"
                                                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-red-500 outline-none h-16 resize-none"
                                                            value={remarks[request.id] || ''}
                                                            onChange={(e) => setRemarks({...remarks, [request.id]: e.target.value})}
                                                        ></textarea>
                                                    </div>
                                                    
                                                    {request.status === 'pending' && (
                                                        <div className="flex gap-2 w-full sm:w-auto">
                                                            <button 
                                                                onClick={() => handleAction(request, 'rejected')}
                                                                disabled={isProcessing === request.id}
                                                                className="flex-1 sm:flex-none px-6 py-3 bg-slate-100 text-slate-800 font-bold rounded-xl hover:bg-red-50 hover:text-red-600 transition-all active:scale-95 disabled:opacity-50"
                                                            >
                                                                Reject
                                                            </button>
                                                            <button 
                                                                onClick={() => handleAction(request, 'approved')}
                                                                disabled={isProcessing === request.id}
                                                                className="flex-1 sm:flex-none px-6 py-3 bg-red-600 text-white font-black rounded-xl hover:bg-red-700 transition-all active:scale-95 disabled:opacity-50 shadow-md"
                                                            >
                                                                Approve
                                                            </button>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </AnimatePresence>
                </div>
            </main>
        </div>
    );
};

export default ManageMonetizationPage;
