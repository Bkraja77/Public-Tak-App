
import * as React from 'react';
import { User, View } from '../types';
import Header from '../components/Header';
import UserAvatar from '../components/UserAvatar';
import { db } from '../firebaseConfig';
import { motion } from 'motion/react';
import { formatCount } from '../utils/formatters';

interface LeaderboardProps {
  onBack: () => void;
  currentUser: User | null;
  onNavigate: (view: View, params?: any) => void;
}

const LeaderboardItem: React.FC<{ user: User; rank: number; stats: any; isCurrentUser: boolean; onClick: () => void }> = ({ user, rank, stats, isCurrentUser, onClick }) => (
    <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: rank * 0.05 }}
        onClick={onClick}
        className={`flex items-center gap-4 p-4 rounded-2xl transition-all cursor-pointer ${
            isCurrentUser ? 'bg-blue-50 border-2 border-blue-200 shadow-sm' : 'bg-white border border-gray-100 hover:border-gray-300 hover:shadow-md'
        }`}
    >
        <div className="flex-shrink-0 w-8 text-center">
            {rank === 1 ? <span className="text-2xl">🥇</span> : 
             rank === 2 ? <span className="text-2xl">🥈</span> : 
             rank === 3 ? <span className="text-2xl">🥉</span> : 
             <span className="font-bold text-gray-400">{rank}</span>}
        </div>
        <UserAvatar 
            userId={user.uid}
            src={user.profilePicUrl} 
            name={user.name}
            className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm" 
            alt={user.name} 
        />
        <div className="flex-grow">
            <h4 className="font-bold text-gray-900 flex items-center gap-1">
                {user.name}
                {user.isVerified && <span className="material-symbols-outlined text-blue-500 text-sm">verified</span>}
                {isCurrentUser && <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.5 rounded-full ml-1">YOU</span>}
            </h4>
            <p className="text-xs text-gray-500">@{user.username}</p>
        </div>
        <div className="text-right">
            <p className="text-sm font-bold text-gray-900">{formatCount(stats.totalViews || 0)}</p>
            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-tighter">Views</p>
        </div>
    </motion.div>
);

const Leaderboard: React.FC<LeaderboardProps> = ({ onBack, currentUser, onNavigate }) => {
    const [topUsers, setTopUsers] = React.useState<{ user: User; stats: any }[]>([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
        // In a real app, we'd have a 'user_stats' collection or aggregated data
        // For now, let's fetch top users by their wallet balance or follower count as a proxy for activity
        const usersQuery = db.collection('users').orderBy('walletBalance', 'desc').limit(20);
        
        const unsubscribe = usersQuery.onSnapshot(snapshot => {
            const users = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    user: { uid: doc.id, ...data } as unknown as User,
                    stats: {
                        totalViews: (data.walletBalance || 0) * 100, // Proxy views for demo
                        followerCount: data.followerCount || 0
                    }
                };
            });
            setTopUsers(users);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Top Reporters" showBackButton onBack={onBack} currentUser={currentUser} />
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-24">
                <div className="max-w-3xl mx-auto">
                    <div className="bg-gradient-to-br from-red-600 to-red-800 rounded-3xl p-8 text-white mb-8 shadow-2xl relative overflow-hidden">
                        <div className="absolute right-0 bottom-0 opacity-10 transform scale-150 translate-x-1/4 translate-y-1/4">
                             <span className="material-symbols-outlined text-[200px]">military_tech</span>
                        </div>
                        <h2 className="text-3xl font-black italic tracking-tighter">PUBLIC TAK STARS</h2>
                        <p className="text-red-100 mt-2 font-medium">The most influential reporters across India this month.</p>
                        <div className="mt-8 flex gap-2">
                             <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold border border-white/20">Updated Hourly</span>
                             <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold border border-white/20">All India</span>
                        </div>
                    </div>

                    <div className="space-y-3">
                        {loading ? (
                            [...Array(6)].map((_, i) => (
                                <div key={i} className="h-20 bg-gray-100 rounded-2xl animate-pulse"></div>
                            ))
                        ) : topUsers.map((item, index) => (
                            <LeaderboardItem 
                                key={item.user.uid || index} 
                                user={item.user} 
                                rank={index + 1} 
                                stats={item.stats} 
                                isCurrentUser={currentUser?.uid === item.user.uid}
                                onClick={() => onNavigate(View.PublicProfile, { userId: item.user.uid })}
                            />
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Leaderboard;
