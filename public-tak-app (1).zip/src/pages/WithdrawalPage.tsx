
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { User, View, WithdrawalRequest, BankDetails } from '../types';
import { db, serverTimestamp, firebase } from '../firebaseConfig';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';

interface WithdrawalPageProps {
    onBack: () => void;
    currentUser: User | null;
    onNavigate: (view: View) => void;
}

const WithdrawalPage: React.FC<WithdrawalPageProps> = ({ onBack, currentUser, onNavigate }) => {
    const { t } = useLanguage();
    const { showToast } = useToast();
    
    // KYC State
    const [panNumber, setPanNumber] = useState(currentUser?.panNumber || '');
    const [isKycSubmitting, setIsKycSubmitting] = useState(false);
    
    // Bank Details State
    const [bankDetails, setBankDetails] = useState<BankDetails>(currentUser?.bankDetails || {
        upiId: '',
        bankName: '',
        accountNumber: '',
        ifscCode: '',
        accountHolderName: ''
    });
    
    // Withdrawal State
    const [amount, setAmount] = useState<string>('');
    const [isWithdrawing, setIsWithdrawing] = useState(false);
    const [history, setHistory] = useState<WithdrawalRequest[]>([]);
    const [loadingHistory, setLoadingHistory] = useState(true);

    const kycStatus = currentUser?.kycStatus || 'none';

    useEffect(() => {
        if (!currentUser) return;
        
        const unsubscribe = db.collection('users')
            .doc(currentUser.uid)
            .collection('withdrawals')
            .orderBy('requestedAt', 'desc')
            .limit(10)
            .onSnapshot(snapshot => {
                const list = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                    requestedAt: doc.data().requestedAt?.toDate() || new Date(),
                    processedAt: doc.data().processedAt?.toDate() || null
                } as WithdrawalRequest));
                setHistory(list);
                setLoadingHistory(false);
            }, err => {
                console.error("Error fetching withdrawal history:", err);
                setLoadingHistory(false);
            });

        return () => unsubscribe();
    }, [currentUser]);

    const handleUpdateKYC = async () => {
        if (!currentUser) return;
        if (panNumber.length !== 10) {
            showToast("Please enter a valid 10-digit PAN number", "error");
            return;
        }

        setIsKycSubmitting(true);
        try {
            await db.collection('users').doc(currentUser.uid).update({
                panNumber: panNumber.toUpperCase(),
                kycStatus: 'pending'
            });
            showToast("KYC details submitted for verification", "success");
        } catch (error) {
            console.error("Error updating KYC:", error);
            showToast("Failed to submit KYC", "error");
        } finally {
            setIsKycSubmitting(false);
        }
    };

    const handleSaveBankDetails = async () => {
        if (!currentUser) return;
        
        if (!bankDetails.upiId && (!bankDetails.accountNumber || !bankDetails.ifscCode)) {
            showToast("Please provide at least UPI ID or Bank Account details", "error");
            return;
        }

        try {
            await db.collection('users').doc(currentUser.uid).update({
                bankDetails: bankDetails
            });
            showToast("Bank details saved successfully", "success");
        } catch (error) {
            console.error("Error saving bank details:", error);
            showToast("Failed to save bank details", "error");
        }
    };

    const handleWithdraw = async () => {
        if (!currentUser) return;
        const withdrawAmount = parseFloat(amount);

        if (kycStatus !== 'verified') {
            showToast("Your KYC must be verified before withdrawal", "info");
            return;
        }

        if (isNaN(withdrawAmount) || withdrawAmount < 100) {
            showToast("Minimum withdrawal amount is ₹100", "error");
            return;
        }

        if (withdrawAmount > (currentUser.walletBalance || 0)) {
            showToast("Insufficient balance", "error");
            return;
        }

        setIsWithdrawing(true);
        try {
            const batch = db.batch();
            
            // 1. Deduct from wallet
            const userRef = db.collection('users').doc(currentUser.uid);
            batch.update(userRef, {
                walletBalance: firebase.firestore.FieldValue.increment(-withdrawAmount)
            });

            // 2. Create withdrawal request
            const withdrawRef = db.collection('users').doc(currentUser.uid).collection('withdrawals').doc();
            const requestData: Omit<WithdrawalRequest, 'id'> = {
                userId: currentUser.uid,
                userName: currentUser.name,
                amount: withdrawAmount,
                status: 'pending',
                bankDetails: bankDetails,
                requestedAt: serverTimestamp()
            };
            batch.set(withdrawRef, requestData);

            // 3. Admin notification (global collection for admins to process)
            const adminRequestRef = db.collection('admin_withdrawals').doc(withdrawRef.id);
            batch.set(adminRequestRef, requestData);

            await batch.commit();
            showToast("Withdrawal request sent successfully", "success");
            setAmount('');
        } catch (error) {
            console.error("Error processing withdrawal:", error);
            showToast("Failed to process withdrawal", "error");
        } finally {
            setIsWithdrawing(false);
        }
    };

    if (!currentUser) return null;

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Wallet & KYC" showBackButton onBack={onBack} />
            
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-32">
                <div className="max-w-3xl mx-auto space-y-8">
                    
                    {/* Compliance Alert */}
                    <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-xl">
                        <div className="flex items-start gap-3">
                            <span className="material-symbols-outlined text-blue-600 mt-0.5">info</span>
                            <div>
                                <h4 className="text-blue-800 font-bold">Government Compliance (Rule 194B/194BA)</h4>
                                <p className="text-blue-700 text-sm mt-1">
                                    As per Indian tax laws, KYC (PAN verification) is mandatory. Net winnings above ₹10,000 are subject to 30% TDS deduction. Please ensure your PAN and Bank details are correct.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Step 1: KYC Verification */}
                    <section className="glass-card p-6">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold">1</div>
                            <h3 className="text-xl font-bold text-gray-900">Identity Verification</h3>
                            {kycStatus === 'verified' && (
                                <span className="ml-auto flex items-center gap-1.5 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold uppercase tracking-wider">
                                    <span className="material-symbols-outlined text-sm">verified</span>
                                    Verified
                                </span>
                            )}
                        </div>

                        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                             <div className="flex items-center justify-between gap-4">
                                <div>
                                    <h4 className="font-bold text-gray-800">PAN Verification</h4>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {kycStatus === 'verified' 
                                            ? `Verified: ${currentUser.panNumber}` 
                                            : kycStatus === 'pending'
                                            ? 'Your documents are under review (24-48h)'
                                            : 'Mandatory for bank withdrawals'}
                                    </p>
                                </div>
                                <button 
                                    onClick={() => onNavigate(View.KYC)}
                                    className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all transform active:scale-95 ${
                                        kycStatus === 'verified'
                                        ? 'bg-white text-gray-700 border border-gray-200'
                                        : 'bg-red-600 text-white shadow-lg shadow-red-200'
                                    }`}
                                >
                                    {kycStatus === 'verified' ? 'View Details' : kycStatus === 'pending' ? 'Check Status' : 'Start KYC'}
                                </button>
                             </div>
                        </div>
                    </section>

                    {/* Step 2: Withdrawal Destination */}
                    <section className="glass-card p-6">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold">2</div>
                            <h3 className="text-xl font-bold text-gray-900">Withdrawal Destination</h3>
                        </div>

                        <div className="space-y-4">
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <label className="block text-xs font-bold text-gray-500 uppercase px-1">UPI ID (Recommended)</label>
                                    <input 
                                        type="text" 
                                        value={bankDetails.upiId}
                                        onChange={(e) => setBankDetails({...bankDetails, upiId: e.target.value})}
                                        placeholder="username@upi"
                                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all"
                                    />
                                </div>
                                <div className="space-y-1">
                                    <label className="block text-xs font-bold text-gray-500 uppercase px-1">Account Holder Name</label>
                                    <input 
                                        type="text" 
                                        value={bankDetails.accountHolderName}
                                        onChange={(e) => setBankDetails({...bankDetails, accountHolderName: e.target.value})}
                                        placeholder="As per bank records"
                                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all"
                                    />
                                </div>
                             </div>

                             <div className="pt-2">
                                <details className="group">
                                    <summary className="text-sm font-bold text-red-600 cursor-pointer list-none flex items-center gap-2">
                                        <span className="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
                                        Or Use Bank Account Details
                                    </summary>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 animate-in fade-in slide-in-from-top-2">
                                        <div className="space-y-1">
                                            <label className="block text-xs font-bold text-gray-500 uppercase px-1">Bank Name</label>
                                            <input 
                                                type="text" 
                                                value={bankDetails.bankName}
                                                onChange={(e) => setBankDetails({...bankDetails, bankName: e.target.value})}
                                                placeholder="e.g. State Bank of India"
                                                className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all"
                                            />
                                        </div>
                                        <div className="space-y-1">
                                            <label className="block text-xs font-bold text-gray-500 uppercase px-1">Account Number</label>
                                            <input 
                                                type="text" 
                                                value={bankDetails.accountNumber}
                                                onChange={(e) => setBankDetails({...bankDetails, accountNumber: e.target.value})}
                                                placeholder="Enter Account Number"
                                                className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all"
                                            />
                                        </div>
                                        <div className="space-y-1">
                                            <label className="block text-xs font-bold text-gray-500 uppercase px-1">IFSC Code</label>
                                            <input 
                                                type="text" 
                                                value={bankDetails.ifscCode}
                                                onChange={(e) => setBankDetails({...bankDetails, ifscCode: e.target.value.toUpperCase()})}
                                                placeholder="SBIN0001234"
                                                className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all uppercase font-mono"
                                            />
                                        </div>
                                    </div>
                                </details>
                             </div>

                             <button 
                                onClick={handleSaveBankDetails}
                                className="w-full md:w-auto px-8 py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-black transition-all transform active:scale-95 shadow-lg"
                             >
                                Save Details
                             </button>
                        </div>
                    </section>

                    {/* Step 3: Request Withdrawal */}
                    <section className="glass-card p-6 bg-gradient-to-br from-white to-red-50/30">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-10 h-10 rounded-full bg-gray-900 text-white flex items-center justify-center font-bold">3</div>
                            <h3 className="text-xl font-bold text-gray-900">Request Withdrawal</h3>
                        </div>

                        <div className="flex flex-col md:flex-row items-end gap-6">
                            <div className="flex-grow w-full">
                                <label className="block text-sm font-medium text-gray-700 mb-2">Amount to Withdraw (Min ₹100)</label>
                                <div className="relative">
                                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-gray-400">₹</span>
                                    <input 
                                        type="number" 
                                        value={amount}
                                        onChange={(e) => setAmount(e.target.value)}
                                        placeholder="0.00"
                                        className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-2xl text-2xl font-black text-gray-900 focus:ring-2 focus:ring-red-500 transition-all"
                                    />
                                </div>
                                <div className="flex justify-between mt-3 px-1 text-sm">
                                    <span className="text-gray-500 font-medium">Available Balance:</span>
                                    <span className="text-gray-900 font-bold">₹{currentUser.walletBalance?.toFixed(2) || '0.00'}</span>
                                </div>
                            </div>
                            
                            <button 
                                onClick={handleWithdraw}
                                disabled={isWithdrawing || kycStatus !== 'verified'}
                                className={`w-full md:w-auto px-10 py-4 font-black rounded-2xl shadow-xl transition-all transform active:scale-95 flex items-center justify-center gap-2 ${
                                    kycStatus === 'verified' 
                                    ? 'bg-red-600 text-white hover:bg-red-700' 
                                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                                }`}
                            >
                                {isWithdrawing ? 'Processing...' : 'Withdraw Now'}
                                <span className="material-symbols-outlined">payments</span>
                            </button>
                        </div>
                    </section>

                    {/* Transaction History */}
                    <section className="space-y-4">
                        <h3 className="text-xl font-bold text-gray-900 px-1">Recent Withdrawals</h3>
                        {loadingHistory ? (
                            <div className="p-12 flex justify-center"><div className="w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full animate-rotate"></div></div>
                        ) : history.length === 0 ? (
                            <div className="glass-card p-12 text-center text-gray-400">
                                <span className="material-symbols-outlined text-6xl mb-4 opacity-20">history</span>
                                <p>No withdrawal requests yet.</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {history.map((req) => (
                                    <motion.div 
                                        key={req.id}
                                        initial={{ opacity: 0, x: -10 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        className="glass-card p-4 flex items-center justify-between gap-4"
                                    >
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-2xl bg-gray-100 flex items-center justify-center text-gray-600">
                                                <span className="material-symbols-outlined">receipt_long</span>
                                            </div>
                                            <div>
                                                <div className="flex items-center gap-2">
                                                    <span className="font-black text-gray-900">₹{req.amount}</span>
                                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                                        req.status === 'completed' ? 'bg-green-100 text-green-700' :
                                                        req.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                                        'bg-yellow-100 text-yellow-700'
                                                    }`}>
                                                        {req.status}
                                                    </span>
                                                </div>
                                                <p className="text-xs text-gray-500 mt-0.5">{req.requestedAt.toLocaleDateString()} at {req.requestedAt.toLocaleTimeString()}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-xs font-bold text-gray-400">ID: {req.id.slice(-6).toUpperCase()}</p>
                                            {req.remarks && <p className="text-[10px] text-red-500 italic mt-1">{req.remarks}</p>}
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </section>
                </div>
            </main>
        </div>
    );
};

export default WithdrawalPage;
