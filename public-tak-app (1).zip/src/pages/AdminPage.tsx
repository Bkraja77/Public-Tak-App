
import React, { useState, useEffect } from 'react';
import { User, View } from '../types';
import Header from '../components/Header';
import { db } from '../firebaseConfig';
import { motion } from 'motion/react';

interface AdminPageProps {
  onBack: () => void;
  currentUser: User | null;
  onLogin: () => void;
  onLogout: () => void;
  onNavigate: (view: View) => void;
  unreadNotificationsCount: number;
}

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1
        }
    }
};

const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
        opacity: 1, 
        y: 0,
        transition: { type: "spring", stiffness: 300, damping: 24 }
    }
};

const AdminCard: React.FC<{ icon: string; title: string; description: string; color: string; onClick?: () => void; badge?: number }> = ({ icon, title, description, color, onClick, badge }) => (
    <motion.button 
        variants={cardVariants}
        whileHover={{ y: -8, scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onClick} 
        className="glass-card text-left w-full p-6 flex items-start space-x-4 transition-all duration-300 h-full relative group shadow-sm hover:shadow-xl border-white/50"
    >
        <div className={`p-4 rounded-2xl bg-gradient-to-br ${color} shadow-lg shrink-0 group-hover:rotate-6 transition-transform`}>
            <span className="material-symbols-outlined text-3xl text-white">{icon}</span>
        </div>
        <div className="flex-grow pt-1">
            <h3 className="font-black text-lg text-gray-900 group-hover:text-blue-600 transition-colors leading-tight">{title}</h3>
            <p className="text-gray-500 mt-2 text-sm font-medium leading-relaxed">{description}</p>
        </div>
        {badge && badge > 0 ? (
            <div className="absolute top-4 right-4 bg-red-600 text-white text-[10px] font-black px-2.5 py-1 rounded-full shadow-lg border-2 border-white animate-bounce">
                {badge}
            </div>
        ) : null}
    </motion.button>
);

const AdminPage: React.FC<AdminPageProps> = ({ onBack, currentUser, onLogin, onLogout, onNavigate, unreadNotificationsCount }) => {
    const [unreadFeedbackCount, setUnreadFeedbackCount] = useState(0);
    const [reportCount, setReportCount] = useState(0);
    const [pendingReporterCount, setPendingReporterCount] = useState(0);

    useEffect(() => {
        if (currentUser?.role !== 'admin') return;

        const unsubscribeFeedback = db.collection('feedback')
            .where('status', '==', 'unread')
            .onSnapshot(snapshot => {
                setUnreadFeedbackCount(snapshot.size);
            }, error => {
                console.error("Error counting unread feedback:", error);
            });

        const unsubscribeReports = db.collection('reports').onSnapshot(snapshot => {
            setReportCount(snapshot.size);
        }, error => {
            console.error("Error counting reports:", error);
        });

        const unsubscribeReporters = db.collection('reporter_requests')
            .where('status', '==', 'pending')
            .onSnapshot(snapshot => {
                setPendingReporterCount(snapshot.size);
            }, error => {
                console.error("Error counting pending reporters:", error);
            });

        return () => {
            unsubscribeFeedback();
            unsubscribeReports();
            unsubscribeReporters();
        };
    }, [currentUser]);

    return (
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col h-full bg-transparent"
        >
            <Header 
                title="Admin Panel" 
                showBackButton 
                onBack={onBack}
                currentUser={currentUser}
                onProfileClick={() => onNavigate(View.User)}
                onLogin={onLogin}
            />
            <main className="flex-grow overflow-y-auto p-4 md:p-10 pb-32">
                <div className="w-full max-w-7xl mx-auto">
                    <motion.div 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="mb-10"
                    >
                        <h2 className="text-4xl font-black text-gray-900 tracking-tighter">Command Center</h2>
                        <p className="text-gray-500 font-bold mt-2 lowercase">manage your news network from one spot</p>
                    </motion.div>
                    
                    <motion.div 
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible"
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                    >
                        <AdminCard icon="feedback" title="User Feedback" description="View and manage messages from users." color="from-pink-500 to-rose-500" onClick={() => onNavigate(View.ViewFeedback)} badge={unreadFeedbackCount} />
                        <AdminCard icon="article" title="Create Article" description="Write and publish a new news article." color="from-blue-600 to-indigo-600" onClick={() => onNavigate(View.CreatePost)} />
                        <AdminCard icon="group" title="Manage Users" description="View, edit, or remove user accounts." color="from-blue-500 to-indigo-500" onClick={() => onNavigate(View.ManageUsers)} />
                        <AdminCard icon="monetization_on" title="Manage Ads" description="Configure AdSense and AdMob." color="from-emerald-500 to-lime-500" onClick={() => onNavigate(View.ManageAds)} />
                        <AdminCard icon="payments" title="Monetization" description="Review monetization requests and verify creators." color="from-red-600 to-orange-500" onClick={() => onNavigate(View.ManageMonetization)} />
                        <AdminCard icon="analytics" title="View Analytics" description="Check website traffic and engagement." color="from-purple-500 to-pink-500" onClick={() => onNavigate(View.Analytics)}/>
                        <AdminCard icon="flag" title="Moderate Content" description="Review and manage reported content." color="from-red-500 to-orange-500" onClick={() => onNavigate(View.ModerateContent)} badge={reportCount} />
                        <AdminCard icon="badge" title="Manage Reporters" description="Review Aadhaar e-KYC and issue Digital Media ID Cards." color="from-indigo-600 to-blue-700" onClick={() => onNavigate(View.ManageReporters)} badge={pendingReporterCount} />
                        <AdminCard icon="badge" title="Manage KYC" description="Review and approve user identity documents." color="from-blue-600 to-cyan-500" onClick={() => onNavigate(View.ManageKYC)} />
                        <AdminCard icon="account_balance" title="Manage Withdrawals" description="Process user payout requests and UTR." color="from-amber-600 to-orange-500" onClick={() => onNavigate(View.ManageWithdrawals)} />
                        <AdminCard icon="campaign" title="Send Notifications" description="Push alerts and updates to users." color="from-yellow-500 to-amber-500" onClick={() => onNavigate(View.Notifications)} badge={unreadNotificationsCount} />
                        <AdminCard icon="settings_applications" title="Site Settings" description="Configure application-wide settings." color="from-gray-500 to-gray-600" onClick={() => onNavigate(View.SiteSettings)} />
                    </motion.div>
                </div>
            </main>
        </motion.div>
    );
};

export default AdminPage;
