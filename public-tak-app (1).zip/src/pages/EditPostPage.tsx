
import React, { useState, useEffect, useRef } from 'react';
import Header from '../components/Header';
import { User, Post } from '../types';
import { db, storage, serverTimestamp } from '../firebaseConfig';
import { subscribeCategories } from '../utils/categories';
import { v4 as uuidv4 } from 'uuid';
import LocationSelector from '../components/LocationSelector';
import { checkContentSafety } from '../services/geminiService';

interface EditPostPageProps {
  onBack: () => void;
  currentUser: User;
  postId: string;
}

const newsCategoriesFallback = ['Politics', 'Crime', 'Sports', 'Entertainment', 'Business', 'Technology', 'Health', 'Education', 'Jobs', 'World', 'General'];
const MAX_TITLE_LENGTH = 200;

/**
 * Compresses an image file client-side before uploading.
 * @param file The image file to compress.
 * @param quality The desired quality (0 to 1).
 * @param maxSize The maximum width or height of the image.
 * @returns A promise that resolves with the compressed image file.
 */
const compressImage = (file: File, quality: number = 0.8, maxSize: number = 1280): Promise<File> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let { width, height } = img;

                if (width > height) {
                    if (width > maxSize) {
                        height *= maxSize / width;
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width *= maxSize / height;
                        height = maxSize;
                    }
                }

                canvas.width = width;
                canvas.height = height;

                const ctx = canvas.getContext('2d');
                if (!ctx) return reject(new Error('Could not get canvas context'));
                
                ctx.drawImage(img, 0, 0, width, height);

                canvas.toBlob(
                    (blob) => {
                        if (blob) {
                            resolve(new File([blob], file.name, { type: 'image/jpeg', lastModified: Date.now() }));
                        } else {
                            reject(new Error('Canvas toBlob failed'));
                        }
                    },
                    'image/jpeg',
                    quality
                );
            };
            img.onerror = () => reject(new Error('Failed to load image for compression'));
        };
        reader.onerror = () => reject(new Error('Failed to read file for compression'));
    });
};

interface RichTextEditorToolbarProps {
    editorRef: React.RefObject<HTMLDivElement>;
    onImageUpload: () => void;
    onAlign: (alignment: 'left' | 'center' | 'right') => void;
    isImageSelected: boolean;
}

const RichTextEditorToolbar: React.FC<RichTextEditorToolbarProps> = ({ editorRef, onImageUpload, onAlign, isImageSelected }) => {
    const handleCommand = (command: string, value: string | null = null) => {
        if (editorRef.current) {
            editorRef.current.focus();
            document.execCommand(command, false, value || undefined);
        }
    };

    const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        handleCommand('foreColor', e.target.value);
    };

    // Prevents the editor from losing focus when a button is clicked
    const preventDefault = (e: React.MouseEvent | React.ChangeEvent<HTMLSelectElement>) => e.preventDefault();

    return (
        <div className="flex items-center flex-wrap gap-1 p-2 border border-b-0 border-gray-300 bg-gray-50 rounded-t-lg text-gray-700 sticky top-0 z-10">
            <button type="button" onMouseDown={preventDefault} onClick={() => handleCommand('bold')} className="p-2 hover:bg-gray-200 rounded" title="Bold"><span className="material-symbols-outlined">format_bold</span></button>
            <button type="button" onMouseDown={preventDefault} onClick={() => handleCommand('italic')} className="p-2 hover:bg-gray-200 rounded" title="Italic"><span className="material-symbols-outlined">format_italic</span></button>
            <button type="button" onMouseDown={preventDefault} onClick={() => handleCommand('underline')} className="p-2 hover:bg-gray-200 rounded" title="Underline"><span className="material-symbols-outlined">format_underlined</span></button>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button 
                type="button" 
                onMouseDown={preventDefault} 
                onClick={() => onAlign('left')} 
                className={`p-2 hover:bg-gray-200 rounded ${isImageSelected ? 'text-blue-600' : ''}`} 
                title={isImageSelected ? "Align Image Left" : "Align Text Left"}
            >
                <span className="material-symbols-outlined">format_align_left</span>
            </button>
            <button 
                type="button" 
                onMouseDown={preventDefault} 
                onClick={() => onAlign('center')} 
                className={`p-2 hover:bg-gray-200 rounded ${isImageSelected ? 'text-blue-600' : ''}`} 
                title={isImageSelected ? "Align Image Center" : "Align Text Center"}
            >
                <span className="material-symbols-outlined">format_align_center</span>
            </button>
            <button 
                type="button" 
                onMouseDown={preventDefault} 
                onClick={() => onAlign('right')} 
                className={`p-2 hover:bg-gray-200 rounded ${isImageSelected ? 'text-blue-600' : ''}`} 
                title={isImageSelected ? "Align Image Right" : "Align Text Right"}
            >
                <span className="material-symbols-outlined">format_align_right</span>
            </button>

            <div className="h-6 border-l border-gray-300 mx-1"></div>

            <div className="relative p-2 hover:bg-gray-200 rounded" title="Text Color">
                <span className="material-symbols-outlined">format_color_text</span>
                <input type="color" onChange={handleColorChange} className="absolute inset-0 opacity-0 w-full h-full cursor-pointer" />
            </div>
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            <button type="button" onMouseDown={preventDefault} onClick={onImageUpload} className="p-2 hover:bg-gray-200 rounded" title="Insert Image">
                <span className="material-symbols-outlined">image</span>
            </button>
        </div>
    );
};


const EditPostPage: React.FC<EditPostPageProps> = ({ onBack, currentUser, postId }) => {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [category, setCategory] = useState('');
    const [newsCategories, setNewsCategories] = useState<string[]>(newsCategoriesFallback);

    useEffect(() => {
        const unsubscribe = subscribeCategories((data) => {
            setNewsCategories(data.newsCategories);
        });
        return unsubscribe;
    }, []);

    const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
    const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
    const [existingThumbnailUrl, setExistingThumbnailUrl] = useState<string>('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const editorRef = useRef<HTMLDivElement>(null);
    const isInitialLoad = useRef(true);
    const imageInputRef = useRef<HTMLInputElement>(null);
    const [isUploadingImage, setIsUploadingImage] = useState(false);
    const savedRange = useRef<Range | null>(null);
    
    // Store image DOM element in ref to avoid circular JSON error in state
    const selectedImageRef = useRef<HTMLImageElement | null>(null);
    const [isImageSelected, setIsImageSelected] = useState(false);
    
    // Location state
    const [state, setState] = useState('');
    const [district, setDistrict] = useState('');
    const [block, setBlock] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            setIsLoading(true);
            const postDocRef = db.collection('posts').doc(postId);
            const postSnap = await postDocRef.get();

            if (postSnap.exists) {
                const postData = postSnap.data() as Omit<Post, 'id'>;
                // Security check
                if (postData.authorId !== currentUser.uid && currentUser.role !== 'admin') {
                    setError("You are not authorized to edit this post.");
                    setIsLoading(false);
                    return;
                }
                setTitle(postData.title);
                setContent(postData.content);
                setCategory(postData.category || 'General');
                setThumbnailPreview(postData.thumbnailUrl);
                setExistingThumbnailUrl(postData.thumbnailUrl);
                setState(postData.state || '');
                setDistrict(postData.district || '');
                setBlock(postData.block || '');
            } else {
                setError("Post not found.");
            }
            setIsLoading(false);
        };
        fetchPost();
    }, [postId, currentUser.uid, currentUser.role]);

    useEffect(() => {
        if (editorRef.current && content && isInitialLoad.current) {
            editorRef.current.innerHTML = content;
            isInitialLoad.current = false;
        }
    }, [content]);

    const [isDragging, setIsDragging] = useState(false);
    
    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };
    
    const handleDragLeave = () => {
        setIsDragging(false);
    };
    
    const handleDrop = async (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            if (file.type.startsWith('image/')) {
                if (file.size > 10 * 1024 * 1024) { 
                    setError("Image is too large. Please select a file under 10MB.");
                    return;
                }
                try {
                    const compressedFile = await compressImage(file);
                    setThumbnailFile(compressedFile);
                    setThumbnailPreview(URL.createObjectURL(compressedFile));
                    setError(null);
                } catch (err) {
                    console.error("Image compression error:", err);
                    setError("Could not process image.");
                }
            } else {
                setError("Please drop an image file.");
            }
        }
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (file.size > 10 * 1024 * 1024) { // 10MB limit before compression
                setError("Image is too large. Please select a file under 10MB.");
                return;
            }
            try {
                const compressedFile = await compressImage(file);
                setThumbnailFile(compressedFile);
                setThumbnailPreview(URL.createObjectURL(compressedFile));
                setError(null); // Clear previous errors
            } catch (err) {
                console.error("Image compression error:", err);
                setError("Could not process image. Please try another one.");
            }
        }
    };
    
    const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
        setContent(e.currentTarget.innerHTML);
    };

    const handleEditorClick = (e: React.MouseEvent) => {
        const target = e.target as HTMLElement;
        
        // Handle previous selection
        if (selectedImageRef.current && target !== selectedImageRef.current) {
            // Check connectedness to avoid errors if node was removed
            if (selectedImageRef.current.isConnected) {
                selectedImageRef.current.style.outline = 'none';
            }
            selectedImageRef.current = null;
            setIsImageSelected(false);
        }

        // Handle new selection
        if (target.tagName === 'IMG') {
            const img = target as HTMLImageElement;
            selectedImageRef.current = img;
            img.style.outline = '3px solid #3b82f6'; // Visual feedback
            img.style.outlineOffset = '2px';
            setIsImageSelected(true);
        }
    };

    const handleAlignment = (alignment: 'left' | 'center' | 'right') => {
        if (selectedImageRef.current) {
            const img = selectedImageRef.current;
            // Aligning specific selected image
            if (alignment === 'left') {
                img.style.float = 'left';
                img.style.margin = '0 1rem 1rem 0';
                img.style.display = 'block';
            } else if (alignment === 'right') {
                img.style.float = 'right';
                img.style.margin = '0 0 1rem 1rem';
                img.style.display = 'block';
            } else if (alignment === 'center') {
                img.style.float = 'none';
                img.style.margin = '1rem auto';
                img.style.display = 'block';
            }
            // Update the content state to reflect the style change
            if (editorRef.current) {
                setContent(editorRef.current.innerHTML);
            }
        } else {
            // Standard text alignment
            const command = alignment === 'left' ? 'justifyLeft' : alignment === 'center' ? 'justifyCenter' : 'justifyRight';
            document.execCommand(command, false, undefined);
            editorRef.current?.focus();
        }
    };
    
    const handleTriggerImageUpload = () => {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            savedRange.current = selection.getRangeAt(0);
        }
        imageInputRef.current?.click();
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files || !e.target.files[0]) return;
        const file = e.target.files[0];
        
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            setError("Image file is too large. Please select an image under 5MB.");
            return;
        }

        setIsUploadingImage(true);
        setError(null);

        try {
            const imageRef = storage.ref(`post-images/${uuidv4()}-${file.name}`);
            const uploadTask = await imageRef.put(file);
            const imageUrl = await uploadTask.ref.getDownloadURL();

            if (savedRange.current) {
                const selection = window.getSelection();
                selection?.removeAllRanges();
                selection?.addRange(savedRange.current);
            } else {
                editorRef.current?.focus();
            }

            const imgHtml = `<img src="${imageUrl}" alt="uploaded content" style="max-width: 100%; height: auto; border-radius: 0.5rem; margin: 1rem 0; display: block;" />`;
            document.execCommand('insertHTML', false, imgHtml);
            
            if (editorRef.current) {
                setContent(editorRef.current.innerHTML);
            }
            savedRange.current = null;

        } catch (err: any) {
            console.error("Image upload failed:", err?.message || String(err));
            setError("Image upload failed. Please try again.");
        } finally {
            setIsUploadingImage(false);
            if (e.target) e.target.value = '';
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        
        const isContentEmpty = !content || content.replace(/<[^>]*>?/gm, '').trim().length === 0;

        if (!title.trim() || isContentEmpty || !category) {
            setError("Title, content and category cannot be empty.");
            return;
        }

        setIsLoading(true);

        // AI Moderation with Fail-Open Logic
        let isViolated = false;
        try {
             const strippedContent = content.replace(/<[^>]*>?/gm, '');
             const safetyResult = await checkContentSafety(title, strippedContent.substring(0, 2000));
             isViolated = safetyResult.isViolated;
        } catch (aiError: any) {
            // Warn but don't stop. 
            // If the model or API fails, we default to non-violation to not block the user.
            console.warn("AI Moderation skipped due to error:", aiError.message);
        }

        if (isViolated) {
            setError("This post could not be updated because it appears to violate our content policy regarding inappropriate material. Please revise your content.");
            setIsLoading(false);
            return;
        }

        try {
            let locationType: 'Overall' | 'State' | 'District' | 'Block' = 'Overall';
            if (state && district && block) {
                locationType = 'Block';
            } else if (state && district) {
                locationType = 'District';
            } else if (state) {
                locationType = 'State';
            }

            let newThumbnailUrl = existingThumbnailUrl;

            // If a new thumbnail is uploaded
            if (thumbnailFile) {
                // 1. Delete old thumbnail from Storage
                if (existingThumbnailUrl) {
                    const oldStorageRef = storage.refFromURL(existingThumbnailUrl);
                    try {
                        await oldStorageRef.delete();
                    } catch (storageError) {
                        console.warn("Could not delete old thumbnail, it might not exist:", storageError);
                    }
                }

                // 2. Upload new thumbnail
                const fileExtension = thumbnailFile.name.split('.').pop();
                const newThumbnailRef = storage.ref(`thumbnails/${uuidv4()}.${fileExtension}`);
                const uploadResult = await newThumbnailRef.put(thumbnailFile);
                newThumbnailUrl = await uploadResult.ref.getDownloadURL();
            }

            // Cleanup before save: remove selection outlines from content HTML
            let finalContent = content;
            if (editorRef.current) {
                // Clone the content to a temporary div to clean up
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = content;
                const images = tempDiv.querySelectorAll('img');
                images.forEach(img => {
                    img.style.outline = 'none';
                    img.style.outlineOffset = 'none';
                });
                finalContent = tempDiv.innerHTML;
            }

            // 3. Update post document in Firestore
            const postDocRef = db.collection('posts').doc(postId);
            await postDocRef.update({
                title: title,
                content: finalContent,
                category: category,
                thumbnailUrl: newThumbnailUrl,
                updatedAt: serverTimestamp(),
                locationType,
                state,
                district,
                block,
            });

            onBack();

        } catch (err: any) {
            // Prevent circular structure error by logging only the message
            console.error("Error updating post:", err instanceof Error ? err.message : String(err));
            setError(err.message || "Failed to update post. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading && !title) { // Show loading only on initial fetch
        return (
            <div className="flex flex-col h-full bg-transparent">
                <Header title="Edit Post" showBackButton onBack={onBack} />
                <div className="flex items-center justify-center h-full">
                    <p>Loading post...</p>
                </div>
            </div>
        )
    }

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title="Edit Post" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-5 md:p-8 pb-20">
                <form onSubmit={handleSubmit} className="w-full glass-card p-6 md:p-8 space-y-6">
                     {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg" role="alert">
                            <strong className="font-bold">Error: </strong>
                            <span className="block sm:inline">{error}</span>
                        </div>
                    )}
                    
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                            Title <span className="text-red-500">*</span>
                        </label>
                        <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500" required maxLength={MAX_TITLE_LENGTH} />
                        <div className="flex justify-between items-center mt-2 text-xs">
                            <p className="text-gray-500">A clear, catchy title works best.</p>
                            <p className={`font-medium ${
                                title.length > MAX_TITLE_LENGTH * 0.9 ? 'text-red-500' : 'text-gray-500'
                            }`}>
                                {title.length}/{MAX_TITLE_LENGTH}
                            </p>
                        </div>
                    </div>

                    <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                            Category <span className="text-red-500">*</span>
                        </label>
                        <select
                            id="category"
                            value={category}
                            onChange={e => setCategory(e.target.value)}
                            className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500"
                            required
                        >
                            <option value="" disabled>Select a category</option>
                            {newsCategories.map(cat => (
                                <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </select>
                    </div>

                    <LocationSelector 
                      state={state}
                      setState={setState}
                      district={district}
                      setDistrict={setDistrict}
                      block={block}
                      setBlock={setBlock}
                    />

                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                           Thumbnail Image
                        </label>
                        <div 
                            onDragOver={handleDragOver}
                            onDragLeave={handleDragLeave}
                            onDrop={handleDrop}
                            className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md transition-all duration-200 ${
                                isDragging 
                                ? 'border-blue-500 bg-blue-50/50 scale-[1.01] shadow-md shadow-blue-50' 
                                : 'border-gray-300 bg-gray-50 hover:bg-white'
                            }`}
                        >
                             <div className="space-y-1 text-center">
                                {thumbnailPreview ? (
                                    <img src={thumbnailPreview} alt="Thumbnail Preview" className="mx-auto h-40 w-auto object-contain rounded" />
                                ) : (
                                    <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                    </svg>
                                )}
                                <div className="flex text-sm text-gray-600 justify-center mt-2">
                                    <label htmlFor="edit-post-file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 px-2 py-1 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                                        <span>{thumbnailPreview ? 'Change thumbnail' : 'Upload a file'}</span>
                                        <input id="edit-post-file-upload" name="edit-post-file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange}/>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                            News Article <span className="text-red-500">*</span>
                        </label>
                        <RichTextEditorToolbar 
                            editorRef={editorRef} 
                            onImageUpload={handleTriggerImageUpload}
                            onAlign={handleAlignment} 
                            isImageSelected={isImageSelected}
                        />
                        <div className="relative">
                            <div
                                id="content"
                                ref={editorRef}
                                contentEditable="true"
                                onInput={handleContentChange}
                                onClick={handleEditorClick}
                                className="w-full p-4 border border-gray-300 bg-white rounded-b-lg h-96 resize-y overflow-y-auto text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg leading-relaxed"
                            />
                            {isUploadingImage && (
                                <div className="absolute inset-0 bg-white/80 flex items-center justify-center rounded-b-lg z-10">
                                    <div className="text-center p-4 bg-white/50 rounded-lg">
                                        <svg className="animate-spin h-8 w-8 text-blue-600 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        <p className="mt-2 text-gray-700 font-semibold">Uploading image...</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                    
                    <button 
                        type="submit" 
                        disabled={isLoading} 
                        className="w-full px-8 py-4 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white border-none rounded-xl text-xl font-black shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-0.5 active:scale-95 disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-3"
                    >
                        {isLoading ? (
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                        ) : (
                            <span className="material-symbols-outlined text-2xl">save</span>
                        )}
                        <span>{isLoading ? 'Saving Changes...' : 'Save Changes'}</span>
                    </button>
                </form>
                <input type="file" ref={imageInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
            </main>
        </div>
    );
};

export default EditPostPage;
