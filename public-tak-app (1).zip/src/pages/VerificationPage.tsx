
import React from 'react';
import { User, View } from '../types';
import Header from '../components/Header';
import { motion } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { db, firebase } from '../firebaseConfig';

interface VerificationPageProps {
  onBack: () => void;
  currentUser: User | null;
  onNavigate: (view: View) => void;
}

const VerificationPage: React.FC<VerificationPageProps> = ({ onBack, currentUser, onNavigate }) => {
  const { t } = useLanguage();
  const { showToast } = useToast();
  const [loading, setLoading] = React.useState(false);

  const benefits = [
    {
      icon: 'verified',
      title: 'Global Credibility',
      desc: 'Get the verified badge and stand out as an authentic creator.',
      color: 'text-blue-600',
      bg: 'bg-blue-50'
    },
    {
      icon: 'trending_up',
      title: '3x Reach Boost',
      desc: 'Verified accounts are prioritized in discovery and search results.',
      color: 'text-orange-600',
      bg: 'bg-orange-50'
    },
    {
      icon: 'support_agent',
      title: 'Priority Support',
      desc: 'Direct access to our dedicated creator support team.',
      color: 'text-purple-600',
      bg: 'bg-purple-50'
    },
    {
      icon: 'analytics',
      title: 'Advanced Analytics',
      desc: 'Detailed insights into your audience demographics and growth.',
      color: 'text-emerald-600',
      bg: 'bg-emerald-50'
    }
  ];

  const handlePurchase = async () => {
    if (!currentUser) return;
    setLoading(true);
    
    try {
        // 1. Create order on server
        const orderResponse = await fetch('/api/payment/order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ amount: 400 })
        });
        
        const orderData = await orderResponse.json();
        
        if (!orderData || !orderData.id) {
            throw new Error("Failed to create order");
        }

        // 2. Open Razorpay Modal
        const options = {
            key: 'rzp_test_Sfov0bF3zEHs4X', // Test Key provided by user
            amount: orderData.amount,
            currency: orderData.currency,
            name: "Public Tak App",
            description: "Blue Tick Verification",
            image: "https://publictak.app/icon-192.png",
            order_id: orderData.id,
            handler: async (response: any) => {
                setLoading(true);
                try {
                    // 3. Verify payment on server
                    const verifyResponse = await fetch('/api/payment/verify', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            razorpay_order_id: response.razorpay_order_id,
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_signature: response.razorpay_signature,
                            userId: currentUser.uid
                        })
                    });

                    const verifyData = await verifyResponse.json();

                    if (verifyData.success) {
                        showToast("Congratulations! You are now a Verified Creator.", "success");
                        onNavigate(View.CreatorDashboard);
                    } else {
                        showToast("Verification failed: " + verifyData.error, "error");
                    }
                } catch (err) {
                    console.error("Verification error:", err);
                    showToast("Error verifying payment", "error");
                } finally {
                    setLoading(false);
                }
            },
            prefill: {
                name: currentUser.name,
                email: currentUser.email || "",
                contact: ""
            },
            theme: {
                color: "#2563eb"
            }
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.on('payment.failed', function (response: any) {
            showToast("Payment failed: " + response.error.description, "error");
            setLoading(false);
        });
        rzp.open();
        
    } catch (error) {
        console.error("Verification payment error:", error);
        showToast("Error starting payment process.", "error");
        setLoading(false);
    }
  };

  if (!currentUser) return null;

  return (
    <div className="flex flex-col h-full bg-white">
      <Header title="Get Blue Tick" showBackButton onBack={onBack} currentUser={currentUser} />
      
      <main className="flex-grow overflow-y-auto pb-24">
        <div className="max-w-4xl mx-auto px-4 py-8 md:py-12">
            
            {/* Hero Section */}
            <div className="text-center mb-12">
                <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="inline-flex items-center justify-center p-4 bg-blue-50 rounded-full mb-6"
                >
                    <span className="material-symbols-outlined text-6xl text-blue-600">verified</span>
                </motion.div>
                <motion.h1 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-4xl md:text-5xl font-black text-gray-900 tracking-tight"
                >
                    Upgrade to <span className="text-blue-600 underline decoration-blue-200 underline-offset-8">Verified</span>
                </motion.h1>
                <motion.p 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="mt-4 text-gray-500 text-lg max-w-xl mx-auto font-medium"
                >
                    Join the ranks of elite creators on Public Tak App and unlock powerful tools to grow your influence.
                </motion.p>
            </div>

            {/* Benefits Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                {benefits.map((benefit, idx) => (
                    <motion.div
                        key={benefit.title}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 + idx * 0.1 }}
                        className="p-6 rounded-3xl border border-gray-100 bg-white hover:border-blue-100 hover:shadow-xl hover:shadow-blue-500/5 transition-all group"
                    >
                        <div className={`w-12 h-12 rounded-2xl ${benefit.bg} ${benefit.color} flex items-center justify-center mb-4 transition-transform group-hover:scale-110`}>
                            <span className="material-symbols-outlined">{benefit.icon}</span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">{benefit.title}</h3>
                        <p className="text-gray-500 mt-2 text-sm leading-relaxed">{benefit.desc}</p>
                    </motion.div>
                ))}
            </div>

            {/* Pricing Card */}
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                className="glass-card p-8 md:p-10 border-2 border-blue-600 shadow-2xl shadow-blue-600/10 text-center relative overflow-hidden"
            >
                <div className="absolute top-0 right-0 p-4">
                    <span className="bg-blue-600 text-white text-[10px] font-black px-3 py-1 rounded-full tracking-widest uppercase">Best Value</span>
                </div>
                
                <h4 className="text-sm font-black text-blue-600 uppercase tracking-[0.3em] mb-2">Lifetime Access</h4>
                <div className="flex items-baseline justify-center gap-1">
                    <span className="text-2xl font-bold text-gray-400">₹</span>
                    <span className="text-7xl font-black text-gray-900 tracking-tighter">400</span>
                </div>
                <p className="text-gray-500 mt-2 font-medium">One-time payment. No subscription.</p>

                <div className="mt-8 space-y-4">
                    <button 
                        onClick={handlePurchase}
                        disabled={loading || currentUser.isVerified}
                        className={`w-full py-5 rounded-2xl font-black text-xl transition-all shadow-xl flex items-center justify-center gap-3 active:scale-95 ${
                            currentUser.isVerified 
                            ? 'bg-emerald-100 text-emerald-600 cursor-default'
                            : 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/30'
                        }`}
                    >
                        {loading ? (
                            <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                        ) : currentUser.isVerified ? (
                            <>
                                <span className="material-symbols-outlined">check_circle</span>
                                Already Verified
                            </>
                        ) : (
                            <>
                                Buy Blue Tick Now
                                <span className="material-symbols-outlined">arrow_forward</span>
                            </>
                        )}
                    </button>
                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">Secure Payment via UPI / Cards</p>
                </div>
            </motion.div>

            {/* Testimonial / Social Proof */}
            <div className="mt-16 text-center space-y-4">
                <div className="flex justify-center -space-x-2">
                    {[1,2,3,4,5].map(i => (
                        <img 
                            key={i}
                            src={`https://picsum.photos/seed/user${i}/100/100`} 
                            className="w-10 h-10 rounded-full border-4 border-white shadow-sm"
                        />
                    ))}
                </div>
                <p className="text-sm font-bold text-gray-500">Joined by 2,000+ top creators in Bharat</p>
            </div>
        </div>
      </main>
    </div>
  );
};

export default VerificationPage;
