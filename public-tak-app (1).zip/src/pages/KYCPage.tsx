
import React, { useState } from 'react';
import Header from '../components/Header';
import { User, View } from '../types';
import { db } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { motion } from 'motion/react';

interface KYCPageProps {
    onBack: () => void;
    currentUser: User | null;
}

const KYCPage: React.FC<KYCPageProps> = ({ onBack, currentUser }) => {
    const { showToast } = useToast();
    const [loading, setLoading] = useState(false);
    const [panNumber, setPanNumber] = useState(currentUser?.panNumber || '');
    const [fullName, setFullName] = useState(currentUser?.name || '');
    const [dob, setDob] = useState('');
    const [photo, setPhoto] = useState<string | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 2 * 1024 * 1024) {
                showToast("File size too large (Max 2MB)", "error");
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setPhoto(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) return;

        if (panNumber.length !== 10) {
            showToast("Enter a valid 10-digit PAN number", "error");
            return;
        }

        if (!photo) {
            showToast("Please upload a photo of your PAN card", "error");
            return;
        }

        setLoading(true);
        try {
            await db.collection('users').doc(currentUser.uid).update({
                panNumber: panNumber.toUpperCase(),
                panPhotoUrl: photo, // Storing base64 for demo purposes as requested "Smooth Working"
                kycStatus: 'pending',
                kycSubmissionDate: new Date()
            });
            
            // Also add to a global kyc_requests collection for easier admin management
            await db.collection('kyc_requests').doc(currentUser.uid).set({
                userId: currentUser.uid,
                userName: fullName,
                panNumber: panNumber.toUpperCase(),
                panPhotoUrl: photo,
                status: 'pending',
                submittedAt: new Date()
            });

            showToast("KYC details submitted successfully! Approval usually takes 24 hours.", "success");
            onBack();
        } catch (error) {
            console.error("Error submitting KYC:", error);
            showToast("Failed to submit KYC details", "error");
        } finally {
            setLoading(false);
        }
    };

    if (!currentUser) return null;

    const status = currentUser.kycStatus || 'none';

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="PAN KYC Verification" showBackButton onBack={onBack} />
            
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-32">
                <div className="max-w-2xl mx-auto">
                    
                    {/* Status Banner */}
                    {status !== 'none' && (
                        <div className={`mb-8 p-4 rounded-2xl flex items-center gap-4 ${
                            status === 'verified' ? 'bg-green-100 text-green-700' :
                            status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-red-100 text-red-700'
                        }`}>
                            <span className="material-symbols-outlined text-2xl">
                                {status === 'verified' ? 'verified' : status === 'pending' ? 'hourglass_empty' : 'cancel'}
                            </span>
                            <div>
                                <p className="font-bold uppercase text-xs tracking-widest">Current Status: {status}</p>
                                <p className="text-sm">
                                    {status === 'verified' ? 'Your identity is verified. You can now withdraw funds.' : 
                                     status === 'pending' ? 'Your documents are being reviewed by our team.' :
                                     'Your last submission was rejected. Please re-submit correct details.'}
                                </p>
                            </div>
                        </div>
                    )}

                    <div className="glass-card p-6 md:p-10">
                        <div className="flex items-center gap-4 mb-8">
                            <div className="w-12 h-12 bg-red-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-red-200">
                                <span className="material-symbols-outlined">badge</span>
                            </div>
                            <div>
                                <h2 className="text-2xl font-black text-gray-900 tracking-tight">Identity Details</h2>
                                <p className="text-gray-500 text-sm">Please provide your original PAN card details.</p>
                            </div>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="space-y-2">
                                <label className="block text-sm font-bold text-gray-700 ml-1">Full Name (As on PAN)</label>
                                <input 
                                    type="text" 
                                    required
                                    value={fullName}
                                    onChange={(e) => setFullName(e.target.value)}
                                    placeholder="Enter full name"
                                    disabled={status === 'verified' || status === 'pending'}
                                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all disabled:opacity-60"
                                />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <label className="block text-sm font-bold text-gray-700 ml-1">PAN Number</label>
                                    <input 
                                        type="text" 
                                        required
                                        maxLength={10}
                                        value={panNumber}
                                        onChange={(e) => setPanNumber(e.target.value.toUpperCase())}
                                        placeholder="ABCDE1234F"
                                        disabled={status === 'verified' || status === 'pending'}
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all uppercase font-mono tracking-widest disabled:opacity-60"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="block text-sm font-bold text-gray-700 ml-1">Date of Birth</label>
                                    <input 
                                        type="date" 
                                        required
                                        value={dob}
                                        onChange={(e) => setDob(e.target.value)}
                                        disabled={status === 'verified' || status === 'pending'}
                                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 transition-all disabled:opacity-60"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="block text-sm font-bold text-gray-700 ml-1">Upload Photo (Front Side)</label>
                                <div className={`relative border-2 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center transition-all ${
                                    photo ? 'border-red-500 bg-red-50/30' : 'border-gray-200 hover:border-red-400 hover:bg-red-50/10'
                                }`}>
                                    {photo ? (
                                        <div className="relative group">
                                            <img src={photo} alt="PAN Preview" className="max-h-48 rounded-xl shadow-lg" />
                                            {status !== 'verified' && status !== 'pending' && (
                                                <button 
                                                    type="button"
                                                    onClick={() => setPhoto(null)}
                                                    className="absolute -top-3 -right-3 bg-red-600 text-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg hover:bg-red-700 transition-colors"
                                                >
                                                    <span className="material-symbols-outlined text-sm">close</span>
                                                </button>
                                            )}
                                        </div>
                                    ) : (
                                        <>
                                            <span className="material-symbols-outlined text-5xl text-gray-400 mb-2">image</span>
                                            <p className="text-gray-500 text-xs text-center">Click to upload or drag & drop<br/>Max size: 2MB (JPG/PNG)</p>
                                            <input 
                                                type="file" 
                                                accept="image/*"
                                                onChange={handleFileChange}
                                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                            />
                                        </>
                                    )}
                                </div>
                            </div>

                            <div className="pt-4">
                                <button
                                    type="submit"
                                    disabled={loading || status === 'verified' || status === 'pending'}
                                    className={`w-full py-4 rounded-2xl font-black text-lg transition-all shadow-xl shadow-red-500/10 flex items-center justify-center gap-3 active:scale-95 ${
                                        status === 'verified' ? 'bg-green-100 text-green-600 cursor-default' :
                                        status === 'pending' ? 'bg-yellow-100 text-yellow-600 cursor-default' :
                                        'bg-red-600 text-white hover:bg-red-700'
                                    }`}
                                >
                                    {loading ? (
                                        <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                                    ) : status === 'verified' ? (
                                        <>
                                            <span className="material-symbols-outlined">check_circle</span>
                                            Verified Successfully
                                        </>
                                    ) : status === 'pending' ? (
                                        <>
                                            <span className="material-symbols-outlined">hourglass_top</span>
                                            Under Review
                                        </>
                                    ) : (
                                        <>
                                            Submit for Verification
                                            <span className="material-symbols-outlined text-sm">arrow_forward</span>
                                        </>
                                    )}
                                </button>
                            </div>
                        </form>

                        <div className="mt-10 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                           <h4 className="flex items-center gap-2 text-sm font-bold text-gray-700 mb-2">
                               <span className="material-symbols-outlined text-sm">security</span>
                               Privacy Policy for KYC
                           </h4>
                           <p className="text-[10px] text-gray-500 leading-relaxed">
                               Your identity documents are encrypted and stored securely. We only use this information to verify your identity as per Indian tax laws (Rule 194B/194BA). We will never share your private data with third parties.
                           </p>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default KYCPage;
