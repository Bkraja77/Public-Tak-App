import React, { useState, useEffect, useMemo } from 'react';
import Header from '../components/Header';
import UserAvatar from '../components/UserAvatar';
import { db } from '../firebaseConfig';
import { Post, User, View } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { motion, AnimatePresence } from 'motion/react';

interface SearchPageProps {
    onNavigate: (view: View, params?: any) => void;
    onViewPost: (postId: string) => void;
    currentUser: User | null;
    onViewUser: (userId: string) => void;
    searchType?: 'all' | 'video';
}

const SkeletonItem = () => (
    <div className="glass-card flex items-center gap-4 p-4 animate-pulse">
        <div className="w-20 h-20 bg-gray-200 rounded-xl shrink-0"></div>
        <div className="flex-1 space-y-3">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-3 bg-gray-200 rounded w-1/4"></div>
        </div>
    </div>
);

const SearchPage: React.FC<SearchPageProps> = ({ onNavigate, onViewPost, currentUser, onViewUser, searchType = 'all' }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [allPosts, setAllPosts] = useState<Post[]>([]);
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { t } = useLanguage();

    useEffect(() => {
        setLoading(true);
        setError(null);

        const handleFirestoreError = (err: any) => {
            console.error("Error fetching data:", err);
            setError(t('error'));
            setLoading(false);
        };
        
        const postsQuery = db.collection(searchType === 'video' ? 'videos' : 'posts');
        const unsubscribePosts = postsQuery.onSnapshot((snapshot) => {
            const fetchedPosts = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title,
                    content: searchType === 'video' ? (data.description || '') : (data.content || ''),
                    thumbnailUrl: data.thumbnailUrl,
                    authorId: data.authorId,
                    authorName: data.authorName,
                    authorProfilePicUrl: data.authorProfilePicUrl,
                    viewCount: data.viewCount || 0,
                    shareCount: data.shareCount || 0,
                    category: data.category || 'General',
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
                    locationType: data.locationType || 'Overall',
                    state: data.state || '',
                    district: data.district || '',
                    block: data.block || '',
                } as Post;
            });
            setAllPosts(fetchedPosts);
            setLoading(false);
        }, handleFirestoreError);

        const usersQuery = db.collection("users");
        const unsubscribeUsers = usersQuery.onSnapshot((snapshot) => {
            const fetchedUsers = snapshot.docs.map(doc => ({
                uid: doc.id,
                ...doc.data(),
            } as User));
            setAllUsers(fetchedUsers);
            setLoading(false);
        }, handleFirestoreError);

        return () => {
            unsubscribePosts();
            unsubscribeUsers();
        };
    }, [t, searchType]);

    const searchResults = useMemo(() => {
        if (!searchTerm.trim()) {
            return { filteredPosts: [], filteredUsers: [] };
        }

        const lowercasedTerm = searchTerm.toLowerCase();

        const filteredPosts = allPosts.filter(post =>
            (post?.title?.toLowerCase() ?? '').includes(lowercasedTerm) ||
            (post?.content?.toLowerCase() ?? '').includes(lowercasedTerm)
        );

        const filteredUsers = allUsers.filter(user =>
            (user?.name?.toLowerCase() ?? '').includes(lowercasedTerm) ||
            (user?.username?.toLowerCase() ?? '').includes(lowercasedTerm)
        );

        return { filteredPosts, filteredUsers };
    }, [searchTerm, allPosts, allUsers]);


    const renderContent = () => {
        if (loading && searchTerm.trim()) {
            return (
                <div className="space-y-4">
                    {[1, 2, 3, 4].map(i => <SkeletonItem key={i} />)}
                </div>
            );
        }
        
        if (error) {
            return (
                <div className="p-8 text-center bg-red-50 text-red-600 rounded-3xl border border-red-100">
                    <span className="material-symbols-outlined text-4xl mb-2">error</span>
                    <p className="font-bold">{error}</p>
                </div>
            );
        }

        if (!searchTerm.trim()) {
            return (
                <div className="flex flex-col items-center justify-center py-20 text-gray-300">
                    <motion.div
                        animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
                        transition={{ duration: 3, repeat: Infinity }}
                        className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mb-6"
                    >
                        <span className="material-symbols-outlined text-6xl">search</span>
                    </motion.div>
                    <h3 className="text-xl font-black text-gray-400">Looking for something?</h3>
                    <p className="text-sm font-medium mt-2">Search for news posts or creators</p>
                </div>
            );
        }

        const { filteredPosts, filteredUsers } = searchResults;
        const hasResults = filteredPosts.length > 0 || filteredUsers.length > 0;

        if (!hasResults) {
            return (
                <div className="flex flex-col items-center justify-center py-20 text-gray-300">
                    <div className="w-32 h-32 bg-gray-100 rounded-full flex items-center justify-center mb-6">
                        <span className="material-symbols-outlined text-6xl opacity-50">search_off</span>
                    </div>
                    <h3 className="text-xl font-black text-gray-400">No results found</h3>
                    <p className="text-sm font-medium mt-2">Try searching for something else</p>
                </div>
            );
        }

        return (
            <div className="space-y-8 pb-10">
                <AnimatePresence mode="popLayout">
                    {filteredUsers.length > 0 && (
                        <motion.section 
                            key="users"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="space-y-4"
                        >
                            <div className="flex items-center justify-between px-2">
                                <h2 className="text-lg font-black text-gray-900 uppercase tracking-widest">{t('users')}</h2>
                                <span className="text-xs font-bold text-gray-400">{filteredUsers.length} found</span>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                {filteredUsers.map(user => (
                                    <motion.div 
                                        key={user.uid} 
                                        layout
                                        onClick={() => onViewUser(user.uid)} 
                                        className="glass-card flex items-center gap-4 p-4 cursor-pointer hover:border-red-200 hover:bg-red-50/30 transition-all active:scale-[0.98]"
                                    >
                                        <UserAvatar 
                                            userId={user.uid}
                                            src={user.profilePicUrl}
                                            name={user.name}
                                            currentUser={currentUser}
                                            className="w-14 h-14 rounded-2xl object-cover shadow-sm bg-white border border-gray-100" 
                                        />
                                        <div className="min-w-0">
                                            <h3 className="font-black text-gray-900 truncate leading-tight">{user.name}</h3>
                                            <p className="text-xs font-bold text-red-600">@{user.username}</p>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </motion.section>
                    )}

                    {filteredPosts.length > 0 && (
                        <motion.section 
                            key="posts"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.1 }}
                            className="space-y-4"
                        >
                            <div className="flex items-center justify-between px-2">
                                <h2 className="text-lg font-black text-gray-900 uppercase tracking-widest">{t('post')}</h2>
                                <span className="text-xs font-bold text-gray-400">{filteredPosts.length} found</span>
                            </div>
                            <div className="space-y-4">
                                {filteredPosts.map(post => (
                                    <motion.div 
                                        key={post.id} 
                                        layout
                                        onClick={() => {
                                            if (searchType === 'video') {
                                                onNavigate(View.VideoHome, { videoId: post.id });
                                            } else {
                                                onViewPost(post.id);
                                            }
                                        }} 
                                        className="glass-card flex gap-4 p-4 cursor-pointer hover:border-red-200 hover:bg-red-50/30 transition-all active:scale-[0.99]"
                                    >
                                        {post.thumbnailUrl && (
                                            <img 
                                                src={post.thumbnailUrl} 
                                                alt={post.title} 
                                                className="w-24 h-24 object-cover rounded-2xl shrink-0 shadow-sm border border-gray-50" 
                                            />
                                        )}
                                        <div className="flex-1 min-w-0 flex flex-col justify-center">
                                            <h3 className="font-bold text-gray-900 line-clamp-2 leading-tight mb-2 group-hover:text-red-600 transition-colors">
                                                {post.title}
                                            </h3>
                                            <div className="flex items-center gap-2 mt-auto">
                                                <div className="w-5 h-5 rounded-full bg-gray-100 shrink-0 overflow-hidden">
                                                    <UserAvatar 
                                                        userId={post.authorId}
                                                        src={post.authorProfilePicUrl}
                                                        name={post.authorName}
                                                        currentUser={currentUser}
                                                        className="w-full h-full rounded-full object-cover" 
                                                    />
                                                </div>
                                                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest truncate">{post.authorName}</p>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                            </div>
                        </motion.section>
                    )}
                </AnimatePresence>
            </div>
        );
    };

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header 
                title={searchType === 'video' ? 'वीडियो खोजें' : t('search')} 
                showBackButton 
                onBack={() => onNavigate(searchType === 'video' ? View.VideoHome : View.Main)} 
                currentUser={currentUser}
                onProfileClick={() => onNavigate(View.User)}
                onLogin={() => onNavigate(View.Login)}
            />
            <main className="flex-grow flex flex-col overflow-hidden">
                <div className="p-4 bg-white border-b border-gray-100 md:px-8">
                    <div className="max-w-4xl mx-auto relative group">
                         <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors">search</span>
                         <input
                            autoFocus
                            type="text"
                            placeholder={t('searchPlaceholder')}
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full py-4 pl-12 pr-4 bg-gray-50 border border-gray-200 rounded-2xl text-gray-900 font-bold focus:bg-white focus:ring-4 focus:ring-red-500/10 focus:border-red-200 transition-all outline-none"
                        />
                        {searchTerm && (
                            <button 
                                onClick={() => setSearchTerm('')}
                                className="absolute right-4 top-1/2 -translate-y-1/2 w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"
                            >
                                <span className="material-symbols-outlined text-sm">close</span>
                            </button>
                        )}
                    </div>
                </div>
                
                <div className="flex-grow overflow-y-auto p-4 md:p-8">
                    <div className="max-w-4xl mx-auto">
                        {renderContent()}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default SearchPage;
