
import React, { useState, useEffect } from 'react';
import { auth, db, firebase, serverTimestamp } from '../firebaseConfig';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { APP_LOGO_URL } from '../utils/constants';

interface LoginPageProps {
  onBack: () => void;
  onLoginSuccess: () => void;
}

type AuthMode = 'login' | 'signup';

const PasswordRequirement: React.FC<{ isValid: boolean; text: string }> = ({ isValid, text }) => (
    <div className={`flex items-center text-xs transition-colors ${isValid ? 'text-green-600' : 'text-gray-400'}`}>
        <span className="material-symbols-outlined mr-1 text-sm">
            {isValid ? 'check_circle' : 'circle'}
        </span>
        {text}
    </div>
);

const LoginPage: React.FC<LoginPageProps> = ({ onBack, onLoginSuccess }) => {
    const [authMode, setAuthMode] = useState<AuthMode>('login');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [showVerificationMessage, setShowVerificationMessage] = useState(false);
    const [showResetMessage, setShowResetMessage] = useState(false);
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [isConfirmPasswordVisible, setIsConfirmPasswordVisible] = useState(false);
    const [isGoogleLoading, setIsGoogleLoading] = useState(false);
    const [unauthorizedDomainInfo, setUnauthorizedDomainInfo] = useState<string | null>(null);
    const { t } = useLanguage();
    const { showToast } = useToast();

    const [passwordCriteria, setPasswordCriteria] = useState({
        length: false,
        uppercase: false,
        lowercase: false,
        number: false,
        specialChar: false,
    });
    
    const [referrerName, setReferrerName] = useState<string | null>(null);
    const [referralCode, setReferralCode] = useState<string | null>(null);

    useEffect(() => {
        const storedRef = localStorage.getItem('referralCode');
        if (storedRef) {
            setReferralCode(storedRef);
            // Optional: Fetch referrer name
            db.collection('users').where('referralCode', '==', storedRef).get()
                .then(snap => {
                    if (!snap.empty) {
                        setReferrerName(snap.docs[0].data().name);
                    }
                });
        }
    }, []);

    // Clear fields when switching modes
    useEffect(() => {
        setEmail('');
        setPassword('');
        setName('');
        setConfirmPassword('');
        setError(null);
    }, [authMode]);

    useEffect(() => {
        setPasswordCriteria({
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /[0-9]/.test(password),
            specialChar: /[\W_]/.test(password),
        });
    }, [password]);

    // Listen for Google Redirect Sign-In results on mount
    useEffect(() => {
        let isSubscribed = true;
        auth.getRedirectResult().then((result) => {
            if (!isSubscribed) return;
            if (result && result.user) {
                showToast("Google से लॉगिन सफल!", "success");
                onLoginSuccess();
            }
        }).catch((error: any) => {
            if (!isSubscribed) return;
            console.error("Google redirect sign-in error:", error);
            if (error.code === 'auth/unauthorized-domain') {
                const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'publictak.app';
                setUnauthorizedDomainInfo(currentHost);
                setError(`यह डोमेन (${currentHost}) Firebase Authentication में Authorized नहीं है।`);
            } else if (error.code && error.code !== 'auth/popup-closed-by-user') {
                setError(error.message || "Google लॉगिन विफल रहा");
            }
        });

        return () => {
            isSubscribed = false;
        };
    }, [onLoginSuccess, showToast]);

    const isMobileOrRestricted = () => {
        if (typeof window === 'undefined') return false;
        const ua = navigator.userAgent || '';
        const isMobile = /Android|iPhone|iPad|iPod/i.test(ua);
        const isPWA = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
        const isInApp = /FBAN|FBAV|Instagram|WhatsApp|wv|Line/i.test(ua);
        return isMobile || isPWA || isInApp;
    };

    const handleGoogleLogin = async (forceRedirect: boolean = false) => {
        setIsGoogleLoading(true);
        setError(null);
        setUnauthorizedDomainInfo(null);

        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({
            prompt: 'select_account'
        });

        try {
            if (forceRedirect) {
                showToast("Google पर रीडायरेक्ट किया जा रहा है...", "info");
                await auth.signInWithRedirect(provider);
                return;
            }

            // On mobile or in-app webviews, popups are frequently blocked or disconnected.
            // Try popup, and automatically fall back to redirect if popup fails or is blocked.
            try {
                await auth.signInWithPopup(provider);
                showToast("Google से लॉगिन सफल!", "success");
            } catch (popupErr: any) {
                console.warn("Popup attempt failed, checking fallback:", popupErr);
                if (
                    popupErr.code === 'auth/popup-blocked' ||
                    popupErr.code === 'auth/cancelled-popup-request' ||
                    (popupErr.code === 'auth/popup-closed-by-user' && isMobileOrRestricted())
                ) {
                    showToast("पॉपअप अवरुद्ध है, सुरक्षित रीडायरेक्ट शुरू हो रहा है...", "info");
                    await auth.signInWithRedirect(provider);
                    return;
                }
                throw popupErr;
            }
        } catch (error: any) {
            console.error("Google login error:", error);
            
            let msg = "Google Login failed";
            if (error.code === 'auth/popup-closed-by-user') {
                msg = "लॉगिन विंडो बंद कर दी गई। आप पुनः प्रयास कर सकते हैं।";
            } else if (error.code === 'auth/popup-blocked') {
                msg = "ब्राउज़र ने पॉपअप रोक दिया है। कृपया नीचे दिए गए रीडायरेक्ट विकल्प से लॉगिन करें।";
            } else if (error.code === 'auth/unauthorized-domain') {
                const currentHost = typeof window !== 'undefined' ? window.location.hostname : 'publictak.app';
                setUnauthorizedDomainInfo(currentHost);
                msg = `यह डोमेन (${currentHost}) Firebase में Authorized नहीं है।`;
            } else if (error.message) {
                msg = error.message;
            }
            
            setError(msg);
            showToast(msg, "error");
        } finally {
            setIsGoogleLoading(false);
        }
    };

    const handlePasswordReset = async () => {
        setError(null);
        setShowResetMessage(false);
        if (!email.trim()) {
            setError('Please enter your email address to reset your password.');
            showToast("Please enter your email", "info");
            return;
        }
        setIsLoading(true);
        try {
            await auth.sendPasswordResetEmail(email);
            setShowResetMessage(true);
            showToast("Password reset email sent", "success");
        } catch (error: any) {
            if (error.code === 'auth/user-not-found') {
                setShowResetMessage(true); // Security: don't reveal if user exists
                showToast("If account exists, email sent", "info");
            } else {
                setError(error.message);
                showToast(error.message, "error");
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setShowResetMessage(false);
        setIsLoading(true);

        if (authMode === 'signup' && !name.trim()) {
            setError('Please enter your full name.');
            setIsLoading(false);
            return;
        }
        if (!email.trim()) {
            setError('Please enter your email address.');
            setIsLoading(false);
            return;
        }
        if (!password) {
            setError('Please enter your password.');
            setIsLoading(false);
            return;
        }

        if (authMode === 'signup') {
            const allCriteriaMet = Object.values(passwordCriteria).every(Boolean);
            if (!allCriteriaMet) {
                setError('Password does not meet all the requirements.');
                setIsLoading(false);
                return;
            }
            if (password !== confirmPassword) {
                setError('Passwords do not match.');
                setIsLoading(false);
                return;
            }
            try {
                const userCredential = await auth.createUserWithEmailAndPassword(email, password);
                const user = userCredential.user;
                if (!user) throw new Error("Could not create user account.");
                
                // Generate username from Name
                const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, '');
                const randomSuffix = Math.floor(1000 + Math.random() * 9000);
                const username = `${cleanName}${randomSuffix}`;

                const profilePicUrl = `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(email)}`;
                await user.updateProfile({
                    displayName: name,
                    photoURL: profilePicUrl,
                });

                showToast("Verification email sent!", "success");

                setShowVerificationMessage(true);
                await auth.signOut();

            } catch (error: any) {
                if (error.code === 'auth/email-already-in-use') {
                    setError('This email address is already in use by another account. Please log in or use a different email.');
                    showToast("Email already in use", "error");
                } else {
                    setError(error.message);
                    showToast(error.message, "error");
                }
            } finally {
                setIsLoading(false);
            }
        } else { // Login mode
            try {
                const userCredential = await auth.signInWithEmailAndPassword(email, password);
                const user = userCredential.user;

                if (user && !user.emailVerified) {
                    setError('Please verify your email address. Check your inbox for a verification link.');
                    showToast("Email not verified", "error");
                    await auth.signOut();
                    setIsLoading(false);
                    return;
                }

                const adminEmails = ['bikash512singh@gmail.com', 'publictakapp@gmail.com'];
                if (user && user.email && adminEmails.includes(user.email)) {
                    const userDocRef = db.collection("users").doc(user.uid);
                    await userDocRef.set({ role: 'admin' }, { merge: true });
                    await db.collection("admins").doc(user.uid).set({ 
                        uid: user.uid, 
                        email: user.email, 
                        role: 'admin',
                        name: user.displayName || user.email.split('@')[0]
                    }, { merge: true });
                }

                showToast("Welcome back!", "success");
                
                // Do NOT call onLoginSuccess() here.
                // We let the central auth listener in App.tsx handle the navigation when the user state updates.
            } catch (error: any) {
                if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
                     setError('Incorrect email or password. Please try again.');
                     showToast("Invalid credentials", "error");
                } else {
                     setError(error.message);
                     showToast(error.message, "error");
                }
                setIsLoading(false); // Only stop loading if there was an error
            } 
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-50">
            {/* Top Red Header Strip */}
            <div className="w-full h-14 bg-red-600 flex items-center justify-between px-4 shadow-md shrink-0 z-20">
                <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/10 text-white transition-colors">
                    <span className="material-symbols-outlined">arrow_back</span>
                </button>
                <h1 className="text-white font-bold text-lg tracking-wide">
                    {authMode === 'login' ? 'Login' : 'Sign Up'}
                </h1>
                <div className="w-10"></div> {/* Spacer for centering */}
            </div>
            
            {/* Scrollable Main Content */}
            <main className="flex-grow overflow-y-auto scrollbar-thin md:scrollbar-default">
                <div className="flex items-center justify-center min-h-full p-4 md:p-8">
                    <div className="bg-white w-full max-w-md rounded-3xl shadow-xl overflow-hidden relative animate-in fade-in zoom-in-95 duration-300 border border-gray-100">
                        
                        {/* Logo Section - Top of Card */}
                        <div className="flex justify-center pt-8 pb-4">
                            <div className="bg-white p-2 rounded-full">
                                <img 
                                    src={APP_LOGO_URL}
                                    alt="Public Tak App Logo" 
                                    className="w-20 h-20 object-contain drop-shadow-md hover:scale-105 transition-transform"
                                />
                            </div>
                        </div>

                        {/* Referral Banner */}
                        {referralCode && !showVerificationMessage && (
                            <div className="bg-gradient-to-r from-red-50 to-orange-50 border-b border-orange-100 px-8 py-4 flex items-center gap-4">
                                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-red-600 shrink-0 border border-orange-100">
                                    <span className="material-symbols-outlined text-3xl">redeem</span>
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-red-600 uppercase tracking-widest leading-none mb-1">Gift Unlocked</p>
                                    <p className="text-xs text-gray-700 font-bold leading-tight">
                                        {referrerName ? `You've been invited by ${referrerName}` : `You've been invited by a friend`} to join Public Tak App.
                                    </p>
                                </div>
                            </div>
                        )}

                        <div className="px-8 pb-8">
                            {showVerificationMessage ? (
                                <div className="text-center">
                                    <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                        <span className="material-symbols-outlined text-4xl text-green-600">mark_email_read</span>
                                    </div>
                                    <h2 className="text-2xl font-bold text-gray-800 mb-2">Check Your Email</h2>
                                    <p className="text-gray-500 mb-8 leading-relaxed">
                                        We've sent a verification link to <strong>{email}</strong>. Please verify your account to continue.
                                    </p>
                                    <button
                                        onClick={() => { setShowVerificationMessage(false); setAuthMode('login'); }}
                                        className="w-full py-3 bg-red-600 text-white font-bold rounded-xl shadow-lg hover:bg-red-700 transition-all"
                                    >
                                        Back to Login
                                    </button>
                                </div>
                            ) : (
                                <>
                                    <div className="text-center mb-8">
                                        <h2 className="text-2xl font-bold text-gray-800">
                                            {authMode === 'login' ? t('welcome') : t('createAccount')}
                                        </h2>
                                        <p className="text-gray-500 text-sm mt-1">
                                            {authMode === 'login' ? 'Please sign in to continue' : 'Join Public Tak App for local updates'}
                                        </p>
                                    </div>

                                    <form onSubmit={handleSubmit} className="space-y-5">
                                        {error && (
                                            <div className="bg-red-50 border-l-4 border-red-500 p-3 rounded text-xs text-red-700 font-medium">
                                                {error}
                                            </div>
                                        )}
                                        
                                        {showResetMessage && (
                                            <div className="bg-green-50 border-l-4 border-green-500 p-3 rounded text-xs text-green-700 font-medium">
                                                Password reset email sent. Check your inbox.
                                            </div>
                                        )}

                                        {authMode === 'signup' && (
                                            <div className="relative group">
                                                <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors">person</span>
                                                <input
                                                    type="text"
                                                    id="name"
                                                    value={name}
                                                    onChange={e => setName(e.target.value)}
                                                    required
                                                    placeholder={t('fullName')}
                                                    autoComplete="name"
                                                    className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white transition-all text-gray-800 text-sm font-medium placeholder:text-gray-400"
                                                />
                                            </div>
                                        )}

                                        <div className="relative group">
                                            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors">email</span>
                                            <input
                                                type="email"
                                                id="email"
                                                value={email}
                                                onChange={e => setEmail(e.target.value)}
                                                required
                                                placeholder={t('email')}
                                                autoComplete="email"
                                                className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white transition-all text-gray-800 text-sm font-medium placeholder:text-gray-400"
                                            />
                                        </div>

                                        <div className="relative group">
                                            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors">lock</span>
                                            <input
                                                type={isPasswordVisible ? 'text' : 'password'}
                                                id="password"
                                                value={password}
                                                onChange={e => setPassword(e.target.value)}
                                                required
                                                placeholder={t('password')}
                                                autoComplete={authMode === 'login' ? 'current-password' : 'new-password'}
                                                className="w-full pl-10 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white transition-all text-gray-800 text-sm font-medium placeholder:text-gray-400"
                                            />
                                            <button type="button" onClick={() => setIsPasswordVisible(!isPasswordVisible)} className="absolute inset-y-0 right-0 px-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors">
                                                <span className="material-symbols-outlined text-lg">
                                                    {isPasswordVisible ? 'visibility_off' : 'visibility'}
                                                </span>
                                            </button>
                                        </div>

                                        {authMode === 'signup' && (
                                            <>
                                                <div className="relative group">
                                                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors">lock_reset</span>
                                                    <input
                                                        type={isConfirmPasswordVisible ? 'text' : 'password'}
                                                        id="confirm-password"
                                                        value={confirmPassword}
                                                        onChange={e => setConfirmPassword(e.target.value)}
                                                        required
                                                        placeholder={t('confirmPassword')}
                                                        autoComplete="new-password"
                                                        className="w-full pl-10 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white transition-all text-gray-800 text-sm font-medium placeholder:text-gray-400"
                                                    />
                                                    <button type="button" onClick={() => setIsConfirmPasswordVisible(!isConfirmPasswordVisible)} className="absolute inset-y-0 right-0 px-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors">
                                                        <span className="material-symbols-outlined text-lg">
                                                            {isConfirmPasswordVisible ? 'visibility_off' : 'visibility'}
                                                        </span>
                                                    </button>
                                                </div>
                                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-2 gap-y-1 pl-1">
                                                    <PasswordRequirement isValid={passwordCriteria.length} text="8+ chars" />
                                                    <PasswordRequirement isValid={passwordCriteria.uppercase} text="Uppercase" />
                                                    <PasswordRequirement isValid={passwordCriteria.lowercase} text="Lowercase" />
                                                    <PasswordRequirement isValid={passwordCriteria.number} text="Number" />
                                                    <PasswordRequirement isValid={passwordCriteria.specialChar} text="Special char" />
                                                </div>
                                            </>
                                        )}

                                        {authMode === 'login' && (
                                            <div className="flex justify-end -mt-2">
                                                <button
                                                    type="button"
                                                    onClick={handlePasswordReset}
                                                    disabled={isLoading}
                                                    className="text-xs font-semibold text-red-600 hover:text-red-700 transition-colors"
                                                >
                                                    {t('forgotPassword')}
                                                </button>
                                            </div>
                                        )}

                                        <button 
                                            type="submit" 
                                            disabled={isLoading}
                                            className="w-full py-3.5 bg-gradient-to-r from-red-600 to-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-200 hover:shadow-xl hover:scale-[1.02] active:scale-95 transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed text-sm uppercase tracking-wide"
                                        >
                                            {isLoading ? (
                                                <span className="flex items-center justify-center gap-2">
                                                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                                    {t('loading')}
                                                </span>
                                            ) : (
                                                authMode === 'login' ? t('login') : t('signup')
                                            )}
                                        </button>
                                    </form>

                                    <div className="relative my-8">
                                        <div className="absolute inset-0 flex items-center">
                                            <div className="w-full border-t border-gray-200"></div>
                                        </div>
                                        <div className="relative flex justify-center text-sm">
                                            <span className="px-3 bg-white text-gray-400 font-medium">OR</span>
                                        </div>
                                    </div>

                                    <div className="space-y-3">
                                        <button 
                                            type="button"
                                            onClick={() => handleGoogleLogin(false)} 
                                            disabled={isGoogleLoading || isLoading}
                                            className="w-full flex items-center justify-center gap-3 py-3.5 border border-gray-200 rounded-xl hover:bg-gray-50 active:scale-[0.98] transition-all duration-150 disabled:opacity-60 disabled:cursor-not-allowed shadow-sm bg-white"
                                        >
                                            {isGoogleLoading ? (
                                                <span className="flex items-center justify-center gap-2.5 text-sm font-semibold text-gray-700">
                                                    <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                                                    Google से कनेक्ट हो रहे हैं...
                                                </span>
                                            ) : (
                                                <>
                                                    <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5" alt="Google" />
                                                    <span className="font-semibold text-gray-700 group-hover:text-gray-900 text-sm">{t('continueWithGoogle')}</span>
                                                </>
                                            )}
                                        </button>

                                        {unauthorizedDomainInfo && (
                                            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-left space-y-2 text-xs text-amber-900 animate-in fade-in duration-200">
                                                <div className="flex items-center gap-2 font-bold text-amber-950">
                                                    <span className="material-symbols-outlined text-base text-amber-600">admin_panel_settings</span>
                                                    <span>Firebase Authorized Domain सेटअप:</span>
                                                </div>
                                                <p className="text-gray-600 leading-relaxed">
                                                    Google Login को सुचारू बनाने के लिए अपने <strong>Firebase Console</strong> में यह डोमेन Authorized करें:
                                                </p>
                                                <div className="bg-white p-2.5 rounded-lg border border-amber-200 font-mono text-[11px] text-gray-800 break-all select-all flex items-center justify-between gap-2">
                                                    <span>https://publictak.app/__/auth/handler</span>
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            navigator.clipboard.writeText("https://publictak.app/__/auth/handler");
                                                            showToast("Redirect URI कॉपीड!", "success");
                                                        }}
                                                        className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded font-sans font-semibold text-[10px] shrink-0"
                                                    >
                                                        Copy
                                                    </button>
                                                </div>
                                                <div className="text-[11px] text-gray-500 pt-1">
                                                    <strong>चरण:</strong> Firebase Console &rarr; Authentication &rarr; Settings &rarr; Authorized Domains &rarr; Add <code>{unauthorizedDomainInfo}</code>
                                                </div>
                                                <button
                                                    type="button"
                                                    onClick={() => handleGoogleLogin(true)}
                                                    className="w-full mt-2 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1.5"
                                                >
                                                    <span className="material-symbols-outlined text-sm">open_in_browser</span>
                                                    रीडायरेक्ट से लॉगिन करें (Redirect Mode)
                                                </button>
                                            </div>
                                        )}
                                    </div>

                                    <div className="mt-8 text-center">
                                        <p className="text-gray-600 text-sm">
                                            {authMode === 'login' ? t('dontHaveAccount') : t('alreadyHaveAccount')}
                                            <button 
                                                onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setError(null); }} 
                                                className="ml-2 font-bold text-red-600 hover:text-red-700 hover:underline transition-colors"
                                            >
                                                {authMode === 'login' ? t('signup') : t('login')}
                                            </button>
                                        </p>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default LoginPage;