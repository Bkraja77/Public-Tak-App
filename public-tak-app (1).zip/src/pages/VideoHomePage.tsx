import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { View, User, Video, Comment } from '../types';
import { db, serverTimestamp, increment } from '../firebaseConfig';
import { subscribeCategories } from '../utils/categories';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import Header from '../components/Header';
import { indianLocations } from '../utils/locations';
import SEO from '../components/SEO';
import Categories, { CategoryItem } from '../components/Categories';
import LocationFilter from '../components/LocationFilter';
import { APP_LOGO_URL } from '../utils/constants';
import VideoCard from '../components/VideoCard';
import ReelItem from '../components/ReelItem';
import VideoCommentItem from '../components/VideoCommentItem';
import ReportModal from '../components/ReportModal';
import SuggestedUsers from '../components/SuggestedUsers';
import SuggestedReels from '../components/SuggestedReels';
import UserAvatar from '../components/UserAvatar';
import { shareVideo, hasUserSharedLocally } from '../utils/shareUtils';
import { appCacheService } from '../services/appCacheService';

interface VideoHomePageProps {
  onNavigate: (view: View, params?: any) => void;
  currentUser: User | null;
  onLogin: () => void;
  onLogout: () => void;
  onViewUser: (userId: string) => void;
  selectedVideoId?: string | null;
  onClearSelectedVideo?: () => void;
}

const videoCategoriesFallback = ['Recent Video', 'Politics', 'Crime', 'Sports', 'Entertainment', 'Business', 'Technology', 'Health', 'Education', 'Jobs', 'World', 'General'];

const SAMPLE_VIDEOS = [
  {
    title: "डिजिटल पत्रकारिता का बढ़ता दौर - ग्रामीण भारत में मोबाइल से रिपोर्टिंग",
    description: "ग्रामीण पत्रकार अब सीधे मोबाइल फोन के जरिए गांव-गांव की खबरें बिना किसी बड़े कैमरे या स्टूडियो के देश-विदेश तक पहुंचा रहे हैं।",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-news-anchor-reporting-with-screen-in-background-34354-large.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1495020689067-958852a6565d?auto=format&fit=crop&q=80&w=600",
    category: "Technology",
    authorId: "system_reporter",
    authorName: "विकास सिंह (Public Reporter)",
    authorProfilePicUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150",
    authorIsVerified: true,
    locationType: "Overall",
    viewCount: 1240,
    likeCount: 485,
    commentCount: 42,
    shareCount: 189
  },
  {
    title: "स्थानीय चुनावों में जनता की राय: ग्राउंड जीरो से विशेष रिपोर्ट",
    description: "इस चुनावी मौसम में जनता क्या सोचती है? देखिए हमारे विशेष ग्राउंड कवरेज में सीधे मतदाताओं की जुबानी।",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-blogging-with-a-smartphone-at-home-40348-large.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1540910419892-4a36d2c3266c?auto=format&fit=crop&q=80&w=600",
    category: "Politics",
    authorId: "system_politics",
    authorName: "साक्षी शर्मा",
    authorProfilePicUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
    authorIsVerified: true,
    locationType: "State",
    state: "Bihar",
    viewCount: 3852,
    likeCount: 1420,
    commentCount: 98,
    shareCount: 412
  },
  {
    title: "खेल जगत की बड़ी खबरें: राष्ट्रीय खेलों के लिए खिलाड़ियों की तैयारी",
    description: "भारत के कोने-कोने से आए युवा एथलीट इस साल होने वाले राष्ट्रीय खेलों के लिए जमकर पसीना बहा रहे हैं।",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-man-using-a-smartphone-close-up-40341-large.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&q=80&w=600",
    category: "Sports",
    authorId: "system_sports",
    authorName: "अमित कुमार",
    authorProfilePicUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
    authorIsVerified: false,
    locationType: "Overall",
    viewCount: 941,
    likeCount: 320,
    commentCount: 15,
    shareCount: 64
  }
];

const VideoHomePage: React.FC<VideoHomePageProps> = ({ 
  onNavigate, 
  currentUser, 
  onLogin, 
  onLogout, 
  onViewUser,
  selectedVideoId,
  onClearSelectedVideo
}) => {
  const cachedVideos = appCacheService.getFeedVideos();
  const [videos, setVideos] = useState<Video[]>(() => cachedVideos);
  const [loading, setLoading] = useState(() => cachedVideos.length === 0);
  const [videoCategories, setVideoCategories] = useState<string[]>(videoCategoriesFallback);

  useEffect(() => {
    const unsubscribe = subscribeCategories((data) => {
      const cats = data.videoCategories;
      const updated = cats.includes('Recent Video') ? cats : ['Recent Video', ...cats];
      setVideoCategories(updated);
    });
    return unsubscribe;
  }, []);



  const [selectedCategory, setSelectedCategory] = useState('Recent Video');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSearchTab, setActiveSearchTab] = useState<'videos' | 'creators'>('videos');
  const [searchedCreators, setSearchedCreators] = useState<User[]>([]);
  const [isSeeding, setIsSeeding] = useState(false);

  // Location filter states
  const [selectedState, setSelectedState] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedBlock, setSelectedBlock] = useState('');
  const [initialLocationSet, setInitialLocationSet] = useState(false);

  // Reels Immersive Player State
  const [reelsActive, setReelsActive] = useState(false);
  const [currentReelIndex, setCurrentReelIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [followedAuthors, setFollowedAuthors] = useState<string[]>(() => currentUser ? appCacheService.getFollowingList(currentUser.uid) : []);
  const [reelLikes, setReelLikes] = useState<{ [videoId: string]: boolean }>({});
  const [reelLikeCounts, setReelLikeCounts] = useState<{ [videoId: string]: number }>({});
  const [reportingVideo, setReportingVideo] = useState<Video | null>(null);

  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const { t } = useLanguage();
  const { showToast } = useToast();

  const states = Object.keys(indianLocations);
  const districts = selectedState ? Object.keys(indianLocations[selectedState] || {}) : [];
  const blocks = selectedState && selectedDistrict ? (indianLocations[selectedState] || {})[selectedDistrict] || [] : [];

  const NEAR_ME = 'Near Me';

  // Determine User's Locality Label for Display
  const userLocationLabel = useMemo(() => {
    if (!currentUser) return '';
    return currentUser.preferredBlock || currentUser.preferredDistrict || currentUser.preferredState || '';
  }, [currentUser]);

  // Construct Display Categories
  const displayCategories = useMemo(() => {
    const items: CategoryItem[] = [];
    
    // 1. Static Near Me Category
    items.push({
      id: NEAR_ME,
      label: t('nearMe') || 'Near Me',
      icon: 'my_location'
    });

    // 2. Standard Categories
    videoCategories.forEach(cat => {
      items.push({
        id: cat,
        label: t(cat.toLowerCase()) || cat,
        icon: cat === 'Recent Video' ? 'local_fire_department' : undefined
      });
    });

    return items;
  }, [t]);

  const handleStateSelect = (state: string) => {
    if (!currentUser) {
      onLogin();
      return;
    }
    setSelectedState(state);
    setSelectedDistrict('');
    setSelectedBlock('');
  };

  const handleDistrictSelect = (district: string) => {
    if (!currentUser) {
      onLogin();
      return;
    }
    setSelectedDistrict(district);
    setSelectedBlock('');
  };

  const handleBlockSelect = (block: string) => {
    if (!currentUser) {
      onLogin();
      return;
    }
    setSelectedBlock(block);
  };

  const handleLocationReset = () => {
    setSelectedState('');
    setSelectedDistrict('');
    setSelectedBlock('');
  };

  const handleCategorySelect = (category: string) => {
    // Special logic for "Near Me"
    if (category === NEAR_ME) {
      if (!currentUser) {
        onLogin();
        return;
      }
      // Check if user has set location
      if (!currentUser.preferredState && !currentUser.preferredDistrict) {
         showToast(t('pleaseSetLocation'), "info");
         onNavigate(View.EditProfile);
         return;
      }

      // Reset to user's preferences
      setSelectedState(currentUser.preferredState || '');
      setSelectedDistrict(currentUser.preferredDistrict || '');
      setSelectedBlock(currentUser.preferredBlock || '');
      
      setSelectedCategory(category);
      setSearchQuery('');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Restrict access for non-logged-in users for categories other than 'Recent Video'
    if (category !== 'Recent Video' && !currentUser) {
      onLogin();
      return;
    }

    setSelectedCategory(category);
    setSearchQuery('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    if (currentUser && !initialLocationSet && currentUser.preferredState) {
      setSelectedState(currentUser.preferredState);
      if (currentUser.preferredDistrict) {
        setSelectedDistrict(currentUser.preferredDistrict);
      }
      if (currentUser.preferredBlock) {
        setSelectedBlock(currentUser.preferredBlock);
      }
      setInitialLocationSet(true);
    } else if (!currentUser && initialLocationSet) {
      setInitialLocationSet(false);
      handleLocationReset();
    }
  }, [currentUser, initialLocationSet]);

  // Real-time listener for videos
  useEffect(() => {
    const unsubscribe = db.collection('videos')
      .orderBy('createdAt', 'desc')
      .limit(60)
      .onSnapshot((snapshot) => {
        const fetchedVideos = snapshot.docs
          .filter(doc => {
            const data = doc.data();
            // Exclude hidden/flagged videos unless current user is admin or author
            if (data.isHidden || data.flagged || data.status === 'flagged') {
              if (currentUser?.role === 'admin' || currentUser?.uid === data.authorId) {
                return true;
              }
              return false;
            }
            return true;
          })
          .map(doc => {
            const data = doc.data();
            return {
              id: doc.id,
              title: data.title || '',
              description: data.description || '',
              videoUrl: data.videoUrl || '',
              thumbnailUrl: data.thumbnailUrl || '',
              authorId: data.authorId || '',
              authorName: data.authorName || '',
              authorProfilePicUrl: data.authorProfilePicUrl || '',
              authorIsVerified: !!data.authorIsVerified,
              viewCount: data.viewCount || 0,
              likeCount: data.likeCount || 0,
              commentCount: data.commentCount || 0,
              shareCount: data.shareCount || 0,
              category: data.category || 'General',
              createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
              locationType: data.locationType || 'Overall',
              state: data.state || '',
              district: data.district || '',
              block: data.block || ''
            } as Video;
          }).filter(v => !v.authorId.startsWith('system_'));
        setVideos(fetchedVideos);
        appCacheService.setFeedVideos(fetchedVideos);
        setLoading(false);
      }, (err) => {
        console.error("Error fetching videos:", err);
        setLoading(false);
      });

    return () => unsubscribe();
  }, []);

  // Handle auto-opening of deep-linked or selected video (e.g. from notifications)
  useEffect(() => {
    if (!loading && selectedVideoId && videos.length > 0) {
      const selectedVid = videos.find(v => v.id === selectedVideoId);
      if (selectedVid) {
        // Reset category, location, and search filters so all videos are available in the queue for scrolling up and down
        setSelectedCategory('Recent Video');
        setSelectedState('');
        setSelectedDistrict('');
        setSelectedBlock('');
        setSearchQuery('');

        const timer = setTimeout(() => {
          const freshFiltered = filteredVideosRef.current;
          const indexInFiltered = freshFiltered.findIndex(v => v.id === selectedVideoId);
          if (indexInFiltered !== -1) {
            openReel(indexInFiltered);
          } else {
            const idxInAll = videos.findIndex(v => v.id === selectedVideoId);
            openReel(idxInAll !== -1 ? idxInAll : 0);
          }
        }, 120);

        return () => clearTimeout(timer);
      }
    }
  }, [loading, selectedVideoId, videos]);

  // Sync likes and following for current user
  useEffect(() => {
    if (!currentUser) {
      setReelLikes({});
      setFollowedAuthors([]);
      return;
    }

    const cached = appCacheService.getFollowingList(currentUser.uid);
    if (cached.length > 0) {
      setFollowedAuthors(cached);
    }

    // Sync following list
    const unsubscribeFollowing = db.collection('users')
      .doc(currentUser.uid)
      .collection('following')
      .onSnapshot(snap => {
        const ids = snap.docs.map(doc => doc.id);
        setFollowedAuthors(ids);
        appCacheService.setFollowingList(currentUser.uid, ids);
      });

    return () => {
      unsubscribeFollowing();
    };
  }, [currentUser?.uid]);

  // Search creators if search query changes
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchedCreators([]);
      return;
    }

    const query = searchQuery.toLowerCase().trim();
    const unsubscribeCreators = db.collection('users')
      .onSnapshot(snap => {
        const users = snap.docs.map(doc => ({ uid: doc.id, ...doc.data() } as User));
        const filtered = users.filter(u => 
          u.name.toLowerCase().includes(query) || 
          u.username.toLowerCase().includes(query)
        );
        setSearchedCreators(filtered);
      });

    return () => unsubscribeCreators();
  }, [searchQuery]);

  // Filter videos based on category, search query, state, district, and block
  const filteredVideos = useMemo(() => {
    return videos.filter(video => {
      // 1. Category Filter
      if (selectedCategory !== 'Recent Video' && selectedCategory !== NEAR_ME) {
        if (video.category !== selectedCategory) return false;
      }

      // 2. Local/Location Filters
      if (selectedState && video.state !== selectedState) return false;
      if (selectedDistrict && video.district !== selectedDistrict) return false;
      if (selectedBlock && video.block !== selectedBlock) return false;

      // 3. Search Query Filter (only when on 'videos' search tab)
      if (searchQuery.trim()) {
        const searchLower = searchQuery.toLowerCase();
        const matchesTitle = video.title.toLowerCase().includes(searchLower);
        const matchesDesc = video.description?.toLowerCase().includes(searchLower) || false;
        const matchesCategory = video.category.toLowerCase().includes(searchLower);
        if (!matchesTitle && !matchesDesc && !matchesCategory) return false;
      }

      return true;
    });
  }, [videos, selectedCategory, searchQuery, selectedState, selectedDistrict, selectedBlock]);

  const isProgrammaticScrollRef = useRef(false);
  const scrollBehaviorRef = useRef<ScrollBehavior>('auto');
  const filteredVideosRef = useRef(filteredVideos);
  useEffect(() => {
    filteredVideosRef.current = filteredVideos;
  }, [filteredVideos]);

  // Set up isMobile detection
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Set up IntersectionObserver to detect the most visible/centered video card on mobile
  useEffect(() => {
    if (!isMobile) {
      setActiveVideoId(null);
      return;
    }

    // Don't auto-unmute home page videos if reels modal is active
    if (reelsActive) {
      setActiveVideoId(null);
      return;
    }

    const observerOptions = {
      root: null,
      // Target elements centered in the screen
      rootMargin: '-30% 0px -30% 0px',
      threshold: [0.1, 0.3, 0.5, 0.8]
    };

    let visibleRatios: { [key: string]: number } = {};

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const videoId = entry.target.getAttribute('data-video-id');
        if (!videoId) return;

        if (entry.isIntersecting) {
          visibleRatios[videoId] = entry.intersectionRatio;
        } else {
          delete visibleRatios[videoId];
        }
      });

      // Find the video ID with the maximum intersection ratio
      let maxRatio = 0;
      let mostVisibleId: string | null = null;
      Object.entries(visibleRatios).forEach(([id, ratio]) => {
        if (ratio > maxRatio) {
          maxRatio = ratio;
          mostVisibleId = id;
        }
      });

      if (mostVisibleId) {
        setActiveVideoId(mostVisibleId);
      } else {
        setActiveVideoId(null);
      }
    }, observerOptions);

    // Give the DOM a tiny bit of time to render the cards
    const timeout = setTimeout(() => {
      const cards = document.querySelectorAll('.video-card-container');
      cards.forEach(card => observer.observe(card));
    }, 150);

    return () => {
      clearTimeout(timeout);
      observer.disconnect();
    };
  }, [isMobile, reelsActive, filteredVideos]);

  // Automatically scroll the snap container to correct element when activeReelIndex changes (only programmatically)
  useEffect(() => {
    if (reelsActive && scrollContainerRef.current && isProgrammaticScrollRef.current) {
      const container = scrollContainerRef.current;
      
      const performScroll = () => {
        if (!container) return;
        const clientHeight = container.clientHeight;
        if (clientHeight === 0) {
          requestAnimationFrame(performScroll);
          return;
        }
        const targetScrollTop = currentReelIndex * clientHeight;
        container.scrollTo({ top: targetScrollTop, behavior: scrollBehaviorRef.current });
        
        // Keep isProgrammaticScrollRef.current true for 200ms to ignore any noise or race condition from mounting intersections
        setTimeout(() => {
          isProgrammaticScrollRef.current = false;
        }, 200);
      };

      performScroll();
    }
  }, [reelsActive, currentReelIndex]);

  // Set up IntersectionObserver to detect visible reel and update currentReelIndex accordingly
  useEffect(() => {
    if (!reelsActive || !scrollContainerRef.current) return;

    const container = scrollContainerRef.current;
    const observerOptions = {
      root: container,
      rootMargin: '0px',
      threshold: 0.6, // Active when at least 60% visible
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      // IGNORE intersections if programmatic scroll is in progress to avoid resetting index
      if (isProgrammaticScrollRef.current) return;

      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const indexAttr = entry.target.getAttribute('data-index');
          if (indexAttr !== null) {
            const index = parseInt(indexAttr, 10);
            setCurrentReelIndex((prev) => {
              if (prev !== index) {
                setShowComments(false);

                // Increment view count for newly scrolled video
                const targetVideo = filteredVideosRef.current[index];
                if (targetVideo) {
                  db.collection('videos').doc(targetVideo.id).update({
                    viewCount: increment(1)
                  }).catch(err => console.error("Error updating view count on scroll intersection:", err));
                }
                return index;
              }
              return prev;
            });
          }
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    // Give a small delay to ensure React has fully rendered children items
    const setupTimer = setTimeout(() => {
      const targets = container.querySelectorAll('[data-index]');
      targets.forEach((target) => observer.observe(target));
    }, 100);

    return () => {
      clearTimeout(setupTimer);
      observer.disconnect();
    };
  }, [reelsActive, filteredVideos]);

  // Keyboard navigation for cinematic reels player (Up/Down arrow keys & Escape)
  useEffect(() => {
    if (!reelsActive) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (showComments) return; // Don't intercept arrow keys if comment drawer is open
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (currentReelIndex < filteredVideos.length - 1) {
          isProgrammaticScrollRef.current = true;
          scrollBehaviorRef.current = 'smooth';
          setCurrentReelIndex(prev => prev + 1);
          setShowComments(false);
        }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (currentReelIndex > 0) {
          isProgrammaticScrollRef.current = true;
          scrollBehaviorRef.current = 'smooth';
          setCurrentReelIndex(prev => prev - 1);
          setShowComments(false);
        }
      } else if (e.key === 'Escape') {
        closeReel();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [reelsActive, currentReelIndex, filteredVideos.length, showComments]);

  // Desktop wheel controller for step-by-step smooth reel transitions
  useEffect(() => {
    if (!reelsActive || !scrollContainerRef.current) return;
    const container = scrollContainerRef.current;
    let wheelCooldown = false;

    const handleWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) < 25) return;
      if (wheelCooldown) return;

      wheelCooldown = true;
      setTimeout(() => { wheelCooldown = false; }, 300);

      if (e.deltaY > 0) {
        if (currentReelIndex < filteredVideos.length - 1) {
          isProgrammaticScrollRef.current = true;
          scrollBehaviorRef.current = 'smooth';
          setCurrentReelIndex(prev => prev + 1);
          setShowComments(false);
        }
      } else {
        if (currentReelIndex > 0) {
          isProgrammaticScrollRef.current = true;
          scrollBehaviorRef.current = 'smooth';
          setCurrentReelIndex(prev => prev - 1);
          setShowComments(false);
        }
      }
    };

    container.addEventListener('wheel', handleWheel, { passive: true });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [reelsActive, currentReelIndex, filteredVideos.length]);

  // Open the cinematic reels player
  const openReel = async (index: number) => {
    isProgrammaticScrollRef.current = true;
    scrollBehaviorRef.current = 'auto'; // instant scroll on opening clicked video
    setCurrentReelIndex(index);
    setReelsActive(true);
    setIsMuted(false); // Unmute full screen reel on opening
    setShowComments(false);

    const targetVideo = filteredVideos[index];
    // Push a custom history state so the physical back button can close the reel
    window.history.pushState(
      { view: View.VideoHome, videoId: targetVideo?.id, isReel: true }, 
      '', 
      targetVideo ? `?videoId=${targetVideo.id}` : ''
    );

    // Increment view count in Firestore
    if (targetVideo) {
      try {
        await db.collection('videos').doc(targetVideo.id).update({
          viewCount: increment(1)
        });
      } catch (err) {
        console.error("Error incrementing view count:", err);
      }
    }
  };

  // Close the cinematic reels player
  const closeReel = () => {
    setReelsActive(false);
    if (onClearSelectedVideo) {
      onClearSelectedVideo();
    }
    // If we're closing via the UI close button, pop the isReel state we pushed
    if (window.history.state && window.history.state.isReel) {
      window.history.back();
    }
  };

  // Handle mobile physical back button press to close the reel
  useEffect(() => {
    const handlePopStateLocal = (e: PopStateEvent) => {
      if (reelsActive) {
        setReelsActive(false);
        if (onClearSelectedVideo) {
          onClearSelectedVideo();
        }
      }
    };

    window.addEventListener('popstate', handlePopStateLocal);
    return () => {
      window.removeEventListener('popstate', handlePopStateLocal);
    };
  }, [reelsActive, onClearSelectedVideo]);

  const handleVideoEnded = (idx: number) => {
    if (idx < filteredVideos.length - 1) {
      isProgrammaticScrollRef.current = true;
      scrollBehaviorRef.current = 'smooth'; // smooth scroll for autoplay next
      setCurrentReelIndex(idx + 1);
    }
  };



  // Synchronize browser history and URL with the active reel as the user scrolls
  const activeVideo = filteredVideos[currentReelIndex];
  useEffect(() => {
    if (reelsActive && activeVideo) {
      window.history.replaceState(
        { view: View.VideoHome, videoId: activeVideo.id, isReel: true },
        '',
        `?videoId=${activeVideo.id}`
      );
    }
  }, [activeVideo, reelsActive]);

  // Fetch comments for active reel video
  useEffect(() => {
    if (!activeVideo || !reelsActive) {
      setComments([]);
      return;
    }

    const unsubscribeComments = db.collection('videos')
      .doc(activeVideo.id)
      .collection('comments')
      .onSnapshot(snap => {
        const list = snap.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            content: data.content || '',
            authorId: data.authorId || '',
            authorName: data.authorName || '',
            authorProfilePicUrl: data.authorProfilePicUrl || '',
            authorIsVerified: !!data.authorIsVerified,
            isPinned: !!data.isPinned,
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(),
          } as Comment;
        });

        list.sort((a, b) => {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
          const timeA = a.createdAt ? a.createdAt.getTime() : 0;
          const timeB = b.createdAt ? b.createdAt.getTime() : 0;
          return timeB - timeA;
        });

        setComments(list);
      });

    // Check if liked by current user
    let unsubscribeLikeState = () => {};
    if (currentUser) {
      unsubscribeLikeState = db.collection('videos')
        .doc(activeVideo.id)
        .collection('likes')
        .doc(currentUser.uid)
        .onSnapshot(doc => {
          setReelLikes(prev => ({ ...prev, [activeVideo.id]: doc.exists }));
        });
    }

    // Sync like count in real time
    const unsubscribeLikeCount = db.collection('videos')
      .doc(activeVideo.id)
      .collection('likes')
      .onSnapshot(snap => {
        setReelLikeCounts(prev => ({ ...prev, [activeVideo.id]: snap.size }));
      });

    return () => {
      unsubscribeComments();
      unsubscribeLikeState();
      unsubscribeLikeCount();
    };
  }, [activeVideo, reelsActive, currentUser]);

  // Like / Unlike handler
  const handleLikeVideo = async (videoId: string) => {
    if (!currentUser) {
      onLogin();
      return;
    }

    const isCurrentlyLiked = reelLikes[videoId];
    const likeRef = db.collection('videos').doc(videoId).collection('likes').doc(currentUser.uid);
    const videoDocRef = db.collection('videos').doc(videoId);

    try {
      if (isCurrentlyLiked) {
        setReelLikes(prev => ({ ...prev, [videoId]: false }));
        setReelLikeCounts(prev => ({ ...prev, [videoId]: Math.max(0, (prev[videoId] || 0) - 1) }));
        await likeRef.delete();
        await videoDocRef.update({ likeCount: increment(-1) });
      } else {
        setReelLikes(prev => ({ ...prev, [videoId]: true }));
        setReelLikeCounts(prev => ({ ...prev, [videoId]: (prev[videoId] || 0) + 1 }));
        await likeRef.set({ likedAt: serverTimestamp(), userId: currentUser.uid });
        await videoDocRef.update({ likeCount: increment(1) });
      }
    } catch (err) {
      console.error("Error liking/unliking video:", err);
      showToast("Operation failed", "error");
    }
  };

  // Follow / Unfollow creator from reel
  const handleFollowCreator = async (authorId: string, authorName: string) => {
    if (!currentUser) {
      onLogin();
      return;
    }

    const isFollowing = followedAuthors.includes(authorId);

    // Optimistic UI update
    if (isFollowing) {
      appCacheService.removeFollow(currentUser.uid, authorId);
      setFollowedAuthors(prev => prev.filter(id => id !== authorId));
    } else {
      appCacheService.addFollow(currentUser.uid, authorId);
      setFollowedAuthors(prev => [...prev, authorId]);
    }

    const currentUserRef = db.collection('users').doc(currentUser.uid);
    const authorRef = db.collection('users').doc(authorId);
    const followRef = currentUserRef.collection('following').doc(authorId);
    const followerRef = authorRef.collection('followers').doc(currentUser.uid);

    try {
      if (isFollowing) {
        await Promise.allSettled([
          followRef.delete(),
          followerRef.delete(),
          currentUserRef.update({ followingCount: increment(-1) }),
          authorRef.update({ followerCount: increment(-1) })
        ]);
        showToast(`Unfollowed ${authorName}`, "info");
      } else {
        await Promise.allSettled([
          followRef.set({ followedAt: serverTimestamp() }),
          followerRef.set({ 
            followedAt: serverTimestamp(),
            followerId: currentUser.uid,
            followerName: currentUser.name || '',
            followerProfilePicUrl: currentUser.profilePicUrl || ''
          }),
          currentUserRef.update({ followingCount: increment(1) }),
          authorRef.update({ followerCount: increment(1) }),
          authorRef.collection('notifications').add({
            type: 'new_follower',
            fromUserId: currentUser.uid,
            fromUserName: currentUser.name,
            fromUserProfilePicUrl: currentUser.profilePicUrl || '',
            fromUserIsVerified: !!currentUser.isVerified,
            createdAt: serverTimestamp(),
            read: false
          })
        ]);
        showToast(`Following ${authorName}`, "success");
      }
    } catch (err) {
      console.error("Error following/unfollowing user:", err);
    }
  };

  // Submit comment on video
  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() || !currentUser || !activeVideo) return;

    setIsSubmittingComment(true);
    const text = newCommentText.trim();
    setNewCommentText('');

    try {
      await db.collection('videos').doc(activeVideo.id).collection('comments').add({
        content: text,
        authorId: currentUser.uid,
        authorName: currentUser.name || '',
        authorProfilePicUrl: currentUser.profilePicUrl || '',
        authorIsVerified: !!currentUser.isVerified,
        createdAt: serverTimestamp()
      });

      await db.collection('videos').doc(activeVideo.id).update({
        commentCount: increment(1)
      });

      // Send notification to video creator
      if (currentUser.uid !== activeVideo.authorId) {
        await db.collection('users').doc(activeVideo.authorId).collection('notifications').add({
          type: 'new_comment',
          fromUserId: currentUser.uid,
          fromUserName: currentUser.name || '',
          fromUserProfilePicUrl: currentUser.profilePicUrl || '',
          fromUserIsVerified: !!currentUser.isVerified,
          postId: activeVideo.id,
          videoId: activeVideo.id,
          postTitle: `your video: "${activeVideo.title.substring(0, 20)}..."`,
          postThumbnailUrl: activeVideo.thumbnailUrl || '',
          commentText: text.substring(0, 80),
          createdAt: serverTimestamp(),
          read: false
        });
      }
      showToast("Comment added", "success");
    } catch (err) {
      console.error("Error writing comment:", err);
      showToast("Comment submission failed", "error");
    } finally {
      setIsSubmittingComment(false);
    }
  };

  // Delete comment on video
  const handleDeleteVideoComment = async (commentId: string) => {
    if (!activeVideo || !commentId) return;
    try {
      await db.collection('videos')
        .doc(activeVideo.id)
        .collection('comments')
        .doc(commentId)
        .delete();
      
      await db.collection('videos').doc(activeVideo.id).update({
        commentCount: increment(-1)
      });
      showToast("Comment deleted", "success");
    } catch (err) {
      console.error("Error deleting comment:", err);
      showToast("Failed to delete comment", "error");
    }
  };

  // Share video functionality
  const handleShareVideo = async (video: Video) => {
    if (!currentUser) {
      showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
      onLogin();
      return;
    }

    const alreadyShared = hasUserSharedLocally('videos', video.id, currentUser);
    if (!alreadyShared) {
      setVideos(prev => prev.map(v => v.id === video.id ? { ...v, shareCount: (v.shareCount || 0) + 1 } : v));
    }

    const isNewShare = await shareVideo({
      video,
      currentUser,
      showToast,
    });

    if (!isNewShare && !alreadyShared) {
      setVideos(prev => prev.map(v => v.id === video.id ? { ...v, shareCount: Math.max(0, (v.shareCount || 1) - 1) } : v));
    }
  };

  const handleReportVideo = (video: Video) => {
    if (!currentUser) {
      showToast("कृपया रिपोर्ट करने के लिए लॉग इन करें।", "info");
      onLogin();
      return;
    }
    setReportingVideo(video);
  };

  // Up/Down navigation helper
  const navigateReel = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentReelIndex > 0) {
      setCurrentReelIndex(prev => prev - 1);
      setShowComments(false);
    } else if (direction === 'next' && currentReelIndex < filteredVideos.length - 1) {
      setCurrentReelIndex(prev => prev + 1);
      setShowComments(false);
    }
  };

  return (
    <div className="flex-grow min-h-screen bg-gray-50 dark:bg-slate-950 pb-20 md:pb-6 font-sans">
      <SEO 
        title="वीडियो बुलेटिन | Public Tak App"
        description="देश और अपने राज्य की स्थानीय वीडियो खबरें, रील्स और ब्रेकिंग रिपोर्ट्स देखें।"
      />

      {/* ================= Desktop Header ================= */}
      <div className="hidden md:block bg-white/80 dark:bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 border-b border-gray-200/60 dark:border-slate-800/60 shadow-sm animate-fade-in">
          <div className="w-full max-w-7xl mx-auto px-4 animate-fade-in">
              <div className="flex flex-col gap-2 pt-4 pb-2">
                  {/* Top Row: Search & Location */}
                  <div className="flex items-center gap-4 w-full">
                       {/* Search Bar - Full Width */}
                       <div className="flex-grow relative">
                          <input 
                              type="text" 
                              placeholder="वीडियो बुलेटिन या वीडियो क्रिएटर खोजें..."
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              className="w-full pl-11 pr-4 py-2.5 bg-gray-100/80 dark:bg-slate-900/80 hover:bg-white dark:hover:bg-slate-900 focus:bg-white dark:focus:bg-slate-900 border border-transparent focus:border-red-200 dark:focus:border-red-950 rounded-xl text-gray-800 dark:text-gray-100 placeholder-gray-500 focus:ring-4 focus:ring-red-500/10 transition-all duration-300 outline-none shadow-sm"
                          />
                          <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">search</span>
                      </div>

                      {/* Location Filters - Compact Row */}
                      <div className="flex items-center gap-2 p-1 bg-gray-50 dark:bg-slate-900 rounded-lg border border-gray-100 dark:border-slate-800 shadow-sm flex-shrink-0">
                          <select value={selectedState} onChange={(e) => handleStateSelect(e.target.value)} className="bg-transparent text-sm font-medium text-gray-700 dark:text-gray-300 py-1.5 px-2 outline-none cursor-pointer hover:text-red-600 transition-colors border-r border-gray-200 dark:border-slate-800 max-w-[120px] truncate">
                              <option value="" className="dark:bg-slate-950">State</option>
                              {states.map(s => <option key={s} value={s} className="dark:bg-slate-950">{s}</option>)}
                          </select>
                          <select value={selectedDistrict} onChange={(e) => handleDistrictSelect(e.target.value)} disabled={!selectedState} className="bg-transparent text-sm font-medium text-gray-700 dark:text-gray-300 py-1.5 px-2 outline-none cursor-pointer hover:text-red-600 transition-colors disabled:text-gray-400 max-w-[120px] truncate">
                              <option value="" className="dark:bg-slate-950">District</option>
                              {districts.map(d => <option key={d} value={d} className="dark:bg-slate-950">{d}</option>)}
                          </select>
                           {selectedDistrict && (
                              <select value={selectedBlock} onChange={(e) => handleBlockSelect(e.target.value)} disabled={!selectedDistrict} className="bg-transparent text-sm font-medium text-gray-700 dark:text-gray-300 py-1.5 px-2 outline-none cursor-pointer hover:text-red-600 transition-colors disabled:text-gray-400 border-l border-gray-200 dark:border-slate-800 max-w-[120px] truncate hidden lg:block">
                                  <option value="" className="dark:bg-slate-950">Block</option>
                                  {blocks.map(b => <option key={b} value={b} className="dark:bg-slate-950">{b}</option>)}
                              </select>
                           )}
                          {(selectedState || selectedDistrict) && (
                              <button onClick={handleLocationReset} className="p-1.5 text-red-500 hover:bg-red-50 rounded-full transition-colors ml-1" title="Reset">
                                  <span className="material-symbols-outlined text-lg">close</span>
                              </button>
                          )}
                      </div>
                  </div>

                  {/* Bottom Row: Categories */}
                  <div className="w-full overflow-x-auto scrollbar-hide pt-1">
                       <div className="flex items-center gap-1 pb-1">
                           {displayCategories.map(cat => (
                              <button 
                                  key={cat.id}
                                  onClick={() => handleCategorySelect(cat.id)}
                                  className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-semibold transition-all duration-200 border border-transparent ${
                                      selectedCategory === cat.id
                                      ? 'bg-red-600 text-white shadow-md' 
                                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-800 hover:border-gray-200 dark:hover:border-slate-700'
                                  }`}
                              >
                                  {cat.icon && <span className="material-symbols-outlined text-[18px]">{cat.icon}</span>}
                                  {cat.label}
                              </button>
                          ))}
                       </div>
                  </div>
              </div>
          </div>
      </div>

      {/* ================= Mobile Header ================= */}
      <div className="md:hidden">
           <Header 
              title="Public Tak App"
              logoUrl={APP_LOGO_URL}
              showSettingsButton
              onSettings={() => onNavigate(View.Settings)}
              onEPaper={() => onNavigate(View.EPaper)}
              currentUser={currentUser}
              onProfileClick={() => onNavigate(View.User)}
              onLogin={onLogin}
              onSearchClick={() => onNavigate(View.Search, { searchType: 'video' })}
          />
      </div>
      
      {/* Mobile Filters (Sticky Top) */}
      <div className="sticky top-0 z-20 md:hidden shadow-sm">
        <Categories 
            categories={displayCategories}
            selectedCategory={selectedCategory}
            onSelectCategory={handleCategorySelect}
        />
        <LocationFilter 
          selectedState={selectedState}
          setSelectedState={handleStateSelect}
          selectedDistrict={selectedDistrict}
          setSelectedDistrict={handleDistrictSelect}
          selectedBlock={selectedBlock}
          setSelectedBlock={handleBlockSelect}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 pt-4">

        {/* Conditional Search Tabs if Query is present */}
        {searchQuery.trim() && (
          <div className="flex border-b border-gray-200 dark:border-slate-800 mb-6">
            <button
              onClick={() => setActiveSearchTab('videos')}
              className={`flex-1 py-3 text-center text-sm font-bold border-b-2 transition-all ${
                activeSearchTab === 'videos' 
                  ? 'border-red-600 text-red-600' 
                  : 'border-transparent text-gray-500'
              }`}
            >
              वीडियो ({filteredVideos.length})
            </button>
            <button
              onClick={() => setActiveSearchTab('creators')}
              className={`flex-1 py-3 text-center text-sm font-bold border-b-2 transition-all ${
                activeSearchTab === 'creators' 
                  ? 'border-red-600 text-red-600' 
                  : 'border-transparent text-gray-500'
              }`}
            >
              क्रिएटर ({searchedCreators.length})
            </button>
          </div>
        )}

        {/* Dynamic content area */}
        {loading && videos.length === 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="glass-card overflow-hidden bg-white dark:bg-slate-900/80 border border-gray-100 dark:border-slate-800/80 flex flex-col h-full rounded-2xl relative shadow-sm animate-pulse">
                {/* Header: Author Info Skeleton */}
                <div className="p-3 flex items-start gap-2 border-b border-gray-50/50 dark:border-slate-800/50">
                  <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-slate-800 shrink-0"></div>
                  <div className="flex-grow space-y-1.5 pt-0.5">
                    <div className="h-3 bg-gray-200 dark:bg-slate-800 rounded w-2/3"></div>
                    <div className="h-2 bg-gray-200 dark:bg-slate-800/60 rounded w-1/3"></div>
                  </div>
                </div>

                {/* Thumbnail / Cover Area Skeleton */}
                <div className="relative w-full aspect-video sm:h-44 bg-gray-100 dark:bg-slate-800/50 flex-shrink-0">
                  <div className="absolute top-3 left-3 bg-gray-200 dark:bg-slate-700 h-4.5 w-16 rounded-full"></div>
                </div>

                {/* Info Area Skeleton */}
                <div className="p-4 flex-grow flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="h-3.5 bg-gray-200 dark:bg-slate-800 rounded w-full"></div>
                    <div className="h-3.5 bg-gray-200 dark:bg-slate-800 rounded w-5/6"></div>
                  </div>
                  
                  {/* Action/stats row skeleton */}
                  <div className="flex items-center justify-between border-t border-gray-50 dark:border-slate-800/50 pt-3">
                    <div className="flex gap-4">
                      <div className="h-4 w-8 bg-gray-200 dark:bg-slate-800 rounded"></div>
                      <div className="h-4 w-8 bg-gray-200 dark:bg-slate-800 rounded"></div>
                    </div>
                    <div className="h-4 w-10 bg-gray-200 dark:bg-slate-800 rounded-full"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : searchQuery.trim() && activeSearchTab === 'creators' ? (
          // Fulfill search request: restrict to users if searching creator
          searchedCreators.length === 0 ? (
            <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 p-8 shadow-sm">
              <span className="material-symbols-outlined text-7xl text-gray-300">person_search</span>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mt-4">कोई क्रिएटर नहीं मिला</h3>
              <p className="text-sm text-gray-500 mt-1">अन्य कीवर्ड का उपयोग करके खोजें</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4">
              {searchedCreators.map((user) => (
                <div 
                  key={user.uid}
                  onClick={() => onViewUser(user.uid)}
                  className="glass-card p-4 bg-white hover:bg-gray-50 dark:bg-slate-900 dark:hover:bg-slate-800/80 cursor-pointer flex items-center gap-3 border transition-all"
                >
                  <UserAvatar 
                    userId={user.uid}
                    src={user.profilePicUrl}
                    name={user.name}
                    currentUser={currentUser}
                    className="w-12 h-12 rounded-full object-cover shadow-sm ring-2 ring-gray-100 dark:ring-slate-800"
                  />
                  <div className="flex-grow min-w-0">
                    <div className="flex items-center gap-1">
                      <h4 className="font-bold text-sm text-gray-900 dark:text-white truncate">{user.name}</h4>
                      {user.isVerified && <span className="material-symbols-outlined text-blue-500 text-[16px] font-bold shrink-0" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>}
                    </div>
                    <p className="text-xs text-gray-500 truncate">@{user.username || 'user'}</p>
                    <p className="text-[10px] text-red-600 font-bold mt-1 uppercase tracking-wider">{user.followerCount || 0} फ़ॉलोअर्स</p>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : filteredVideos.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 p-8 shadow-sm">
            <span className="material-symbols-outlined text-7xl text-gray-300">movie_off</span>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mt-4">कोई वीडियो नहीं मिला</h3>
            <p className="text-sm text-gray-500 mt-1">कृपया कोई अन्य श्रेणी या फ़िल्टर चुनें</p>
          </div>
        ) : (
          /* Main Video Grid */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-6">
            {filteredVideos.map((video, idx) => (
              <React.Fragment key={video.id}>
                <div 
                  className="video-card-container" 
                  data-video-id={video.id}
                >
                  <VideoCard
                    video={video}
                    currentUser={currentUser}
                    onLogin={onLogin}
                    onViewUser={onViewUser}
                    isFollowing={followedAuthors.includes(video.authorId)}
                    onFollowToggle={handleFollowCreator}
                    onPlay={() => openReel(idx)}
                    onCommentClick={() => {
                      openReel(idx);
                      setTimeout(() => {
                        setShowComments(true);
                      }, 250);
                    }}
                    onShareClick={() => handleShareVideo(video)}
                    onReport={handleReportVideo}
                    isMobile={isMobile}
                    isActive={video.id === activeVideoId}
                    reelsActive={reelsActive}
                  />
                </div>

                {/* Periodic rendering of SuggestedReels slider inside the feed */}
                {(isMobile 
                  ? (idx === 1 || (idx > 1 && (idx - 1) % 6 === 0))
                  : (idx === 3 || (idx > 3 && (idx - 3) % 8 === 0))
                ) && (
                  <div className="col-span-full py-4">
                    <SuggestedReels 
                      videos={filteredVideos}
                      currentVideoId={activeVideoId || undefined}
                      onPlayVideo={(videoId) => {
                        const targetIndex = filteredVideos.findIndex(v => v.id === videoId);
                        if (targetIndex !== -1) {
                          openReel(targetIndex);
                        }
                      }}
                    />
                  </div>
                )}

                {/* Periodic rendering of SuggestedUsers slider inside the feed */}
                {(isMobile
                  ? (idx === 3 || (idx > 3 && (idx - 4) % 6 === 0))
                  : (idx === 7 || (idx > 7 && (idx - 7) % 8 === 0))
                ) && (
                  <div className="col-span-full py-4">
                    <SuggestedUsers 
                      currentUser={currentUser}
                      followingList={followedAuthors}
                      handleFollowToggle={async (targetUserId, targetUserName) => {
                        await handleFollowCreator(targetUserId, targetUserName);
                      }}
                      onViewUser={onViewUser}
                      onLogin={onLogin}
                    />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>

      {/* INSTAGRAM-STYLE CINEMATIC REELS PLAYER MODAL */}
      <AnimatePresence>
        {reelsActive && activeVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950 z-[100] flex flex-col md:flex-row items-center justify-center overflow-hidden"
          >
            {/* Left/Back Button */}
            <button
              onClick={closeReel}
              className="absolute top-4 left-4 z-[110] w-10 h-10 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60 transition-colors shadow-md border border-white/10"
              title="Close Player"
            >
              <span className="material-symbols-outlined text-2xl">arrow_back</span>
            </button>

            {/* Reel snap-scroll view container */}
            <div className="relative w-full max-w-md h-full md:h-[92vh] md:rounded-3xl overflow-hidden bg-black flex flex-col justify-center shadow-2xl shadow-black border border-white/5">
              
              {/* Vertically scroll-snapped list of all filtered videos */}
              <div
                ref={scrollContainerRef}
                className="flex-1 w-full h-full overflow-y-auto snap-y snap-mandatory scrollbar-hide"
                style={{ scrollSnapType: 'y mandatory', WebkitOverflowScrolling: 'touch' }}
              >
                {filteredVideos.map((video, idx) => (
                  <div
                    key={video.id}
                    data-index={idx}
                    className="snap-start snap-always w-full h-full relative shrink-0"
                    style={{ height: '100%', scrollSnapStop: 'always' }}
                  >
                    <ReelItem
                      video={video}
                      currentUser={currentUser}
                      isActive={idx === currentReelIndex}
                      isMuted={isMuted}
                      isFollowing={followedAuthors.includes(video.authorId)}
                      onMuteToggle={() => setIsMuted(prev => !prev)}
                      onFollowToggle={handleFollowCreator}
                      onCommentBoxClick={() => setShowComments(true)}
                      onShareClick={() => handleShareVideo(video)}
                      onViewUser={(userId) => {
                        setReelsActive(false);
                        if (onClearSelectedVideo) {
                          onClearSelectedVideo();
                        }
                        onViewUser(userId);
                      }}
                      onLogin={onLogin}
                      onVideoEnded={() => handleVideoEnded(idx)}
                      onVideoDeleted={(deletedId) => {
                        if (filteredVideos.length <= 1) {
                          closeReel();
                        } else {
                          if (currentReelIndex >= filteredVideos.length - 1) {
                            setCurrentReelIndex(prev => Math.max(0, prev - 1));
                          }
                        }
                      }}
                    />
                  </div>
                ))}
              </div>

              {/* Sliding Bottom Comments Drawer for Reel - AS PER SCREENSHOT 2 */}
              <AnimatePresence>
                {showComments && (
                  <motion.div
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "100%" }}
                    transition={{ type: "spring", damping: 30, stiffness: 300 }}
                    className="absolute inset-x-0 bottom-0 h-[65%] bg-white rounded-t-3xl z-40 flex flex-col overflow-hidden shadow-2xl border-t border-gray-200 text-gray-900"
                  >
                    {/* Header: Drag Indicator and Centered Comments Label */}
                    <div className="flex flex-col flex-shrink-0 bg-white pt-2 pb-3 border-b border-gray-100">
                      <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-2" />
                      <div className="px-4 flex items-center justify-between">
                        <div className="w-8" /> {/* Spacer to balance Close button */}
                        <div className="text-center">
                          <h3 className="font-bold text-sm text-gray-900">Comments</h3>
                        </div>
                        <button
                          onClick={() => setShowComments(false)}
                          className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700 transition-colors"
                        >
                          <span className="material-symbols-outlined text-lg">close</span>
                        </button>
                      </div>
                    </div>

                    {/* Comments List scrollable section */}
                    <div className="flex-1 overflow-y-auto px-4 py-2 space-y-1 divide-y divide-gray-100 bg-white">
                      {comments.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-16 text-center text-gray-500">
                          <span className="material-symbols-outlined text-5xl opacity-40">chat_bubble_outline</span>
                          <p className="text-xs font-bold mt-3">No comments yet. Start the conversation!</p>
                        </div>
                      ) : (
                        comments.map((comment) => (
                          <VideoCommentItem
                            key={comment.id}
                            comment={comment}
                            videoId={activeVideo.id}
                            currentUser={currentUser}
                            onLogin={onLogin}
                            videoAuthorId={activeVideo.authorId}
                            onDeleteComment={handleDeleteVideoComment}
                            onViewUser={(userId) => {
                              setShowComments(false);
                              setReelsActive(false);
                              if (onClearSelectedVideo) {
                                onClearSelectedVideo();
                              }
                              onViewUser(userId);
                            }}
                          />
                        ))
                      )}
                    </div>

                    {/* Quick Emojis Selection Bar - AS PER SCREENSHOT 2 */}
                    <div className="px-4 py-2 flex items-center justify-around bg-gray-50 border-t border-gray-100 flex-shrink-0">
                      {['❤️', '😂', '🔥', '👏', '😢', '😍', '😐', '😄'].map((emoji) => (
                        <button
                          key={emoji}
                          type="button"
                          onClick={() => setNewCommentText(prev => prev + emoji)}
                          className="text-xl hover:scale-125 active:scale-95 transition-transform"
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>

                    {/* Comment input form section with user avatar - AS PER SCREENSHOT 2 */}
                    <form 
                      onSubmit={handleSubmitComment}
                      className="p-3 pb-6 border-t border-gray-100 flex gap-3 items-center bg-white flex-shrink-0"
                    >
                      <UserAvatar
                        userId={currentUser?.uid}
                        src={currentUser?.profilePicUrl}
                        name={currentUser?.name}
                        currentUser={currentUser}
                        className="w-8 h-8 rounded-full object-cover shrink-0 ring-1 ring-gray-200"
                      />
                      <div className="flex-1 relative flex items-center">
                        <input
                          type="text"
                          value={newCommentText}
                          onChange={(e) => setNewCommentText(e.target.value)}
                          placeholder={`Add a comment for ${activeVideo.authorName.replace(/\s+/g, '_').toLowerCase()}...`}
                          className="w-full bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full py-2.5 pl-4 pr-12 text-xs font-medium text-gray-800 outline-none placeholder-gray-400 focus:border-red-500 focus:bg-white transition-all"
                        />
                        <button
                          type="submit"
                          disabled={isSubmittingComment || !newCommentText.trim()}
                          className="absolute right-2 p-1.5 rounded-full text-red-600 hover:text-red-500 disabled:opacity-30 hover:scale-105 active:scale-95 transition-all flex items-center justify-center"
                          title="Post comment"
                        >
                          <span className="material-symbols-outlined text-xl">send</span>
                        </button>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {reportingVideo && currentUser && (
        <ReportModal
          video={reportingVideo}
          user={currentUser}
          onClose={() => setReportingVideo(null)}
          onSuccess={() => setReportingVideo(null)}
        />
      )}
    </div>
  );
};

export default VideoHomePage;
