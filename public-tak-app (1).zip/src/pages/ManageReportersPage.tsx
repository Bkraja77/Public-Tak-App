import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { db } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';
import { ReporterDetails, User, View } from '../types';
import { APP_LOGO_URL } from '../utils/constants';
import { ReporterIdCardModal } from '../components/ReporterIdCardModal';

interface ManageReportersPageProps {
  onBack: () => void;
  currentUser: User | null;
  onNavigate: (view: View, params?: any) => void;
}

const DESIGNATIONS = [
  "District Bureau Chief",
  "Senior Digital Reporter",
  "Crime & Special Correspondent",
  "Digital Media Journalist",
  "Block Bureau Incharge",
  "State Bureau Reporter",
  "Investigative Digital Journalist",
  "Rural & Panchayat Correspondent",
  "Youth & Sports Reporter",
  "Freelance Digital Journalist"
];

export const ManageReportersPage: React.FC<ManageReportersPageProps> = ({
  onBack,
  currentUser,
  onNavigate,
}) => {
  const { showToast } = useToast();
  const [requests, setRequests] = useState<ReporterDetails[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedRequest, setSelectedRequest] = useState<ReporterDetails | null>(null);

  // ID Card preview modal states
  const [cardModalReporter, setCardModalReporter] = useState<ReporterDetails | null>(null);
  const [showCardModal, setShowCardModal] = useState<boolean>(false);

  const openIdCardPreview = (reporter: ReporterDetails) => {
    setCardModalReporter(reporter);
    setShowCardModal(true);
  };

  // Edit / Customization states for Admin
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editDesignation, setEditDesignation] = useState<string>('');
  const [editReporterId, setEditReporterId] = useState<string>('');
  const [editValidTill, setEditValidTill] = useState<string>('');
  const [adminNotes, setAdminNotes] = useState<string>('');
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  // Rejection modal states
  const [showRejectModal, setShowRejectModal] = useState<boolean>(false);
  const [rejectReason, setRejectReason] = useState<string>('');
  const [previewDocImage, setPreviewDocImage] = useState<{ url: string; title: string } | null>(null);

  // Deletion modal states
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [requestToDelete, setRequestToDelete] = useState<ReporterDetails | null>(null);

  useEffect(() => {
    const unsubscribe = db.collection('reporter_requests')
      .orderBy('submittedAt', 'desc')
      .onSnapshot(
        (snapshot) => {
          const list = snapshot.docs.map((doc) => {
            const data = doc.data() as ReporterDetails;
            return {
              ...data,
              id: doc.id,
              submittedAt: data.submittedAt?.toDate ? data.submittedAt.toDate() : new Date(),
              approvedAt: data.approvedAt?.toDate ? data.approvedAt.toDate() : undefined,
            };
          });
          setRequests(list);
          setLoading(false);
        },
        (err) => {
          console.error('Error fetching reporter requests:', err);
          setLoading(false);
        }
      );

    return () => unsubscribe();
  }, []);

  // When a request is selected, sync the edit fields
  useEffect(() => {
    if (selectedRequest) {
      setEditDesignation(selectedRequest.designation || 'Digital Media Journalist');
      setEditReporterId(selectedRequest.reporterIdNumber || `PT-DM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
      setEditValidTill(selectedRequest.validTill || new Date(new Date().setFullYear(new Date().getFullYear() + 2)).toISOString().split('T')[0]);
      setAdminNotes(selectedRequest.adminNotes || '');
      setIsEditing(false);
    }
  }, [selectedRequest]);

  // Filter requests
  const filteredRequests = requests.filter((req) => {
    const matchesTab = activeTab === 'all' || req.status === activeTab;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      req.fullName.toLowerCase().includes(q) ||
      req.reporterIdNumber.toLowerCase().includes(q) ||
      req.district.toLowerCase().includes(q) ||
      req.mobile.includes(q) ||
      (req.designation && req.designation.toLowerCase().includes(q));

    return matchesTab && matchesSearch;
  });

  const pendingCount = requests.filter((r) => r.status === 'pending').length;
  const approvedCount = requests.filter((r) => r.status === 'approved').length;

  // Helper to remove any undefined fields before writing to Firestore
  const cleanObject = (obj: any) => {
    const cleaned: any = {};
    Object.keys(obj).forEach((key) => {
      if (obj[key] !== undefined) {
        cleaned[key] = obj[key];
      }
    });
    return cleaned;
  };

  // Handle Approve Request
  const handleApprove = async () => {
    if (!selectedRequest) return;
    setActionLoading(true);

    try {
      const now = new Date();
      const rawUpdatedData: any = {
        ...selectedRequest,
        status: 'approved',
        approvedAt: now,
        designation: editDesignation.trim(),
        reporterIdNumber: editReporterId.trim(),
        validTill: editValidTill,
        adminNotes: adminNotes.trim(),
        signatureUrl: selectedRequest.signatureUrl || '',
        qrCodeData: `https://publictak.app/?reporterVerify=${selectedRequest.userId}&ref=${editReporterId.trim()}`
      };

      const updatedData = cleanObject(rawUpdatedData) as ReporterDetails;

      const batch = db.batch();

      // 1. Update request in reporter_requests
      const reqRef = db.collection('reporter_requests').doc(selectedRequest.id);
      batch.set(reqRef, updatedData, { merge: true });

      // 2. Mirror into public 'reporters' directory for QR scans & verification
      const pubRef = db.collection('reporters').doc(selectedRequest.userId);
      batch.set(pubRef, updatedData);

      // 3. Update user document
      const userRef = db.collection('users').doc(selectedRequest.userId);
      batch.set(userRef, {
        reporterStatus: 'approved',
        reporterIdNumber: editReporterId.trim(),
        reporterDesignation: editDesignation.trim(),
        reporterValidTill: editValidTill,
        reporterPhotoUrl: selectedRequest.photoUrl || '',
        isVerified: true // Auto-grant verified checkmark
      }, { merge: true });

      await batch.commit();

      showToast(`रिपोर्टर ${selectedRequest.fullName} का e-KYC स्वीकृत हुआ और Digital Media ID Card जनरेट हो गया! ✓`, 'success');
      setSelectedRequest({ ...updatedData });
      
      // Instantly open the newly generated ID card in preview modal for smooth admin verification
      setCardModalReporter(updatedData);
      setShowCardModal(true);
    } catch (err: any) {
      console.error('Approval failed:', err);
      showToast(`स्वीकृति में त्रुटि: ${err.message}`, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Handle Reject Request
  const handleReject = async () => {
    if (!selectedRequest || !rejectReason.trim()) {
      showToast('कृपया अस्वीकृति का कारण लिखें', 'error');
      return;
    }
    setActionLoading(true);

    try {
      const batch = db.batch();

      // 1. Update request document
      const reqRef = db.collection('reporter_requests').doc(selectedRequest.id);
      batch.update(reqRef, {
        status: 'rejected',
        rejectionReason: rejectReason.trim(),
        rejectedAt: new Date()
      });

      // 2. Remove from public reporters if previously approved
      const pubRef = db.collection('reporters').doc(selectedRequest.userId);
      batch.delete(pubRef);

      // 3. Update user doc
      const userRef = db.collection('users').doc(selectedRequest.userId);
      batch.update(userRef, {
        reporterStatus: 'rejected',
      });

      await batch.commit();

      showToast(`आवेदन अस्वीकृत कर दिया गया। कारण रिपोर्टर को दिखेगा।`, 'info');
      setShowRejectModal(false);
      setRejectReason('');
      setSelectedRequest((prev) => (prev ? { ...prev, status: 'rejected', rejectionReason: rejectReason } : null));
    } catch (err: any) {
      console.error('Rejection failed:', err);
      showToast('अस्वीकृति में त्रुटि हुई', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Save changes without approving/rejecting
  const handleSaveCustomDetails = async () => {
    if (!selectedRequest) return;
    setActionLoading(true);
    try {
      const updatedData: Partial<ReporterDetails> = {
        designation: editDesignation.trim(),
        reporterIdNumber: editReporterId.trim(),
        validTill: editValidTill,
        adminNotes: adminNotes.trim(),
      };

      const batch = db.batch();
      const reqRef = db.collection('reporter_requests').doc(selectedRequest.id);
      batch.update(reqRef, updatedData);

      if (selectedRequest.status === 'approved') {
        const pubRef = db.collection('reporters').doc(selectedRequest.userId);
        batch.update(pubRef, updatedData);

        const userRef = db.collection('users').doc(selectedRequest.userId);
        batch.update(userRef, {
          reporterDesignation: editDesignation.trim(),
          reporterIdNumber: editReporterId.trim(),
          reporterValidTill: editValidTill,
        });
      }

      await batch.commit();

      setSelectedRequest((prev) => (prev ? { ...prev, ...updatedData } : null));
      setIsEditing(false);
      showToast('रिपोर्टर विवरण सफलतापूर्वक अपडेट हुआ! ✓', 'success');
    } catch (err: any) {
      console.error('Error saving reporter details:', err);
      showToast('अपडेट विफल', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Handle Permanent Deletion of Reporter Application
  const handleDeleteRequest = async () => {
    if (!requestToDelete) return;
    setActionLoading(true);

    try {
      const batch = db.batch();

      // 1. Delete from reporter_requests collection
      const reqRef = db.collection('reporter_requests').doc(requestToDelete.id);
      batch.delete(reqRef);

      // 2. Delete from public reporters collection if present
      const pubRef = db.collection('reporters').doc(requestToDelete.userId);
      batch.delete(pubRef);

      // 3. Reset user status in users collection
      const userRef = db.collection('users').doc(requestToDelete.userId);
      batch.set(userRef, {
        reporterStatus: 'none',
        reporterIdNumber: '',
        reporterDesignation: '',
      }, { merge: true });

      await batch.commit();

      // Clear local storage cache
      try {
        localStorage.removeItem(`local_reporter_request_${requestToDelete.userId}`);
      } catch (_) {}

      // Update UI state immediately
      setRequests((prev) => prev.filter((r) => r.id !== requestToDelete.id));
      if (selectedRequest?.id === requestToDelete.id) {
        setSelectedRequest(null);
      }

      setShowDeleteModal(false);
      const name = requestToDelete.fullName;
      setRequestToDelete(null);
      showToast(`रिपोर्टर आवेदन (${name}) सफलतापूर्वक हटा दिया गया! ✓`, 'success');
    } catch (err: any) {
      console.error('Delete request failed:', err);
      showToast(`हटाने में त्रुटि: ${err.message || 'Error'}`, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50/50">
      <Header
        title="Reporter e-KYC & ID Management"
        showBackButton
        onBack={onBack}
        currentUser={currentUser}
      />

      <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-32">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Top Banner */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-gray-200 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-blue-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
                  Admin Command
                </span>
                <span className="bg-red-100 text-red-700 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                  Digital Media Network
                </span>
              </div>
              <h1 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight mt-1">
                रिपोर्टर e-KYC व ID कार्ड प्रबंधन
              </h1>
              <p className="text-gray-500 text-xs md:text-sm mt-0.5">
                आधार e-KYC सत्यापन, पदनाम निर्धारण, अनुमोदन एवं डिजिटल मीडिया ID कार्ड जारी करें।
              </p>
            </div>

            {/* Quick Stats & Action to Preview All ID Cards */}
            <div className="flex items-center gap-3 flex-wrap">
              <button
                onClick={() => {
                  const approvedList = requests.filter((r) => r.status === 'approved');
                  if (approvedList.length > 0) {
                    openIdCardPreview(approvedList[0]);
                  } else if (requests.length > 0) {
                    openIdCardPreview(requests[0]);
                  } else {
                    showToast('कोई रिपोर्टर रिकॉर्ड उपलब्ध नहीं है', 'info');
                  }
                }}
                className="px-4 py-2.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 hover:from-blue-800 hover:to-indigo-900 text-white rounded-2xl shadow-md text-left flex items-center gap-2.5 transition-all active:scale-95 border border-blue-500/30"
                title="सभी रिपोर्टर्स के ID कार्ड्स प्रीव्यू करें"
              >
                <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-lg">badge</span>
                </div>
                <div>
                  <span className="text-xs font-black block leading-tight">सभी ID कार्ड देखें</span>
                  <span className="text-[10px] text-blue-200 font-medium">Preview All ID Cards ({approvedCount})</span>
                </div>
              </button>

              <div className="px-3.5 py-2 bg-amber-50 border border-amber-200 rounded-2xl text-center">
                <span className="text-lg font-black text-amber-700 block leading-tight">{pendingCount}</span>
                <span className="text-[9px] font-bold text-amber-800 uppercase tracking-wider">Pending e-KYC</span>
              </div>
              <div className="px-3.5 py-2 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                <span className="text-lg font-black text-emerald-700 block leading-tight">{approvedCount}</span>
                <span className="text-[9px] font-bold text-emerald-800 uppercase tracking-wider">Active Reporters</span>
              </div>
            </div>
          </div>

          {/* Filter Bar & Search */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Status Tabs */}
            <div className="flex bg-gray-200 p-1 rounded-2xl w-full sm:w-auto overflow-x-auto">
              <button
                onClick={() => setActiveTab('pending')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  activeTab === 'pending' ? 'bg-amber-500 text-white shadow' : 'text-gray-700 hover:bg-gray-300/60'
                }`}
              >
                <span>Pending e-KYC</span>
                {pendingCount > 0 && (
                  <span className="bg-white text-amber-700 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                    {pendingCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('approved')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  activeTab === 'approved' ? 'bg-emerald-600 text-white shadow' : 'text-gray-700 hover:bg-gray-300/60'
                }`}
              >
                <span>Approved</span>
                <span className="bg-white/20 text-xs px-1 rounded-full">{approvedCount}</span>
              </button>
              <button
                onClick={() => setActiveTab('rejected')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'rejected' ? 'bg-red-600 text-white shadow' : 'text-gray-700 hover:bg-gray-300/60'
                }`}
              >
                Rejected
              </button>
              <button
                onClick={() => setActiveTab('all')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeTab === 'all' ? 'bg-gray-900 text-white shadow' : 'text-gray-700 hover:bg-gray-300/60'
                }`}
              >
                All ({requests.length})
              </button>
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
                search
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="नाम, ID, जिला या मोबाइल से खोजें..."
                className="w-full pl-9 pr-4 py-2.5 bg-white border border-gray-300 rounded-2xl text-xs font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          {/* Main Grid: List on Left, Inspector on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* LEFT LIST SECTION */}
            <div className="lg:col-span-1 space-y-3">
              <h3 className="text-xs font-black text-gray-500 uppercase tracking-wider px-1">
                आवेदन सूची ({filteredRequests.length})
              </h3>

              {loading ? (
                <div className="p-12 flex justify-center">
                  <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : filteredRequests.length === 0 ? (
                <div className="bg-white p-12 text-center text-gray-400 rounded-3xl border border-gray-200">
                  <span className="material-symbols-outlined text-5xl mb-2 opacity-20">fact_check</span>
                  <p className="text-xs font-bold">कोई आवेदन नहीं मिला</p>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[750px] overflow-y-auto pr-1">
                  {filteredRequests.map((req) => {
                    const isSelected = selectedRequest?.id === req.id;
                    return (
                      <button
                        key={req.id}
                        onClick={() => setSelectedRequest(req)}
                        className={`w-full text-left p-4 rounded-2xl border transition-all ${
                          isSelected
                            ? 'bg-blue-50 border-blue-500 shadow-md ring-2 ring-blue-400/30'
                            : 'bg-white border-gray-200 hover:border-gray-300 hover:shadow-sm'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {/* Photo Avatar */}
                          <div className="w-12 h-12 rounded-xl overflow-hidden bg-gray-100 border border-gray-200 flex-shrink-0">
                            <img
                              src={req.photoUrl || APP_LOGO_URL}
                              alt={req.fullName}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="font-extrabold text-sm text-gray-900 truncate">{req.fullName}</p>
                              <span
                                className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                                  req.status === 'approved'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : req.status === 'rejected'
                                    ? 'bg-red-100 text-red-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {req.status}
                              </span>
                            </div>

                            <p className="text-xs font-semibold text-blue-700 truncate mt-0.5">
                              {req.designation}
                            </p>
                            <div className="flex items-center justify-between gap-1 mt-1.5">
                              <div className="flex items-center gap-1.5 text-[10px] text-gray-500 truncate">
                                <span>📍 {req.district}</span>
                                <span>•</span>
                                <span className="font-mono font-semibold">{req.reporterIdNumber}</span>
                              </div>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openIdCardPreview(req);
                                }}
                                className="px-2.5 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 hover:text-blue-900 text-[10px] font-bold rounded-lg border border-blue-200 transition-colors flex items-center gap-1 shrink-0"
                                title="ID Card Preview"
                              >
                                <span className="material-symbols-outlined text-[13px]">badge</span>
                                <span>ID Preview</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* RIGHT INSPECTOR / ACTIONS PANEL */}
            <div className="lg:col-span-2">
              <AnimatePresence mode="wait">
                {selectedRequest ? (
                  <motion.div
                    key={selectedRequest.id}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    className="bg-white rounded-3xl border border-gray-200 shadow-xl overflow-hidden"
                  >
                    {/* Header */}
                    <div className="bg-gradient-to-r from-blue-900 via-indigo-950 to-blue-900 p-6 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-20 rounded-2xl overflow-hidden border-2 border-white/40 shadow-md flex-shrink-0 bg-gray-800">
                          <img
                            src={selectedRequest.photoUrl}
                            alt={selectedRequest.fullName}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="bg-red-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                              DIGITAL MEDIA
                            </span>
                            <span className="bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                              <span className="material-symbols-outlined text-[12px]">verified</span>
                              {selectedRequest.aadhaarVerified ? 'Aadhaar e-KYC Verified' : 'Unverified'}
                            </span>
                          </div>
                          <h2 className="text-2xl font-black mt-1">{selectedRequest.fullName}</h2>
                          <p className="text-xs text-blue-200 mt-0.5">
                            ID: <span className="font-mono font-bold text-white">{selectedRequest.reporterIdNumber}</span> • {selectedRequest.district}, {selectedRequest.state}
                          </p>
                        </div>
                      </div>

                      {/* Top Actions in Header */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          onClick={() => openIdCardPreview(selectedRequest)}
                          className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-1.5 active:scale-95"
                          title="Instant ID Card Modal Preview"
                        >
                          <span className="material-symbols-outlined text-sm">badge</span>
                          ID Card Preview
                        </button>
                        <button
                          onClick={() => onNavigate(View.ReporterIdCard, { reporterId: selectedRequest.userId })}
                          className="px-3 py-2 bg-white/20 hover:bg-white/30 text-white text-xs font-bold rounded-xl backdrop-blur-sm transition-all flex items-center gap-1"
                          title="अलग पूरे पेज में खोलें (Open Full Page)"
                        >
                          <span className="material-symbols-outlined text-sm">open_in_new</span>
                          <span className="hidden sm:inline">Full Page</span>
                        </button>
                      </div>
                    </div>

                    {/* Body Content */}
                    <div className="p-6 md:p-8 space-y-6">
                      {/* e-KYC & Verification Badge Strip */}
                      <div className="bg-emerald-50/70 border border-emerald-200 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                            <span className="material-symbols-outlined">verified_user</span>
                          </div>
                          <div>
                            <p className="text-xs font-black text-emerald-900 uppercase">
                              Aadhaar e-KYC Verified ({selectedRequest.aadhaarEkycMethod.toUpperCase()})
                            </p>
                            <p className="text-[11px] text-emerald-700 font-mono">
                              Aadhaar: {selectedRequest.aadhaarNumber} • Ref Token: {selectedRequest.aadhaarRefId || 'N/A'}
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] text-gray-500 font-bold block uppercase">Submitted Date</span>
                          <span className="text-xs font-bold text-gray-800">
                            {selectedRequest.submittedAt instanceof Date
                              ? selectedRequest.submittedAt.toLocaleDateString()
                              : 'Recent'}
                          </span>
                        </div>
                      </div>

                      {/* Personal & Jurisdiction Details Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Father / Husband</span>
                          <span className="font-extrabold text-gray-900 block mt-0.5">{selectedRequest.fatherOrHusbandName}</span>
                        </div>

                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Date of Birth & Gender</span>
                          <span className="font-bold text-gray-900 block mt-0.5">{selectedRequest.dob} ({selectedRequest.gender})</span>
                        </div>

                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Blood Group</span>
                          <span className="font-extrabold text-red-700 block mt-0.5">{selectedRequest.bloodGroup || 'O+'}</span>
                        </div>

                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Primary Mobile</span>
                          <span className="font-mono font-extrabold text-gray-900 block mt-0.5">{selectedRequest.mobile}</span>
                        </div>

                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Emergency Phone</span>
                          <span className="font-mono font-extrabold text-red-600 block mt-0.5">{selectedRequest.emergencyContact || 'None'}</span>
                        </div>

                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Reporting Beat</span>
                          <span className="font-bold text-blue-900 block mt-0.5 truncate">{selectedRequest.beat}</span>
                        </div>

                        <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100 col-span-2 sm:col-span-3">
                          <span className="text-gray-400 text-[10px] font-bold uppercase block">Residential Address</span>
                          <span className="font-medium text-gray-800 block mt-0.5 leading-relaxed">
                            {selectedRequest.fullAddress}, Block: {selectedRequest.block || 'N/A'}, District: {selectedRequest.district}, State: {selectedRequest.state} - PIN: {selectedRequest.pincode}
                          </span>
                        </div>
                      </div>

                      {/* ========================================================= */}
                      {/* UPLOADED e-KYC DOCUMENTS (AADHAAR & PAN & PHOTO) */}
                      {/* ========================================================= */}
                      <div className="bg-gray-50 rounded-3xl p-5 border border-gray-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-black uppercase tracking-wider text-gray-900 flex items-center gap-1.5">
                            <span className="material-symbols-outlined text-base text-indigo-600">badge</span>
                            अपलोड किए गए e-KYC दस्तावेज (Aadhaar & PAN Documents)
                          </h4>
                          <span className="text-[10px] font-bold text-gray-500 bg-white px-2.5 py-1 rounded-full border">
                            क्लिक करके बड़ा देखें
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {/* Aadhaar Front */}
                          <div className="bg-white p-3 rounded-2xl border border-gray-200 shadow-sm flex flex-col items-center">
                            <span className="text-[10px] font-black text-gray-700 uppercase mb-2">आधार कार्ड (Front)</span>
                            {selectedRequest.aadhaarFrontUrl ? (
                              <div
                                onClick={() => setPreviewDocImage({ url: selectedRequest.aadhaarFrontUrl!, title: 'आधार कार्ड (Front / आगे का भाग)' })}
                                className="w-full h-28 rounded-xl overflow-hidden bg-gray-100 cursor-pointer relative group border hover:border-blue-500"
                              >
                                <img
                                  src={selectedRequest.aadhaarFrontUrl}
                                  alt="Aadhaar Front"
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                                  <span className="material-symbols-outlined text-lg">zoom_in</span>
                                </div>
                              </div>
                            ) : (
                              <div className="w-full h-28 rounded-xl bg-gray-100 flex items-center justify-center text-gray-400 text-xs">
                                No Front Image
                              </div>
                            )}
                          </div>

                          {/* Aadhaar Back */}
                          <div className="bg-white p-3 rounded-2xl border border-gray-200 shadow-sm flex flex-col items-center">
                            <span className="text-[10px] font-black text-gray-700 uppercase mb-2">आधार कार्ड (Back)</span>
                            {selectedRequest.aadhaarBackUrl ? (
                              <div
                                onClick={() => setPreviewDocImage({ url: selectedRequest.aadhaarBackUrl!, title: 'आधार कार्ड (Back / पते वाला भाग)' })}
                                className="w-full h-28 rounded-xl overflow-hidden bg-gray-100 cursor-pointer relative group border hover:border-blue-500"
                              >
                                <img
                                  src={selectedRequest.aadhaarBackUrl}
                                  alt="Aadhaar Back"
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                                  <span className="material-symbols-outlined text-lg">zoom_in</span>
                                </div>
                              </div>
                            ) : (
                              <div className="w-full h-28 rounded-xl bg-gray-100 flex items-center justify-center text-gray-400 text-xs">
                                No Back Image
                              </div>
                            )}
                          </div>

                          {/* PAN Card */}
                          <div className="bg-white p-3 rounded-2xl border border-gray-200 shadow-sm flex flex-col items-center">
                            <div className="flex items-center justify-between w-full mb-2">
                              <span className="text-[10px] font-black text-gray-700 uppercase">पैन कार्ड (PAN)</span>
                              {selectedRequest.panNumber && (
                                <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                                  {selectedRequest.panNumber}
                                </span>
                              )}
                            </div>
                            {selectedRequest.panCardUrl ? (
                              <div
                                onClick={() => setPreviewDocImage({ url: selectedRequest.panCardUrl!, title: `पैन कार्ड (${selectedRequest.panNumber || 'PAN'})` })}
                                className="w-full h-28 rounded-xl overflow-hidden bg-gray-100 cursor-pointer relative group border hover:border-indigo-500"
                              >
                                <img
                                  src={selectedRequest.panCardUrl}
                                  alt="PAN Card"
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                                  <span className="material-symbols-outlined text-lg">zoom_in</span>
                                </div>
                              </div>
                            ) : (
                              <div className="w-full h-28 rounded-xl bg-gray-100 flex items-center justify-center text-gray-400 text-xs">
                                {selectedRequest.panNumber ? 'No Photo (Number Only)' : 'Not Uploaded'}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Signature Preview */}
                      {selectedRequest.signatureUrl && (
                        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-between">
                          <div>
                            <span className="text-xs font-black text-gray-700 block">Reporter Signature</span>
                            <span className="text-[10px] text-gray-400">Card holder verified signature</span>
                          </div>
                          <div className="h-12 w-32 bg-white rounded-xl border border-gray-300 p-1 flex items-center justify-center">
                            <img src={selectedRequest.signatureUrl} alt="Signature" className="max-h-full max-w-full object-contain" />
                          </div>
                        </div>
                      )}

                      {/* ========================================================= */}
                      {/* ADMIN CUSTOMIZATION / EDIT PANEL */}
                      {/* ========================================================= */}
                      <div className="bg-blue-50/50 rounded-3xl p-5 border border-blue-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-black uppercase tracking-wider text-blue-950 flex items-center gap-1.5">
                            <span className="material-symbols-outlined text-base text-blue-600">tune</span>
                            एडमिन कस्टमाइज़ेशन व पदनाम निर्धारण (Admin Controls)
                          </h4>
                          {!isEditing ? (
                            <button
                              onClick={() => setIsEditing(true)}
                              className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1"
                            >
                              <span className="material-symbols-outlined text-sm">edit</span>
                              Edit Details
                            </button>
                          ) : (
                            <button
                              onClick={handleSaveCustomDetails}
                              disabled={actionLoading}
                              className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-sm hover:bg-blue-700"
                            >
                              Save Changes
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          {/* Designation */}
                          <div className="space-y-1">
                            <label className="block text-[11px] font-bold text-gray-700">Assign Designation:</label>
                            {isEditing ? (
                              <input
                                type="text"
                                value={editDesignation}
                                onChange={(e) => setEditDesignation(e.target.value)}
                                className="w-full px-3 py-2 bg-white border border-blue-300 rounded-xl text-xs font-bold text-gray-900"
                              />
                            ) : (
                              <p className="text-xs font-black text-blue-900 bg-white px-3 py-2 rounded-xl border border-gray-200">
                                {selectedRequest.designation}
                              </p>
                            )}
                          </div>

                          {/* Reporter ID */}
                          <div className="space-y-1">
                            <label className="block text-[11px] font-bold text-gray-700">Reporter ID No:</label>
                            {isEditing ? (
                              <input
                                type="text"
                                value={editReporterId}
                                onChange={(e) => setEditReporterId(e.target.value)}
                                className="w-full px-3 py-2 bg-white border border-blue-300 rounded-xl text-xs font-mono font-bold text-gray-900"
                              />
                            ) : (
                              <p className="text-xs font-mono font-black text-gray-900 bg-white px-3 py-2 rounded-xl border border-gray-200">
                                {selectedRequest.reporterIdNumber}
                              </p>
                            )}
                          </div>

                          {/* Valid Till */}
                          <div className="space-y-1">
                            <label className="block text-[11px] font-bold text-gray-700">Validity (Valid Till):</label>
                            {isEditing ? (
                              <input
                                type="date"
                                value={editValidTill}
                                onChange={(e) => setEditValidTill(e.target.value)}
                                className="w-full px-3 py-2 bg-white border border-blue-300 rounded-xl text-xs font-bold text-gray-900"
                              />
                            ) : (
                              <p className="text-xs font-mono font-black text-emerald-800 bg-white px-3 py-2 rounded-xl border border-gray-200">
                                {selectedRequest.validTill}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Admin Notes */}
                        {isEditing && (
                          <div className="space-y-1 pt-1">
                            <label className="block text-[11px] font-bold text-gray-700">Admin Internal Notes:</label>
                            <input
                              type="text"
                              value={adminNotes}
                              onChange={(e) => setAdminNotes(e.target.value)}
                              placeholder="e.g. Verified by District Head"
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl text-xs"
                            />
                          </div>
                        )}
                      </div>

                      {/* Main Action Buttons */}
                      <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-100 flex-wrap">
                        {selectedRequest.status !== 'approved' && (
                          <>
                            <button
                              onClick={handleApprove}
                              disabled={actionLoading}
                              className="flex-1 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50"
                            >
                              {actionLoading ? (
                                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              ) : (
                                <>
                                  <span className="material-symbols-outlined">verified</span>
                                  e-KYC स्वीकृत करें व ID कार्ड जारी करें (Approve)
                                </>
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => openIdCardPreview(selectedRequest)}
                              className="py-4 px-5 bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold text-xs rounded-2xl border border-blue-200 flex items-center justify-center gap-1.5 transition-all shadow-sm"
                              title="स्वीकृति से पहले देखें कि ID कार्ड कैसा दिखेगा"
                            >
                              <span className="material-symbols-outlined text-base">visibility</span>
                              Draft ID Preview
                            </button>
                          </>
                        )}

                        {selectedRequest.status === 'approved' && (
                          <button
                            onClick={() => openIdCardPreview(selectedRequest)}
                            className="flex-1 py-4 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 hover:from-blue-800 hover:to-indigo-900 text-white font-black text-sm rounded-2xl shadow-xl shadow-blue-500/20 flex items-center justify-center gap-2 transition-all active:scale-95"
                          >
                            <span className="material-symbols-outlined text-xl">badge</span>
                            Digital Media ID Card प्रीव्यू व डाउनलोड करें
                          </button>
                        )}

                        <button
                          onClick={() => setShowRejectModal(true)}
                          disabled={actionLoading}
                          className="px-5 py-4 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs rounded-2xl border border-amber-200 transition-all flex items-center justify-center gap-1.5"
                        >
                          <span className="material-symbols-outlined text-base">cancel</span>
                          {selectedRequest.status === 'approved' ? 'कार्ड निरस्त करें (Revoke)' : 'अस्वीकृत करें (Reject)'}
                        </button>

                        <button
                          onClick={() => {
                            setRequestToDelete(selectedRequest);
                            setShowDeleteModal(true);
                          }}
                          disabled={actionLoading}
                          className="px-5 py-4 bg-red-50 hover:bg-red-100 text-red-600 hover:text-red-700 font-bold text-xs rounded-2xl border border-red-200 transition-all flex items-center justify-center gap-1.5"
                          title="Delete Request"
                        >
                          <span className="material-symbols-outlined text-base">delete</span>
                          आवेदन हटाएं (Delete)
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="h-full min-h-[450px] flex flex-col items-center justify-center bg-white rounded-3xl border border-gray-200 text-gray-400 p-12 text-center">
                    <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mb-4 border border-blue-100">
                      <span className="material-symbols-outlined text-4xl">badge</span>
                    </div>
                    <h3 className="text-xl font-black text-gray-900 mb-1">Reporter Verification Desk</h3>
                    <p className="text-xs text-gray-500 max-w-sm">
                      बाईं ओर की सूची से किसी रिपोर्टर का आवेदन चुनें और उनका आधार e-KYC व विवरण देखकर ID कार्ड जारी करें।
                    </p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>

      {/* REJECTION REASON MODAL */}
      <AnimatePresence>
        {showRejectModal && (
          <div className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-6 md:p-8 w-full max-w-md shadow-2xl border border-gray-200"
            >
              <div className="flex items-center gap-3 text-red-600 mb-4">
                <div className="w-10 h-10 rounded-2xl bg-red-100 flex items-center justify-center">
                  <span className="material-symbols-outlined">warning</span>
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900">आवेदन अस्वीकृत करें</h3>
                  <p className="text-xs text-gray-500">कृपया कारण स्पष्ट रूप से लिखें</p>
                </div>
              </div>

              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="उदा. फोटो अस्पष्ट है / आधार विवरण अधूरा है / कार्यक्षेत्र स्पष्ट नहीं है..."
                rows={4}
                className="w-full p-4 bg-gray-50 border border-gray-300 rounded-2xl text-xs font-medium focus:ring-2 focus:ring-red-500 outline-none mb-6"
              ></textarea>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowRejectModal(false)}
                  className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs"
                >
                  रद्द करें (Cancel)
                </button>
                <button
                  type="button"
                  onClick={handleReject}
                  disabled={actionLoading || !rejectReason.trim()}
                  className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-md disabled:opacity-50"
                >
                  {actionLoading ? 'प्रोसेसिंग...' : 'अस्वीकार करें (Confirm)'}
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* DELETE CONFIRMATION MODAL */}
        {showDeleteModal && requestToDelete && (
          <div className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-6 md:p-8 w-full max-w-md shadow-2xl border border-gray-200"
            >
              <div className="flex items-center gap-3 text-red-600 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-red-100 flex items-center justify-center flex-shrink-0 text-red-600">
                  <span className="material-symbols-outlined text-2xl">delete_forever</span>
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900">रिपोर्टर आवेदन हटाएं?</h3>
                  <p className="text-xs text-gray-500">यह क्रिया स्थायी है और पूर्ववत नहीं की जा सकती।</p>
                </div>
              </div>

              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 mb-6 space-y-1 text-xs">
                <p className="font-extrabold text-gray-900">{requestToDelete.fullName}</p>
                <p className="text-gray-500">ID: <span className="font-mono font-bold text-gray-800">{requestToDelete.reporterIdNumber}</span></p>
                <p className="text-gray-500">जिला / राज्य: <span className="font-bold text-gray-800">{requestToDelete.district}, {requestToDelete.state}</span></p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowDeleteModal(false);
                    setRequestToDelete(null);
                  }}
                  className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs"
                >
                  रद्द करें (Cancel)
                </button>
                <button
                  type="button"
                  onClick={handleDeleteRequest}
                  disabled={actionLoading}
                  className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-md disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {actionLoading ? 'हटाया जा रहा है...' : 'हां, स्थायी रूप से हटाएं'}
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* Document Full Image Lightbox */}
        {previewDocImage && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl max-w-2xl w-full p-5 shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-3">
                <h4 className="font-black text-gray-900 text-sm">{previewDocImage.title}</h4>
                <button
                  onClick={() => setPreviewDocImage(null)}
                  className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500"
                >
                  <span className="material-symbols-outlined text-base">close</span>
                </button>
              </div>
              <div className="rounded-2xl overflow-hidden max-h-[75vh] flex items-center justify-center bg-gray-950">
                <img
                  src={previewDocImage.url}
                  alt={previewDocImage.title}
                  className="max-h-full max-w-full object-contain"
                />
              </div>
            </motion.div>
          </div>
        )}

        {/* Full Interactive HD ID Card Preview Modal */}
        <ReporterIdCardModal
          isOpen={showCardModal}
          onClose={() => setShowCardModal(false)}
          reporter={cardModalReporter}
          reportersList={
            activeTab === 'approved'
              ? requests.filter((r) => r.status === 'approved')
              : filteredRequests
          }
          onSelectReporter={(rep) => setCardModalReporter(rep)}
          onNavigate={onNavigate}
          onApprove={
            cardModalReporter && cardModalReporter.status !== 'approved'
              ? handleApprove
              : undefined
          }
        />
      </AnimatePresence>
    </div>
  );
};

export default ManageReportersPage;
