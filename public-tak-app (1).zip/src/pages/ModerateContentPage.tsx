
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { db, storage, serverTimestamp } from '../firebaseConfig';
import { User } from '../types';
import ConfirmationModal from '../components/ConfirmationModal';

interface Report {
    id: string;
    postId: string;
    postTitle: string;
    contentType?: 'post' | 'video';
    reporterId: string;
    reporterName: string;
    reason: string;
    category?: string;
    severity?: string;
    isAiFlagged?: boolean;
    authorId?: string;
    authorName?: string;
    createdAt: {
        toDate: () => Date;
    } | null;
}

interface ModerateContentPageProps {
    onBack: () => void;
    currentUser: User | null;
}

const SkeletonReport = () => (
    <div className="glass-card p-6 border-l-4 border-gray-300 animate-pulse">
        <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div className="w-full">
                <div className="h-6 w-3/4 bg-gray-200 rounded mb-2"></div>
                <div className="h-4 w-1/3 bg-gray-200 rounded mb-4"></div>
                <div className="p-4 bg-gray-100 rounded-lg h-24"></div>
            </div>
            <div className="flex gap-2 shrink-0">
                <div className="h-10 w-20 bg-gray-200 rounded"></div>
                <div className="h-10 w-24 bg-gray-200 rounded"></div>
            </div>
        </div>
    </div>
);

const ModerateContentPage: React.FC<ModerateContentPageProps> = ({ onBack, currentUser }) => {
    const [reports, setReports] = useState<Report[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState<'all' | 'ai' | 'user'>('all');
    
    // State for deleting a post
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [itemToDelete, setItemToDelete] = useState<{ reportId: string; postId: string; contentType?: string } | null>(null);

    // State for approving / unhiding
    const [isApproveModalOpen, setIsApproveModalOpen] = useState(false);
    const [itemToApprove, setItemToApprove] = useState<Report | null>(null);

    // State for dismissing a report
    const [isDismissModalOpen, setIsDismissModalOpen] = useState(false);
    const [reportToDismissId, setReportToDismissId] = useState<string | null>(null);

    useEffect(() => {
        if (currentUser?.role !== 'admin') {
            setLoading(false);
            return;
        }
        const q = db.collection('reports').orderBy('createdAt', 'desc');
        const unsubscribe = q.onSnapshot((snapshot) => {
            const reportsData = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            } as Report));
            setReports(reportsData);
            setLoading(false);
            setError(null);
        }, (err) => {
            console.error("Firestore error in ModerateContentPage:", err);
            setError("Failed to load reports. Ensure your Firestore security rules grant admin access.");
            setLoading(false);
        });
        return () => unsubscribe();
    }, [currentUser]);

    const openApproveModal = (report: Report) => {
        setItemToApprove(report);
        setIsApproveModalOpen(true);
    };

    const handleApproveContent = async () => {
        if (!itemToApprove) return;
        const { id: reportId, postId, contentType, postTitle, authorId } = itemToApprove;

        try {
            // Unhide and unflag in target collection
            const collectionName = contentType === 'video' ? 'videos' : 'posts';
            const docRef = db.collection(collectionName).doc(postId);
            const docSnap = await docRef.get();

            if (docSnap.exists) {
                await docRef.update({
                    flagged: false,
                    isHidden: false,
                    status: 'published',
                    adminApproved: true,
                    adminApprovedAt: serverTimestamp()
                });
            }

            // Notify author
            if (authorId) {
                try {
                    await db.collection('users').doc(authorId).collection('notifications').add({
                        type: 'content_approved',
                        title: '✅ आपकी पोस्ट स्वीकृत (Approved)',
                        body: `एडमिन समीक्षा के बाद आपकी पोस्ट/वीडियो "${postTitle}" को स्वीकृत कर सार्वजनिक कर दिया गया है।`,
                        read: false,
                        createdAt: serverTimestamp()
                    });
                } catch (notifErr) {
                    console.warn("Error sending author approval notification:", notifErr);
                }
            }

            // Delete report
            await db.collection('reports').doc(reportId).delete();
            alert("सामग्री स्वीकृत और सार्वजनिक कर दी गई है! (Approved and Unhidden successfully)");
        } catch (err) {
            console.error("Error approving content:", err);
            alert("Failed to approve content. Please try again.");
        } finally {
            setIsApproveModalOpen(false);
            setItemToApprove(null);
        }
    };

    const openDismissModal = (reportId: string) => {
        setReportToDismissId(reportId);
        setIsDismissModalOpen(true);
    };

    const handleConfirmDismiss = async () => {
        if (!reportToDismissId) return;
        try {
            await db.collection('reports').doc(reportToDismissId).delete();
        } catch (error) {
            console.error("Error dismissing report:", error);
            alert("Failed to dismiss report. Please try again.");
        } finally {
            setIsDismissModalOpen(false);
            setReportToDismissId(null);
        }
    };

    const handleDeletePost = async () => {
        if (!itemToDelete) return;
        const { reportId, postId } = itemToDelete;

        try {
            // 1. Try deleting from posts collection first
            const postRef = db.collection('posts').doc(postId);
            const postSnap = await postRef.get();

            if (postSnap.exists) {
                const postData = postSnap.data();
                if (postData?.thumbnailUrl && postData.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                    try {
                        const storageRef = storage.refFromURL(postData.thumbnailUrl);
                        await storageRef.delete();
                    } catch (storageErr) {
                        console.warn("Could not delete thumbnail:", storageErr);
                    }
                }
                await postRef.delete();
            } else {
                // 2. Try deleting from videos collection if not found in posts
                const videoRef = db.collection('videos').doc(postId);
                const videoSnap = await videoRef.get();

                if (videoSnap.exists) {
                    const videoData = videoSnap.data();
                    if (videoData?.thumbnailUrl && videoData.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                        try {
                            const storageRef = storage.refFromURL(videoData.thumbnailUrl);
                            await storageRef.delete();
                        } catch (storageErr) {
                            console.warn("Could not delete video thumbnail:", storageErr);
                        }
                    }
                    if (videoData?.videoUrl && videoData.videoUrl.includes('firebasestorage.googleapis.com')) {
                        try {
                            const storageRef = storage.refFromURL(videoData.videoUrl);
                            await storageRef.delete();
                        } catch (storageErr) {
                            console.warn("Could not delete video file:", storageErr);
                        }
                    }
                    await videoRef.delete();
                }
            }
           
            // 3. Delete report document
            await db.collection('reports').doc(reportId).delete();

        } catch (error) {
            console.error("Error deleting reported item:", error);
            alert("Failed to delete item. Check Firestore rules.");
        } finally {
            setIsDeleteModalOpen(false);
            setItemToDelete(null);
        }
    };

    const openDeleteModal = (reportId: string, postId: string, contentType?: string) => {
        setItemToDelete({ reportId, postId, contentType });
        setIsDeleteModalOpen(true);
    };

    if (currentUser?.role !== 'admin') {
        return (
             <div className="flex flex-col h-full bg-transparent">
                <Header title="Moderate Content" showBackButton onBack={onBack} />
                <main className="flex-grow flex items-center justify-center p-5 text-center">
                    <div className="glass-card p-10">
                        <span className="material-symbols-outlined text-6xl text-red-500 mb-4">lock</span>
                        <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
                        <p className="text-red-600 font-semibold">You do not have permission to access this page.</p>
                    </div>
                </main>
            </div>
        );
    }

    const filteredReports = reports.filter(report => {
        if (activeTab === 'ai') return report.isAiFlagged;
        if (activeTab === 'user') return !report.isAiFlagged;
        return true;
    });

    const aiCount = reports.filter(r => r.isAiFlagged).length;
    const userCount = reports.filter(r => !r.isAiFlagged).length;

    const renderContent = () => {
        if (loading) {
            return (
                <div className="space-y-6">
                    {[1, 2, 3].map(i => <SkeletonReport key={i} />)}
                </div>
            );
        }
        if (error) {
            return <div className="text-center text-red-700 bg-red-100 p-4 rounded-lg"><p>{error}</p></div>;
        }
        if (filteredReports.length > 0) {
            return (
                <div className="space-y-6">
                    {filteredReports.map(report => {
                        const isAi = report.isAiFlagged;
                        return (
                            <div key={report.id} className={`glass-card p-6 border-l-4 transition-all ${
                                isAi ? 'border-amber-500 bg-amber-50/20' : 'border-red-500'
                            }`}>
                                <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                                            {isAi ? (
                                                <span className="bg-gradient-to-r from-amber-600 to-red-600 text-white text-[11px] font-black px-2.5 py-1 rounded-lg shadow-sm flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-sm">smart_toy</span>
                                                    <span>AI Safety Alert</span>
                                                </span>
                                            ) : (
                                                <span className="bg-red-100 text-red-700 text-[11px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 border border-red-200">
                                                    <span className="material-symbols-outlined text-sm">flag</span>
                                                    <span>User Report</span>
                                                </span>
                                            )}

                                            <span className={`text-[10px] px-2.5 py-1 rounded-lg font-black uppercase tracking-wider ${
                                                report.contentType === 'video' 
                                                    ? 'bg-purple-100 text-purple-700 border border-purple-200' 
                                                    : 'bg-blue-100 text-blue-700 border border-blue-200'
                                            }`}>
                                                {report.contentType === 'video' ? '📹 Video' : '📰 Article'}
                                            </span>

                                            {report.severity && (
                                                <span className="text-[10px] px-2 py-0.5 rounded font-black uppercase bg-red-600 text-white">
                                                    {report.severity} risk
                                                </span>
                                            )}
                                        </div>

                                        <h3 className="font-bold text-lg text-gray-900 leading-snug mb-1">{report.postTitle}</h3>
                                        <p className="text-xs text-gray-500">
                                            Item ID: <span className="font-mono bg-gray-100 px-1 py-0.5 rounded">{report.postId}</span>
                                            {report.authorName && (
                                                <span className="ml-2 font-medium text-gray-700">| Author: {report.authorName}</span>
                                            )}
                                        </p>
                                        
                                        <div className="mt-3 p-4 bg-white/80 dark:bg-slate-900/80 rounded-2xl border border-gray-200/80 shadow-sm">
                                            <p className="font-black text-gray-700 dark:text-gray-200 text-xs uppercase tracking-wide mb-1 flex items-center gap-1">
                                                <span className="material-symbols-outlined text-sm text-red-500">gavel</span>
                                                Violation Details / Reason
                                            </p>
                                            <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                                                "{report.reason}"
                                            </p>
                                            <p className="text-xs text-gray-500 mt-2 border-t border-gray-100 pt-2 flex justify-between items-center">
                                                <span>Reported Source: {report.reporterName}</span>
                                                <span>{report.createdAt ? report.createdAt.toDate().toLocaleString() : 'Just now'}</span>
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <div className="flex flex-col gap-2.5 w-full md:w-auto shrink-0 md:min-w-[180px]">
                                        {/* Approve / Unhide Button */}
                                        <button 
                                            onClick={() => openApproveModal(report)} 
                                            className="w-full px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl shadow-md transition-all transform active:scale-95 text-xs flex items-center justify-center gap-1.5"
                                        >
                                            <span className="material-symbols-outlined text-base">verified</span>
                                            <span>Approve & Unhide</span>
                                        </button>

                                        {/* Dismiss Report */}
                                        <button 
                                            onClick={() => openDismissModal(report.id)} 
                                            className="w-full px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all text-xs flex items-center justify-center gap-1.5 border border-slate-300"
                                        >
                                            <span className="material-symbols-outlined text-base">close</span>
                                            <span>Dismiss Report</span>
                                        </button>

                                        {/* Delete Post/Video */}
                                        <button 
                                            onClick={() => openDeleteModal(report.id, report.postId, report.contentType)} 
                                            className="w-full px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl transition-all shadow-sm text-xs flex items-center justify-center gap-1.5"
                                        >
                                            <span className="material-symbols-outlined text-base">delete_forever</span>
                                            <span>Delete Permanently</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            );
        }
        return (
            <div className="text-center py-16 glass-card flex flex-col items-center">
                <span className="material-symbols-outlined text-6xl text-green-500 mb-4">verified_user</span>
                <h3 className="text-xl font-bold text-gray-800">All Clear!</h3>
                <p className="text-gray-600 mt-1">There are no flagged items or reports to review right now.</p>
            </div>
        );
    };

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title="Moderate Content" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-5 md:p-8 pb-20">
                <div className="w-full max-w-5xl mx-auto">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                        <div>
                            <h2 className="text-2xl font-extrabold text-gray-900">Content Moderation & Safety</h2>
                            <p className="text-xs text-gray-500 mt-0.5">Review AI-flagged harmful articles/videos and user reports</p>
                        </div>

                        {/* Filter Tabs */}
                        <div className="flex bg-gray-200/80 p-1 rounded-2xl gap-1 shrink-0">
                            <button
                                onClick={() => setActiveTab('all')}
                                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                                    activeTab === 'all' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600 hover:text-gray-900'
                                }`}
                            >
                                <span>All ({reports.length})</span>
                            </button>
                            <button
                                onClick={() => setActiveTab('ai')}
                                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                                    activeTab === 'ai' ? 'bg-amber-500 text-white shadow-sm' : 'text-gray-600 hover:text-amber-700'
                                }`}
                            >
                                <span className="material-symbols-outlined text-xs">smart_toy</span>
                                <span>AI Flagged ({aiCount})</span>
                            </button>
                            <button
                                onClick={() => setActiveTab('user')}
                                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                                    activeTab === 'user' ? 'bg-red-600 text-white shadow-sm' : 'text-gray-600 hover:text-red-700'
                                }`}
                            >
                                <span className="material-symbols-outlined text-xs">flag</span>
                                <span>User Reports ({userCount})</span>
                            </button>
                        </div>
                    </div>

                    {renderContent()}
                </div>
            </main>

            {/* Approval Modal */}
            <ConfirmationModal
                isOpen={isApproveModalOpen}
                onClose={() => setIsApproveModalOpen(false)}
                onConfirm={handleApproveContent}
                title="Confirm Content Approval"
                message={`Are you sure you want to approve "${itemToApprove?.postTitle}"? It will be unhidden and made publicly visible on the platform.`}
                confirmButtonText="Approve & Publish"
                confirmButtonColor="bg-emerald-600 hover:bg-emerald-700"
            />

            {/* Delete Modal */}
            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleDeletePost}
                title="Confirm Item Deletion"
                message="Are you sure you want to delete this content? This action is permanent and will remove the video/article files as well."
                confirmButtonText="Delete Permanently"
            />

            {/* Dismiss Modal */}
            <ConfirmationModal
                isOpen={isDismissModalOpen}
                onClose={() => setIsDismissModalOpen(false)}
                onConfirm={handleConfirmDismiss}
                title="Confirm Dismissal"
                message="Are you sure you want to dismiss this report? The item will remain in its current state, but the report will be deleted."
                confirmButtonText="Dismiss Report"
                confirmButtonColor="bg-blue-600 hover:bg-blue-700"
            />
        </div>
    );
};

export default ModerateContentPage;
