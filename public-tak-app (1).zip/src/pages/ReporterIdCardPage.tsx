import React, { useState, useEffect, useRef } from 'react';
import { User, View, ReporterDetails } from '../types';
import Header from '../components/Header';
import { db } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { APP_LOGO_URL } from '../utils/constants';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface ReporterIdCardPageProps {
  onBack: () => void;
  currentUser: User | null;
  onNavigate: (view: View) => void;
  reporterIdFromQuery?: string;
}

export const ReporterIdCardPage: React.FC<ReporterIdCardPageProps> = ({
  onBack,
  currentUser,
  onNavigate,
  reporterIdFromQuery,
}) => {
  const { showToast } = useToast();
  const [reporter, setReporter] = useState<ReporterDetails | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeSide, setActiveSide] = useState<'both' | 'front' | 'back'>('both');

  const frontCardRef = useRef<HTMLDivElement | null>(null);
  const backCardRef = useRef<HTMLDivElement | null>(null);
  const bothCardsContainerRef = useRef<HTMLDivElement | null>(null);

  const targetUid = reporterIdFromQuery || currentUser?.uid;

  useEffect(() => {
    if (!targetUid) {
      setLoading(false);
      return;
    }

    const fetchReporterData = async () => {
      try {
        // 1. Try local cache first for instant load
        const cached = localStorage.getItem(`local_reporter_request_${targetUid}`);
        if (cached) {
          try {
            const parsed = JSON.parse(cached);
            setReporter(parsed);
          } catch (_) {}
        }

        // 2. Try to fetch from verified 'reporters' collection first
        let doc = await db.collection('reporters').doc(targetUid).get();
        if (!doc.exists) {
          // 3. If not yet mirrored, check 'reporter_requests'
          doc = await db.collection('reporter_requests').doc(targetUid).get();
        }
        if (!doc.exists) {
          const q1 = await db.collection('reporters').where('userId', '==', targetUid).limit(1).get();
          if (!q1.empty) doc = q1.docs[0];
        }
        if (!doc.exists) {
          const q2 = await db.collection('reporter_requests').where('userId', '==', targetUid).limit(1).get();
          if (!q2.empty) doc = q2.docs[0];
        }
        if (!doc.exists) {
          const q3 = await db.collection('reporters').where('reporterIdNumber', '==', targetUid).limit(1).get();
          if (!q3.empty) doc = q3.docs[0];
        }
        if (!doc.exists) {
          const q4 = await db.collection('reporter_requests').where('reporterIdNumber', '==', targetUid).limit(1).get();
          if (!q4.empty) doc = q4.docs[0];
        }

        if (doc.exists) {
          const data = doc.data() as ReporterDetails;
          setReporter({
            ...data,
            id: doc.id,
            submittedAt: data.submittedAt?.toDate ? data.submittedAt.toDate() : new Date(),
            approvedAt: data.approvedAt?.toDate ? data.approvedAt.toDate() : undefined,
          });
        }
      } catch (err) {
        console.error('Error fetching reporter ID card:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchReporterData();
  }, [targetUid]);

  // Fallback data if user is previewing or applying
  const displayReporter: ReporterDetails = reporter || {
    id: currentUser?.uid || 'demo-reporter',
    userId: currentUser?.uid || 'demo-reporter',
    reporterIdNumber: currentUser?.reporterIdNumber || 'PT-DM-2026-0849',
    fullName: currentUser?.name || 'डिजिटल मीडिया रिपोर्टर',
    fatherOrHusbandName: 'श्री रामेश्वर प्रसाद',
    dob: '1995-08-15',
    gender: currentUser?.gender || 'Male',
    bloodGroup: 'B+',
    mobile: currentUser?.phone || '9876543210',
    email: currentUser?.email || 'reporter@publictak.app',
    emergencyContact: '9876543211',
    aadhaarNumber: 'XXXX-XXXX-8821',
    aadhaarVerified: true,
    aadhaarEkycMethod: 'aadhaar_otp',
    aadhaarRefId: 'UIDAI-994821',
    state: currentUser?.preferredState || 'Bihar',
    district: currentUser?.preferredDistrict || 'Patna',
    block: currentUser?.preferredBlock || 'Sadar',
    pincode: '800001',
    fullAddress: 'वार्ड संख्या 12, मेन रोड, पटना, बिहार - 800001',
    designation: currentUser?.reporterDesignation || 'District Bureau Chief',
    beat: 'General / Digital News (समग्र समाचार)',
    photoUrl: currentUser?.profilePicUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    signatureUrl: '',
    organizationName: 'Public Tak App',
    organizationLogo: currentUser?.profilePicUrl || APP_LOGO_URL,
    authorizedSignatoryName: 'Editor-in-Chief / Director',
    status: (currentUser?.reporterStatus as any) || 'approved',
    submittedAt: new Date(),
    validFrom: '2026-01-01',
    validTill: '2028-12-31',
    qrCodeData: `https://publictak.app/?reporterVerify=${currentUser?.uid || 'demo'}&ref=PT-DM-2026-0849`
  };

  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Dedicated Print Function with Font and Image Preloading
  const handlePrint = async () => {
    try {
      if ((document as any).fonts && (document as any).fonts.ready) {
        await (document as any).fonts.ready;
      }
    } catch (_) {}
    window.print();
  };

  // High-Resolution PDF Download Function (Smooth on Android & Web)
  const handleDownloadPDF = async () => {
    if (isGeneratingPdf) return;
    try {
      setIsGeneratingPdf(true);
      showToast("HD प्रिंट PDF तैयार किया जा रहा है...", "info");

      if ((document as any).fonts && (document as any).fonts.ready) {
        await (document as any).fonts.ready;
      }

      const container = bothCardsContainerRef.current;
      if (!container) throw new Error("Card container not found");

      const canvas = await html2canvas(container, {
        scale: 2.5,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const imgProps = pdf.getImageProperties(imgData);
      const imgHeight = (imgProps.height * (pdfWidth - 20)) / imgProps.width;

      pdf.addImage(imgData, 'JPEG', 10, 20, pdfWidth - 20, imgHeight);
      pdf.save(`PublicTak_Reporter_ID_${displayReporter.reporterIdNumber || 'Card'}.pdf`);
      showToast("ID कार्ड PDF सफलतापूर्वक डाउनलोड हो गया!", "success");
    } catch (err: any) {
      console.error("PDF generation failed:", err);
      showToast("PDF बनाने में समस्या आई, कृपया 'प्रिंट करें' का उपयोग करें।", "error");
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Profile Logo & Name of the user (Channel / Profile details for Header)
  const userProfileLogo = currentUser?.profilePicUrl || APP_LOGO_URL;
  const userProfileDisplayName = currentUser?.name || 'पब्लिक तक क्रिएटर';

  if (loading) {
    return (
      <div className="flex flex-col h-full bg-white">
        <Header title="डिजिटल मीडिया ID कार्ड" showBackButton onBack={onBack} />
        <div className="flex-1 flex items-center justify-center">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-100">
      <div className="id-card-no-print">
        <Header
          title="डिजिटल मीडिया पहचान पत्र"
          showBackButton
          onBack={onBack}
          currentUser={currentUser}
        />
      </div>

      <main className="flex-grow overflow-y-auto p-3 sm:p-6 md:p-8 pb-32">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Admin Mode Inspection Banner */}
          {(currentUser?.role === 'admin' || !!reporterIdFromQuery) && (
            <div className="id-card-no-print bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white p-4 sm:p-5 rounded-3xl border border-blue-800/60 shadow-md flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400 shrink-0">
                  <span className="material-symbols-outlined text-xl">admin_panel_settings</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                      Admin ID Inspection
                    </span>
                    <span className="text-xs text-blue-200 font-mono">
                      {displayReporter.reporterIdNumber}
                    </span>
                  </div>
                  <p className="text-sm font-black text-white mt-0.5">
                    Viewing ID Card: {displayReporter.fullName} ({displayReporter.designation})
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onNavigate(View.ManageReporters)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow transition-all flex items-center gap-1.5"
                >
                  <span className="material-symbols-outlined text-sm">arrow_back</span>
                  <span>वापस रिपोर्टर प्रबंधन</span>
                </button>
              </div>
            </div>
          )}

          {/* Top Info & Action Toolbar */}
          <div className="id-card-no-print flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-5 md:p-6 rounded-3xl border border-gray-200 shadow-sm">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-blue-600 text-white text-[11px] font-black uppercase px-3 py-1 rounded-full tracking-wider shadow-sm">
                  PUBLIC TAK APP
                </span>
                <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">verified</span> e-KYC Verified
                </span>
                <span className="bg-amber-100 text-amber-900 text-[11px] font-bold px-2.5 py-1 rounded-full">
                  आधिकारिक ID कार्ड
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-gray-900 mt-2">
                डिजिटल मीडिया पहचान पत्र (ID Card)
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                ID Number: <span className="font-mono font-bold text-gray-900">{displayReporter.reporterIdNumber}</span> • {displayReporter.district}, {displayReporter.state}
              </p>
            </div>

            {/* Action Buttons - Dedicated Print & PDF Download Buttons */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <button
                onClick={handleDownloadPDF}
                disabled={isGeneratingPdf}
                className="flex-1 md:flex-none px-5 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 text-white font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                title="Download High-Resolution ID Card PDF"
              >
                <span className="material-symbols-outlined text-xl">
                  {isGeneratingPdf ? 'hourglass_top' : 'download'}
                </span>
                <span>{isGeneratingPdf ? 'तैयार हो रहा है...' : 'PDF डाउनलोड करें'}</span>
              </button>

              <button
                onClick={handlePrint}
                className="flex-1 md:flex-none px-5 py-3.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 hover:from-blue-800 hover:to-indigo-900 text-white font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-blue-500/25 transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                title="Print ID Card (Front & Back)"
              >
                <span className="material-symbols-outlined text-xl">print</span>
                <span>ID Card प्रिंट करें</span>
              </button>

              {currentUser?.role !== 'admin' && (
                <button
                  onClick={() => onNavigate(View.ReporterRegistration)}
                  className="p-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-2xl transition-colors shrink-0"
                  title="विवरण संपादित करें (Edit Details)"
                >
                  <span className="material-symbols-outlined text-lg">edit</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Side Selector */}
          <div className="id-card-no-print flex items-center justify-between flex-wrap gap-3 bg-white px-4 py-3 rounded-2xl border border-gray-200">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-700">
              <span className="material-symbols-outlined text-blue-600 text-base">visibility</span>
              <span>कार्ड साइड प्रीव्यू (Preview Mode):</span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="inline-flex bg-gray-100 p-1 rounded-xl">
                <button
                  onClick={() => setActiveSide('both')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeSide === 'both' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  दोनों साइड (Both)
                </button>
                <button
                  onClick={() => setActiveSide('front')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeSide === 'front' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  आगे (Front)
                </button>
                <button
                  onClick={() => setActiveSide('back')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    activeSide === 'back' ? 'bg-blue-600 text-white shadow' : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  पीछे (Back)
                </button>
              </div>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* ID CARDS CONTAINER (PRINTABLE SHEET FOR FRONT & BACK)                     */}
          {/* ========================================================================= */}
          <div
            ref={bothCardsContainerRef}
            id="printable-id-card-sheet"
            className="printable-id-card-sheet p-4 sm:p-8 md:p-10 bg-gradient-to-br from-slate-200 via-gray-100 to-slate-200 rounded-3xl border border-gray-300 shadow-inner flex flex-wrap items-center justify-center gap-6 md:gap-8 overflow-x-auto"
          >
            {/* --------------------------------------------------------------------- */}
            {/* CARD 1: FRONT SIDE (PREMIUM DIGITAL MEDIA IDENTITY CARD)               */}
            {/* --------------------------------------------------------------------- */}
            <div
              ref={frontCardRef}
              className={`id-card-item w-[338px] h-[538px] bg-white rounded-3xl shadow-2xl border-2 border-slate-300 relative flex-col justify-between overflow-hidden text-gray-900 select-none font-sans shrink-0 ${
                activeSide === 'back' ? 'hidden print:flex' : 'flex'
              }`}
              style={{
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.05)',
                boxSizing: 'border-box',
                WebkitPrintColorAdjust: 'exact',
                printColorAdjust: 'exact',
              }}
            >
                {/* Top Lanyard Slot Simulation (Hole Punch Area) */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-2 bg-gray-300 rounded-full border border-gray-400 shadow-inner z-30 opacity-90"></div>

                {/* Top Header Section with safe padding so lanyard hole doesn't touch the line */}
                <div className="pt-6 pb-2 px-3 bg-gradient-to-b from-blue-900 via-indigo-950 to-blue-900 text-white relative text-center flex flex-col items-center">
                  {/* Holographic Top Stripe - Placed safely below lanyard punch area */}
                  <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500 rounded-full mb-2 shadow-sm"></div>

                  {/* Centered User Profile Logo & Header Titles */}
                  <div className="flex flex-col items-center justify-center text-center w-full">
                    <div className="flex items-center justify-center gap-2 mb-0.5">
                      <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-amber-300 shadow-md bg-white shrink-0 flex items-center justify-center">
                        <img
                          src={userProfileLogo}
                          alt="User Profile Logo"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="text-center">
                        <h3
                          className="text-[12.5px] font-black uppercase tracking-wider text-amber-300 m-0 p-0 block text-center"
                          style={{ lineHeight: '15px' }}
                        >
                          PUBLIC TAK APP
                        </h3>
                        <h4
                          className="text-[13px] font-black uppercase tracking-wide text-white drop-shadow-sm truncate max-w-[210px] m-0 p-0 block mt-0.5 text-center"
                          style={{ lineHeight: '16px' }}
                        >
                          {userProfileDisplayName}
                        </h4>
                      </div>
                    </div>

                    <p
                      className="text-[8.5px] text-blue-200 font-bold tracking-tight m-0 p-0 block text-center mt-0.5"
                      style={{ lineHeight: '12px' }}
                    >
                      पब्लिक तक डिजिटल मीडिया रिपोर्टर
                    </p>
                  </div>

                  {/* Red Digital Media Badge Bar */}
                  <div className="mt-1.5 w-full bg-red-600 text-white text-center py-0.5 rounded-lg shadow-sm border border-red-400/40">
                    <span
                      className="text-[10px] font-black uppercase tracking-wider block m-0 p-0 text-center"
                      style={{ lineHeight: '14px' }}
                    >
                      DIGITAL MEDIA IDENTITY CARD
                    </span>
                  </div>
                </div>

                {/* Card Body / Reporter Info */}
                <div className="px-3.5 py-1.5 flex-1 flex flex-col justify-between relative overflow-hidden">
                  {/* Watermark Logo Background - Remains Public Tak Official Logo */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                    <img src={APP_LOGO_URL} alt="Public Tak Watermark" className="w-44 h-44 object-contain grayscale" />
                  </div>

                  {/* Photo & ID Badges */}
                  <div className="flex items-center justify-center gap-3 relative z-10 my-0.5">
                    <div className="w-24 h-32 rounded-2xl overflow-hidden border-2 border-blue-900 shadow-lg bg-gray-100 relative shrink-0">
                      <img
                        src={displayReporter.photoUrl}
                        alt={displayReporter.fullName}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div
                        className="absolute bottom-0 inset-x-0 bg-blue-900/90 text-white text-[8px] font-black text-center py-0.5 uppercase tracking-wider"
                        style={{ lineHeight: '11px' }}
                      >
                        e-KYC VERIFIED
                      </div>
                    </div>

                    {/* Quick Badges beside photo */}
                    <div className="space-y-1.5 text-left flex-1 min-w-0">
                      <div className="bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-xl">
                        <span
                          className="text-[8.5px] font-bold text-gray-500 uppercase block m-0 p-0"
                          style={{ lineHeight: '12px' }}
                        >
                          Reporter ID:
                        </span>
                        <span
                          className="text-[11px] font-mono font-black text-blue-900 block truncate m-0 p-0"
                          style={{ lineHeight: '15px' }}
                        >
                          {displayReporter.reporterIdNumber}
                        </span>
                      </div>

                      <div className="bg-red-50 border border-red-200 px-2.5 py-1 rounded-xl">
                        <span
                          className="text-[8.5px] font-bold text-gray-500 uppercase block m-0 p-0"
                          style={{ lineHeight: '12px' }}
                        >
                          Blood Group:
                        </span>
                        <span
                          className="text-[11px] font-black text-red-700 block m-0 p-0"
                          style={{ lineHeight: '15px' }}
                        >
                          {displayReporter.bloodGroup || 'O+'}
                        </span>
                      </div>

                      <div className="bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-xl">
                        <span
                          className="text-[8.5px] font-bold text-gray-500 uppercase block m-0 p-0"
                          style={{ lineHeight: '12px' }}
                        >
                          Valid Till:
                        </span>
                        <span
                          className="text-[11px] font-mono font-black text-emerald-800 block m-0 p-0"
                          style={{ lineHeight: '15px' }}
                        >
                          {displayReporter.validTill || '2028-12-31'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Reporter Name & Designation */}
                  <div className="text-center relative z-10 my-0.5">
                    <h2
                      className="text-[15px] font-black text-gray-950 uppercase tracking-tight truncate px-2 m-0 p-0 block"
                      style={{ lineHeight: '19px' }}
                    >
                      {displayReporter.fullName}
                    </h2>
                    <div className="inline-block mt-0.5 px-3 py-0.5 bg-gradient-to-r from-blue-700 to-indigo-800 text-white text-[10px] font-black uppercase rounded-full shadow-sm">
                      <span className="block" style={{ lineHeight: '13px' }}>
                        {displayReporter.designation}
                      </span>
                    </div>
                  </div>

                  {/* Details Grid */}
                  <div className="bg-gray-50 border border-gray-200 rounded-xl p-2 space-y-1 relative z-10 text-[9.5px]">
                    <div className="flex justify-between items-center border-b border-gray-200/60 pb-0.5">
                      <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Jurisdiction (क्षेत्र):</span>
                      <span className="font-extrabold text-gray-900 text-right truncate max-w-[160px]" style={{ lineHeight: '13px' }}>
                        {displayReporter.district}, {displayReporter.state}
                      </span>
                    </div>

                    <div className="flex justify-between items-center border-b border-gray-200/60 pb-0.5">
                      <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Beat / Category:</span>
                      <span className="font-extrabold text-gray-900 truncate max-w-[160px] text-right" style={{ lineHeight: '13px' }}>
                        {displayReporter.beat}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Mobile / संपर्क:</span>
                      <span className="font-mono font-extrabold text-gray-900" style={{ lineHeight: '13px' }}>{displayReporter.mobile}</span>
                    </div>
                  </div>
                </div>

                {/* Card Footer: Signatures & Digital Seal */}
                <div className="px-3.5 py-1.5 bg-gradient-to-r from-slate-100 via-gray-50 to-slate-100 border-t border-gray-200 flex items-center justify-between">
                  {/* Reporter Signature */}
                  <div className="text-center">
                    <div className="h-5 w-18 flex items-center justify-center">
                      {displayReporter.signatureUrl ? (
                        <img
                          src={displayReporter.signatureUrl}
                          alt="Signature"
                          className="max-h-full max-w-full object-contain"
                        />
                      ) : (
                        <span className="font-serif italic text-[11px] font-bold text-blue-900" style={{ lineHeight: '13px' }}>
                          {displayReporter.fullName.split(' ')[0]}
                        </span>
                      )}
                    </div>
                    <span
                      className="text-[7.5px] font-black uppercase tracking-wider text-gray-500 border-t border-gray-300 pt-0.5 block"
                      style={{ lineHeight: '10px' }}
                    >
                      Card Holder Sign
                    </span>
                  </div>

                  {/* Official Digital Seal */}
                  <div className="w-9 h-9 rounded-full border border-dashed border-red-600 bg-red-50 flex flex-col items-center justify-center text-red-700 shadow-sm leading-none p-0.5 text-center shrink-0">
                    <span className="text-[5.5px] font-black uppercase tracking-tighter" style={{ lineHeight: '7px' }}>DIGITAL MEDIA</span>
                    <span className="material-symbols-outlined text-[11px]">verified</span>
                    <span className="text-[5.5px] font-black uppercase tracking-tighter" style={{ lineHeight: '7px' }}>VERIFIED</span>
                  </div>

                  {/* Authorized Signatory */}
                  <div className="text-center">
                    <div className="h-5 w-20 flex items-center justify-center">
                      <span className="font-serif italic text-[11px] font-black text-indigo-900" style={{ lineHeight: '13px' }}>
                        Editor-in-Chief
                      </span>
                    </div>
                    <span
                      className="text-[7.5px] font-black uppercase tracking-wider text-gray-500 border-t border-gray-300 pt-0.5 block"
                      style={{ lineHeight: '10px' }}
                    >
                      Authorized Signatory
                    </span>
                  </div>
                </div>
              </div>

            {/* --------------------------------------------------------------------- */}
            {/* CARD 2: BACK SIDE (TERMS, QR CODE & AADHAAR e-KYC VERIFICATION)         */}
            {/* --------------------------------------------------------------------- */}
            <div
              ref={backCardRef}
              className={`id-card-item w-[338px] h-[538px] bg-white rounded-3xl shadow-2xl border-2 border-slate-300 relative flex-col justify-between overflow-hidden text-gray-900 select-none font-sans shrink-0 ${
                activeSide === 'front' ? 'hidden print:flex' : 'flex'
              }`}
              style={{
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(0, 0, 0, 0.05)',
                boxSizing: 'border-box',
                WebkitPrintColorAdjust: 'exact',
                printColorAdjust: 'exact',
              }}
            >
              {/* Top Lanyard Slot Simulation (Hole Punch Area) */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-2 bg-gray-300 rounded-full border border-gray-400 shadow-inner z-30 opacity-90"></div>

              {/* Back Top Header with safe padding below lanyard hole */}
              <div
                className="pt-6 pb-2 px-3.5 text-white text-center id-card-back-header-gradient"
                style={{
                  background: 'linear-gradient(180deg, #0f172a 0%, #111827 50%, #0f172a 100%)',
                  WebkitPrintColorAdjust: 'exact',
                  printColorAdjust: 'exact',
                }}
              >
                <div
                  className="h-1.5 w-full rounded-full mb-2 shadow-sm"
                  style={{
                    background: 'linear-gradient(90deg, #ef4444 0%, #fbbf24 50%, #ef4444 100%)',
                    WebkitPrintColorAdjust: 'exact',
                    printColorAdjust: 'exact',
                  }}
                ></div>
                <h3
                  className="text-xs font-black uppercase tracking-wider text-amber-300 block m-0 p-0"
                  style={{ lineHeight: '15px' }}
                >
                  PUBLIC TAK APP
                </h3>
                <p
                  className="text-[8.5px] text-gray-300 font-bold uppercase tracking-wider block m-0 p-0 mt-0.5"
                  style={{ lineHeight: '12px' }}
                >
                  Accreditation Terms & Emergency Contact
                </p>
              </div>

              {/* Back Content */}
              <div className="px-3.5 py-1.5 flex-1 flex flex-col justify-between space-y-1.5 text-[9.5px]">
                {/* Address & Personal Details Card */}
                <div
                  className="border border-gray-200 rounded-xl p-2.5 space-y-1"
                  style={{
                    backgroundColor: '#f8fafc',
                    WebkitPrintColorAdjust: 'exact',
                    printColorAdjust: 'exact',
                  }}
                >
                  <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                    <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Father/Husband:</span>
                    <span className="font-extrabold text-gray-900" style={{ lineHeight: '13px' }}>{displayReporter.fatherOrHusbandName}</span>
                  </div>

                  <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                    <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Date of Birth:</span>
                    <span className="font-mono font-extrabold text-gray-900" style={{ lineHeight: '13px' }}>{displayReporter.dob}</span>
                  </div>

                  <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                    <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Aadhaar (Masked):</span>
                    <span className="font-mono font-extrabold text-emerald-700 flex items-center gap-1" style={{ lineHeight: '13px' }}>
                      <span className="material-symbols-outlined text-[11px]">verified</span>
                      {displayReporter.aadhaarNumber}
                    </span>
                  </div>

                  <div className="flex justify-between border-b border-gray-200/60 pb-0.5">
                    <span className="font-bold text-gray-500" style={{ lineHeight: '13px' }}>Emergency Phone:</span>
                    <span className="font-mono font-extrabold text-red-600" style={{ lineHeight: '13px' }}>
                      {displayReporter.emergencyContact || displayReporter.mobile}
                    </span>
                  </div>

                  <div className="pt-0.5">
                    <span className="font-bold text-gray-500 block" style={{ lineHeight: '12px' }}>Residential Address:</span>
                    <span className="font-medium text-gray-800 text-[9px] block mt-0.5" style={{ lineHeight: '13px' }}>
                      {displayReporter.fullAddress} (PIN: {displayReporter.pincode})
                    </span>
                  </div>
                </div>

                {/* QR Code & Live Verification */}
                <div
                  className="flex items-center gap-2.5 border border-blue-200 p-2 rounded-xl"
                  style={{
                    backgroundColor: '#eff6ff',
                    WebkitPrintColorAdjust: 'exact',
                    printColorAdjust: 'exact',
                  }}
                >
                  {/* QR Code Container */}
                  <div className="w-14 h-14 bg-white p-0.5 rounded-lg border border-gray-300 shadow-sm flex-shrink-0 flex items-center justify-center">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(
                        `https://publictak.app/?reporterVerify=${displayReporter.userId}&id=${displayReporter.reporterIdNumber}`
                      )}`}
                      alt="QR Code"
                      className="w-full h-full object-contain"
                      crossOrigin="anonymous"
                      referrerPolicy="no-referrer"
                      loading="eager"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <span
                      className="bg-blue-600 text-white text-[7.5px] font-black uppercase px-2 py-0.5 rounded-full inline-block"
                      style={{
                        lineHeight: '11px',
                        WebkitPrintColorAdjust: 'exact',
                        printColorAdjust: 'exact',
                      }}
                    >
                      SCAN TO VERIFY
                    </span>
                    <p className="text-[8.5px] font-bold text-gray-900 mt-0.5" style={{ lineHeight: '12px' }}>
                      स्कैन करके लाइव रिपोर्टर प्रोफाइल व सत्यापन देखें
                    </p>
                    <p className="text-[7.5px] font-mono text-gray-500 mt-0.5 truncate" style={{ lineHeight: '11px' }}>
                      publictak.app/verify/{displayReporter.reporterIdNumber}
                    </p>
                  </div>
                </div>

                {/* Digital Media Ethics Code & Terms */}
                <div
                  className="p-2 rounded-xl border border-gray-200 text-[8px] text-gray-600 space-y-0.5"
                  style={{
                    backgroundColor: '#f8fafc',
                    WebkitPrintColorAdjust: 'exact',
                    printColorAdjust: 'exact',
                  }}
                >
                  <p className="font-bold text-gray-900 uppercase" style={{ lineHeight: '11px' }}>
                    निर्देश व नियम (Terms & Instructions):
                  </p>
                  <p style={{ lineHeight: '11px' }}>
                    1. यह पहचान पत्र <b>Public Tak App</b> द्वारा डिजिटल समाचार संकलन एवं इलेक्ट्रॉनिक पत्रकारिता हेतु जारी किया गया है।
                  </p>
                  <p style={{ lineHeight: '11px' }}>
                    2. यह कार्ड अहस्तांतरणीय (Non-Transferable) है और डिजिटल मीडिया आचार संहिता के अनुपालन हेतु बाध्यकारी है।
                  </p>
                  <p style={{ lineHeight: '11px' }}>
                    3. कार्ड खोने या किसी पूछताछ के संदर्भ में तुरंत <b>support@publictak.app</b> पर संपर्क करें।
                  </p>
                </div>
              </div>

              {/* Back Footer */}
              <div
                className="px-3.5 py-1.5 text-white text-center text-[8.5px] font-medium flex items-center justify-between"
                style={{
                  backgroundColor: '#111827',
                  color: '#ffffff',
                  WebkitPrintColorAdjust: 'exact',
                  printColorAdjust: 'exact',
                }}
              >
                <span style={{ lineHeight: '12px' }}>Public Tak App</span>
                <span className="text-amber-400 font-bold" style={{ lineHeight: '12px' }}>www.publictak.app</span>
                <span style={{ lineHeight: '12px' }}>Govt. Reg. Digital Media</span>
              </div>
            </div>
          </div>

          {/* Guidelines / Printing instructions */}
          <div className="id-card-no-print bg-white p-5 rounded-3xl border border-gray-200 shadow-sm space-y-3">
            <h3 className="text-xs sm:text-sm font-black text-gray-900 flex items-center gap-2">
              <span className="material-symbols-outlined text-blue-600 text-lg">verified</span>
              ID कार्ड प्रिंटिंग दिशा-निर्देश (Print Instructions)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-gray-600">
              <div className="p-3.5 bg-blue-50/70 rounded-2xl border border-blue-200">
                <span className="font-black text-blue-950 flex items-center gap-1.5 mb-1.5">
                  <span className="material-symbols-outlined text-base text-blue-700">print</span>
                  1. डायरेक्ट प्रिंट करें
                </span>
                <p className="leading-relaxed">
                  ऊपर दिए गए <b>"ID Card प्रिंट करें"</b> बटन पर क्लिक करें। आपका ब्राउज़र प्रिंट डायलॉग खोलेगा जिसमें फ्रंट और बैक दोनों कार्ड पूर्ण रंगों, फ़ोटो व बैकग्राउंड के साथ एक ही A4 शीट पर सही अनुपात में प्रिंट होंगे।
                </p>
              </div>

              <div className="p-3.5 bg-emerald-50/70 rounded-2xl border border-emerald-200">
                <span className="font-black text-emerald-950 flex items-center gap-1.5 mb-1.5">
                  <span className="material-symbols-outlined text-base text-emerald-700">badge</span>
                  2. PVC Card या Glossy Paper
                </span>
                <p className="leading-relaxed">
                  प्रिंट डायलॉग में <b>Save as PDF</b> चुनकर किसी भी नज़दीकी PVC कार्ड प्रिंटर या फोटो स्टूडियो से असली प्लास्टिक पहचान पत्र के रूप में प्रिंट करवाएं।
                </p>
              </div>

              <div className="p-3.5 bg-purple-50/70 rounded-2xl border border-purple-200">
                <span className="font-black text-purple-950 flex items-center gap-1.5 mb-1.5">
                  <span className="material-symbols-outlined text-base text-purple-700">qr_code_scanner</span>
                  3. Lanyard Ribbon & QR Verify
                </span>
                <p className="leading-relaxed">
                  प्रिंट कराने के बाद फ्रंट और बैक को लैमिनेट कराकर प्रेस रिबन में पहनें। कार्ड पर दिए <b>QR कोड</b> को स्कैन कर कोई भी आपकी लाइव रिपोर्टर पहचान जांच सकता है।
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ReporterIdCardPage;

