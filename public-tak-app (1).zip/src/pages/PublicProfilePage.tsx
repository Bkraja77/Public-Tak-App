
import React, { useState, useEffect } from 'react';
import { User, View, Post, Video } from '../types';
import Header from '../components/Header';
import SEO from '../components/SEO';
import UserListModal from '../components/UserListModal';
import UserAvatar from '../components/UserAvatar';
import { db, serverTimestamp, increment } from '../firebaseConfig';
import { formatCount } from '../utils/formatters';
import { useToast } from '../contexts/ToastContext';
import { appCacheService } from '../services/appCacheService';

interface PublicProfilePageProps {
    userId: string;
    currentUser: User | null;
    onBack: () => void;
    onViewPost: (postId: string) => void;
    onViewUser: (userId: string) => void;
    onLogin: () => void;
    onNavigate: (view: View, params?: any) => void;
    onAdminEditUser: (userId: string) => void;
}

const StatBox: React.FC<{ value: number; label: string; onClick?: () => void }> = ({ value, label, onClick }) => (
    <div 
        onClick={onClick}
        className={`flex flex-col items-center justify-center p-3 bg-gray-50 rounded-xl min-w-[80px] border border-gray-100 transition-transform hover:scale-105 ${onClick ? 'cursor-pointer hover:bg-blue-50 hover:border-blue-100' : ''}`}
    >
        <p className="text-2xl font-bold text-gray-900">{formatCount(value)}</p>
        <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</p>
    </div>
);

const SkeletonPublicProfile = () => (
    <div className="flex flex-col h-full bg-transparent animate-pulse">
        <div className="h-14 bg-white/80 border-b border-gray-200"></div>
        <main className="flex-grow overflow-y-auto pb-20 md:pb-0">
             <div className="max-w-7xl mx-auto w-full md:px-4 md:py-6">
                <div className="glass-card overflow-hidden mb-8 mx-0 md:mx-0 rounded-none md:rounded-2xl border-x-0 md:border bg-white border-gray-100">
                    <div className="h-32 md:h-48 bg-gray-200"></div>
                    <div className="px-6 pb-6 md:px-8 md:pb-8 relative">
                         <div className="flex flex-col md:flex-row items-center md:items-end -mt-12 md:-mt-16 gap-4 md:gap-8">
                            <div className="w-24 h-24 md:w-40 md:h-40 rounded-full bg-gray-300 ring-4 ring-white shadow-lg"></div>
                            <div className="flex-grow text-center md:text-left mb-2 md:mb-4 w-full flex flex-col items-center md:items-start space-y-3 mt-12 md:mt-0">
                                <div className="h-8 w-48 bg-gray-200 rounded-lg"></div>
                                <div className="h-4 w-32 bg-gray-200 rounded"></div>
                                <div className="h-16 w-full max-w-xl bg-gray-100 rounded-lg hidden md:block"></div>
                            </div>
                            <div className="flex flex-col items-end gap-4 w-full md:w-auto mt-4 md:mt-0">
                                <div className="flex justify-center w-full md:w-auto gap-4 md:gap-8 bg-white md:bg-transparent p-2 md:p-0 rounded-xl border md:border-none border-gray-100">
                                    <div className="h-14 w-16 bg-gray-200 rounded-lg"></div>
                                    <div className="h-14 w-16 bg-gray-200 rounded-lg"></div>
                                    <div className="h-14 w-16 bg-gray-200 rounded-lg"></div>
                                </div>
                                <div className="h-10 w-full md:w-32 bg-gray-200 rounded-lg"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="px-4 md:px-0">
                    <div className="h-8 w-32 bg-gray-200 rounded mb-6"></div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {[1, 2, 3, 4].map((i) => (
                            <div key={i} className="glass-card overflow-hidden h-72 flex flex-col">
                                <div className="h-40 bg-gray-200 w-full"></div>
                                <div className="p-4 flex-grow space-y-3">
                                    <div className="h-5 w-3/4 bg-gray-200 rounded"></div>
                                    <div className="h-4 w-1/2 bg-gray-200 rounded"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
             </div>
        </main>
    </div>
);

const PublicProfilePage: React.FC<PublicProfilePageProps> = ({ userId, currentUser, onBack, onViewPost, onViewUser, onLogin, onNavigate, onAdminEditUser }) => {
    const { showToast } = useToast();
    const cachedProfile = appCacheService.getUserProfile(userId);
    const [profileUser, setProfileUser] = useState<User | null>(() => cachedProfile);
    const [posts, setPosts] = useState<Post[]>(() => appCacheService.getUserPosts(userId));
    const [videos, setVideos] = useState<Video[]>(() => appCacheService.getUserVideos(userId));
    const [followersCount, setFollowersCount] = useState<number>(() => cachedProfile?.followerCount || 0);
    const [followingCount, setFollowingCount] = useState<number>(() => cachedProfile?.followingCount || 0);
    const [isFollowing, setIsFollowing] = useState<boolean>(() => (currentUser && userId) ? appCacheService.isFollowing(currentUser.uid, userId) : false);
    const [followsMe, setFollowsMe] = useState(false);
    const [loading, setLoading] = useState<boolean>(() => !cachedProfile && appCacheService.getUserPosts(userId).length === 0);
    const [postError, setPostError] = useState<string | null>(null);
    const [activeList, setActiveList] = useState<'followers' | 'following' | null>(null);
    const [activeTab, setActiveTab] = useState<'posts' | 'videos'>('posts');
    const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);

    const touchStartCoords = React.useRef<{ x: number; y: number } | null>(null);
    const hasMoved = React.useRef(false);

    const handleTouchStartCustom = (e: React.TouchEvent) => {
        const touch = e.touches[0];
        touchStartCoords.current = { x: touch.clientX, y: touch.clientY };
        hasMoved.current = false;
    };

    const handleTouchMoveCustom = (e: React.TouchEvent) => {
        if (!touchStartCoords.current) return;
        const touch = e.touches[0];
        const dx = Math.abs(touch.clientX - touchStartCoords.current.x);
        const dy = Math.abs(touch.clientY - touchStartCoords.current.y);
        if (dx > 10 || dy > 10) {
            hasMoved.current = true;
        }
    };

    const handleMouseDownCustom = (e: React.MouseEvent) => {
        touchStartCoords.current = { x: e.clientX, y: e.clientY };
        hasMoved.current = false;
    };

    const handleMouseMoveCustom = (e: React.MouseEvent) => {
        if (!touchStartCoords.current) return;
        const dx = Math.abs(e.clientX - touchStartCoords.current.x);
        const dy = Math.abs(e.clientY - touchStartCoords.current.y);
        if (dx > 10 || dy > 10) {
            hasMoved.current = true;
        }
    };

    const handlePressEnd = (e: React.MouseEvent | React.TouchEvent | React.PointerEvent, onClick: () => void) => {
        touchStartCoords.current = null;
        if (hasMoved.current) {
            hasMoved.current = false;
            return;
        }
        onClick();
    };

    useEffect(() => {
        if (!cachedProfile) {
            setLoading(true);
        }

        const userDocRef = db.collection('users').doc(userId);
        const unsubscribeUser = userDocRef.onSnapshot((docSnap) => {
            if (docSnap.exists) {
                const fetched = { uid: docSnap.id, ...docSnap.data() } as User;
                setProfileUser(fetched);
                appCacheService.setUserProfile(userId, fetched);
            } else {
                console.error("User not found");
            }
        });

        const followersQuery = db.collection("users").doc(userId).collection("followers");
        const unsubscribeFollowers = followersQuery.onSnapshot((snapshot) => setFollowersCount(snapshot.size));
        
        const followingQuery = db.collection("users").doc(userId).collection("following");
        const unsubscribeFollowing = followingQuery.onSnapshot((snapshot) => setFollowingCount(snapshot.size));

        return () => {
            unsubscribeUser();
            unsubscribeFollowers();
            unsubscribeFollowing();
        };
    }, [userId]);

    useEffect(() => {
        let unsubscribeIsFollowing = () => {};
        let unsubscribeFollowsMe = () => {};
        
        if (currentUser) {
            const isFollowingRef = db.collection('users').doc(currentUser.uid).collection('following').doc(userId);
            unsubscribeIsFollowing = isFollowingRef.onSnapshot((doc) => {
                const exists = doc.exists;
                setIsFollowing(exists);
                if (exists) {
                    appCacheService.addFollow(currentUser.uid, userId);
                } else {
                    appCacheService.removeFollow(currentUser.uid, userId);
                }
            });

            // Check if profile user follows current user
            const followsMeRef = db.collection('users').doc(userId).collection('following').doc(currentUser.uid);
            unsubscribeFollowsMe = followsMeRef.onSnapshot((doc) => {
                setFollowsMe(doc.exists);
            });
        }

        return () => {
            unsubscribeIsFollowing();
            unsubscribeFollowsMe();
        };
    }, [userId, currentUser?.uid]);

     useEffect(() => {
        setPostError(null);
        const postsQuery = db.collection("posts").where("authorId", "==", userId);
        const unsubscribePosts = postsQuery.onSnapshot((snapshot) => {
            const userPosts = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title,
                    content: data.content,
                    thumbnailUrl: data.thumbnailUrl,
                    authorId: data.authorId,
                    authorName: data.authorName,
                    authorProfilePicUrl: data.authorProfilePicUrl,
                    viewCount: data.viewCount || 0,
                    shareCount: data.shareCount || 0,
                    category: data.category || 'General',
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
                    locationType: data.locationType || 'Overall',
                    state: data.state || '',
                    district: data.district || '',
                    block: data.block || '',
                    isPinned: data.isPinned || false,
                } as Post;
            });
            // Sort posts by pinned first, then by creation date (newest first).
            userPosts.sort((a, b) => {
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                const dateA = a.createdAt ? a.createdAt.getTime() : 0;
                const dateB = b.createdAt ? b.createdAt.getTime() : 0;
                return dateB - dateA;
            });
            setPosts(userPosts);
            appCacheService.setUserPosts(userId, userPosts);
            setLoading(false); // Posts loaded (or empty) -> done loading
        }, (error) => {
            console.error("Error fetching user posts:", error);
            setPostError("Could not load posts. Please try again later.");
            setLoading(false);
        });
        
        return () => unsubscribePosts();
    }, [userId]);

    useEffect(() => {
        const videosQuery = db.collection("videos").where("authorId", "==", userId);
        const unsubscribeVideos = videosQuery.onSnapshot((snapshot) => {
            const fetchedVideos = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title || '',
                    description: data.description || '',
                    videoUrl: data.videoUrl || '',
                    thumbnailUrl: data.thumbnailUrl || '',
                    authorId: data.authorId || '',
                    authorName: data.authorName || '',
                    authorProfilePicUrl: data.authorProfilePicUrl || '',
                    viewCount: data.viewCount || 0,
                    likeCount: data.likeCount || 0,
                    commentCount: data.commentCount || 0,
                    shareCount: data.shareCount || 0,
                    category: data.category || 'General',
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
                    locationType: data.locationType || 'Overall',
                    state: data.state || '',
                    district: data.district || '',
                    block: data.block || '',
                    isPinned: data.isPinned || false,
                } as Video;
            });
            
            // Sort videos by pinned first, then by creation date (newest first).
            fetchedVideos.sort((a, b) => {
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                const dateA = a.createdAt ? a.createdAt.getTime() : 0;
                const dateB = b.createdAt ? b.createdAt.getTime() : 0;
                return dateB - dateA;
            });

            setVideos(fetchedVideos);
            appCacheService.setUserVideos(userId, fetchedVideos);
        }, (error) => {
            console.error("Error fetching user videos:", error);
        });

        return () => unsubscribeVideos();
    }, [userId]);

    const handleFollowToggle = async () => {
        if (!currentUser || !profileUser) {
            onLogin();
            return;
        }

        const wasFollowing = isFollowing;
        const newFollowingState = !wasFollowing;

        // Optimistic UI update
        setIsFollowing(newFollowingState);
        if (newFollowingState) {
            appCacheService.addFollow(currentUser.uid, profileUser.uid);
        } else {
            appCacheService.removeFollow(currentUser.uid, profileUser.uid);
        }
        setProfileUser(prev => {
            if (!prev) return prev;
            return {
                ...prev,
                followerCount: wasFollowing ? Math.max(0, (prev.followerCount || 0) - 1) : (prev.followerCount || 0) + 1
            };
        });

        const currentUserRef = db.collection('users').doc(currentUser.uid);
        const targetUserRef = db.collection('users').doc(profileUser.uid);

        const followingRef = currentUserRef.collection('following').doc(profileUser.uid);
        const followerRef = targetUserRef.collection('followers').doc(currentUser.uid);

        try {
            if (wasFollowing) {
                // UNFOLLOW
                await Promise.allSettled([
                    followingRef.delete(),
                    followerRef.delete(),
                    currentUserRef.update({ followingCount: increment(-1) }),
                    targetUserRef.update({ followerCount: increment(-1) })
                ]);
                showToast(`Unfollowed ${profileUser.name}`, "info");
            } else {
                // FOLLOW / FOLLOW BACK
                await Promise.allSettled([
                    followingRef.set({ followedAt: serverTimestamp() }),
                    followerRef.set({ 
                        followedAt: serverTimestamp(),
                        followerId: currentUser.uid,
                        followerName: currentUser.name || '',
                        followerProfilePicUrl: currentUser.profilePicUrl || ''
                    }),
                    currentUserRef.update({ followingCount: increment(1) }),
                    targetUserRef.update({ followerCount: increment(1) }),
                    targetUserRef.collection('notifications').add({
                        type: 'new_follower',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name,
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        fromUserIsVerified: currentUser.isVerified || false,
                        createdAt: serverTimestamp(),
                        read: false
                    })
                ]);
                showToast(followsMe ? `Followed back ${profileUser.name}` : `Following ${profileUser.name}`, "success");
            }
        } catch (error) {
            console.error("Error following/unfollowing user:", error);
        }
    };
    
    const renderPosts = () => {
        if (postError) {
             return <div className="text-center py-10 glass-card"><p className="text-red-500">{postError}</p></div>;
        }
        if (posts.length > 0) {
            return (
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-500">
                    {posts.map((post) => (
                        <div 
                            key={post.id} 
                            onMouseDown={handleMouseDownCustom}
                            onMouseMove={handleMouseMoveCustom}
                            onMouseUp={(e) => handlePressEnd(e, () => onViewPost(post.id))}
                            onTouchStart={handleTouchStartCustom}
                            onTouchMove={handleTouchMoveCustom}
                            onTouchEnd={(e) => handlePressEnd(e, () => onViewPost(post.id))}
                            className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-gray-950 cursor-pointer shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 select-none"
                        >
                            {post.thumbnailUrl ? (
                                <img 
                                    src={post.thumbnailUrl} 
                                    alt={post.title} 
                                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                                />
                            ) : (
                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 gap-1 bg-gray-950">
                                    <span className="material-symbols-outlined text-4xl">article</span>
                                    <span className="text-[10px] font-bold text-gray-500">Article</span>
                                </div>
                            )}
                            
                            {/* Text and stats overlay on bottom half */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-2 md:p-3 opacity-100">
                                <h3 className="text-white text-[10px] sm:text-xs font-black line-clamp-2 leading-tight mb-1">{post.title}</h3>
                                <div className="flex items-center justify-between text-[8px] sm:text-[10px] text-gray-300">
                                     <span>{post.createdAt ? post.createdAt.toLocaleDateString() : 'N/A'}</span>
                                     <div className="flex items-center gap-0.5">
                                         <span className="material-symbols-outlined text-[10px] sm:text-xs text-gray-300">visibility</span>
                                         <span>{formatCount(post.viewCount)}</span>
                                     </div>
                                </div>
                            </div>

                            {/* Pinned Badge */}
                            {post.isPinned && (
                                <div className="absolute top-2 left-2 bg-red-600 text-white p-1 rounded-full shadow-md flex items-center justify-center animate-pulse z-10" title="Pinned Post">
                                    <span className="material-symbols-outlined text-[10px] sm:text-xs font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>push_pin</span>
                                </div>
                            )}

                            {/* Category Badge */}
                            <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md text-white/90 px-2 py-0.5 rounded text-[8px] sm:text-[10px] font-black uppercase tracking-wider">
                                {post.category}
                            </div>
                        </div>
                    ))}
                </div>
            );
        }
        return (
             <div className="text-center py-20 glass-card">
                <span className="material-symbols-outlined text-6xl text-gray-300 mb-4">post_add</span>
                <p className="text-gray-600 text-lg">This user hasn't posted anything yet.</p>
            </div>
        )
    };

    if (loading) {
        return <SkeletonPublicProfile />;
    }

    if (!profileUser) {
        return (
            <div className="flex flex-col h-full bg-transparent">
                <Header title="Not Found" showBackButton onBack={onBack} />
                <div className="flex items-center justify-center h-full"><p>User not found.</p></div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full bg-transparent">
            <SEO 
                title={`👤 ${profileUser.name} - Verified News Reporter | Public Tak App`}
                description={`${profileUser.name} ki sabhi taza khabrein, video updates aur verified reports Public Tak App par padhein.`}
                image={profileUser.profilePicUrl}
                url={`https://publictak.app/?userId=${userId}`}
                type="profile"
                author={profileUser.name}
            />
            <Header 
                title={profileUser.name} 
                showBackButton 
                onBack={onBack} 
                currentUser={currentUser}
                onProfileClick={() => onNavigate(View.User)}
                onLogin={onLogin}
            />
            <main className="flex-grow overflow-y-auto pb-20 md:pb-0">
                 <div className="max-w-7xl mx-auto w-full md:px-4 md:py-6">
                     {/* Full Width Profile Header */}
                    <div className="glass-card overflow-hidden mb-8 mx-0 md:mx-0 rounded-none md:rounded-2xl border-x-0 md:border">
                        <div className="relative h-32 md:h-48 bg-gradient-to-r from-gray-800 to-gray-600">
                             <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-black/30 to-transparent"></div>
                        </div>
                        
                        <div className="px-6 pb-6 md:px-8 md:pb-8 relative">
                             <div className="flex flex-col md:flex-row items-center md:items-end -mt-12 md:-mt-16 gap-4 md:gap-8">
                                {/* Avatar */}
                                <div className="relative">
                                    <UserAvatar 
                                        userId={profileUser.uid}
                                        src={profileUser.profilePicUrl}
                                        name={profileUser.name}
                                        currentUser={currentUser}
                                        className="h-24 w-24 md:h-40 md:w-40 rounded-full object-cover ring-4 ring-white shadow-lg bg-white"
                                        alt={`${profileUser.name}'s profile picture`} 
                                    />
                                </div>
                                
                                 {/* Info */}
                                <div className="flex-grow text-center md:text-left mb-2 md:mb-4">
                                    <div className="flex flex-col md:flex-row items-center md:items-center gap-1 md:gap-4">
                                        <div className="flex items-center gap-1 md:gap-2">
                                            <h1 className="text-2xl md:text-4xl font-bold text-gray-900">{profileUser.name}</h1>
                                            {profileUser.isVerified && (
                                                <span className="material-symbols-outlined text-blue-500 text-2xl md:text-3xl font-bold" title="Verified Creator">verified</span>
                                            )}
                                        </div>
                                        
                                        {/* Warning Asterisks */}
                                        {(profileUser.asteriskCount || 0) > 0 && (
                                            <div className="flex items-center px-3 py-1 bg-red-100 text-red-600 rounded-full text-xs font-black ring-1 ring-red-200">
                                                {Array(profileUser.asteriskCount).fill('*').join('')}
                                                <span className="ml-1 uppercase text-[10px]">Violation Warning</span>
                                            </div>
                                        )}
                                        
                                        {/* Desktop Follow Button */}
                                        <div className="hidden md:block">
                                            {(!currentUser || currentUser.uid !== userId) && (
                                                <button 
                                                    onClick={handleFollowToggle} 
                                                    className={`
                                                        px-6 py-2 text-sm font-black rounded-full transition-all duration-300 shadow-sm active:scale-95 flex items-center justify-center gap-1.5
                                                        ${isFollowing 
                                                            ? 'bg-gray-100 text-gray-600 border border-gray-200' 
                                                            : followsMe
                                                                ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white border border-blue-500 animate-follow-back-blink shadow-md shadow-blue-500/40'
                                                                : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border border-red-500 animate-follow-blink shadow-md shadow-red-500/40'}
                                                    `}
                                                >
                                                    {isFollowing ? (
                                                        <>
                                                            <span className="material-symbols-outlined text-base font-bold">done</span>
                                                            <span>Following</span>
                                                        </>
                                                    ) : (
                                                        <>
                                                            <span className="material-symbols-outlined text-base font-black">person_add</span>
                                                            <span>{followsMe ? 'Follow Back' : 'Follow'}</span>
                                                        </>
                                                    )}
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    <p className="text-blue-600 font-medium">@{profileUser.username}</p>
                                    {profileUser.bio && <p className="mt-2 text-sm text-gray-600 max-w-prose">{profileUser.bio}</p>}
                                    
                                     {profileUser.preferredState && (
                                        <div className="mt-3 flex items-center justify-center md:justify-start gap-1 text-sm text-gray-500">
                                            <span className="material-symbols-outlined text-base">location_on</span>
                                            <span>
                                                {profileUser.preferredDistrict && `${profileUser.preferredDistrict}, `}
                                                {profileUser.preferredState}
                                            </span>
                                        </div>
                                    )}
                                </div>

                                {/* Stats & Actions */}
                                <div className="flex flex-col items-end gap-4 w-full md:w-auto">
                                    <div className="flex justify-center w-full md:w-auto gap-4 md:gap-8 bg-white md:bg-transparent p-2 md:p-0 rounded-xl shadow-sm md:shadow-none border md:border-none border-gray-100">
                                        <StatBox value={posts.length} label="Posts" />
                                        <StatBox value={videos.length} label="Videos" />
                                        <StatBox value={followersCount} label="Followers" onClick={() => setActiveList('followers')} />
                                        <StatBox value={followingCount} label="Following" onClick={() => setActiveList('following')} />
                                    </div>
                                    
                                    <div className="flex flex-col w-full gap-2">
                                         {(!currentUser || currentUser.uid !== userId) && (
                                             <button 
                                                onClick={handleFollowToggle} 
                                                className={`
                                                    w-full md:w-auto px-10 py-3 text-base font-black rounded-full transition-all duration-300 shadow-sm active:scale-95 flex items-center justify-center gap-2
                                                    ${isFollowing 
                                                        ? 'bg-gray-100 text-gray-600 border border-gray-200' 
                                                        : followsMe
                                                            ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white border border-blue-500 animate-follow-back-blink shadow-lg shadow-blue-500/40'
                                                            : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border border-red-500 animate-follow-blink shadow-lg shadow-red-500/40'}
                                                `}
                                            >
                                                {isFollowing ? (
                                                    <>
                                                        <span className="material-symbols-outlined text-lg font-bold">done</span>
                                                        <span>Following</span>
                                                    </>
                                                ) : (
                                                    <>
                                                        <span className="material-symbols-outlined text-lg font-black">person_add</span>
                                                        <span>{followsMe ? 'Follow Back' : 'Follow'}</span>
                                                    </>
                                                )}
                                            </button>
                                        )}
                                        
                                        {currentUser?.role === 'admin' && (
                                            <button 
                                                onClick={() => onAdminEditUser(userId)}
                                                className="w-full md:w-auto px-8 py-2.5 text-base font-semibold rounded-full transition-all shadow-sm hover:shadow-md bg-gray-800 text-white hover:bg-gray-900 flex items-center justify-center gap-2"
                                            >
                                                <span className="material-symbols-outlined text-sm">admin_panel_settings</span>
                                                Manage User
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="px-4 md:px-0">
                        {/* Tab Headers */}
                        <div className="flex border-b border-gray-200 mb-6">
                            <button
                                onClick={() => setActiveTab('posts')}
                                className={`pb-3 px-4 font-bold text-lg border-b-2 transition-all flex items-center gap-2 ${
                                    activeTab === 'posts'
                                        ? 'border-red-600 text-red-600'
                                        : 'border-transparent text-gray-500 hover:text-gray-700'
                                }`}
                            >
                                <span className="material-symbols-outlined text-xl">article</span>
                                Posts
                                <span className="ml-1 bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs font-bold">
                                    {posts.length}
                                </span>
                            </button>
                            <button
                                onClick={() => setActiveTab('videos')}
                                className={`pb-3 px-4 font-bold text-lg border-b-2 transition-all flex items-center gap-2 ${
                                    activeTab === 'videos'
                                        ? 'border-red-600 text-red-600'
                                        : 'border-transparent text-gray-500 hover:text-gray-700'
                                }`}
                            >
                                <span className="material-symbols-outlined text-xl">movie</span>
                                Videos
                                <span className="ml-1 bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs font-bold">
                                    {videos.length}
                                </span>
                            </button>
                        </div>

                        {/* Tab Contents */}
                        {activeTab === 'posts' ? (
                            renderPosts()
                        ) : (
                            <div>
                                {videos.length > 0 ? (
                                    <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-500">
                                        {videos.map((video) => (
                                            <div 
                                                key={video.id} 
                                                onMouseDown={handleMouseDownCustom}
                                                onMouseMove={handleMouseMoveCustom}
                                                onMouseUp={(e) => handlePressEnd(e, () => onNavigate(View.VideoHome, { videoId: video.id }))}
                                                onTouchStart={handleTouchStartCustom}
                                                onTouchMove={handleTouchMoveCustom}
                                                onTouchEnd={(e) => handlePressEnd(e, () => onNavigate(View.VideoHome, { videoId: video.id }))}
                                                className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-gray-900 cursor-pointer shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 select-none"
                                            >
                                                {video.thumbnailUrl ? (
                                                    <img 
                                                        src={video.thumbnailUrl} 
                                                        alt={video.title} 
                                                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                                                    />
                                                ) : (
                                                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 gap-1 bg-gray-950">
                                                        <span className="material-symbols-outlined text-4xl">movie</span>
                                                        <span className="text-[10px] font-bold text-gray-500">Bulletin</span>
                                                    </div>
                                                )}
                                                
                                                {/* Video Play Overlay Icon */}
                                                <div className="absolute inset-0 bg-black/25 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                                    <div className="bg-white/95 text-red-600 p-2 md:p-3 rounded-full shadow-lg transform scale-90 group-hover:scale-100 transition-transform duration-300 flex items-center justify-center">
                                                        <span className="material-symbols-outlined text-xl md:text-2xl font-bold fill-current">play_arrow</span>
                                                    </div>
                                                </div>

                                                {/* Pinned Badge */}
                                                {video.isPinned && (
                                                    <div className="absolute top-2 left-2 bg-red-600 text-white p-1 rounded-full shadow-md flex items-center justify-center animate-pulse z-10" title="Pinned Video">
                                                        <span className="material-symbols-outlined text-[10px] sm:text-xs font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>push_pin</span>
                                                    </div>
                                                )}
                                                
                                                {/* Top Category Badge */}
                                                <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md text-white/90 px-2 py-0.5 rounded text-[8px] md:text-[10px] font-black uppercase tracking-wider">
                                                    {video.category}
                                                </div>

                                                {/* Bottom Left View Count Overlay */}
                                                <div className="absolute bottom-2 left-2 bg-black/40 backdrop-blur-md text-white px-2 py-1 rounded-lg text-[9px] md:text-[11px] font-black flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[10px] md:text-xs text-white font-black">visibility</span>
                                                    <span>{formatCount(video.viewCount)}</span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-20 glass-card">
                                        <span className="material-symbols-outlined text-6xl text-gray-300 mb-4">movie</span>
                                        <p className="text-gray-600 text-lg">This user hasn't posted any videos yet.</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </main>

            {/* Custom Video Player Modal */}
            {selectedVideo && (
                <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-md animate-fade-in">
                    <div className="relative bg-gray-900 rounded-3xl overflow-hidden max-w-4xl w-full flex flex-col md:flex-row h-auto md:h-[600px] border border-gray-800 shadow-2xl">
                        {/* Close button */}
                        <button 
                            onClick={() => setSelectedVideo(null)}
                            className="absolute top-4 right-4 bg-black/50 hover:bg-black/85 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors z-10"
                        >
                            <span className="material-symbols-outlined">close</span>
                        </button>

                        {/* Video Section */}
                        <div className="flex-1 bg-black flex items-center justify-center h-[300px] md:h-full relative group">
                            <video 
                                src={selectedVideo.videoUrl} 
                                controls 
                                autoPlay 
                                className="w-full h-full object-contain"
                            />
                        </div>

                        {/* Info Section */}
                        <div className="w-full md:w-[350px] bg-gray-950 p-6 flex flex-col justify-between text-white border-t md:border-t-0 md:border-l border-gray-800 h-auto md:h-full">
                            <div className="space-y-4">
                                <div className="flex items-center gap-2">
                                    <span className="bg-red-600 text-white px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wider">
                                        {selectedVideo.category}
                                    </span>
                                    <span className="text-xs text-gray-400">
                                        {selectedVideo.createdAt ? new Date(selectedVideo.createdAt).toLocaleDateString() : 'N/A'}
                                    </span>
                                </div>
                                <h3 className="text-xl font-bold line-clamp-3 leading-snug">{selectedVideo.title}</h3>
                                {selectedVideo.description && (
                                    <p className="text-sm text-gray-400 line-clamp-6 leading-relaxed whitespace-pre-wrap overflow-y-auto max-h-[150px]">
                                        {selectedVideo.description}
                                    </p>
                                )}
                            </div>

                            <div className="border-t border-gray-800 pt-4 mt-6 space-y-4">
                                {/* Creator Info */}
                                <div className="flex items-center gap-3">
                                    <UserAvatar 
                                        userId={selectedVideo.authorId}
                                        src={selectedVideo.authorProfilePicUrl}
                                        name={selectedVideo.authorName}
                                        currentUser={currentUser}
                                        className="w-10 h-10 rounded-full object-cover border border-gray-800"
                                    />
                                    <div>
                                        <h4 className="font-bold text-sm text-white flex items-center gap-1">
                                            {selectedVideo.authorName}
                                            {selectedVideo.authorIsVerified && (
                                                <span className="material-symbols-outlined text-blue-500 text-sm font-bold">verified</span>
                                            )}
                                        </h4>
                                        <p className="text-xs text-gray-500">Video Creator</p>
                                    </div>
                                </div>

                                {/* Stats */}
                                <div className="flex items-center justify-between text-xs text-gray-400 bg-gray-900/50 p-3 rounded-xl border border-gray-800">
                                    <div className="flex items-center gap-1.5">
                                        <span className="material-symbols-outlined text-base text-gray-400">visibility</span>
                                        <span>{formatCount(selectedVideo.viewCount)} Views</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <span className="material-symbols-outlined text-base text-red-500">favorite</span>
                                        <span>{formatCount(selectedVideo.likeCount || 0)} Likes</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <span className="material-symbols-outlined text-base text-blue-400">comment</span>
                                        <span>{formatCount(selectedVideo.commentCount || 0)}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* User List Modal */}
            {activeList && (
                <UserListModal
                    userId={userId}
                    currentUser={currentUser}
                    type={activeList}
                    onClose={() => setActiveList(null)}
                    onViewUser={(uid) => {
                        onViewUser(uid);
                        setActiveList(null);
                    }}
                />
            )}
        </div>
    );
};

export default PublicProfilePage;
