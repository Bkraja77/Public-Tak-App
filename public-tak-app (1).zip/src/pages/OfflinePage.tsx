import React, { useState, useEffect, useMemo } from 'react';
import { Post } from '../types';
import { appCacheService } from '../services/appCacheService';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';

interface OfflinePageProps {
    onBack?: () => void;
    onNavigateHome?: () => void;
    onSelectPost?: (post: Post) => void;
}

export const OfflinePage: React.FC<OfflinePageProps> = ({
    onBack,
    onNavigateHome,
    onSelectPost
}) => {
    const { t } = useLanguage();
    const { showToast } = useToast();

    const [isOnline, setIsOnline] = useState<boolean>(() => typeof navigator !== 'undefined' ? navigator.onLine : true);
    const [isCheckingConnection, setIsCheckingConnection] = useState<boolean>(false);
    
    // Cached news state
    const [showCachedList, setShowCachedList] = useState<boolean>(false);
    const [cachedPosts, setCachedPosts] = useState<Post[]>([]);
    const [isLoadingCached, setIsLoadingCached] = useState<boolean>(false);
    const [cachedCount, setCachedCount] = useState<number>(0);
    const [hasLoadedOnce, setHasLoadedOnce] = useState<boolean>(false);

    // Search and filter inside cached news
    const [searchQuery, setSearchQuery] = useState<string>('');
    const [selectedCategory, setSelectedCategory] = useState<string>('All');

    // Offline full article modal reader
    const [activeModalPost, setActiveModalPost] = useState<Post | null>(null);

    // Listen to network status changes
    useEffect(() => {
        const handleOnline = () => {
            setIsOnline(true);
            showToast('इंटरनेट कनेक्शन पुनः चालू हो गया है!', 'success');
        };
        const handleOffline = () => {
            setIsOnline(false);
            showToast('आप ऑफ़लाइन हैं। सहेजी गई खबरें पढ़ें।', 'info');
        };

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, [showToast]);

    // Initial count of cached news in IndexedDB
    useEffect(() => {
        let isMounted = true;
        appCacheService.getCachedNewsCount().then(count => {
            if (isMounted) {
                setCachedCount(count);
            }
        }).catch(() => {});

        return () => {
            isMounted = false;
        };
    }, []);

    // Fetch news stored in IndexedDB via appCacheService
    const handleReadCachedNews = async () => {
        setIsLoadingCached(true);
        try {
            // Fetch cached news directly from IndexedDB via appCacheService
            const posts = await appCacheService.getCachedPostsFromIndexedDB();
            setCachedPosts(posts);
            setCachedCount(posts.length);
            setShowCachedList(true);
            setHasLoadedOnce(true);

            if (posts.length > 0) {
                showToast(`IndexedDB से ${posts.length} सहेजी गई खबरें लोड हुईं!`, 'success');
            } else {
                showToast('कोई ऑफ़लाइन खबर नहीं मिली।', 'info');
            }
        } catch (error) {
            console.error('Failed to fetch cached news from IndexedDB:', error);
            showToast('कैश की गई खबरें लोड करने में समस्या आई।', 'error');
        } finally {
            setIsLoadingCached(false);
        }
    };

    // Test connection / reload
    const handleTryAgain = () => {
        setIsCheckingConnection(true);
        if (typeof navigator !== 'undefined' && navigator.onLine) {
            showToast('इंटरनेट कनेक्शन चालू है, पेज रीलोड हो रहा है...', 'success');
            setTimeout(() => {
                window.location.reload();
            }, 500);
        } else {
            setTimeout(() => {
                setIsCheckingConnection(false);
                showToast('अभी भी कोई इंटरनेट कनेक्शन नहीं है। कृपया वाई-फाई या मोबाइल डेटा जांचें।', 'error');
            }, 800);
        }
    };

    // Extract dynamic categories from cached posts
    const availableCategories = useMemo(() => {
        const set = new Set<string>();
        cachedPosts.forEach(p => {
            if (p.category) set.add(p.category);
        });
        return ['All', ...Array.from(set)];
    }, [cachedPosts]);

    // Filtered posts based on query and category
    const filteredCachedPosts = useMemo(() => {
        return cachedPosts.filter(post => {
            const matchesCat = selectedCategory === 'All' || post.category === selectedCategory;
            const query = searchQuery.trim().toLowerCase();
            const matchesQuery = !query || 
                (post.title && post.title.toLowerCase().includes(query)) ||
                (post.content && post.content.toLowerCase().includes(query)) ||
                (post.authorName && post.authorName.toLowerCase().includes(query)) ||
                (post.category && post.category.toLowerCase().includes(query));
            return matchesCat && matchesQuery;
        });
    }, [cachedPosts, searchQuery, selectedCategory]);

    const handleOpenPost = (post: Post) => {
        if (onSelectPost) {
            onSelectPost(post);
        } else {
            setActiveModalPost(post);
        }
    };

    const handleShareOfflinePost = (post: Post) => {
        const text = `${post.title}\n\nपब्लिक तक ऐप पर पढ़ें: https://publictak.app/?postId=${post.id}`;
        if (navigator.share) {
            navigator.share({
                title: post.title,
                text: text,
                url: `https://publictak.app/?postId=${post.id}`
            }).catch(() => {});
        } else {
            navigator.clipboard?.writeText(text);
            showToast('समाचार का लिंक कॉपी हो गया!', 'info');
        }
    };

    return (
        <div className="flex flex-col h-full w-full bg-gray-50 text-gray-900 overflow-y-auto">
            {/* Top Navigation Bar */}
            <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-2xs">
                <div className="flex items-center gap-2.5">
                    {showCachedList ? (
                        <button 
                            type="button"
                            onClick={() => setShowCachedList(false)}
                            className="p-1.5 rounded-xl hover:bg-gray-100 text-gray-700 transition-colors flex items-center gap-1 cursor-pointer"
                            title="वापस जाएं (Back)"
                        >
                            <span className="material-symbols-outlined text-2xl">arrow_back</span>
                        </button>
                    ) : onBack ? (
                        <button 
                            type="button"
                            onClick={onBack}
                            className="p-1.5 rounded-xl hover:bg-gray-100 text-gray-700 transition-colors cursor-pointer"
                            title="वापस जाएं (Back)"
                        >
                            <span className="material-symbols-outlined text-2xl">arrow_back</span>
                        </button>
                    ) : null}

                    <div>
                        <h2 className="text-base sm:text-lg font-black text-gray-900 leading-tight">
                            {showCachedList ? 'ऑफलाइन समाचार (Cached News)' : 'ऑफ़लाइन मोड (Offline Mode)'}
                        </h2>
                        <p className="text-[11px] text-gray-500 font-semibold">
                            {showCachedList 
                                ? `IndexedDB में सहेजी गई ${cachedPosts.length} खबरें` 
                                : 'पब्लिक तक (Public Tak)'}
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    {/* Status Badge */}
                    <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-black border ${
                        isOnline 
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}>
                        <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                        <span>{isOnline ? 'ऑनलाइन' : 'ऑफ़लाइन'}</span>
                    </div>

                    {onNavigateHome && (
                        <button 
                            type="button"
                            onClick={onNavigateHome}
                            className="p-2 rounded-xl text-gray-600 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                            title="होम पर जाएं (Home)"
                        >
                            <span className="material-symbols-outlined text-xl">home</span>
                        </button>
                    )}
                </div>
            </header>

            {/* MAIN BODY */}
            {!showCachedList ? (
                /* OFFLINE HERO VIEW */
                <div className="flex-1 flex flex-col items-center justify-center p-6 sm:p-10 text-center max-w-lg mx-auto my-auto animate-in fade-in duration-200">
                    {/* Animated Cloud Off Illustration */}
                    <div className="relative mb-6">
                        <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-amber-50 border-2 border-amber-200/80 flex items-center justify-center text-amber-600 shadow-inner">
                            <span className="material-symbols-outlined text-5xl sm:text-6xl animate-pulse">
                                cloud_off
                            </span>
                        </div>
                        <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-amber-600 text-white text-[11px] font-black rounded-full uppercase tracking-wider shadow-sm">
                            Offline
                        </span>
                    </div>

                    {/* Headline */}
                    <h1 className="text-2xl sm:text-3xl font-black text-gray-900 tracking-tight">
                        आप ऑफ़लाइन हैं
                    </h1>
                    <p className="text-sm text-gray-500 mt-1 font-bold">
                        You are currently offline
                    </p>

                    {/* Description */}
                    <p className="mt-3 text-sm text-gray-600 max-w-sm leading-relaxed">
                        इंटरनेट कनेक्शन उपलब्ध नहीं है। बिना इंटरनेट के भी आप पहले से डिवाइस के 
                        <strong> IndexedDB</strong> में सहेजी गई ताज़ा खबरें पढ़ सकते हैं।
                    </p>

                    {/* ACTION BUTTONS */}
                    <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full max-w-xs sm:max-w-md">
                        {/* Primary Button: Read Cached News */}
                        <button
                            id="read-cached-news-btn"
                            type="button"
                            onClick={handleReadCachedNews}
                            disabled={isLoadingCached}
                            className="w-full sm:flex-1 py-3.5 px-5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-black text-sm sm:text-base rounded-2xl shadow-lg shadow-red-600/25 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                        >
                            {isLoadingCached ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                    <span>लोड हो रहा है...</span>
                                </>
                            ) : (
                                <>
                                    <span className="material-symbols-outlined text-xl">menu_book</span>
                                    <span>Read Cached News</span>
                                    {cachedCount > 0 && (
                                        <span className="ml-1 px-2 py-0.5 bg-white/20 rounded-full text-xs font-bold">
                                            {cachedCount}
                                        </span>
                                    )}
                                </>
                            )}
                        </button>

                        {/* Secondary Button: Try Again */}
                        <button
                            id="try-again-btn"
                            type="button"
                            onClick={handleTryAgain}
                            disabled={isCheckingConnection}
                            className="w-full sm:w-auto py-3.5 px-6 bg-white hover:bg-gray-100 text-gray-800 font-black text-sm rounded-2xl border border-gray-300 shadow-2xs active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                        >
                            {isCheckingConnection ? (
                                <>
                                    <div className="w-4 h-4 border-2 border-gray-800 border-t-transparent rounded-full animate-spin" />
                                    <span>जांच हो रही है...</span>
                                </>
                            ) : (
                                <>
                                    <span className="material-symbols-outlined text-lg">refresh</span>
                                    <span>Try Again</span>
                                </>
                            )}
                        </button>
                    </div>

                    {/* Hindi subtitle for the action */}
                    <p className="text-xs text-gray-400 mt-2 font-medium">
                        (कैश की गई खबरें पढ़ें • इंटरनेट की आवश्यकता नहीं)
                    </p>

                    {/* Offline Info Card */}
                    <div className="mt-8 p-4 bg-white border border-gray-200/90 rounded-2xl text-left w-full shadow-2xs">
                        <div className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                                <span className="material-symbols-outlined text-lg">offline_pin</span>
                            </div>
                            <div className="text-xs text-gray-600 space-y-1">
                                <p className="font-bold text-gray-800">
                                    स्वचालित ऑफ़लाइन संग्रहण (Auto-Cache)
                                </p>
                                <p className="text-gray-500 leading-normal">
                                    जब भी आप ऑनलाइन होते हैं, पब्लिक तक ऐप मुख्य समाचारों को आपके ब्राउज़र के IndexedDB में सुरक्षित रखता है ताकि कमजोर नेटवर्क या यात्रा में भी आप खबरें पढ़ सकें।
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                /* CACHED NEWS LIST VIEW */
                <div className="flex-1 flex flex-col p-4 sm:p-6 max-w-3xl mx-auto w-full">
                    {/* Header Controls */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                        <div className="flex items-center gap-2">
                            <span className="material-symbols-outlined text-red-600 text-2xl">local_library</span>
                            <div>
                                <h3 className="text-lg font-black text-gray-900 leading-tight">
                                    सहेजी गई ऑफ़लाइन खबरें
                                </h3>
                                <p className="text-xs text-gray-500">
                                    बिना इंटरनेट के पढ़ने के लिए उपलब्ध ({filteredCachedPosts.length} समाचार)
                                </p>
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            <button
                                type="button"
                                onClick={handleReadCachedNews}
                                disabled={isLoadingCached}
                                className="px-3 py-1.5 bg-white hover:bg-gray-100 text-gray-700 font-bold text-xs rounded-xl border border-gray-200 flex items-center gap-1.5 shadow-2xs cursor-pointer transition-colors"
                                title="पुनः लोड करें"
                            >
                                <span className="material-symbols-outlined text-sm">sync</span>
                                <span>ताज़ा करें</span>
                            </button>

                            <button
                                type="button"
                                onClick={() => setShowCachedList(false)}
                                className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-xl border border-gray-200 flex items-center gap-1.5 cursor-pointer transition-colors"
                            >
                                <span className="material-symbols-outlined text-sm">arrow_upward</span>
                                <span>ऑफ़लाइन स्क्रीन</span>
                            </button>
                        </div>
                    </div>

                    {/* Search Bar */}
                    <div className="relative mb-3">
                        <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-lg">
                            search
                        </span>
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="ऑफलाइन खबरों में खोजें (उदा. शीर्षक, श्रेणी, लेखक)..."
                            className="w-full pl-10 pr-9 py-2.5 bg-white border border-gray-200 rounded-xl text-xs sm:text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 shadow-2xs transition-all"
                        />
                        {searchQuery && (
                            <button
                                type="button"
                                onClick={() => setSearchQuery('')}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 p-0.5 cursor-pointer"
                            >
                                <span className="material-symbols-outlined text-sm">close</span>
                            </button>
                        )}
                    </div>

                    {/* Category Filter Pills */}
                    {availableCategories.length > 2 && (
                        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 scrollbar-none">
                            {availableCategories.map(cat => (
                                <button
                                    key={cat}
                                    type="button"
                                    onClick={() => setSelectedCategory(cat)}
                                    className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                                        selectedCategory === cat 
                                            ? 'bg-red-600 text-white shadow-xs' 
                                            : 'bg-white hover:bg-gray-100 text-gray-600 border border-gray-200'
                                    }`}
                                >
                                    {cat === 'All' ? 'सभी (All)' : cat}
                                </button>
                            ))}
                        </div>
                    )}

                    {/* News Posts List */}
                    {isLoadingCached ? (
                        <div className="py-16 flex flex-col items-center justify-center text-gray-500 gap-3">
                            <div className="w-8 h-8 border-3 border-red-600 border-t-transparent rounded-full animate-spin" />
                            <p className="text-xs font-bold">IndexedDB से खबरें प्राप्त की जा रही हैं...</p>
                        </div>
                    ) : filteredCachedPosts.length === 0 ? (
                        <div className="p-8 my-6 bg-white rounded-2xl border border-gray-200 text-center shadow-2xs">
                            <div className="w-16 h-16 rounded-2xl bg-gray-100 text-gray-400 flex items-center justify-center mx-auto mb-3">
                                <span className="material-symbols-outlined text-3xl">inbox</span>
                            </div>
                            <h4 className="text-base font-black text-gray-900">
                                कोई सहेजी गई खबर नहीं मिली
                            </h4>
                            <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
                                {searchQuery 
                                    ? `"${searchQuery}" से मेल खाने वाला कोई समाचार नहीं मिला। कृपया दूसरा शब्द खोजें।`
                                    : 'अभी आपके डिवाइस के IndexedDB में कोई ऑफ़लाइन समाचार उपलब्ध नहीं है। जब आप ऑनलाइन होंगे, तो ऐप में लोड हुई खबरें यहां स्वतः सहेज ली जाएंगी।'
                                }
                            </p>
                            {searchQuery ? (
                                <button
                                    type="button"
                                    onClick={() => setSearchQuery('')}
                                    className="mt-4 px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                                >
                                    सर्च साफ़ करें
                                </button>
                            ) : (
                                <button
                                    type="button"
                                    onClick={handleTryAgain}
                                    className="mt-4 px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
                                >
                                    इंटरनेट कनेक्शन जांचें
                                </button>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-3 pb-8">
                            {filteredCachedPosts.map(post => (
                                <article 
                                    key={post.id}
                                    onClick={() => handleOpenPost(post)}
                                    className="p-3.5 sm:p-4 bg-white hover:bg-gray-50/80 rounded-2xl border border-gray-200/90 shadow-2xs hover:shadow-sm transition-all cursor-pointer flex flex-col sm:flex-row gap-3.5 items-start sm:items-center justify-between group"
                                >
                                    <div className="flex items-start gap-3 min-w-0 flex-1">
                                        {/* Optional Thumbnail or Fallback Icon */}
                                        <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-xl bg-gray-100 border border-gray-200 overflow-hidden shrink-0 flex items-center justify-center relative">
                                            {post.thumbnailUrl ? (
                                                <img 
                                                    src={post.thumbnailUrl} 
                                                    alt={post.title}
                                                    referrerPolicy="no-referrer"
                                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                                    onError={(e) => {
                                                        // Graceful fallback for offline image failures
                                                        const target = e.currentTarget;
                                                        target.style.display = 'none';
                                                        if (target.parentElement) {
                                                            const fallbackIcon = document.createElement('span');
                                                            fallbackIcon.className = 'material-symbols-outlined text-gray-400 text-2xl';
                                                            fallbackIcon.innerText = 'article';
                                                            target.parentElement.appendChild(fallbackIcon);
                                                        }
                                                    }}
                                                />
                                            ) : (
                                                <span className="material-symbols-outlined text-gray-400 text-2xl">
                                                    newspaper
                                                </span>
                                            )}
                                            <span className="absolute bottom-1 left-1 px-1 py-0.2 bg-black/60 backdrop-blur-xs text-[9px] text-white font-bold rounded">
                                                ऑफलाइन
                                            </span>
                                        </div>

                                        {/* Article Details */}
                                        <div className="min-w-0 flex-1">
                                            <div className="flex flex-wrap items-center gap-1.5 mb-1 text-[11px]">
                                                {post.category && (
                                                    <span className="px-2 py-0.5 bg-red-50 text-red-700 font-black rounded-md uppercase text-[10px]">
                                                        {post.category}
                                                    </span>
                                                )}
                                                {post.createdAt && (
                                                    <span className="text-gray-400 font-medium">
                                                        {new Date(post.createdAt).toLocaleDateString()}
                                                    </span>
                                                )}
                                                {post.authorName && (
                                                    <span className="text-gray-500 font-semibold truncate max-w-[120px]">
                                                        • {post.authorName}
                                                    </span>
                                                )}
                                            </div>

                                            <h4 className="text-sm sm:text-base font-bold text-gray-900 group-hover:text-red-600 transition-colors line-clamp-2 leading-snug">
                                                {post.title}
                                            </h4>

                                            {post.content && (
                                                <p className="text-xs text-gray-500 line-clamp-1 mt-1 leading-normal font-normal">
                                                    {post.content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ')}
                                                </p>
                                            )}
                                        </div>
                                    </div>

                                    {/* Action Buttons */}
                                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                                        <button
                                            type="button"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleShareOfflinePost(post);
                                            }}
                                            className="p-2 rounded-xl text-gray-500 hover:text-gray-800 hover:bg-gray-100 transition-colors cursor-pointer"
                                            title="शेयर करें"
                                        >
                                            <span className="material-symbols-outlined text-lg">share</span>
                                        </button>

                                        <button
                                            type="button"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleOpenPost(post);
                                            }}
                                            className="px-3.5 py-1.5 bg-red-50 group-hover:bg-red-600 text-red-700 group-hover:text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                                        >
                                            <span>पढ़ें</span>
                                            <span className="material-symbols-outlined text-sm">arrow_forward</span>
                                        </button>
                                    </div>
                                </article>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* FULL ARTICLE OFFLINE READER MODAL */}
            {activeModalPost && (
                <div 
                    className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs animate-in fade-in"
                    onClick={() => setActiveModalPost(null)}
                >
                    <div 
                        className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-gray-200 animate-in zoom-in-95"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Modal Header */}
                        <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md text-[10px] font-black uppercase">
                                    ऑफलाइन मोड
                                </span>
                                {activeModalPost.category && (
                                    <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-md text-[10px] font-black uppercase">
                                        {activeModalPost.category}
                                    </span>
                                )}
                            </div>

                            <button 
                                type="button"
                                onClick={() => setActiveModalPost(null)}
                                className="w-8 h-8 rounded-full hover:bg-gray-200 text-gray-600 flex items-center justify-center transition-colors cursor-pointer"
                                title="बंद करें (Close)"
                            >
                                <span className="material-symbols-outlined text-lg">close</span>
                            </button>
                        </div>

                        {/* Modal Content */}
                        <div className="p-4 sm:p-6 overflow-y-auto flex-1">
                            {/* Headline */}
                            <h2 className="text-xl sm:text-2xl font-black text-gray-900 leading-tight mb-3">
                                {activeModalPost.title}
                            </h2>

                            {/* Author & Date Metadata */}
                            <div className="flex items-center gap-3 text-xs text-gray-500 pb-4 mb-4 border-b border-gray-150">
                                {activeModalPost.authorName && (
                                    <span className="font-bold text-gray-800 flex items-center gap-1">
                                        <span className="material-symbols-outlined text-sm text-red-600">person</span>
                                        {activeModalPost.authorName}
                                    </span>
                                )}
                                {activeModalPost.createdAt && (
                                    <span className="flex items-center gap-1">
                                        <span className="material-symbols-outlined text-sm">calendar_today</span>
                                        {new Date(activeModalPost.createdAt).toLocaleDateString()}
                                    </span>
                                )}
                            </div>

                            {/* Optional Thumbnail */}
                            {activeModalPost.thumbnailUrl && (
                                <div className="mb-4 rounded-2xl overflow-hidden bg-gray-100 max-h-72 border border-gray-200">
                                    <img 
                                        src={activeModalPost.thumbnailUrl} 
                                        alt={activeModalPost.title}
                                        referrerPolicy="no-referrer"
                                        className="w-full h-full object-cover"
                                        onError={(e) => {
                                            e.currentTarget.style.display = 'none';
                                        }}
                                    />
                                </div>
                            )}

                            {/* Article Body */}
                            <div 
                                className="prose prose-sm sm:prose-base text-gray-800 leading-relaxed max-w-none"
                                dangerouslySetInnerHTML={{ __html: activeModalPost.content }}
                            />
                        </div>

                        {/* Modal Footer */}
                        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between text-xs">
                            <div className="text-gray-500 font-medium">
                                सहेजी गई खबर • IndexedDB
                            </div>
                            <div className="flex items-center gap-2">
                                <button
                                    type="button"
                                    onClick={() => handleShareOfflinePost(activeModalPost)}
                                    className="px-3 py-1.5 bg-white hover:bg-gray-100 text-gray-700 font-bold rounded-xl border border-gray-200 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                                >
                                    <span className="material-symbols-outlined text-sm">share</span>
                                    <span>शेयर</span>
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setActiveModalPost(null)}
                                    className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-xs cursor-pointer transition-colors"
                                >
                                    बंद करें
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OfflinePage;
