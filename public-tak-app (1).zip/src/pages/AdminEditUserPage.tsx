
import React, { useState, useEffect } from 'react';
import { User, Post } from '../types';
import Header from '../components/Header';
import { db, storage } from '../firebaseConfig';
import ConfirmationModal from '../components/ConfirmationModal';
import { formatCount } from '../utils/formatters';

interface AdminEditUserPageProps {
  userId: string;
  onBack: () => void;
  onEditPost: (postId: string) => void;
  onViewPost: (postId: string) => void;
}

const SkeletonEditUser = () => (
    <div className="w-full glass-card p-6 space-y-6 animate-pulse">
        <div className="h-8 w-1/3 bg-gray-200 rounded mb-4"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><div className="h-4 w-20 bg-gray-200 rounded mb-1"></div><div className="h-10 w-full bg-gray-200 rounded"></div></div>
            <div><div className="h-4 w-20 bg-gray-200 rounded mb-1"></div><div className="h-10 w-full bg-gray-200 rounded"></div></div>
        </div>
        <div><div className="h-4 w-20 bg-gray-200 rounded mb-1"></div><div className="h-20 w-full bg-gray-200 rounded"></div></div>
        <div className="h-10 w-32 bg-gray-200 rounded"></div>
    </div>
);

const AdminEditUserPage: React.FC<AdminEditUserPageProps> = ({ userId, onBack, onEditPost, onViewPost }) => {
    const [profileUser, setProfileUser] = useState<User | null>(null);
    const [posts, setPosts] = useState<Post[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    
    const [name, setName] = useState('');
    const [username, setUsername] = useState('');
    const [bio, setBio] = useState('');
    const [role, setRole] = useState<'user' | 'admin'>('user');
    const [isVerified, setIsVerified] = useState(false);
    const [asteriskCount, setAsteriskCount] = useState(0);
    const [isBanned, setIsBanned] = useState(false);
    const [banReason, setBanReason] = useState('');
    const [walletBalance, setWalletBalance] = useState(0);
    const [totalEarnings, setTotalEarnings] = useState(0);
    const [isSaving, setIsSaving] = useState(false);
    
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [postToDelete, setPostToDelete] = useState<{ id: string; thumbnailUrl: string } | null>(null);

    useEffect(() => {
        setLoading(true);
        const userDocRef = db.collection('users').doc(userId);
        const unsubscribeUser = userDocRef.onSnapshot((doc) => {
            if (doc.exists) {
                const userData = { uid: doc.id, ...doc.data() } as User;
                setProfileUser(userData);
                setName(userData.name);
                setUsername(userData.username);
                setBio(userData.bio);
                setRole(userData.role || 'user');
                setIsVerified(userData.isVerified || false);
                setAsteriskCount(userData.asteriskCount || 0);
                setIsBanned(userData.isBanned || false);
                setBanReason(userData.banReason || '');
                setWalletBalance(userData.walletBalance || 0);
                setTotalEarnings(userData.totalEarnings || 0);
            } else {
                setError("User not found.");
            }
            setLoading(false);
        }, (err) => {
            setError("Failed to load user data.");
            setLoading(false);
        });

        const postsQuery = db.collection('posts').where('authorId', '==', userId).orderBy('createdAt', 'desc');
        const unsubscribePosts = postsQuery.onSnapshot((snapshot) => {
            const userPosts = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
                createdAt: doc.data().createdAt?.toDate() || null,
            } as Post));
            setPosts(userPosts);
        }, (err) => {
            console.error("Failed to load posts:", err);
        });

        return () => {
            unsubscribeUser();
            unsubscribePosts();
        };
    }, [userId]);

    const handleProfileSave = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!profileUser) return;
        setIsSaving(true);
        try {
            const userDocRef = db.collection('users').doc(profileUser.uid);
            await userDocRef.update({ 
                name, 
                username, 
                bio,
                role,
                isVerified,
                asteriskCount: Number(asteriskCount),
                isBanned,
                banReason: isBanned ? banReason : '',
                walletBalance: Number(walletBalance),
                totalEarnings: Number(totalEarnings)
            });

            // Synchronize with admins collection
            const adminDocRef = db.collection('admins').doc(profileUser.uid);
            if (role === 'admin') {
                await adminDocRef.set({
                    uid: profileUser.uid,
                    name: name || profileUser.name,
                    email: profileUser.email || '',
                    role: 'admin',
                    updatedAt: new Date()
                }, { merge: true });
            } else {
                try {
                    await adminDocRef.delete();
                } catch (delErr) {
                    console.warn("Could not delete from admins collection:", delErr);
                }
            }

            alert("Profile updated successfully! User role and permissions synchronized.");
        } catch (err) {
            console.error("Error updating profile:", err);
            alert("Failed to update profile.");
        } finally {
            setIsSaving(false);
        }
    };
    
    const openDeleteModal = (postId: string, thumbnailUrl: string) => {
        setPostToDelete({ id: postId, thumbnailUrl });
        setIsDeleteModalOpen(true);
    };
    
    const handleDeletePost = async () => {
        if (!postToDelete) return;
        try {
            // 1. Delete Firestore Document (Priority)
            await db.collection("posts").doc(postToDelete.id).delete();
            
            // 2. Best effort storage delete
            if (postToDelete.thumbnailUrl && postToDelete.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                try {
                    const storageRef = storage.refFromURL(postToDelete.thumbnailUrl);
                    await storageRef.delete();
                } catch (storageErr) {
                    console.warn("Post deleted, but thumbnail cleanup failed:", storageErr);
                }
            }
        } catch (error: any) {
            console.error("Error deleting post:", error);
            alert(`Failed to delete post: ${error.message || "Unknown error"}`);
        } finally {
            setIsDeleteModalOpen(false);
            setPostToDelete(null);
        }
    };

    if (loading) {
        return (
            <div className="flex flex-col h-full bg-transparent">
                <Header title="Edit User" showBackButton onBack={onBack} />
                <main className="flex-grow p-5 md:p-10">
                    <SkeletonEditUser />
                </main>
            </div>
        );
    }

    if (error) {
        return <div className="flex flex-col h-full"><Header title="Error" showBackButton onBack={onBack} /><main className="flex-grow flex items-center justify-center"><p className="text-red-500">{error}</p></main></div>;
    }

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title={`Edit: ${profileUser?.name}`} showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-5 md:p-10 pb-20">
                <div className="w-full space-y-8">
                    <form onSubmit={handleProfileSave} className="glass-card p-6 space-y-4">
                        <h2 className="text-xl font-bold text-gray-800 border-b pb-3 mb-4">User Profile</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                                <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} className="w-full p-2 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500" />
                            </div>
                            <div>
                                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                                <input type="text" id="username" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-2 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500" />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                            <textarea id="bio" value={bio} onChange={e => setBio(e.target.value)} rows={3} className="w-full p-2 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 resize-y focus:ring-2 focus:ring-blue-500"></textarea>
                        </div>

                        {/* Role & Administrative Access */}
                        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-xl border border-purple-200 space-y-4">
                            <div className="flex items-center justify-between">
                                <h3 className="font-bold text-gray-800 flex items-center gap-2">
                                    <span className="material-symbols-outlined text-purple-600">admin_panel_settings</span>
                                    User Role & Access (यूजर भूमिका व अधिकार)
                                </h3>
                                <span className={`px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                                    role === 'admin' 
                                        ? 'bg-purple-600 text-white shadow-sm' 
                                        : 'bg-gray-200 text-gray-700'
                                }`}>
                                    {role === 'admin' ? '👑 Administrator' : '👤 Regular User'}
                                </span>
                            </div>
                            
                            <p className="text-xs text-gray-600 leading-relaxed">
                                {role === 'admin' 
                                    ? 'इस यूजर के पास संपूर्ण एडमिन एक्सेस सक्रिय है। यह यूजर एडमिन पैनल, उपयोगकर्ता प्रबंधन, बैन/अनबैन, कंटेंट मॉडरेशन, मोनेटाइजेशन, ई-पेपर और सेटिंग्स को बिना किसी अनुमति त्रुटि (Permission Error) के प्रबंधित कर सकता है।'
                                    : 'यह एक सामान्य यूजर है। यदि आप इसे एडमिन बनाएंगे तो इसे सभी प्रशासनिक सुविधाएं और डेटाबेस अनुमतियां तुरंत मिल जाएंगी।'
                                }
                            </p>

                            <div className="grid grid-cols-2 gap-3 pt-1">
                                <button
                                    type="button"
                                    onClick={() => setRole('user')}
                                    className={`p-3 rounded-xl border-2 font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                                        role === 'user'
                                            ? 'bg-white border-gray-700 text-gray-900 shadow-sm'
                                            : 'bg-white/60 border-gray-200 text-gray-500 hover:border-gray-300'
                                    }`}
                                >
                                    <span className="material-symbols-outlined text-base">person</span>
                                    Regular User (यूजर)
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setRole('admin')}
                                    className={`p-3 rounded-xl border-2 font-black text-xs flex items-center justify-center gap-2 transition-all ${
                                        role === 'admin'
                                            ? 'bg-purple-600 border-purple-700 text-white shadow-md'
                                            : 'bg-white/60 border-purple-200 text-purple-700 hover:border-purple-400'
                                    }`}
                                >
                                    <span className="material-symbols-outlined text-base">verified</span>
                                    Full Admin (एडमिन बनाएं)
                                </button>
                            </div>
                        </div>

                        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-6">
                            <h3 className="font-bold text-gray-700 flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600">security</span>
                                Moderation & Safety
                            </h3>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-3">
                                    <label className="block text-xs font-bold text-gray-500 uppercase">Warning Asterisks (*)</label>
                                    <div className="flex items-center gap-3">
                                        <button 
                                            type="button" 
                                            onClick={() => setAsteriskCount(Math.max(0, asteriskCount - 1))}
                                            className="w-10 h-10 flex items-center justify-center bg-white border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50"
                                        >
                                            <span className="material-symbols-outlined">remove</span>
                                        </button>
                                        <div className="flex-grow bg-white border border-gray-300 px-4 py-2 rounded-lg text-center font-black text-red-600 text-xl">
                                            {Array(asteriskCount).fill('*').join('') || 'No Asterisks'}
                                            {asteriskCount > 0 && <span className="text-gray-400 text-xs font-medium ml-2">({asteriskCount})</span>}
                                        </div>
                                        <button 
                                            type="button" 
                                            onClick={() => setAsteriskCount(asteriskCount + 1)}
                                            className="w-10 h-10 flex items-center justify-center bg-red-600 text-white rounded-lg hover:bg-red-700"
                                        >
                                            <span className="material-symbols-outlined">add</span>
                                        </button>
                                    </div>
                                    <p className="text-[10px] text-gray-500 italic">Add asterisks for minor violations. Multiple asterisks alert administrators.</p>
                                </div>

                                <div className="space-y-3">
                                    <label className="block text-xs font-bold text-gray-500 uppercase">Account Status</label>
                                    <div className={`p-4 rounded-xl border flex items-center justify-between ${isBanned ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
                                        <div className="flex items-center gap-3">
                                            <span className={`material-symbols-outlined ${isBanned ? 'text-red-600' : 'text-green-600'}`}>
                                                {isBanned ? 'block' : 'check_circle'}
                                            </span>
                                            <span className={`font-bold ${isBanned ? 'text-red-700' : 'text-green-700'}`}>
                                                {isBanned ? 'ACCOUNT BANNED' : 'ACCOUNT ACTIVE'}
                                            </span>
                                        </div>
                                        <button 
                                            type="button"
                                            onClick={() => setIsBanned(!isBanned)}
                                            className={`px-4 py-1.5 rounded-lg font-bold text-xs transition-all ${
                                                isBanned 
                                                ? 'bg-green-600 text-white hover:bg-green-700' 
                                                : 'bg-red-600 text-white hover:bg-red-700'
                                            }`}
                                        >
                                            {isBanned ? 'Unban User' : 'Ban User'}
                                        </button>
                                    </div>
                                    {isBanned && (
                                        <div className="mt-2 space-y-1">
                                            <label className="text-[11px] font-bold text-red-600 uppercase">Ban Reason (दिखने वाला कारण):</label>
                                            <input
                                                type="text"
                                                value={banReason}
                                                onChange={(e) => setBanReason(e.target.value)}
                                                placeholder="e.g. नियमों व शर्तों का उल्लंघन (Violation of Terms)"
                                                className="w-full p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-red-500"
                                            />
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-4">
                            <h3 className="font-bold text-gray-700 flex items-center gap-2">
                                <span className="material-symbols-outlined text-blue-600">workspace_premium</span>
                                Creator Features
                            </h3>
                            <div className="flex items-center gap-2">
                                <input 
                                    type="checkbox" 
                                    id="isVerified" 
                                    checked={isVerified} 
                                    onChange={e => setIsVerified(e.target.checked)}
                                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                                />
                                <label htmlFor="isVerified" className="text-sm font-bold text-gray-700 select-none cursor-pointer">
                                    Verified Reporter (Blue Tick)
                                </label>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="walletBalance" className="block text-xs font-bold text-gray-500 uppercase">Wallet Balance (₹)</label>
                                    <input 
                                        type="number" 
                                        id="walletBalance" 
                                        value={walletBalance} 
                                        onChange={e => setWalletBalance(Number(e.target.value))} 
                                        className="w-full p-2 border border-gray-300 bg-white rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 font-mono"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="totalEarnings" className="block text-xs font-bold text-gray-500 uppercase">Lifetime Earnings (₹)</label>
                                    <input 
                                        type="number" 
                                        id="totalEarnings" 
                                        value={totalEarnings} 
                                        onChange={e => setTotalEarnings(Number(e.target.value))} 
                                        className="w-full p-2 border border-gray-300 bg-white rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 font-mono"
                                    />
                                </div>
                            </div>
                        </div>

                        <button 
                            type="submit" 
                            disabled={isSaving} 
                            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white border-none rounded-xl text-lg font-black shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-0.5 active:scale-95 disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2"
                        >
                            {isSaving ? (
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                            ) : (
                                <span className="material-symbols-outlined text-xl">save</span>
                            )}
                            <span>{isSaving ? 'Saving...' : 'Save Profile'}</span>
                        </button>
                    </form>

                    <div>
                        <h2 className="text-xl font-bold text-gray-800 mb-4">User Posts ({posts.length})</h2>
                        <div className="space-y-4">
                            {posts.length > 0 ? posts.map(post => (
                                <div key={post.id} className="glass-card p-4 flex items-start gap-4">
                                    <div onClick={() => onViewPost(post.id)} className="flex-grow flex items-start gap-4 cursor-pointer">
                                        {post.thumbnailUrl && <img src={post.thumbnailUrl} alt={post.title} className="w-24 h-24 object-cover rounded-md flex-shrink-0" />}
                                        <div className="flex-grow">
                                            <h3 className="font-bold text-red-600 line-clamp-2">{post.title}</h3>
                                            <p className="text-sm text-gray-500 mt-1">
                                                Published: {post.createdAt ? post.createdAt.toLocaleDateString() : 'N/A'}
                                            </p>
                                            <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                                                <span className="material-symbols-outlined text-base">visibility</span>
                                                <span>{formatCount(post.viewCount || 0)}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex flex-col gap-2">
                                        <button onClick={() => onEditPost(post.id)} className="p-2 text-blue-600 bg-blue-100 hover:bg-blue-200 rounded-full transition-colors">
                                            <span className="material-symbols-outlined">edit</span>
                                        </button>
                                        <button onClick={() => openDeleteModal(post.id, post.thumbnailUrl)} className="p-2 text-red-600 bg-red-100 hover:bg-red-200 rounded-full transition-colors">
                                            <span className="material-symbols-outlined">delete</span>
                                        </button>
                                    </div>
                                </div>
                            )) : (
                                <div className="text-center py-8 glass-card">
                                    <p className="text-gray-600">This user has not created any posts.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </main>
            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleDeletePost}
                title="Confirm Post Deletion"
                message="Are you sure you want to permanently delete this post? This action cannot be undone."
                confirmButtonText="Delete Post"
            />
        </div>
    );
};

export default AdminEditUserPage;
