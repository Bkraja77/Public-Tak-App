
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { db, firebase } from '../firebaseConfig';
import { WithdrawalRequest, User } from '../types';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';

const ManageWithdrawalsPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const { showToast } = useToast();
    const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedRequest, setSelectedRequest] = useState<WithdrawalRequest | null>(null);
    const [utrNumber, setUtrNumber] = useState('');
    const [rejectReason, setRejectReason] = useState('');
    const [showProcessModal, setShowProcessModal] = useState(false);
    const [showRejectModal, setShowRejectModal] = useState(false);
    const [isActing, setIsActing] = useState(false);

    useEffect(() => {
        const unsubscribe = db.collection('admin_withdrawals')
            .where('status', '==', 'pending')
            .orderBy('requestedAt', 'desc')
            .onSnapshot(snapshot => {
                const list = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                    requestedAt: doc.data().requestedAt?.toDate() || new Date(),
                    processedAt: doc.data().processedAt?.toDate() || null
                } as WithdrawalRequest));
                setRequests(list);
                setLoading(false);
            }, err => {
                console.error("Error fetching withdrawal requests:", err);
                setLoading(false);
            });

        return () => unsubscribe();
    }, []);

    const handleComplete = async () => {
        if (!selectedRequest || !utrNumber) return;
        setIsActing(true);

        try {
            const batch = db.batch();
            
            // 1. Update in global admin collection
            const adminRef = db.collection('admin_withdrawals').doc(selectedRequest.id);
            batch.update(adminRef, { 
                status: 'completed', 
                utrNumber: utrNumber,
                processedAt: new Date() 
            });

            // 2. Update in user's subcollection
            const userSubRef = db.collection('users').doc(selectedRequest.userId).collection('withdrawals').doc(selectedRequest.id);
            batch.update(userSubRef, { 
                status: 'completed', 
                utrNumber: utrNumber,
                processedAt: new Date() 
            });

            await batch.commit();
            showToast(`Withdrawal of ₹${selectedRequest.amount} marked as completed!`, "success");
            setShowProcessModal(false);
            setSelectedRequest(null);
            setUtrNumber('');
        } catch (error) {
            console.error("Completion error:", error);
            showToast("Failed to complete request", "error");
        } finally {
            setIsActing(false);
        }
    };

    const handleReject = async () => {
        if (!selectedRequest || !rejectReason) return;
        setIsActing(true);

        try {
            const batch = db.batch();
            
            // 1. Refund the amount back to user's wallet
            const userRef = db.collection('users').doc(selectedRequest.userId);
            batch.update(userRef, {
                walletBalance: firebase.firestore.FieldValue.increment(selectedRequest.amount)
            });

            // 2. Update status to rejected
            const adminRef = db.collection('admin_withdrawals').doc(selectedRequest.id);
            batch.update(adminRef, { 
                status: 'rejected', 
                remarks: rejectReason,
                processedAt: new Date() 
            });

            const userSubRef = db.collection('users').doc(selectedRequest.userId).collection('withdrawals').doc(selectedRequest.id);
            batch.update(userSubRef, { 
                status: 'rejected', 
                remarks: rejectReason,
                processedAt: new Date() 
            });

            await batch.commit();
            showToast("Withdrawal rejected and amount refunded to user wallet.", "info");
            setShowRejectModal(false);
            setSelectedRequest(null);
            setRejectReason('');
        } catch (error) {
            console.error("Rejection error:", error);
            showToast("Failed to reject request", "error");
        } finally {
            setIsActing(false);
        }
    };

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        showToast("Copied to clipboard!", "success");
    };

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Manage Withdrawals" showBackButton onBack={onBack} />
            
            <main className="flex-grow overflow-y-auto p-4 md:p-8">
                <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* List Section */}
                    <div className="lg:col-span-1 space-y-4">
                        <div className="flex justify-between items-center px-1">
                            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Pending Requests</h3>
                            <span className="bg-red-100 text-red-600 text-[10px] font-black px-2 py-0.5 rounded-full">{requests.length}</span>
                        </div>

                        {loading ? (
                            <div className="p-12 flex justify-center"><div className="w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div></div>
                        ) : requests.length === 0 ? (
                            <div className="glass-card p-12 text-center text-gray-400">
                                <span className="material-symbols-outlined text-5xl mb-3 opacity-20">payments</span>
                                <p>No pending payouts.</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {requests.map(req => (
                                    <button 
                                        key={req.id}
                                        onClick={() => setSelectedRequest(req)}
                                        className={`w-full text-left glass-card p-4 transition-all flex items-center justify-between gap-3 ${selectedRequest?.id === req.id ? 'ring-2 ring-red-500 bg-red-50/20' : 'hover:bg-white'}`}
                                    >
                                        <div className="flex items-center gap-3 overflow-hidden">
                                            <div className="w-10 h-10 rounded-xl bg-gray-900 text-white flex items-center justify-center font-bold text-lg">₹</div>
                                            <div className="min-w-0">
                                                <p className="font-black text-gray-900 leading-none">₹{req.amount}</p>
                                                <p className="text-[10px] text-gray-500 mt-1 truncate">{req.userName}</p>
                                            </div>
                                        </div>
                                        <div className="text-right shrink-0">
                                            <span className="material-symbols-outlined text-gray-300">chevron_right</span>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Detail Section */}
                    <div className="lg:col-span-2">
                        <AnimatePresence mode="wait">
                            {selectedRequest ? (
                                <motion.div 
                                    key={selectedRequest.id}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="glass-card overflow-hidden h-full flex flex-col"
                                >
                                    <div className="bg-gray-900 p-8 text-white">
                                        <div className="flex justify-between items-start mb-6">
                                            <div>
                                                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-bold">Payout Amount</p>
                                                <h2 className="text-4xl font-black mt-1">₹{selectedRequest.amount}</h2>
                                            </div>
                                            <div className="px-3 py-1 bg-yellow-500/20 text-yellow-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-yellow-500/30">
                                                Pending processing
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <p className="text-gray-500 text-[10px] uppercase font-bold">Request By</p>
                                                <p className="font-bold text-sm">{selectedRequest.userName}</p>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-gray-500 text-[10px] uppercase font-bold">Requested At</p>
                                                <p className="text-sm">{selectedRequest.requestedAt.toLocaleString()}</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="p-8 flex-grow space-y-8">
                                        <div className="space-y-4">
                                            <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Bank / UPI Details</h4>
                                            
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                {selectedRequest.bankDetails.upiId && (
                                                    <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl relative group">
                                                        <p className="text-[10px] font-bold text-blue-500 uppercase">UPI ID</p>
                                                        <p className="text-lg font-black text-blue-900 mt-1">{selectedRequest.bankDetails.upiId}</p>
                                                        <button 
                                                            onClick={() => copyToClipboard(selectedRequest.bankDetails.upiId)}
                                                            className="absolute top-4 right-4 text-blue-600 hover:scale-110 active:scale-90 transition-transform"
                                                        >
                                                            <span className="material-symbols-outlined text-sm">content_copy</span>
                                                        </button>
                                                    </div>
                                                )}
                                                {selectedRequest.bankDetails.accountHolderName && (
                                                    <div className="p-4 bg-gray-50 border border-gray-100 rounded-2xl">
                                                        <p className="text-[10px] font-bold text-gray-400 uppercase">Account Holder</p>
                                                        <p className="font-bold text-gray-800 mt-1">{selectedRequest.bankDetails.accountHolderName}</p>
                                                    </div>
                                                )}
                                                {selectedRequest.bankDetails.accountNumber && (
                                                    <div className="p-4 bg-gray-50 border border-gray-100 rounded-2xl relative group">
                                                        <p className="text-[10px] font-bold text-gray-400 uppercase">Account Number</p>
                                                        <p className="font-bold text-gray-800 mt-1">{selectedRequest.bankDetails.accountNumber}</p>
                                                        <button 
                                                            onClick={() => copyToClipboard(selectedRequest.bankDetails.accountNumber)}
                                                            className="absolute top-4 right-4 text-gray-400"
                                                        >
                                                            <span className="material-symbols-outlined text-sm">content_copy</span>
                                                        </button>
                                                    </div>
                                                )}
                                                {selectedRequest.bankDetails.ifscCode && (
                                                    <div className="p-4 bg-gray-50 border border-gray-100 rounded-2xl">
                                                        <p className="text-[10px] font-bold text-gray-400 uppercase">IFSC Code</p>
                                                        <p className="font-bold text-gray-800 mt-1">{selectedRequest.bankDetails.ifscCode}</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>

                                        <div className="flex flex-col md:flex-row gap-4 pt-6 border-t border-gray-100">
                                            <button 
                                                onClick={() => setShowProcessModal(true)}
                                                className="flex-grow py-4 bg-red-600 text-white font-black rounded-2xl hover:bg-red-700 shadow-xl shadow-red-200 flex items-center justify-center gap-3 transition-all active:scale-95"
                                            >
                                                <span className="material-symbols-outlined">check_circle</span>
                                                Mark as Paid
                                            </button>
                                            <button 
                                                onClick={() => setShowRejectModal(true)}
                                                className="px-6 py-4 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-red-100 hover:text-red-600 transition-all"
                                            >
                                                Reject Request
                                            </button>
                                        </div>
                                    </div>
                                </motion.div>
                            ) : (
                                <div className="h-full min-h-[400px] flex flex-col items-center justify-center glass-card text-gray-400 p-12 text-center">
                                    <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6 border border-gray-100">
                                        <span className="material-symbols-outlined text-6xl opacity-30">account_balance_wallet</span>
                                    </div>
                                    <h2 className="text-xl font-bold text-gray-800 mb-2">Payout Dashboard</h2>
                                    <p className="max-w-sm">Select a pending withdrawal request to view details and process the payment to the user's account.</p>
                                </div>
                            )}
                        </AnimatePresence>
                    </div>
                </div>
            </main>

            {/* Process Modal */}
            <AnimatePresence>
                {showProcessModal && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                        <motion.div 
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
                        >
                            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                                <span className="material-symbols-outlined text-3xl">currency_rupee</span>
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 text-center mb-2">Complete Payment</h3>
                            <p className="text-gray-500 text-sm text-center mb-6">
                                Please enter the Transaction ID / UTR Number after sending ₹{selectedRequest?.amount} to the user.
                            </p>
                            
                            <div className="space-y-4">
                                <input 
                                    type="text" 
                                    value={utrNumber}
                                    onChange={(e) => setUtrNumber(e.target.value)}
                                    placeholder="Enter UTR / Transaction ID"
                                    className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-red-500 transition-all outline-none font-bold"
                                />
                                <div className="flex gap-4 pt-2">
                                    <button 
                                        onClick={() => setShowProcessModal(false)}
                                        className="flex-1 py-4 bg-gray-100 text-gray-700 font-bold rounded-2xl hover:bg-gray-200"
                                    >
                                        Cancel
                                    </button>
                                    <button 
                                        onClick={handleComplete}
                                        disabled={!utrNumber || isActing}
                                        className="flex-2 py-4 bg-green-600 text-white font-black rounded-2xl hover:bg-green-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                                    >
                                        {isActing ? '...' : (
                                            <>Confirm Paid <span className="material-symbols-outlined text-sm">send</span></>
                                        )}
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>

            {/* Reject Modal */}
            <AnimatePresence>
                {showRejectModal && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                        <motion.div 
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
                        >
                            <h3 className="text-xl font-bold text-gray-900 mb-2">Reject Request</h3>
                            <p className="text-gray-500 text-sm mb-4">The amount (₹{selectedRequest?.amount}) will be refunded back to the user's wallet.</p>
                            
                            <textarea 
                                value={rejectReason}
                                onChange={(e) => setRejectReason(e.target.value)}
                                placeholder="Reason for rejection (e.g. Invalid UPI ID)"
                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl min-h-[120px] focus:ring-2 focus:ring-red-500 transition-all outline-none mb-6"
                            ></textarea>

                            <div className="flex gap-4">
                                <button 
                                    onClick={() => setShowRejectModal(false)}
                                    className="flex-1 py-3 bg-gray-100 text-gray-700 font-bold rounded-xl"
                                >
                                    Cancel
                                </button>
                                <button 
                                    onClick={handleReject}
                                    disabled={!rejectReason || isActing}
                                    className="flex-2 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 disabled:opacity-50"
                                >
                                    {isActing ? '...' : 'Reject & Refund'}
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default ManageWithdrawalsPage;
