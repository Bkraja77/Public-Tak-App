
import React, { useState, useRef, useEffect } from 'react';
import Header from '../components/Header';
import { User, Draft, View } from '../types';
import { db, storage, serverTimestamp, firebase, increment } from '../firebaseConfig';
import { subscribeCategories } from '../utils/categories';
import { v4 as uuidv4 } from 'uuid';
import LocationSelector from '../components/LocationSelector';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { uploadManager } from '../services/uploadManager';

import { checkContentSafety } from '../services/geminiService';

interface CreatePostPageProps {
  onBack: () => void;
  currentUser: User | null;
  draftId?: string | null;
  onNavigate: (view: View, params?: any) => void;
}

const newsCategoriesFallback = ['Politics', 'Crime', 'Sports', 'Entertainment', 'Business', 'Technology', 'Health', 'Education', 'Jobs', 'World', 'General'];
const videoCategoriesFallback = ['Politics', 'Crime', 'Sports', 'Entertainment', 'Business', 'Technology', 'Health', 'Education', 'Jobs', 'World', 'General'];
const MAX_TITLE_LENGTH = 200;

const compressImage = (file: File, quality: number = 0.8, maxSize: number = 1280): Promise<File> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let { width, height } = img;

                if (width > height) {
                    if (width > maxSize) {
                        height *= maxSize / width;
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width *= maxSize / height;
                        height = maxSize;
                    }
                }

                canvas.width = width;
                canvas.height = height;

                const ctx = canvas.getContext('2d');
                if (!ctx) return reject(new Error('Could not get canvas context'));
                
                ctx.drawImage(img, 0, 0, width, height);

                canvas.toBlob(
                    (blob) => {
                        if (blob) {
                            resolve(new File([blob], file.name, { type: 'image/jpeg', lastModified: Date.now() }));
                        } else {
                            reject(new Error('Canvas toBlob failed'));
                        }
                    },
                    'image/jpeg',
                    quality
                );
            };
            img.onerror = () => reject(new Error('Failed to load image for compression'));
        };
        reader.onerror = () => reject(new Error('Failed to read file for compression'));
    });
};


interface RichTextEditorToolbarProps {
    editorRef: React.RefObject<HTMLDivElement>;
    onImageUpload: () => void;
    onAlign: (alignment: 'left' | 'center' | 'right') => void;
    isImageSelected: boolean;
}

const RichTextEditorToolbar: React.FC<RichTextEditorToolbarProps> = ({ editorRef, onImageUpload, onAlign, isImageSelected }) => {
    const handleCommand = (command: string, value: string | null = null) => {
        if (editorRef.current) {
            editorRef.current.focus();
            document.execCommand(command, false, value || undefined);
        }
    };

    const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        handleCommand('foreColor', e.target.value);
    };

    const preventDefault = (e: React.MouseEvent | React.ChangeEvent<HTMLSelectElement>) => e.preventDefault();

    return (
        <div className="flex items-center flex-wrap gap-1 p-2 border border-b-0 border-gray-300 bg-gray-50 rounded-t-lg text-gray-700 sticky top-0 z-10">
            <button type="button" onMouseDown={preventDefault} onClick={() => handleCommand('bold')} className="p-2 hover:bg-gray-200 rounded" title="Bold"><span className="material-symbols-outlined">format_bold</span></button>
            <button type="button" onMouseDown={preventDefault} onClick={() => handleCommand('italic')} className="p-2 hover:bg-gray-200 rounded" title="Italic"><span className="material-symbols-outlined">format_italic</span></button>
            <button type="button" onMouseDown={preventDefault} onClick={() => handleCommand('underline')} className="p-2 hover:bg-gray-200 rounded" title="Underline"><span className="material-symbols-outlined">format_underlined</span></button>
            
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            
            <button 
                type="button" 
                onMouseDown={preventDefault} 
                onClick={() => onAlign('left')} 
                className={`p-2 hover:bg-gray-200 rounded ${isImageSelected ? 'text-blue-600' : ''}`} 
                title={isImageSelected ? "Align Image Left" : "Align Text Left"}
            >
                <span className="material-symbols-outlined">format_align_left</span>
            </button>
            <button 
                type="button" 
                onMouseDown={preventDefault} 
                onClick={() => onAlign('center')} 
                className={`p-2 hover:bg-gray-200 rounded ${isImageSelected ? 'text-blue-600' : ''}`} 
                title={isImageSelected ? "Align Image Center" : "Align Text Center"}
            >
                <span className="material-symbols-outlined">format_align_center</span>
            </button>
            <button 
                type="button" 
                onMouseDown={preventDefault} 
                onClick={() => onAlign('right')} 
                className={`p-2 hover:bg-gray-200 rounded ${isImageSelected ? 'text-blue-600' : ''}`} 
                title={isImageSelected ? "Align Image Right" : "Align Text Right"}
            >
                <span className="material-symbols-outlined">format_align_right</span>
            </button>

            <div className="h-6 border-l border-gray-300 mx-1"></div>

            <div className="relative p-2 hover:bg-gray-200 rounded" title="Text Color">
                <span className="material-symbols-outlined">format_color_text</span>
                <input type="color" onChange={handleColorChange} className="absolute inset-0 opacity-0 w-full h-full cursor-pointer" />
            </div>
            <div className="h-6 border-l border-gray-300 mx-1"></div>
            <button type="button" onMouseDown={preventDefault} onClick={onImageUpload} className="p-2 hover:bg-gray-200 rounded" title="Insert Image">
                <span className="material-symbols-outlined">image</span>
            </button>
        </div>
    );
};

const uploadFileWithProgress = (
    file: File, 
    path: string, 
    contentType: string,
    onProgress: (percent: number) => void
): Promise<string> => {
    return new Promise((resolve, reject) => {
        const fileRef = storage.ref(path);
        
        // Resilient progress helper to guarantee smooth UI progression and avoid freezing
        let currentPercent = 0;
        
        // Estimate upload duration based on size: ~1.5s per MB, min 5s, max 30s
        const fileSizeMB = file.size / (1024 * 1024);
        const estimatedTimeMs = Math.max(5000, Math.min(30000, fileSizeMB * 1500));
        const intervalMs = 100;
        const totalSteps = estimatedTimeMs / intervalMs;
        const stepIncrement = 95 / totalSteps;
        
        const progressInterval = setInterval(() => {
            if (currentPercent < 95) {
                // Decay progress rate as we approach 95%
                const remaining = 95 - currentPercent;
                const decayFactor = remaining / 95;
                currentPercent = Math.min(95, currentPercent + (stepIncrement * (0.2 + decayFactor * 0.8)));
                onProgress(currentPercent);
            }
        }, intervalMs);

        const uploadTask = fileRef.put(file, { contentType });
        
        uploadTask.on('state_changed', 
            (snapshot) => {
                const realPercent = snapshot.totalBytes > 0 
                    ? (snapshot.bytesTransferred / snapshot.totalBytes) * 100 
                    : 0;
                // Merge real progress with simulated progress smoothly
                if (realPercent > currentPercent) {
                    currentPercent = Math.min(98, realPercent);
                    onProgress(currentPercent);
                }
            },
            (error) => {
                clearInterval(progressInterval);
                const safeErr = new Error(error?.message || String(error));
                (safeErr as any).code = (error as any)?.code || 'unknown';
                reject(safeErr);
            },
            async () => {
                try {
                    clearInterval(progressInterval);
                    onProgress(100);
                    const downloadUrl = await uploadTask.snapshot.ref.getDownloadURL();
                    resolve(downloadUrl);
                } catch (urlErr: any) {
                    const safeUrlErr = new Error(urlErr?.message || String(urlErr));
                    (safeUrlErr as any).code = urlErr?.code || 'unknown';
                    reject(safeUrlErr);
                }
            }
        );
    });
};

const CreatePostPage: React.FC<CreatePostPageProps> = ({ onBack, currentUser, draftId, onNavigate }) => {
    const [postType, setPostType] = useState<'article' | 'video'>('article');
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [category, setCategory] = useState('');
    const [newsCategories, setNewsCategories] = useState<string[]>(newsCategoriesFallback);
    const [videoCategories, setVideoCategories] = useState<string[]>(videoCategoriesFallback);

    useEffect(() => {
        const unsubscribe = subscribeCategories((data) => {
            setNewsCategories(data.newsCategories);
            setVideoCategories(data.videoCategories);
        });
        return unsubscribe;
    }, []);

    const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
    const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
    // For drafts, we might already have a remote URL if loaded
    const [existingThumbnailUrl, setExistingThumbnailUrl] = useState<string | null>(null);

    const [isLoading, setIsLoading] = useState(false);
    const [isSavingDraft, setIsSavingDraft] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const editorRef = useRef<HTMLDivElement>(null);
    const imageInputRef = useRef<HTMLInputElement>(null);
    const [isUploadingImage, setIsUploadingImage] = useState(false);
    const savedRange = useRef<Range | null>(null);
    
    // Video-specific states
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [videoPreview, setVideoPreview] = useState<string | null>(null);
    const [videoDescription, setVideoDescription] = useState('');
    const videoInputRef = useRef<HTMLInputElement>(null);
    const previewVideoRef = useRef<HTMLVideoElement>(null);
    const [isDraggingVideo, setIsDraggingVideo] = useState(false);
    
    // Store image DOM element in ref to avoid circular JSON error in state
    const selectedImageRef = useRef<HTMLImageElement | null>(null);
    const [isImageSelected, setIsImageSelected] = useState(false);

    // Safety Alert Modal State
    const [safetyModalData, setSafetyModalData] = useState<{
        isOpen: boolean;
        reason: string;
        category: string;
        postId: string;
    }>({ isOpen: false, reason: '', category: '', postId: '' });
    
    // Location state
    const [state, setState] = useState('');
    const [district, setDistrict] = useState('');
    const [block, setBlock] = useState('');

    const [uploadProgress, setUploadProgress] = useState<number>(0);
    const [uploadStage, setUploadStage] = useState<string>('');
    
    const { t } = useLanguage();
    const { showToast } = useToast();

    // Video Drag and Drop Handlers
    const handleVideoDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDraggingVideo(true);
    };
    const handleVideoDragLeave = () => {
        setIsDraggingVideo(false);
    };
    const handleVideoDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDraggingVideo(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            if (file.type.startsWith('video/')) {
                if (file.size > 50 * 1024 * 1024) {
                    setError("Video is too large. Please select a video under 50MB.");
                    showToast("Video is too large (max 50MB)", "error");
                    return;
                }
                setVideoFile(file);
                setVideoPreview(URL.createObjectURL(file));
                setError(null);
            } else {
                showToast("Please drop a video file.", "error");
            }
        }
    };
    const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (file.size > 50 * 1024 * 1024) {
                setError("Video is too large. Please select a video under 50MB.");
                showToast("Video is too large (max 50MB)", "error");
                return;
            }
            setVideoFile(file);
            setVideoPreview(URL.createObjectURL(file));
            setError(null);
        }
    };

    const captureVideoFrame = (auto = false) => {
        const video = previewVideoRef.current;
        if (!video) return;

        try {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 360;
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob((blob) => {
                    if (blob) {
                        const capturedFile = new File([blob], `thumbnail_${Date.now()}.jpg`, { type: 'image/jpeg', lastModified: Date.now() });
                        setThumbnailFile(capturedFile);
                        setThumbnailPreview(URL.createObjectURL(capturedFile));
                        if (!auto) {
                            showToast("Video frame set as thumbnail!", "success");
                        }
                    }
                }, 'image/jpeg', 0.85);
            }
        } catch (err: any) {
            console.error("Frame capture failed:", err?.message || String(err));
            if (!auto) {
                showToast("Failed to set video frame as thumbnail", "error");
            }
        }
    };

    // Load Draft Data if draftId exists
    useEffect(() => {
        if (draftId && currentUser) {
            setIsLoading(true);
            const draftRef = db.collection('users').doc(currentUser.uid).collection('drafts').doc(draftId);
            draftRef.get().then((doc) => {
                if (doc.exists) {
                    const data = doc.data() as Draft;
                    setTitle(data.title || '');
                    setContent(data.content || '');
                    setCategory(data.category || '');
                    setState(data.state || '');
                    setDistrict(data.district || '');
                    setBlock(data.block || '');
                    if (data.thumbnailUrl) {
                        setThumbnailPreview(data.thumbnailUrl);
                        setExistingThumbnailUrl(data.thumbnailUrl);
                    }
                    if (editorRef.current) {
                        editorRef.current.innerHTML = data.content || '';
                    }
                }
                setIsLoading(false);
            }).catch(err => {
                console.error("Error loading draft:", err.message || err);
                showToast("Failed to load draft", "error");
                setIsLoading(false);
            });
        }
    }, [draftId, currentUser]);


    const [isDragging, setIsDragging] = useState(false);
    
    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };
    
    const handleDragLeave = () => {
        setIsDragging(false);
    };
    
    const handleDrop = async (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            if (file.type.startsWith('image/')) {
                if (file.size > 10 * 1024 * 1024) { 
                    setError("Image is too large. Please select a file under 10MB.");
                    showToast("Image is too large", "error");
                    return;
                }
                try {
                    const compressedFile = await compressImage(file);
                    setThumbnailFile(compressedFile);
                    setThumbnailPreview(URL.createObjectURL(compressedFile));
                    setError(null);
                } catch (err) {
                    console.error("Image compression error:", err);
                    setError("Could not process image.");
                    showToast("Could not process image", "error");
                }
            } else {
                showToast("Please drop an image file.", "error");
            }
        }
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (file.size > 10 * 1024 * 1024) { 
                setError("Image is too large. Please select a file under 10MB.");
                showToast("Image is too large", "error");
                return;
            }
            try {
                const compressedFile = await compressImage(file);
                setThumbnailFile(compressedFile);
                setThumbnailPreview(URL.createObjectURL(compressedFile));
                setError(null);
            } catch (err) {
                console.error("Image compression error:", err);
                setError("Could not process image. Please try another one.");
                showToast("Could not process image", "error");
                setThumbnailFile(null);
                setThumbnailPreview(null);
            }
        }
    };
    
    const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
        setContent(e.currentTarget.innerHTML);
    };

    const handleEditorClick = (e: React.MouseEvent) => {
        const target = e.target as HTMLElement;
        
        // Handle previous selection
        if (selectedImageRef.current && target !== selectedImageRef.current) {
            if (selectedImageRef.current.isConnected) {
                selectedImageRef.current.style.outline = 'none';
            }
            selectedImageRef.current = null;
            setIsImageSelected(false);
        }

        // Handle new selection
        if (target.tagName === 'IMG') {
            const img = target as HTMLImageElement;
            selectedImageRef.current = img;
            img.style.outline = '3px solid #3b82f6'; // Visual feedback
            img.style.outlineOffset = '2px';
            setIsImageSelected(true);
        }
    };

    const handleAlignment = (alignment: 'left' | 'center' | 'right') => {
        if (selectedImageRef.current) {
            const img = selectedImageRef.current;
            // Aligning specific selected image
            if (alignment === 'left') {
                img.style.float = 'left';
                img.style.margin = '0 1rem 1rem 0';
                img.style.display = 'block';
            } else if (alignment === 'right') {
                img.style.float = 'right';
                img.style.margin = '0 0 1rem 1rem';
                img.style.display = 'block';
            } else if (alignment === 'center') {
                img.style.float = 'none';
                img.style.margin = '1rem auto';
                img.style.display = 'block';
            }
            // Update the content state to reflect the style change immediately
            if (editorRef.current) {
                setContent(editorRef.current.innerHTML);
            }
        } else {
            // Standard text alignment
            const command = alignment === 'left' ? 'justifyLeft' : alignment === 'center' ? 'justifyCenter' : 'justifyRight';
            document.execCommand(command, false, undefined);
            editorRef.current?.focus();
        }
    };
    
    const handleTriggerImageUpload = () => {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            savedRange.current = selection.getRangeAt(0);
        }
        imageInputRef.current?.click();
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files || !e.target.files[0]) return;
        const file = e.target.files[0];
        
        if (file.size > 5 * 1024 * 1024) { 
            setError("Image file is too large. Please select an image under 5MB.");
            showToast("Image file is too large", "error");
            return;
        }

        setIsUploadingImage(true);
        setError(null);

        try {
            const imageRef = storage.ref(`post-images/${uuidv4()}-${file.name}`);
            const uploadTask = await imageRef.put(file);
            const imageUrl = await uploadTask.ref.getDownloadURL();

            if (savedRange.current) {
                const selection = window.getSelection();
                selection?.removeAllRanges();
                selection?.addRange(savedRange.current);
            } else {
                editorRef.current?.focus();
            }

            const imgHtml = `<img src="${imageUrl}" alt="uploaded content" style="max-width: 100%; height: auto; border-radius: 0.5rem; margin: 1rem 0; display: block;" />`;
            document.execCommand('insertHTML', false, imgHtml);
            
            if (editorRef.current) {
                setContent(editorRef.current.innerHTML);
            }
            savedRange.current = null;
            showToast("Image inserted successfully", "success");

        } catch (err: any) {
            console.error("Image upload failed:", err?.message || String(err));
            setError("Image upload failed. Please try again.");
            showToast("Image upload failed", "error");
        } finally {
            setIsUploadingImage(false);
            if (e.target) e.target.value = '';
        }
    };

    const handleSaveDraft = async () => {
        if (!currentUser) {
            showToast("Please log in to save drafts.", "error");
            return;
        }
        if (!title.trim()) {
            showToast("Please add at least a title to save a draft.", "error");
            return;
        }

        setIsSavingDraft(true);
        try {
            let thumbnailUrl = existingThumbnailUrl || '';

            if (thumbnailFile) {
                const fileExtension = thumbnailFile.name.split('.').pop();
                // Using a standard path that is likely allowed by storage rules
                const thumbnailRef = storage.ref(`thumbnails/drafts/${currentUser.uid}/${uuidv4()}.${fileExtension}`);
                const uploadResult = await thumbnailRef.put(thumbnailFile);
                thumbnailUrl = await uploadResult.ref.getDownloadURL();
                
                setExistingThumbnailUrl(thumbnailUrl);
                setThumbnailFile(null); 
            }

            const draftData = {
                title,
                content,
                category,
                thumbnailUrl,
                state,
                district,
                block,
                authorId: currentUser.uid,
                updatedAt: serverTimestamp(),
            };
            
            // Remove undefined values
            const cleanData = Object.fromEntries(Object.entries(draftData).filter(([_, v]) => v !== undefined));

            const draftsCollection = db.collection('users').doc(currentUser.uid).collection('drafts');
            
            if (draftId) {
                await draftsCollection.doc(draftId).set(cleanData, { merge: true });
            } else {
                // Add createdAt for new drafts
                await draftsCollection.add({ ...cleanData, createdAt: serverTimestamp() });
            }

            showToast("Draft saved successfully!", "success");
            // Redirect to User Profile's Drafts Tab
            onNavigate(View.User, { initialTab: 'drafts' });
        } catch (error: any) {
            // Prevent circular structure error by logging only the message
            console.error("Error saving draft:", error instanceof Error ? error.message : String(error));
            // Improved Error Reporting
            if (error.code === 'permission-denied') {
                 showToast("Permission denied: Unable to save draft. Check your internet connection or account status.", "error");
            } else if (error.code === 'storage/unauthorized') {
                 showToast("Permission denied: Unable to upload draft image.", "error");
            } else {
                 showToast(`Failed to save draft: ${error.message}`, "error");
            }
        } finally {
            setIsSavingDraft(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);

        if (!currentUser) {
            setError("You must be logged in to create a post.");
            showToast("Please log in to create a post", "error");
            return;
        }

        if (currentUser.isBanned && currentUser.role !== 'admin') {
            setError("आपका खाता एडमिन द्वारा प्रतिबंधित (Banned) किया गया है। आप कोई पोस्ट या वीडियो नहीं बना सकते।");
            showToast("खाता प्रतिबंधित है (Account Banned)", "error");
            return;
        }

        if (postType === 'video') {
            if (!title.trim() || !category) {
                setError("Title and category are required.");
                showToast("Please fill in all required fields", "error");
                return;
            }
            if (!videoFile) {
                setError("A video file is required.");
                showToast("Please select a video file", "error");
                return;
            }
            if (!thumbnailFile) {
                setError("A video thumbnail is required.");
                showToast("Please upload a thumbnail for the video", "error");
                return;
            }

            let locationType: 'Overall' | 'State' | 'District' | 'Block' = 'Overall';
            if (state && district && block) {
                locationType = 'Block';
            } else if (state && district) {
                locationType = 'District';
            } else if (state) {
                locationType = 'State';
            }

            // Start background upload
            uploadManager.startUpload({
                title,
                description: videoDescription.trim(),
                category,
                state,
                district,
                block,
                locationType,
                thumbnailFile,
                videoFile,
                currentUser: {
                    uid: currentUser.uid,
                    name: currentUser.name,
                    profilePicUrl: currentUser.profilePicUrl || '',
                    isVerified: currentUser.isVerified || false,
                    role: currentUser.role || 'user'
                },
                draftId
            }).catch(err => {
                console.error("Failed to queue background video upload:", err);
            });

            showToast("Video uploading in the background. Check your channel!", "success");
            
            // Navigate to User Page where they can see the progress of uploads in the videos tab
            onNavigate(View.User, { initialTab: 'videos' });
            return;
        }

        const isContentEmpty = !content || content.replace(/<[^>]*>?/gm, '').trim().length === 0;

        if (!title.trim() || isContentEmpty || !category) {
            setError("Title, category, and content are required.");
            showToast("Please fill in all required fields", "error");
            return;
        }

        if (!thumbnailFile && !existingThumbnailUrl) {
            setError("A thumbnail image is required.");
            showToast("Please upload a thumbnail", "error");
            return;
        }

        setIsLoading(true);
        showToast("Publishing your post...", "info");

        // Safety Guard Check
        const safety = await checkContentSafety(title, content, 'article', category);

        try {
            let locationType: 'Overall' | 'State' | 'District' | 'Block' = 'Overall';
            if (state && district && block) {
                locationType = 'Block';
            } else if (state && district) {
                locationType = 'District';
            } else if (state) {
                locationType = 'State';
            }

            // Cleanup before save: remove selection outlines from content HTML
            let finalContent = content;
            if (editorRef.current) {
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = content;
                const images = tempDiv.querySelectorAll('img');
                images.forEach(img => {
                    img.style.outline = 'none';
                    img.style.outlineOffset = 'none';
                });
                finalContent = tempDiv.innerHTML;
            }

            // Upload Thumbnail (If new file exists)
            let finalThumbnailUrl = existingThumbnailUrl || '';
            if (thumbnailFile) {
                const fileExtension = thumbnailFile.name.split('.').pop();
                const thumbnailRef = storage.ref(`thumbnails/${uuidv4()}.${fileExtension}`);
                const uploadResult = await thumbnailRef.put(thumbnailFile);
                finalThumbnailUrl = await uploadResult.ref.getDownloadURL();
            }
            
            const isViolated = safety.isViolated;
            const flaggedReason = safety.reason || "Violates community safety guidelines";
            const flaggedCategory = safety.category || "Harmful Content";
            const flaggedSeverity = safety.severity || "high";

            const newPostRef = await db.collection("posts").add({
                title,
                content: finalContent,
                category,
                thumbnailUrl: finalThumbnailUrl,
                authorId: currentUser.uid,
                authorName: currentUser.name,
                authorProfilePicUrl: currentUser.profilePicUrl || '',
                authorIsVerified: currentUser.isVerified || false,
                viewCount: 0,
                shareCount: 0,
                createdAt: serverTimestamp(),
                locationType,
                state,
                district,
                block,
                flagged: isViolated,
                flaggedReason: isViolated ? flaggedReason : null,
                flaggedCategory: isViolated ? flaggedCategory : null,
                flaggedSeverity: isViolated ? flaggedSeverity : null,
                isHidden: isViolated,
                status: isViolated ? 'flagged' : 'published'
            });

            // If this was a draft, delete the draft now
            if (draftId) {
                try {
                    await db.collection('users').doc(currentUser.uid).collection('drafts').doc(draftId).delete();
                } catch (draftDelErr) {
                    console.warn("Could not delete draft after publishing", draftDelErr);
                }
            }

            if (isViolated) {
                // Log to Admin Reports and Send Admin & User Notifications
                try {
                    await db.collection('reports').add({
                        postId: newPostRef.id,
                        postTitle: title,
                        contentType: 'post',
                        reporterId: 'AI_SAFETY_GUARD',
                        reporterName: '🤖 AI Safety Moderation Bot',
                        reason: `[AI Flagged - ${flaggedCategory}]: ${flaggedReason}`,
                        category: flaggedCategory,
                        severity: flaggedSeverity,
                        createdAt: serverTimestamp(),
                        isAiFlagged: true,
                        authorId: currentUser.uid,
                        authorName: currentUser.name
                    });

                    // User In-App Alert Notification
                    await db.collection('users').doc(currentUser.uid).collection('notifications').add({
                        type: 'harmful_content_alert',
                        title: '⚠️ AI सुरक्षा चेतावनी (Post Flagged)',
                        body: `आपकी पोस्ट "${title}" में कम्युनिटी गाइडलाइन्स का उल्लंघन पाया गया है: (${flaggedReason})। इसे एडमिन समीक्षा के लिए भेज दिया गया है और फ़ीड से छुपा दिया गया है।`,
                        read: false,
                        createdAt: serverTimestamp()
                    });

                    // Notify Admins
                    const admins = await db.collection('users').where('role', '==', 'admin').get();
                    const batch = db.batch();
                    admins.forEach(adminDoc => {
                        const noticeRef = db.collection('users').doc(adminDoc.id).collection('notifications').doc();
                        batch.set(noticeRef, {
                            type: 'harmful_content',
                            title: "⚠️ Harmful Article Flagged by AI!",
                            body: `${currentUser.name} submitted post flagged by AI: "${title}". Reason: ${flaggedReason}`,
                            read: false,
                            createdAt: serverTimestamp(),
                            fromUserId: currentUser.uid
                        });
                    });
                    await batch.commit();
                } catch (notifyErr) {
                    console.error("Admin notification for harmful content failed:", notifyErr);
                }

                setIsLoading(false);
                // Trigger Harmful Content Alert Modal for User
                setSafetyModalData({
                    isOpen: true,
                    reason: flaggedReason,
                    category: flaggedCategory,
                    postId: newPostRef.id
                });
                return;
            }

            showToast("Article published successfully! Your news story is now live.", "success");
            
            // Referral Conditional Bonus (₹3 on first post)
            if (currentUser && !currentUser.hasPostedFirstNews && currentUser.referredBy) {
                try {
                    const referrerId = currentUser.referredBy;
                    const referrerRef = db.collection('users').doc(referrerId);
                    
                    await referrerRef.update({
                        walletBalance: increment(3),
                        totalEarnings: increment(3)
                    });

                    // Log the post bonus
                    await referrerRef.collection('referrals').add({
                        newUserId: currentUser.uid,
                        amount: 3,
                        type: 'post_bonus',
                        timestamp: serverTimestamp()
                    });

                    // Notification for referrer
                    await referrerRef.collection('notifications').add({
                        title: "Referral Active! ✍️",
                        body: `Your referral ${currentUser.name} posted their first news. ₹3 added to your wallet.`,
                        read: false,
                        timestamp: serverTimestamp(),
                        type: 'referral'
                    });

                    // Update current user so they don't trigger it again
                    await db.collection('users').doc(currentUser.uid).update({
                        hasPostedFirstNews: true
                    });
                } catch (refError) {
                    console.error("Error crediting referral post bonus:", refError);
                }
            } else if (currentUser && !currentUser.hasPostedFirstNews) {
                // Still mark as true even if not referred, so we don't check again
                 await db.collection('users').doc(currentUser.uid).update({
                    hasPostedFirstNews: true
                });
            }

            onBack();

            const sendNotifications = async () => {
                try {
                    const followersSnapshot = await db.collection('users').doc(currentUser.uid).collection('followers').get();
                    if (!followersSnapshot.empty) {
                        const notificationBatch = db.batch();
                        followersSnapshot.forEach(followerDoc => {
                            const followerId = followerDoc.id;
                            const notificationRef = db.collection('users').doc(followerId).collection('notifications').doc();
                            notificationBatch.set(notificationRef, {
                                type: 'new_post',
                                fromUserId: currentUser.uid,
                                fromUserName: currentUser.name,
                                fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                                fromUserIsVerified: currentUser.isVerified || false,
                                postId: newPostRef.id,
                                postTitle: title,
                                postThumbnailUrl: finalThumbnailUrl || '',
                                postType: 'article',
                                createdAt: serverTimestamp(),
                                read: false
                            });
                        });
                        await notificationBatch.commit();
                    }

                    // Trigger Server FCM push notifications
                    try {
                        const cleanDescription = content.replace(/<[^>]*>?/gm, '').substring(0, 100);
                        await fetch("/api/notify-followers", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                publisherId: currentUser.uid,
                                postId: newPostRef.id,
                                type: 'article',
                                title: title,
                                description: cleanDescription,
                                thumbnailUrl: finalThumbnailUrl || '',
                                publisherName: currentUser.name,
                                publisherProfilePicUrl: currentUser.profilePicUrl || ''
                            })
                        });
                    } catch (pushErr) {
                        console.error("FCM Push notification trigger failed:", pushErr);
                    }
                } catch (notificationError) {
                    console.error("Background notification failed:", notificationError);
                }
            };
            
            sendNotifications();

        } catch (err: any) {
            // Prevent circular structure error by logging only the message
            console.error("Error creating post:", err instanceof Error ? err.message : String(err));
            setError(err.message || "Failed to create post. Please try again.");
            showToast("Failed to publish post", "error");
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-transparent relative">
            <Header title={draftId ? t('edit') + ' Draft' : t('newPost')} showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-5 md:p-8 pb-20">
                <form onSubmit={handleSubmit} className="w-full glass-card p-6 md:p-8 space-y-6">
                    {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg" role="alert">
                            <strong className="font-bold">{t('error')}: </strong>
                            <span className="block sm:inline">{error}</span>
                        </div>
                    )}
                    
                    {/* Post Type Selector Tabs */}
                    <div className="flex bg-gray-100 dark:bg-slate-900 p-1.5 rounded-xl border border-gray-200 dark:border-slate-800">
                        <button
                            type="button"
                            onClick={() => setPostType('article')}
                            className={`flex-1 py-3 rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                                postType === 'article'
                                    ? 'bg-white dark:bg-slate-800 text-red-600 shadow-md'
                                    : 'text-gray-500 hover:text-gray-900 dark:text-slate-400 dark:hover:text-slate-200'
                            }`}
                        >
                            <span className="material-symbols-outlined text-lg">description</span>
                            <span>Article Post</span>
                        </button>
                        <button
                            type="button"
                            onClick={() => setPostType('video')}
                            className={`flex-1 py-3 rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                                postType === 'video'
                                    ? 'bg-white dark:bg-slate-800 text-red-600 shadow-md'
                                    : 'text-gray-500 hover:text-gray-900 dark:text-slate-400 dark:hover:text-slate-200'
                            }`}
                        >
                            <span className="material-symbols-outlined text-lg">play_circle</span>
                            <span>Video Bulletin</span>
                        </button>
                    </div>
                    
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                            {postType === 'video' ? 'Video Title' : t('title')} <span className="text-red-500">*</span>
                        </label>
                        <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500" required maxLength={MAX_TITLE_LENGTH} />
                        <div className="flex justify-between items-center mt-2 text-xs">
                            <p className="text-gray-500">A clear, catchy title works best.</p>
                            <p className={`font-medium ${
                                title.length > MAX_TITLE_LENGTH * 0.9 ? 'text-red-500' : 'text-gray-500'
                            }`}>
                                {title.length}/{MAX_TITLE_LENGTH}
                            </p>
                        </div>
                    </div>

                    <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                            Category <span className="text-red-500">*</span>
                        </label>
                        <select
                            id="category"
                            value={category}
                            onChange={e => setCategory(e.target.value)}
                            className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500"
                            required
                        >
                            <option value="" disabled>Select a category</option>
                            {(postType === 'video' ? videoCategories : newsCategories).map(cat => (
                                <option key={cat} value={cat}>{t(cat.toLowerCase()) || cat}</option>
                            ))}
                        </select>
                    </div>
                    
                    <LocationSelector 
                      state={state}
                      setState={setState}
                      district={district}
                      setDistrict={setDistrict}
                      block={block}
                      setBlock={setBlock}
                    />

                     {postType === 'article' && (
                        <div>
                            <label htmlFor="thumbnail" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('thumbnail')} <span className="text-red-500">*</span>
                            </label>
                            <div 
                                onDragOver={handleDragOver}
                                onDragLeave={handleDragLeave}
                                onDrop={handleDrop}
                                className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md transition-all duration-200 ${
                                    isDragging 
                                    ? 'border-blue-500 bg-blue-50/50 scale-[1.01] shadow-md shadow-blue-50' 
                                    : 'border-gray-300 bg-gray-50 hover:bg-white'
                                }`}
                            >
                                <div className="space-y-1 text-center">
                                    {thumbnailPreview ? (
                                        <img src={thumbnailPreview} alt="Thumbnail Preview" className="mx-auto h-40 w-auto object-contain rounded" />
                                    ) : (
                                        <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    )}
                                    <div className="flex text-sm text-gray-600 justify-center mt-2">
                                        <label htmlFor="create-post-file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 px-2 py-1 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                                            <span>{t('uploadFile')}</span>
                                            <input id="create-post-file-upload" name="create-post-file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
                                        </label>
                                        <p className="pl-1">{t('orDragDrop')}</p>
                                    </div>
                                    <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                                </div>
                            </div>
                        </div>
                     )}

                    {/* Conditional Fields based on Post Type */}
                    {postType === 'article' ? (
                        <div>
                            <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('writeArticle')} <span className="text-red-500">*</span>
                            </label>
                            <RichTextEditorToolbar 
                                editorRef={editorRef} 
                                onImageUpload={handleTriggerImageUpload} 
                                onAlign={handleAlignment} 
                                isImageSelected={isImageSelected}
                            />
                            <div className="relative">
                                <div
                                    id="content"
                                    ref={editorRef}
                                    contentEditable="true"
                                    onInput={handleContentChange}
                                    onClick={handleEditorClick}
                                    className="w-full p-4 border border-gray-300 bg-white rounded-b-lg h-96 resize-y overflow-y-auto text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg leading-relaxed"
                                />
                                {(!content || content.replace(/<[^>]*>?/gm, '').trim().length === 0) && (
                                    <div className="absolute top-4 left-4 text-gray-400 pointer-events-none">
                                        {t('writeArticle')}...
                                    </div>
                                )}
                                 {isUploadingImage && (
                                    <div className="absolute inset-0 bg-white/80 flex items-center justify-center rounded-b-lg z-10">
                                        <div className="text-center p-4 bg-white/50 rounded-lg">
                                            <svg className="animate-spin h-8 w-8 text-blue-600 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                            <p className="mt-2 text-gray-700 font-semibold">Uploading image...</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Video File <span className="text-red-500">*</span>
                                </label>
                                <div 
                                    onDragOver={handleVideoDragOver}
                                    onDragLeave={handleVideoDragLeave}
                                    onDrop={handleVideoDrop}
                                    className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md transition-all duration-200 ${
                                        isDraggingVideo 
                                        ? 'border-blue-500 bg-blue-50/50 scale-[1.01] shadow-md shadow-blue-50' 
                                        : 'border-gray-300 bg-gray-50 hover:bg-white'
                                    }`}
                                >
                                    <div className="space-y-1 text-center w-full">
                                        {videoPreview ? (
                                            <div className="mx-auto max-w-sm rounded-xl overflow-hidden shadow-lg border relative bg-slate-950 p-2">
                                                <video 
                                                    ref={previewVideoRef}
                                                    src={videoPreview} 
                                                    className="w-full aspect-video object-contain" 
                                                    controls 
                                                    playsInline 
                                                    crossOrigin="anonymous"
                                                    onLoadedData={() => {
                                                        const video = previewVideoRef.current;
                                                        if (video) {
                                                            // Seek to 1 second or 10% of video duration to bypass potential black screen intro frames
                                                            const seekTime = Math.min(1.0, video.duration || 1.0);
                                                            video.currentTime = seekTime;
                                                            
                                                            const handleSeeked = () => {
                                                                captureVideoFrame(true);
                                                                video.removeEventListener('seeked', handleSeeked);
                                                            };
                                                            video.addEventListener('seeked', handleSeeked);
                                                        }
                                                    }}
                                                />
                                                <button 
                                                    type="button"
                                                    onClick={() => { setVideoFile(null); setVideoPreview(null); setThumbnailFile(null); setThumbnailPreview(null); }}
                                                    className="absolute top-4 right-4 bg-red-600/90 text-white rounded-full p-1.5 shadow-lg hover:bg-red-700 transition-colors z-10"
                                                >
                                                    <span className="material-symbols-outlined text-sm font-bold">delete</span>
                                                </button>

                                                {/* Frame Selection Controls */}
                                                <div className="mt-3 p-3 bg-white dark:bg-slate-900 rounded-lg text-left border border-gray-100 dark:border-slate-800">
                                                    <p className="text-xs font-bold text-gray-700 dark:text-gray-200 mb-1 flex items-center gap-1">
                                                        <span className="material-symbols-outlined text-sm text-red-500">photo_camera</span>
                                                        <span>Thumbnail Adjustment</span>
                                                    </p>
                                                    <p className="text-[11px] text-gray-500 dark:text-gray-400 mb-2">
                                                        Play/seek the video to any frame, then click the button below to set it as the main thumbnail:
                                                    </p>
                                                    <button
                                                        type="button"
                                                        onClick={() => captureVideoFrame(false)}
                                                        className="w-full py-2 px-3 bg-red-600 hover:bg-red-700 active:scale-[0.98] transition-all text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm"
                                                    >
                                                        <span className="material-symbols-outlined text-[16px]">capture</span>
                                                        <span>Set Current Frame as Thumbnail</span>
                                                    </button>
                                                                                            {/* Selected Frame Thumbnail Preview */}
                                                {thumbnailPreview && (
                                                    <div className="mt-2.5 p-2 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-800 rounded-lg flex items-center gap-2.5 text-left">
                                                        <div className="w-16 h-12 bg-black rounded overflow-hidden border border-gray-300 dark:border-slate-700 flex-shrink-0">
                                                            <img src={thumbnailPreview} alt="Thumbnail" className="w-full h-full object-cover" />
                                                        </div>
                                                        <div className="flex-1 min-w-0">
                                                            <p className="text-[11px] font-bold text-gray-800 dark:text-gray-200">Thumbnail set successfully!</p>
                                                            <p className="text-[9px] text-green-600 font-semibold flex items-center gap-0.5">
                                                                 <span className="material-symbols-outlined text-[10px] font-bold">check_circle</span>
                                                                 Successfully set
                                                            </p>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>      </div>
                                        ) : (
                                            <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                                <path d="M4 8h40v32H4V8zm4 4v24h32V12H8zm8 4h16v16H16V16zm4 4v8l8-4-8-4z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                            </svg>
                                        )}
                                        {!videoPreview && (
                                            <>
                                                <div className="flex text-sm text-gray-600 justify-center mt-2">
                                                    <label htmlFor="video-file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-red-600 hover:text-red-500 px-2 py-1 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-red-500">
                                                        <span>Choose Video File</span>
                                                        <input id="video-file-upload" name="video-file-upload" type="file" className="sr-only" accept="video/*" onChange={handleVideoFileChange} />
                                                    </label>
                                                    <p className="pl-1">or drag and drop</p>
                                                </div>
                                                <p className="text-xs text-gray-500">MP4, MOV, WebM formats (up to 50MB)</p>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label htmlFor="videoDescription" className="block text-sm font-medium text-gray-700 mb-1">
                                    Video Description (Optional)
                                </label>
                                <textarea
                                    id="videoDescription"
                                    value={videoDescription}
                                    onChange={e => setVideoDescription(e.target.value)}
                                    placeholder="Write a brief description or hashtags for this video bulletin..."
                                    className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500 text-sm h-24"
                                />
                            </div>
                        </div>
                    )}
                    
                    {postType === 'article' && isLoading && (
                        <div className="p-4 bg-blue-50 dark:bg-slate-900 border border-blue-100 dark:border-slate-800 rounded-xl space-y-2.5 animate-fade-in mt-4">
                            <div className="flex justify-between items-center text-xs">
                                <span className="font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1">
                                    <span className="material-symbols-outlined text-sm animate-spin">sync</span>
                                    {uploadStage || 'Publishing...'}
                                </span>
                                <span className="font-black text-slate-800 dark:text-white">{uploadProgress || 0}%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                                <div 
                                    className="bg-gradient-to-r from-blue-600 to-indigo-500 h-full rounded-full transition-all duration-300"
                                    style={{ width: `${uploadProgress || 5}%` }}
                                />
                            </div>
                        </div>
                    )}
                    
                    <div className="flex flex-col sm:flex-row gap-4 mt-6">
                        {postType === 'article' && (
                            <button 
                                type="button" 
                                onClick={handleSaveDraft}
                                disabled={isSavingDraft || isLoading} 
                                className="flex-1 px-6 py-3.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95"
                            >
                                {isSavingDraft ? (
                                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                                ) : (
                                    <span className="material-symbols-outlined text-xl">save</span>
                                )}
                                <span>{isSavingDraft ? 'Saving...' : 'Save Draft'}</span>
                            </button>
                        )}
                        
                        <button 
                            type="submit" 
                            disabled={isLoading || isSavingDraft} 
                            className={`${postType === 'video' ? 'w-full' : 'flex-[1.5]'} px-6 py-3.5 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white border-none rounded-xl text-lg font-black shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-0.5 active:scale-95 disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2`}
                        >
                            <span className="material-symbols-outlined text-xl">send</span>
                            <span>{isLoading ? t('publishing') : 'Publish Now'}</span>
                        </button>
                    </div>
                </form>
                <input type="file" ref={imageInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />

                {/* AI Safety Violation Alert Modal */}
                {safetyModalData.isOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
                        <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-red-100 transform transition-all scale-100">
                            {/* Red Header Bar */}
                            <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 p-6 text-white text-center relative">
                                <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-3 backdrop-blur-md shadow-inner border border-white/30">
                                    <span className="material-symbols-outlined text-4xl text-amber-200">shield_lock</span>
                                </div>
                                <h3 className="text-xl font-black tracking-tight">⚠️ AI सुरक्षा चेतावनी (AI Safety Alert)</h3>
                                <p className="text-xs text-red-100 mt-1 font-medium">Harmful Content Flagged & Sent to Admin</p>
                            </div>

                            {/* Modal Body */}
                            <div className="p-6 space-y-4">
                                <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-left">
                                    <div className="flex items-center gap-2 text-red-700 font-bold text-xs uppercase tracking-wide mb-1">
                                        <span className="material-symbols-outlined text-base text-red-600">report_problem</span>
                                        <span>फ्लैग होने का कारण (Violation Reason)</span>
                                    </div>
                                    <p className="text-sm font-semibold text-gray-800 leading-relaxed">
                                        "{safetyModalData.reason}"
                                    </p>
                                    <div className="mt-2 pt-2 border-t border-red-200/60 flex justify-between text-[11px] text-red-600 font-bold">
                                        <span>श्रेणी: {safetyModalData.category}</span>
                                        <span className="bg-red-200 text-red-800 px-2 py-0.5 rounded-md">High Priority</span>
                                    </div>
                                </div>

                                <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 leading-relaxed space-y-2">
                                    <p className="font-bold flex items-center gap-1.5 text-amber-800">
                                        <span className="material-symbols-outlined text-sm">visibility_off</span>
                                        सुरक्षा व्यवस्था (Security Status):
                                    </p>
                                    <p>
                                        आपकी पोस्ट को स्वचालित रूप से **छुपा (Hide)** दिया गया है और **एडमिन की समीक्षा (Admin Review)** के लिए भेज दिया गया है। एडमिन द्वारा समीक्षा के बाद ही इसे सार्वजनिक फ़ीड में दिखाया जाएगा।
                                    </p>
                                </div>

                                <div className="pt-2 flex flex-col gap-2.5">
                                    <button
                                        onClick={() => {
                                            setSafetyModalData({ isOpen: false, reason: '', category: '', postId: '' });
                                            onNavigate(View.User, { initialTab: 'myNews' });
                                        }}
                                        className="w-full py-3 px-4 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-black text-sm rounded-xl shadow-lg hover:shadow-xl transition-all transform active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        <span className="material-symbols-outlined text-lg">account_circle</span>
                                        <span>माय प्रोफाइल देखें (Go to My Profile)</span>
                                    </button>
                                    <button
                                        onClick={() => {
                                            setSafetyModalData({ isOpen: false, reason: '', category: '', postId: '' });
                                            onBack();
                                        }}
                                        className="w-full py-2.5 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-xl transition-all"
                                    >
                                        ठीक है, वापस जाएं (Acknowledge & Close)
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};

export default CreatePostPage;
