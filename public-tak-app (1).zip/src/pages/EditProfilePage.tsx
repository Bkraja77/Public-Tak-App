
import React, { useState, useRef } from 'react';
import Header from '../components/Header';
import { User } from '../types';
import { auth, db, storage, firebase } from '../firebaseConfig';
import { v4 as uuidv4 } from 'uuid';
import { indianLocations } from '../utils/locations';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { userProfileCache } from '../services/userProfileCache';

interface EditProfilePageProps {
  onBack: () => void;
  currentUser: User;
  onProfileUpdate: (updatedData: Partial<User>) => void;
}

const compressImage = (file: File, quality: number = 0.8, maxSize: number = 512): Promise<File> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let { width, height } = img;

                if (width > height) {
                    if (width > maxSize) {
                        height *= maxSize / width;
                        width = maxSize;
                    }
                } else {
                    if (height > maxSize) {
                        width *= maxSize / height;
                        height = maxSize;
                    }
                }

                canvas.width = width;
                canvas.height = height;

                const ctx = canvas.getContext('2d');
                if (!ctx) return reject(new Error('Could not get canvas context'));
                
                ctx.drawImage(img, 0, 0, width, height);

                canvas.toBlob(
                    (blob) => {
                        if (blob) {
                            resolve(new File([blob], file.name, { type: 'image/jpeg', lastModified: Date.now() }));
                        } else {
                            reject(new Error('Canvas toBlob failed'));
                        }
                    },
                    'image/jpeg',
                    quality
                );
            };
            img.onerror = () => reject(new Error('Failed to load image for compression'));
        };
        reader.onerror = () => reject(new Error('Failed to read file for compression'));
    });
};


const EditProfilePage: React.FC<EditProfilePageProps> = ({ onBack, currentUser, onProfileUpdate }) => {
    const [name, setName] = useState(currentUser.name);
    const [username, setUsername] = useState(currentUser.username);
    const [bio, setBio] = useState(currentUser.bio);
    const [profilePicFile, setProfilePicFile] = useState<File | null>(null);
    const [profilePicPreview, setProfilePicPreview] = useState<string>(currentUser.profilePicUrl);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { t } = useLanguage();
    const { showToast } = useToast();

    const [preferredState, setPreferredState] = useState(currentUser.preferredState || '');
    const [preferredDistrict, setPreferredDistrict] = useState(currentUser.preferredDistrict || '');
    const [preferredBlock, setPreferredBlock] = useState(currentUser.preferredBlock || '');
    const [gender, setGender] = useState<'Male' | 'Female' | 'Other' | ''>(currentUser.gender || '');
    const [ageGroup, setAgeGroup] = useState(currentUser.ageGroup || '');

    const states = Object.keys(indianLocations);
    const districts = preferredState ? Object.keys(indianLocations[preferredState] || {}) : [];
    const blocks = preferredState && preferredDistrict ? (indianLocations[preferredState][preferredDistrict] || []) : [];

    const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setPreferredState(e.target.value);
        setPreferredDistrict('');
        setPreferredBlock('');
    };

    const handleDistrictChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setPreferredDistrict(e.target.value);
        setPreferredBlock('');
    };

    const handleBlockChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setPreferredBlock(e.target.value);
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            // Updated limit to 5MB to match storage.rules
            if (file.size > 5 * 1024 * 1024) { 
                setError("File is too large. Please select an image under 5MB.");
                return;
            }
            try {
                const compressedFile = await compressImage(file);
                setProfilePicFile(compressedFile);
                setProfilePicPreview(URL.createObjectURL(compressedFile));
                setError(null);
            } catch (err) {
                console.error("Image compression error:", err);
                setError("Could not process image. Please try another one.");
            }
        }
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);

        if (!name.trim()) {
            setError("Name is compulsory / नाम भरना अनिवार्य है।");
            return;
        }

        if (!username.trim()) {
            setError("User name is compulsory / यूज़र नाम भरना अनिवार्य है।");
            return;
        }

        if (!gender) {
            setError("Demographics: Gender selection is compulsory / लिंग (Gender) चुनना अनिवार्य है।");
            return;
        }

        if (!ageGroup) {
            setError("Demographics: Age Group selection is compulsory / आयु वर्ग (Age Group) चुनना अनिवार्य है।");
            return;
        }
    
        const hasTextChanged = name !== currentUser.name || username !== currentUser.username || bio !== currentUser.bio;
        const hasImageChanged = !!profilePicFile;
        const hasLocationChanged = preferredState !== (currentUser.preferredState || '') || preferredDistrict !== (currentUser.preferredDistrict || '') || preferredBlock !== (currentUser.preferredBlock || '');
        const hasDemographicsChanged = gender !== (currentUser.gender || '') || ageGroup !== (currentUser.ageGroup || '');
    
        if (!hasTextChanged && !hasImageChanged && !hasLocationChanged && !hasDemographicsChanged) {
            onBack();
            return;
        }
    
        setIsLoading(true);
    
        try {
            let newProfilePicUrl = currentUser.profilePicUrl;
    
            // --- Critical, User-Facing Updates ---
            if (profilePicFile) {
                if (currentUser.profilePicUrl && currentUser.profilePicUrl.includes('firebasestorage.googleapis.com')) {
                    try {
                        const oldStorageRef = storage.refFromURL(currentUser.profilePicUrl);
                        await oldStorageRef.delete();
                    } catch (storageError: any) {
                        if (storageError.code !== 'storage/object-not-found') {
                            console.warn("Could not delete old profile picture:", storageError);
                        }
                    }
                }
                const fileExtension = profilePicFile.name.split('.').pop();
                const profilePicRef = storage.ref(`profile-pics/${currentUser.uid}/${uuidv4()}.${fileExtension}`);
                const uploadResult = await profilePicRef.put(profilePicFile);
                newProfilePicUrl = await uploadResult.ref.getDownloadURL();
            }
    
            const updatedFirestoreData = {
                name,
                username,
                bio,
                profilePicUrl: newProfilePicUrl,
                preferredState,
                preferredDistrict,
                preferredBlock,
                gender,
                ageGroup,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
            };
    
            const userDocRef = db.collection('users').doc(currentUser.uid);
            await userDocRef.set(updatedFirestoreData, { merge: true });
    
            if (auth.currentUser) {
                await auth.currentUser.updateProfile({
                    displayName: name,
                    photoURL: newProfilePicUrl,
                });
            }
    
            // --- Immediate Feedback for a Smooth UX across the entire application ---
            userProfileCache.updateUser(currentUser.uid, {
                name,
                username,
                profilePicUrl: newProfilePicUrl,
            });

            onProfileUpdate({ name, username, bio, profilePicUrl: newProfilePicUrl, preferredState, preferredDistrict, preferredBlock, gender: gender as any, ageGroup: ageGroup as any });
            showToast("Profile updated successfully! / आपकी प्रोफाइल सफलतापूर्वक अपडेट हो गई।", "success");
            onBack();
    
            // --- Comprehensive Background Data Synchronization ---
            const backgroundUpdate = async () => {
                const denormalizedAuthorData = {
                    authorName: name,
                    authorProfilePicUrl: newProfilePicUrl,
                };

                const commitInBatches = async (querySnapshot: any, updateData: object) => {
                    if (!querySnapshot || querySnapshot.empty) return;
                    const batches = [];
                    let currentBatch = db.batch();
                    let operationCount = 0;
    
                    querySnapshot.forEach((doc: any) => {
                        currentBatch.update(doc.ref, updateData);
                        operationCount++;
                        if (operationCount >= 450) {
                            batches.push(currentBatch);
                            currentBatch = db.batch();
                            operationCount = 0;
                        }
                    });
    
                    if (operationCount > 0) {
                        batches.push(currentBatch);
                    }
                    await Promise.all(batches.map(batch => batch.commit()));
                };
    
                // 1. Update all posts authored by this user
                try {
                    const postsQuery = db.collection('posts').where('authorId', '==', currentUser.uid);
                    const postsSnapshot = await postsQuery.get();
                    await commitInBatches(postsSnapshot, denormalizedAuthorData);
                } catch (e) {
                    console.warn("Background posts update notice:", e);
                }

                // 2. Update all videos authored by this user
                try {
                    const videosQuery = db.collection('videos').where('authorId', '==', currentUser.uid);
                    const videosSnapshot = await videosQuery.get();
                    await commitInBatches(videosSnapshot, denormalizedAuthorData);
                } catch (e) {
                    console.warn("Background videos update notice:", e);
                }

                // 3. Attempt comments collectionGroup update
                try {
                    const commentsQuery = db.collectionGroup('comments').where('authorId', '==', currentUser.uid);
                    const commentsSnapshot = await commentsQuery.get();
                    await commitInBatches(commentsSnapshot, denormalizedAuthorData);
                } catch (e) {
                    // Harmless if collectionGroup index is not yet built
                }

                // 4. Attempt replies collectionGroup update
                try {
                    const repliesQuery = db.collectionGroup('replies').where('authorId', '==', currentUser.uid);
                    const repliesSnapshot = await repliesQuery.get();
                    await commitInBatches(repliesSnapshot, denormalizedAuthorData);
                } catch (e) {
                    // Harmless
                }

                // 5. Attempt notifications collectionGroup update
                try {
                    const notificationsQuery = db.collectionGroup('notifications').where('fromUserId', '==', currentUser.uid);
                    const notificationsSnapshot = await notificationsQuery.get();
                    await commitInBatches(notificationsSnapshot, {
                        fromUserProfilePicUrl: newProfilePicUrl,
                        fromUserName: name,
                    });
                } catch (e) {
                    // Harmless
                }
            };
            
            backgroundUpdate();
    
        } catch (err: any) {
            console.error("Error updating profile:", err);
            setError(err.message || "Failed to update profile. Please try again.");
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title={t('editProfile')} showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-5 md:p-10 pb-20">
                <form onSubmit={handleSave} className="w-full glass-card p-6 md:p-8 space-y-8">
                    {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg" role="alert">
                            <strong className="font-bold">{t('error')}: </strong>
                            <span className="block sm:inline">{error}</span>
                        </div>
                    )}

                    <div className="flex flex-col items-center space-y-4">
                        <div className="relative group">
                             <img 
                                className="h-32 w-32 rounded-full ring-4 ring-blue-500/20 object-cover shadow-md" 
                                src={profilePicPreview} 
                                alt="Profile preview" 
                            />
                            <button 
                                type="button" 
                                onClick={() => fileInputRef.current?.click()}
                                className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full shadow-lg hover:bg-blue-700 transition-all"
                                title={t('changePhoto')}
                            >
                                <span className="material-symbols-outlined text-sm">edit</span>
                            </button>
                        </div>
                        <input 
                            type="file" 
                            ref={fileInputRef} 
                            onChange={handleFileChange} 
                            accept="image/png, image/jpeg" 
                            className="hidden" 
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('name')} <span className="text-red-500 font-bold">*</span>
                            </label>
                            <input type="text" id="name" required value={name} onChange={e => setName(e.target.value)} className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500" />
                        </div>

                        <div>
                            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
                                {t('username')} <span className="text-red-500 font-bold">*</span>
                            </label>
                            <input type="text" id="username" required value={username} onChange={e => setUsername(e.target.value)} className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 focus:ring-2 focus:ring-blue-500" />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">{t('bio')}</label>
                        <textarea id="bio" value={bio} onChange={e => setBio(e.target.value)} rows={4} className="w-full p-3 border border-gray-300 bg-gray-50 rounded-lg text-gray-900 resize-y focus:ring-2 focus:ring-blue-500" maxLength={150}></textarea>
                        <p className="text-right text-xs text-gray-500">{bio.length} / 150</p>
                    </div>

                    <div className="space-y-4 p-6 bg-gray-50 rounded-xl border border-gray-200">
                        <div className="flex items-center gap-2 mb-2">
                            <span className="material-symbols-outlined text-blue-600">location_on</span>
                            <h3 className="text-lg font-semibold text-gray-800">{t('myLocation')}</h3>
                        </div>
                        <p className="text-sm text-gray-500 -mt-4 ml-8 mb-4">Set your location to see relevant news on your homepage.</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                                <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">{t('selectState')}</label>
                                <select id="state" value={preferredState} onChange={handleStateChange} className="w-full p-3 border border-gray-300 bg-white rounded-lg focus:ring-2 focus:ring-blue-500 cursor-pointer">
                                    <option value="">{t('selectState')}</option>
                                    {states.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">{t('selectDistrict')}</label>
                                <select id="district" value={preferredDistrict} onChange={handleDistrictChange} disabled={!preferredState} className="w-full p-3 border border-gray-300 bg-white rounded-lg focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 cursor-pointer disabled:cursor-not-allowed">
                                    <option value="">{t('selectDistrict')}</option>
                                    {districts.map(d => <option key={d} value={d}>{d}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="block" className="block text-sm font-medium text-gray-700 mb-1">{t('selectBlock')}</label>
                                <select id="block" value={preferredBlock} onChange={handleBlockChange} disabled={!preferredDistrict} className="w-full p-3 border border-gray-300 bg-white rounded-lg focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 cursor-pointer disabled:cursor-not-allowed">
                                    <option value="">{t('selectBlock')}</option>
                                    {blocks.map(b => <option key={b} value={b}>{b}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4 p-6 bg-gray-50 rounded-xl border border-gray-200">
                        <div className="flex items-center gap-2 mb-2">
                            <span className="material-symbols-outlined text-purple-600">person_search</span>
                            <h3 className="text-lg font-semibold text-gray-800">
                                Demographics <span className="text-red-500 font-bold">*</span>
                            </h3>
                        </div>
                        <p className="text-sm text-gray-500 -mt-4 ml-8 mb-4">This information helps us provide accurate analytics for creators you support.</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">
                                    Gender <span className="text-red-500 font-bold">*</span>
                                </label>
                                <select id="gender" required value={gender} onChange={e => setGender(e.target.value as any)} className="w-full p-3 border border-gray-300 bg-white rounded-lg focus:ring-2 focus:ring-blue-500 cursor-pointer">
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div>
                                <label htmlFor="ageGroup" className="block text-sm font-medium text-gray-700 mb-1">
                                    Age Group <span className="text-red-500 font-bold">*</span>
                                </label>
                                <select id="ageGroup" required value={ageGroup} onChange={e => setAgeGroup(e.target.value as any)} className="w-full p-3 border border-gray-300 bg-white rounded-lg focus:ring-2 focus:ring-blue-500 cursor-pointer">
                                    <option value="">Select Age Group</option>
                                    <option value="13-17">13-17</option>
                                    <option value="18-24">18-24</option>
                                    <option value="25-34">25-34</option>
                                    <option value="35-44">35-44</option>
                                    <option value="45-54">45-54</option>
                                    <option value="55+">55+</option>
                                </select>
                            </div>
                        </div>
                    </div>


                    <button 
                        type="submit" 
                        disabled={isLoading} 
                        className="w-full px-8 py-4 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white border-none rounded-xl text-xl font-black shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-0.5 active:scale-95 disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-3"
                    >
                        {isLoading ? (
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                        ) : (
                            <span className="material-symbols-outlined text-2xl">save</span>
                        )}
                        <span>{isLoading ? t('loading') : t('saveChanges')}</span>
                    </button>
                </form>
            </main>
        </div>
    );
};

export default EditProfilePage;
