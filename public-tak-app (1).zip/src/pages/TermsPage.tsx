
import React from 'react';
import Header from '../components/Header';

interface TermsPageProps {
  onBack: () => void;
}

const TermsPage: React.FC<TermsPageProps> = ({ onBack }) => {
    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title="Terms of Service" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-5 md:p-8 pb-20">
                <div className="glass-card p-8 md:p-12 w-full prose max-w-none prose-lg prose-slate prose-a:text-blue-600 hover:prose-a:text-blue-500 prose-headings:text-gray-800 prose-p:text-gray-600">
                    
                    <div className="text-center mb-10 border-b border-gray-200 pb-8">
                        <h1 className="text-3xl md:text-5xl font-extrabold text-gray-900 mb-4">Terms of Service</h1>
                        <p className="text-base text-gray-500 font-medium">Last Updated: April 22, 2026</p>
                        <p className="text-sm text-gray-500 mt-2">Applicable for Public Tak App Mobile Application and <a href="https://publictak.app" target="_blank" rel="noopener noreferrer">publictak.app</a></p>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                        <div>
                            <section className="mb-8">
                                <h2 className="text-2xl font-bold mb-4 text-gray-800">1. ACCEPTANCE OF TERMS</h2>
                                <p className="mb-3">
                                    Welcome to <strong>Public Tak App</strong>. By using our Platform, you agree to these Terms. We are a community-driven news platform empowering local voices through technology.
                                </p>
                            </section>

                            <section className="mb-8">
                                <h2 className="text-2xl font-bold mb-4 text-gray-800">2. REFERRAL & EARNINGS</h2>
                                <p className="mb-3">
                                    Public Tak App offers a Referral Program. Users can earn rewards in their <strong>Public Tak App Wallet</strong> by inviting new users.
                                </p>
                                <ul className="list-disc pl-5 space-y-2 marker:text-red-500 text-sm">
                                    <li>Earnings are credited after successful verification of the referred account.</li>
                                    <li>Milestone bonuses are awarded for every 10 active referrals.</li>
                                    <li>Public Tak App reserves the right to withhold earnings in case of suspicious activity (bots, fake accounts).</li>
                                    <li>Wallet balance can be withdrawn subject to minimum thresholds and KYC verification.</li>
                                </ul>
                            </section>

                            <section className="mb-8 bg-red-50 border-l-4 border-red-500 p-6 rounded-r-xl shadow-sm">
                                <h2 className="text-xl font-bold mb-4 text-red-800 flex items-center gap-2"><span className="material-symbols-outlined">gavel</span> 3. USER RESPONSIBILITY (ARTICLES & VIDEOS)</h2>
                                <p className="mb-3">
                                    You are <strong>solely responsible</strong> for the news articles, video posts, full-screen reels, comments, and all other content you post on Public Tak App. Public Tak App provides the technology platform, not the content.
                                </p>
                                <p className="font-black text-red-600 uppercase text-xs tracking-widest bg-white p-2 rounded mb-4">Failing to provide evidence or spreading fake news/videos may lead to legal action by authorities.</p>
                                
                                <h3 className="text-lg font-bold mt-4 mb-2 text-gray-800">3.1 User Content Ownership & Liability</h3>
                                <p className="mb-3">
                                    You are <strong>solely responsible</strong> for all text, images, news articles, video recordings, video edits, voiceovers, and other materials ("Content") that you upload, post, or display on Public Tak App. 
                                    <strong> We do not endorse any user opinions or vouch for the accuracy of user-posted news or videos.</strong>
                                </p>

                                <h3 className="text-lg font-bold mt-4 mb-2 text-gray-800">3.2 License Grant</h3>
                                <p className="mb-3">
                                    By posting Content (including articles, images, and videos), you grant Public Tak App a non-exclusive, worldwide, royalty-free license to use, display, reproduce, and distribute your Content on our Platform. You retain ownership of your Content.
                                </p>

                                <h3 className="text-lg font-bold mt-4 mb-2 text-gray-800">3.3 Prohibited Content</h3>
                                <p className="mb-2">You agree <strong>NOT</strong> to post articles, comments, or video content that:</p>
                                <ul className="list-disc pl-5 space-y-1 text-gray-700 marker:text-red-500 mb-4">
                                    <li>Is fake, misleading, altered/manipulated, or spreads misinformation or rumors.</li>
                                    <li>Promotes hate speech, violence, discrimination, or harassment based on race, religion, gender, or caste.</li>
                                    <li>Is defamatory, obscene, pornographic, sexually explicit, or visually offensive.</li>
                                    <li>Infringes on any third party's copyright, trademark, or other intellectual property rights (including background music and licensed video footage).</li>
                                    <li>Violates any local, state, or central laws of India.</li>
                                </ul>

                                <h3 className="text-lg font-bold mt-4 mb-2 text-gray-800">3.4 Specific Video & Reel Guidelines</h3>
                                <p className="mb-2">To prevent violations, all video posts and reels must strictly adhere to the following rules:</p>
                                <ul className="list-disc pl-5 space-y-1 text-gray-700 marker:text-red-500">
                                    <li><strong>Authenticity:</strong> Videos must capture real events or offer authentic reportage. Staged video reporting presented as real news is strictly prohibited.</li>
                                    <li><strong>Copyrighted Media:</strong> Do not upload videos with copyrighted audio, film/television clips, or music without proper licenses or permission.</li>
                                    <li><strong>Sensitivity:</strong> Videos showing severe accidents, blood, physical violence, harassment, or self-harm are strictly banned and will be removed instantly.</li>
                                    <li><strong>Privacy:</strong> Respect the privacy of individuals. Do not record or post video clips of individuals without their explicit consent in private settings.</li>
                                </ul>
                            </section>
                        </div>

                        <div>
                            <section className="mb-8">
                                <h2 className="text-2xl font-bold mb-4 text-gray-800">4. CONTENT MODERATION & TERMINATION</h2>
                                <p className="mb-2"><strong>We reserve the right to:</strong></p>
                                <ul className="list-disc pl-5 space-y-2 mb-4">
                                    <li>Remove or edit any Content that violates these Terms or is deemed inappropriate, without prior notice.</li>
                                    <li>Suspend or terminate your account and access to the Platform if you repeatedly violate these Terms.</li>
                                    <li>Cooperate with law enforcement authorities regarding illegal content.</li>
                                </ul>
                            </section>

                            <section className="mb-8">
                                <h2 className="text-2xl font-bold mb-4 text-gray-800">5. THIRD-PARTY SERVICES & ADS</h2>
                                <p className="mb-2">Our Platform displays advertisements provided by third parties (e.g., Google AdMob, AdSense).</p>
                                <ul className="list-disc pl-5 space-y-2">
                                    <li>We are not responsible for the content, products, or services advertised by third parties.</li>
                                    <li>Interactions with advertisers are solely between you and the advertiser.</li>
                                    <li>We use Google Analytics to understand app usage. Please review their policies.</li>
                                </ul>
                            </section>

                            <section className="mb-8">
                                <h2 className="text-2xl font-bold mb-4 text-gray-800">6. INTELLECTUAL PROPERTY</h2>
                                <p>
                                    The Public Tak App design, logo, code, and graphics (excluding User-Generated Content) are the property of Public Tak App and are protected by copyright and other intellectual property laws. You may not copy, modify, or distribute our proprietary material without written permission.
                                </p>
                            </section>

                            <section className="mb-8 p-6 bg-gray-50 rounded-xl border border-gray-200">
                                <h2 className="text-xl font-bold mb-4 text-gray-800">7. DISCLAIMER & LIABILITY</h2>
                                <p className="mb-3 text-sm uppercase font-bold text-gray-500 tracking-wider">Disclaimer of Warranties</p>
                                <p className="mb-4 text-sm">
                                    THE PLATFORM IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. PUBLIC TAK MAKES NO REPRESENTATIONS OR WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, REGARDING THE ACCURACY, RELIABILITY, OR COMPLETENESS OF ANY CONTENT ON THE PLATFORM.
                                </p>
                                <p className="mb-3 text-sm uppercase font-bold text-gray-500 tracking-wider">Limitation of Liability</p>
                                <p className="text-sm">
                                    TO THE FULLEST EXTENT PERMITTED BY LAW, PUBLIC TAK SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF YOUR USE OF THE PLATFORM OR INABILITY TO USE THE PLATFORM, INCLUDING DAMAGES FOR LOSS OF DATA OR PROFITS.
                                </p>
                            </section>

                            <section className="mb-8">
                                <h2 className="text-2xl font-bold mb-4 text-gray-800">10. CONTACT & GRIEVANCE</h2>
                                <p className="mb-4">
                                    If you have any questions about these Terms or wish to report a violation/grievance, please contact us:
                                </p>
                                <div className="bg-blue-50 p-5 rounded-xl border border-blue-100 inline-block w-full">
                                    <div className="flex items-center gap-3 mb-2">
                                        <span className="material-symbols-outlined text-blue-600">mail</span>
                                        <p className="font-bold text-gray-800 text-lg">Grievance Officer</p>
                                    </div>
                                    <p className="text-gray-600">Email: <a href="mailto:support@publictak.app" className="text-blue-600 hover:underline font-medium">support@publictak.app</a></p>
                                </div>
                            </section>
                        </div>
                    </div>

                    <div className="text-center mt-12 pt-8 border-t border-gray-200 text-sm text-gray-400">
                        <p>© {new Date().getFullYear()} Public Tak App. All rights reserved.</p>
                    </div>

                </div>
            </main>
        </div>
    );
};

export default TermsPage;
