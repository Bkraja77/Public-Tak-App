import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { db } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { subscribeCategories, saveCategories, DEFAULT_NEWS_CATEGORIES, DEFAULT_VIDEO_CATEGORIES } from '../utils/categories';
import { motion } from 'motion/react';

interface SiteSettingsPageProps {
    onBack: () => void;
}

const SiteSettingsPage: React.FC<SiteSettingsPageProps> = ({ onBack }) => {
    const { showToast } = useToast();
    const [newsCategories, setNewsCategories] = useState<string[]>([]);
    const [videoCategories, setVideoCategories] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    // New category inputs
    const [newNewsCat, setNewNewsCat] = useState('');
    const [newVideoCat, setNewVideoCat] = useState('');

    useEffect(() => {
        const unsubscribe = subscribeCategories((data) => {
            setNewsCategories(data.newsCategories);
            setVideoCategories(data.videoCategories);
            setLoading(false);
        });
        return unsubscribe;
    }, []);

    const saveAndUpdate = async (newNews: string[], newVideo: string[]) => {
        setIsSaving(true);
        try {
            await saveCategories(newNews, newVideo);
        } catch (error) {
            console.error("Error saving categories:", error);
            showToast("Failed to save categories to Firestore.", "error");
        } finally {
            setIsSaving(false);
        }
    };

    const handleAddNewsCategory = async (e: React.FormEvent) => {
        e.preventDefault();
        const trimmed = newNewsCat.trim();
        if (!trimmed) return;
        
        // Prevent duplicate case-insensitive
        if (newsCategories.some(cat => cat.toLowerCase() === trimmed.toLowerCase())) {
            showToast("Category already exists in News!", "error");
            return;
        }

        const nextNews = [...newsCategories, trimmed];
        setNewsCategories(nextNews);
        setNewNewsCat('');
        await saveAndUpdate(nextNews, videoCategories);
        showToast("News category added and updated everywhere!", "success");
    };

    const handleAddVideoCategory = async (e: React.FormEvent) => {
        e.preventDefault();
        const trimmed = newVideoCat.trim();
        if (!trimmed) return;

        // Prevent duplicate case-insensitive
        if (videoCategories.some(cat => cat.toLowerCase() === trimmed.toLowerCase())) {
            showToast("Category already exists in Videos!", "error");
            return;
        }

        const nextVideo = [...videoCategories, trimmed];
        setVideoCategories(nextVideo);
        setNewVideoCat('');
        await saveAndUpdate(newsCategories, nextVideo);
        showToast("Video category added and updated everywhere!", "success");
    };

    const handleRemoveNewsCategory = async (categoryToRemove: string) => {
        const nextNews = newsCategories.filter(cat => cat !== categoryToRemove);
        setNewsCategories(nextNews);
        await saveAndUpdate(nextNews, videoCategories);
        showToast("News category removed and updated everywhere!", "success");
    };

    const handleRemoveVideoCategory = async (categoryToRemove: string) => {
        const nextVideo = videoCategories.filter(cat => cat !== categoryToRemove);
        setVideoCategories(nextVideo);
        await saveAndUpdate(newsCategories, nextVideo);
        showToast("Video category removed and updated everywhere!", "success");
    };

    const handleSaveAll = async () => {
        setIsSaving(true);
        try {
            await saveCategories(newsCategories, videoCategories);
            showToast("Categories updated successfully across the app!", "success");
        } catch (error) {
            console.error("Error saving categories:", error);
            showToast("Failed to save categories. Please try again.", "error");
        } finally {
            setIsSaving(false);
        }
    };

    const handleResetToDefaults = async () => {
        if (window.confirm("Are you sure you want to reset all categories to defaults?")) {
            setNewsCategories(DEFAULT_NEWS_CATEGORIES);
            setVideoCategories(DEFAULT_VIDEO_CATEGORIES);
            await saveAndUpdate(DEFAULT_NEWS_CATEGORIES, DEFAULT_VIDEO_CATEGORIES);
            showToast("Categories reset to default and updated everywhere!", "success");
        }
    };

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title="Site Settings" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-32">
                <div className="max-w-4xl mx-auto w-full">
                    {/* Page Intro */}
                    <div className="mb-8">
                        <h2 className="text-3xl font-black text-gray-900 tracking-tight">Site Configuration</h2>
                        <p className="text-gray-500 font-bold mt-1">Manage global app categories and layouts</p>
                    </div>

                    {loading ? (
                        <div className="flex flex-col items-center justify-center py-20">
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
                            <p className="mt-4 text-gray-500 font-medium">Loading settings...</p>
                        </div>
                    ) : (
                        <div className="space-y-8 animate-in fade-in duration-300">
                            
                            {/* Two-Column Grid for Categories */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                
                                {/* Post / News Categories Card */}
                                <div className="glass-card p-6 flex flex-col h-full">
                                    <div className="flex items-center gap-3 mb-6">
                                        <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                                            <span className="material-symbols-outlined text-2xl">article</span>
                                        </div>
                                        <div>
                                            <h3 className="font-black text-lg text-gray-900 leading-tight">News Categories</h3>
                                            <p className="text-xs text-gray-500 mt-0.5">Used for news articles & posts</p>
                                        </div>
                                    </div>

                                    {/* Add Category Form */}
                                    <form onSubmit={handleAddNewsCategory} className="flex gap-2 mb-6">
                                        <input
                                            type="text"
                                            value={newNewsCat}
                                            onChange={(e) => setNewNewsCat(e.target.value)}
                                            placeholder="Enter new category name..."
                                            className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white transition-all font-medium"
                                        />
                                        <button
                                            type="submit"
                                            className="px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-black hover:bg-blue-700 transition-all flex items-center gap-1 active:scale-95"
                                        >
                                            <span className="material-symbols-outlined text-lg">add</span>
                                            Add
                                        </button>
                                    </form>

                                    {/* Categories list */}
                                    <div className="flex-grow space-y-2 max-h-[300px] overflow-y-auto pr-1">
                                        {newsCategories.length === 0 ? (
                                            <p className="text-sm text-gray-500 text-center py-6 italic">No news categories.</p>
                                        ) : (
                                            newsCategories.map((cat, idx) => (
                                                <div 
                                                    key={cat + idx}
                                                    className="flex items-center justify-between px-4 py-2.5 bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-100 transition-colors group"
                                                >
                                                    <span className="text-sm font-semibold text-gray-800">{cat}</span>
                                                    <button
                                                        type="button"
                                                        onClick={() => handleRemoveNewsCategory(cat)}
                                                        className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                                                        title="Delete Category"
                                                    >
                                                        <span className="material-symbols-outlined text-lg">close</span>
                                                    </button>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>

                                {/* Video Categories Card */}
                                <div className="glass-card p-6 flex flex-col h-full">
                                    <div className="flex items-center gap-3 mb-6">
                                        <div className="p-3 bg-red-50 text-red-600 rounded-2xl">
                                            <span className="material-symbols-outlined text-2xl">movie</span>
                                        </div>
                                        <div>
                                            <h3 className="font-black text-lg text-gray-900 leading-tight">Video Categories</h3>
                                            <p className="text-xs text-gray-500 mt-0.5">Used for bulletins & reels</p>
                                        </div>
                                    </div>

                                    {/* Add Category Form */}
                                    <form onSubmit={handleAddVideoCategory} className="flex gap-2 mb-6">
                                        <input
                                            type="text"
                                            value={newVideoCat}
                                            onChange={(e) => setNewVideoCat(e.target.value)}
                                            placeholder="Enter new category name..."
                                            className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-red-500 focus:bg-white transition-all font-medium"
                                        />
                                        <button
                                            type="submit"
                                            className="px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-black hover:bg-red-700 transition-all flex items-center gap-1 active:scale-95"
                                        >
                                            <span className="material-symbols-outlined text-lg">add</span>
                                            Add
                                        </button>
                                    </form>

                                    {/* Categories list */}
                                    <div className="flex-grow space-y-2 max-h-[300px] overflow-y-auto pr-1">
                                        {videoCategories.length === 0 ? (
                                            <p className="text-sm text-gray-500 text-center py-6 italic">No video categories.</p>
                                        ) : (
                                            videoCategories.map((cat, idx) => (
                                                <div 
                                                    key={cat + idx}
                                                    className="flex items-center justify-between px-4 py-2.5 bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-100 transition-colors group"
                                                >
                                                    <span className="text-sm font-semibold text-gray-800">{cat}</span>
                                                    <button
                                                        type="button"
                                                        onClick={() => handleRemoveVideoCategory(cat)}
                                                        className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                                                        title="Delete Category"
                                                    >
                                                        <span className="material-symbols-outlined text-lg">close</span>
                                                    </button>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>

                            </div>

                            {/* Actions Footer */}
                            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-gray-200">
                                <button
                                    type="button"
                                    onClick={handleResetToDefaults}
                                    className="w-full sm:w-auto px-6 py-2.5 text-sm font-bold text-gray-600 hover:text-gray-800 transition-colors flex items-center justify-center gap-1.5"
                                >
                                    <span className="material-symbols-outlined text-lg">restart_alt</span>
                                    Reset to Defaults
                                </button>

                                <div className="flex gap-3 w-full sm:w-auto">
                                    <button
                                        type="button"
                                        onClick={onBack}
                                        className="flex-1 sm:flex-none px-6 py-3 border border-gray-200 hover:bg-gray-50 text-gray-700 font-bold rounded-xl transition-all text-sm text-center"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="button"
                                        onClick={handleSaveAll}
                                        disabled={isSaving}
                                        className="flex-1 sm:flex-none px-8 py-3 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white font-black rounded-xl text-sm text-center shadow-md hover:shadow-lg disabled:opacity-50 disabled:pointer-events-none transition-all active:scale-95 flex items-center justify-center gap-1.5"
                                    >
                                        {isSaving ? (
                                            <>
                                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                                                Saving...
                                            </>
                                        ) : (
                                            <>
                                                <span className="material-symbols-outlined text-lg font-bold">save</span>
                                                Save Changes
                                            </>
                                        )}
                                    </button>
                                </div>
                            </div>

                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default SiteSettingsPage;
