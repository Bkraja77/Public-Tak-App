
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Post, User, View, Comment } from '../types';
import Header from '../components/Header';
import { db, serverTimestamp, increment, storage } from '../firebaseConfig';
import ReportModal from '../components/ReportModal';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from '../components/ConfirmationModal';
import UserAvatar from '../components/UserAvatar';
import AdBanner from '../components/AdBanner';
import { GoogleGenAI, Modality } from "@google/genai";
import SEO from '../components/SEO';
import { formatCount } from '../utils/formatters';
import { sharePost, hasUserSharedLocally, buildPostShareText, recordShareCountOnce, copyTextToClipboard } from '../utils/shareUtils';
import { appCacheService } from '../services/appCacheService';

interface PostDetailPageProps {
    postId: string;
    currentUser: User | null;
    onBack: () => void;
    onLogin: () => void;
    onNavigate: (view: View) => void;
    onViewUser: (userId: string) => void;
    onViewPost: (postId: string) => void;
    onEditPost: (postId: string) => void;
    focusComment?: boolean;
}

interface Reply {
    id: string;
    content: string;
    authorId: string;
    authorName: string;
    authorProfilePicUrl: string;
    createdAt: Date;
    authorIsVerified?: boolean;
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const timeAgo = (date: Date | null | undefined) => {
    if (!date) return 'Just now';
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    return `${days}d`;
};

const ImageLightbox: React.FC<{ imageUrl: string; onClose: () => void }> = ({ imageUrl, onClose }) => {
    const [scale, setScale] = useState(1);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [lastTap, setLastTap] = useState(0);
    const dragStart = useRef({ x: 0, y: 0 });
    const initialPosition = useRef({ x: 0, y: 0 });
    const pinchStartDistance = useRef<number | null>(null);
    const initialScale = useRef<number>(1);

    const handleTouchStart = (e: React.TouchEvent) => {
        if (e.touches.length === 1) {
            dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
            initialPosition.current = { ...position };
        } else if (e.touches.length === 2) {
            const distance = Math.hypot(
                e.touches[0].pageX - e.touches[1].pageX,
                e.touches[0].pageY - e.touches[1].pageY
            );
            pinchStartDistance.current = distance;
            initialScale.current = scale;
        }
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (e.touches.length === 1 && scale > 1) {
            const dx = e.touches[0].clientX - dragStart.current.x;
            const dy = e.touches[0].clientY - dragStart.current.y;
            setPosition({
                x: initialPosition.current.x + dx,
                y: initialPosition.current.y + dy
            });
        } else if (e.touches.length === 2 && pinchStartDistance.current !== null) {
            const currentDistance = Math.hypot(
                e.touches[0].pageX - e.touches[1].pageX,
                e.touches[0].pageY - e.touches[1].pageY
            );
            const ratio = currentDistance / pinchStartDistance.current;
            const newScale = Math.min(Math.max(initialScale.current * ratio, 1), 5);
            setScale(newScale);
            if (newScale === 1) setPosition({ x: 0, y: 0 });
        }
    };

    const handleTouchEnd = () => { pinchStartDistance.current = null; };

    const handleDoubleTap = (e: React.MouseEvent) => {
        e.stopPropagation();
        const now = Date.now();
        if (now - lastTap < 300) {
            if (scale > 1) { setScale(1); setPosition({ x: 0, y: 0 }); } else { setScale(2.5); }
        }
        setLastTap(now);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-2xl animate-in fade-in duration-300 overflow-hidden touch-none" onClick={onClose}>
            <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 active:scale-90 text-white rounded-full transition-all z-[120]"><span className="material-symbols-outlined text-3xl">close</span></button>
            <div className="w-full h-full flex items-center justify-center pointer-events-none" onTouchStart={handleTouchStart} onTouchMove={handleTouchMove} onTouchEnd={handleTouchEnd}>
                <div className="will-change-transform flex items-center justify-center pointer-events-auto" style={{ transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`, transition: pinchStartDistance.current ? 'none' : 'transform 0.1s ease-out' }}>
                    <img src={imageUrl} alt="Fullscreen view" className="max-w-[95vw] max-h-[90vh] object-contain shadow-2xl" onClick={handleDoubleTap} onDragStart={(e) => e.preventDefault()} />
                </div>
            </div>
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-6 bg-white/10 backdrop-blur-xl px-8 py-3 rounded-full border border-white/10 shadow-2xl z-[110]" onClick={(e) => e.stopPropagation()}>
                <button onClick={() => setScale(prev => Math.max(prev - 0.5, 1))} className="text-white hover:text-blue-400 active:scale-75 transition-all" disabled={scale <= 1}><span className="material-symbols-outlined text-3xl">zoom_out</span></button>
                <button onClick={() => { setScale(1); setPosition({x:0, y:0}); }} className="text-white hover:text-blue-400 active:rotate-180 transition-all"><span className="material-symbols-outlined text-2xl">restart_alt</span></button>
                <button onClick={() => setScale(prev => Math.min(prev + 0.5, 5))} className="text-white hover:text-blue-400 active:scale-75 transition-all" disabled={scale >= 5}><span className="material-symbols-outlined text-3xl">zoom_in</span></button>
            </div>
        </div>
    );
};

const ReplyItem: React.FC<{ reply: Reply; postId: string; commentId: string; currentUser: User | null; isPostAuthor: boolean; isAdmin: boolean; onViewUser: (id: string) => void; showToast: (msg: string, type?: 'success' | 'error' | 'info') => void; }> = ({ reply, postId, commentId, currentUser, isPostAuthor, isAdmin, onViewUser, showToast }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState('');
    const [isSavingEdit, setIsSavingEdit] = useState(false);
    const [showMenu, setShowMenu] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => { if (menuRef.current && !menuRef.current.contains(event.target as Node)) setShowMenu(false); };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const isCurrentUserReply = currentUser && currentUser.uid === reply.authorId;
    const saveEdit = async () => {
        if (!editText.trim()) return;
        setIsSavingEdit(true);
        try { await db.collection('posts').doc(postId).collection('comments').doc(commentId).collection('replies').doc(reply.id).update({ content: editText.trim() }); setIsEditing(false); showToast("Reply updated", "success"); } catch (error) { showToast("Failed to update reply", "error"); }
        finally { setIsSavingEdit(false); }
    };
    const handleDeleteReply = async () => { if(!currentUser) return; if(window.confirm("Delete this reply?")) { try { await db.collection('posts').doc(postId).collection('comments').doc(commentId).collection('replies').doc(reply.id).delete(); showToast("Reply deleted.", "success"); } catch (error) { showToast("Could not delete", "error"); } } };

    return (
        <motion.div 
            layout
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex gap-4 group/reply"
        >
            <div className="flex flex-col items-center flex-shrink-0 w-8">
                <div className="w-0.5 h-6 bg-gray-200/60 rounded-full mb-1"></div>
                <UserAvatar 
                    userId={reply.authorId} 
                    src={reply.authorProfilePicUrl} 
                    name={reply.authorName} 
                    currentUser={currentUser} 
                    className="w-8 h-8 rounded-full object-cover aspect-square flex-shrink-0 ring-2 ring-white shadow-sm cursor-pointer hover:scale-110 transition-transform" 
                    onClick={() => onViewUser(reply.authorId)} 
                />
            </div>
            <div className={`flex-grow border transition-all rounded-2xl rounded-tl-none p-3.5 shadow-sm relative ${isEditing ? 'bg-white border-blue-200' : 'bg-gray-50/50 border-gray-100/50 hover:bg-gray-100/80'}`}>
                <div className="flex justify-between items-start mb-1">
                    <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-gray-800 cursor-pointer hover:text-blue-600 transition-colors flex items-center gap-1" onClick={() => onViewUser(reply.authorId)}>
                            {reply.authorName}
                            {reply.authorIsVerified && (
                                <span className="material-symbols-outlined text-blue-500 text-[12px] font-bold" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                            )}
                        </span>
                        {isPostAuthor && <span className="flex items-center gap-0.5 bg-blue-50 text-blue-600 text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest border border-blue-100 shadow-sm"><span className="material-symbols-outlined text-[10px]" style={{ fontVariationSettings: "'FILL' 1" }}>verified</span>Author</span>}
                        <span className="text-[10px] text-gray-400">{timeAgo(reply.createdAt)}</span>
                    </div>
                    {!isEditing && (isAdmin || isCurrentUserReply) && (
                        <div className="relative" ref={menuRef}>
                            <button onClick={() => setShowMenu(!showMenu)} className="p-1 text-gray-300 hover:text-gray-600 active:scale-90 transition-all"><span className="material-symbols-outlined text-base">more_horiz</span></button>
                            {showMenu && <div className="absolute right-0 top-full mt-1 w-28 bg-white rounded-lg shadow-xl border z-20 overflow-hidden animate-in fade-in zoom-in-95 duration-100"><button onClick={() => { setIsEditing(true); setEditText(reply.content); setShowMenu(false); }} className="w-full text-left px-3 py-2 text-xs hover:bg-blue-50 transition-colors">Edit</button><button onClick={handleDeleteReply} className="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 transition-colors">Delete</button></div>}
                        </div>
                    )}
                </div>
                {isEditing ? (
                    <div className="mt-2"><textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="w-full p-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all" autoFocus /><div className="flex justify-end gap-2 mt-2"><button onClick={() => setIsEditing(false)} className="px-2 py-1 text-xs text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200">Cancel</button><button onClick={saveEdit} className="px-2 py-1 text-xs text-white bg-blue-600 rounded-lg disabled:opacity-50 hover:bg-blue-700" disabled={isSavingEdit}>{isSavingEdit ? 'Saving...' : 'Save'}</button></div></div>
                ) : <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap font-medium">{reply.content}</p>}
            </div>
        </motion.div>
    );
};

const CommentItem: React.FC<{ comment: Comment; postId: string; currentUser: User | null; postAuthorId: string; isAdmin: boolean; onViewUser: (id: string) => void; onDelete: (id: string) => void; onLogin: () => void; showToast: (msg: string, type?: 'success' | 'error' | 'info') => void; }> = ({ comment, postId, currentUser, postAuthorId, isAdmin, onViewUser, onDelete, onLogin, showToast }) => {
    const [isLiked, setIsLiked] = useState(false);
    const [likeCount, setLikeCount] = useState(0);
    const [isReplying, setIsReplying] = useState(false);
    const [replyText, setReplyText] = useState('');
    const [isSubmittingReply, setIsSubmittingReply] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState('');
    const [isSavingEdit, setIsSavingEdit] = useState(false);
    const [showMenu, setShowMenu] = useState(false);
    const [serverReplies, setServerReplies] = useState<Reply[]>([]);
    const [localReplies, setLocalReplies] = useState<Reply[]>([]);
    const [showOptionsModal, setShowOptionsModal] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);
    const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);

    const displayReplies = useMemo(() => {
        const combined = [...serverReplies, ...localReplies];
        const uniqueIds = new Set();
        return combined.filter(item => { if (!uniqueIds.has(item.id)) { uniqueIds.add(item.id); return true; } return false; }).sort((a, b) => (a.createdAt?.getTime() || 0) - (b.createdAt?.getTime() || 0));
    }, [serverReplies, localReplies]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => { if (menuRef.current && !menuRef.current.contains(event.target as Node)) setShowMenu(false); };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    useEffect(() => {
        if (!comment.id || !postId) return;
        const unsubLikes = db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('likes').onSnapshot(snapshot => { setLikeCount(snapshot.size); if (currentUser) setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid)); });
        const unsubReplies = db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('replies').onSnapshot(snapshot => {
            const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data(), createdAt: doc.data().createdAt?.toDate ? doc.data().createdAt.toDate() : new Date() } as Reply));
            setServerReplies(fetched);
            setLocalReplies(prev => prev.filter(l => !fetched.some(s => s.authorId === l.authorId && s.content === l.content)));
        });
        return () => { unsubLikes(); unsubReplies(); };
    }, [postId, comment.id, currentUser]);

    const handleLike = async () => {
        if (!currentUser) { onLogin(); return; }
        const prevLiked = isLiked; setIsLiked(!prevLiked); setLikeCount(p => prevLiked ? p - 1 : p + 1);
        try { const ref = db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('likes').doc(currentUser.uid); if (prevLiked) await ref.delete(); else await ref.set({ likedAt: serverTimestamp(), userId: currentUser.uid }); } catch (e) { setIsLiked(prevLiked); setLikeCount(p => prevLiked ? p + 1 : p - 1); showToast("Action failed", "error"); }
    };

    const handleReplySubmit = async () => {
        if (!replyText.trim() || !currentUser) return;
        setIsSubmittingReply(true);
        const tempId = 'local-' + Date.now();
        const newReply: Reply = { id: tempId, content: replyText.trim(), authorId: currentUser.uid, authorName: currentUser.name, authorProfilePicUrl: currentUser.profilePicUrl || '', createdAt: new Date(), authorIsVerified: currentUser.isVerified || false };
        setLocalReplies(prev => [...prev, newReply]);
        const textToSubmit = replyText.trim(); setIsReplying(false); setReplyText('');
        try {
            await db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('replies').add({ 
                content: textToSubmit, 
                authorId: currentUser.uid, 
                authorName: currentUser.name || '', 
                authorProfilePicUrl: currentUser.profilePicUrl || '', 
                createdAt: serverTimestamp(), 
                authorIsVerified: currentUser.isVerified || false 
            });
            if (currentUser.uid !== comment.authorId) { 
                await db.collection('users').doc(comment.authorId).collection('notifications').add({ 
                    type: 'new_comment', 
                    fromUserId: currentUser.uid, 
                    fromUserName: currentUser.name || '', 
                    fromUserProfilePicUrl: currentUser.profilePicUrl || '', 
                    fromUserIsVerified: currentUser.isVerified || false, 
                    postId, 
                    postTitle: `your comment: "${comment.content.substring(0, 20)}..."`, 
                    commentText: textToSubmit.substring(0, 80),
                    createdAt: serverTimestamp(), 
                    read: false 
                }); 
            }
            showToast("Reply posted!", "success");
        } catch (e) { setLocalReplies(p => p.filter(r => r.id !== tempId)); showToast("Failed to reply", "error"); }
        finally { setIsSubmittingReply(false); }
    };

    const saveEdit = async () => { if (!editText.trim()) return; setIsSavingEdit(true); try { await db.collection('posts').doc(postId).collection('comments').doc(comment.id).update({ content: editText.trim() }); setIsEditing(false); showToast("Comment updated", "success"); } catch (e) { showToast("Failed to update", "error"); } finally { setIsSavingEdit(false); } };

    const handlePinComment = async () => {
        if (!comment.id || !postId) return;
        try {
            const commentRef = db.collection('posts').doc(postId).collection('comments').doc(comment.id);
            const isCurrentlyPinned = !!comment.isPinned;
            
            if (!isCurrentlyPinned) {
                const pinnedCommentsSnap = await db.collection('posts')
                    .doc(postId)
                    .collection('comments')
                    .where('isPinned', '==', true)
                    .get();
                
                const batch = db.batch();
                pinnedCommentsSnap.docs.forEach(doc => {
                    batch.update(doc.ref, { isPinned: false });
                });
                batch.update(commentRef, { isPinned: true });
                await batch.commit();
                showToast("Comment pinned to top!", "success");
            } else {
                await commentRef.update({ isPinned: false });
                showToast("Comment unpinned!", "success");
            }
            setShowOptionsModal(false);
        } catch (e) {
            console.error("Error toggling comment pin:", e);
            showToast("Failed to update pin status", "error");
        }
    };

    const handlePressStart = () => {
        if (currentUser?.uid !== postAuthorId) return;
        longPressTimerRef.current = setTimeout(() => {
            setShowOptionsModal(true);
            if (navigator.vibrate) navigator.vibrate(50);
        }, 600);
    };

    const handlePressEnd = () => {
        if (longPressTimerRef.current) {
            clearTimeout(longPressTimerRef.current);
            longPressTimerRef.current = null;
        }
    };

    return (
        <motion.div 
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-4 group select-none"
            onTouchStart={handlePressStart}
            onTouchEnd={handlePressEnd}
            onMouseDown={handlePressStart}
            onMouseUp={handlePressEnd}
            onMouseLeave={handlePressEnd}
        >
            <div className="flex flex-col items-center flex-shrink-0 w-11 relative">
                <UserAvatar 
                    userId={comment.authorId} 
                    src={comment.authorProfilePicUrl} 
                    name={comment.authorName} 
                    currentUser={currentUser} 
                    className="w-11 h-11 rounded-full object-cover aspect-square cursor-pointer ring-2 ring-white shadow-md flex-shrink-0 z-10 hover:scale-110 transition-transform" 
                    onClick={() => onViewUser(comment.authorId)} 
                />
                {displayReplies.length > 0 && <div className="absolute top-11 bottom-0 left-1/2 -translate-x-1/2 w-0.5 bg-gray-100 rounded-full"></div>}
            </div>
            <div className="flex-grow min-w-0">
                <div className={`rounded-2xl rounded-tl-none p-5 relative border transition-all ${comment.isPinned ? 'border-red-200 bg-red-50/20' : isEditing ? 'bg-white border-blue-200' : 'bg-slate-50/50 border-slate-100 group-hover:bg-slate-100/80 shadow-sm'}`}>
                    {comment.isPinned && (
                        <div className="flex items-center gap-1.5 text-red-600 font-extrabold text-[10px] uppercase tracking-wider mb-2">
                            <span className="material-symbols-outlined text-xs font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>push_pin</span>
                            Pinned by Author
                        </div>
                    )}
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                            <p className="font-bold text-sm text-gray-900 cursor-pointer hover:text-blue-600 transition-colors flex items-center gap-1" onClick={() => onViewUser(comment.authorId)}>
                                {comment.authorName}
                                {comment.authorIsVerified && (
                                    <span className="material-symbols-outlined text-blue-500 text-[14px] font-bold" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                                )}
                            </p>
                            {postAuthorId === comment.authorId && <span className="flex items-center gap-1 bg-blue-600 text-white text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest shadow-md"><span className="material-symbols-outlined text-[10px]" style={{ fontVariationSettings: "'FILL' 1" }}>verified</span>Post Author</span>}
                            <span className="text-[10px] text-gray-400 font-medium">{timeAgo(comment.createdAt)}</span>
                        </div>
                        {!isEditing && (isAdmin || currentUser?.uid === comment.authorId || currentUser?.uid === postAuthorId) && (
                            <div className="relative" ref={menuRef}>
                                <button onClick={() => setShowMenu(!showMenu)} className="p-1.5 text-gray-400 hover:text-gray-700 active:scale-90 transition-all"><span className="material-symbols-outlined text-lg">more_horiz</span></button>
                                {showMenu && (
                                    <div className="absolute right-0 top-full mt-1 w-36 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-20 animate-in fade-in zoom-in-95 duration-100">
                                        {currentUser?.uid === comment.authorId && (
                                            <button onClick={() => { setIsEditing(true); setEditText(comment.content); setShowMenu(false); }} className="w-full text-left px-4 py-3 text-sm hover:bg-blue-50 transition-colors flex items-center gap-2">
                                                <span className="material-symbols-outlined text-base">edit</span> Edit
                                            </button>
                                        )}
                                        {currentUser?.uid === postAuthorId && (
                                            <button onClick={handlePinComment} className="w-full text-left px-4 py-3 text-sm hover:bg-blue-50 transition-colors flex items-center gap-2 text-red-600">
                                                <span className="material-symbols-outlined text-base font-bold">push_pin</span> 
                                                {comment.isPinned ? 'Unpin' : 'Pin'}
                                            </button>
                                        )}
                                        {(isAdmin || currentUser?.uid === comment.authorId || currentUser?.uid === postAuthorId) && (
                                            <button onClick={() => onDelete(comment.id)} className="w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2">
                                                <span className="material-symbols-outlined text-base">delete</span> Delete
                                            </button>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                    {isEditing ? (
                        <div className="mt-2"><textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="w-full p-3 text-sm border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all" autoFocus /><div className="flex justify-end gap-2 mt-3"><button onClick={() => setIsEditing(false)} className="px-4 py-2 text-xs font-semibold text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200">Cancel</button><button onClick={saveEdit} className="px-4 py-2 text-xs font-bold text-white bg-blue-600 rounded-xl disabled:opacity-50 hover:bg-blue-700 shadow-md" disabled={isSavingEdit}>{isSavingEdit ? 'Saving...' : 'Save Changes'}</button></div></div>
                    ) : <p className="text-gray-800 text-sm leading-relaxed break-words whitespace-pre-wrap">{comment.content}</p>}
                </div>
                <div className="flex items-center gap-6 mt-2.5 ml-1">
                    <button onClick={handleLike} className={`flex items-center gap-1.5 text-xs font-bold transition-all active:scale-90 ${isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'}`}><span className="material-symbols-outlined text-[18px] transition-all" style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}` }}>favorite</span>{likeCount > 0 ? formatCount(likeCount) : 'Like'}</button>
                    {currentUser && !isReplying && !isEditing && <button onClick={() => setIsReplying(true)} className="text-xs font-bold text-gray-500 hover:text-blue-600 flex items-center gap-1.5 transition-all active:scale-90"><span className="material-symbols-outlined text-[18px]">reply</span>Reply</button>}
                </div>
                {isReplying && (
                    <div className="mt-4 flex gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
                        <UserAvatar 
                            userId={currentUser?.uid} 
                            src={currentUser?.profilePicUrl} 
                            name={currentUser?.name} 
                            currentUser={currentUser} 
                            className="w-8 h-8 rounded-full flex-shrink-0 object-cover aspect-square border-2 border-white shadow-sm" 
                        />
                        <div className="flex-grow">
                            <textarea value={replyText} onChange={(e) => setReplyText(e.target.value)} placeholder={`Reply to ${comment.authorName}...`} className="w-full p-3 text-sm border border-gray-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all bg-white shadow-inner" rows={2} autoFocus />
                            <div className="flex justify-end gap-2 mt-2">
                                <button onClick={() => { setIsReplying(false); setReplyText(''); }} className="px-4 py-2 text-xs font-bold text-gray-500 hover:bg-gray-100 rounded-xl transition-colors">Cancel</button>
                                <button onClick={handleReplySubmit} disabled={isSubmittingReply || !replyText.trim()} className="px-5 py-2 text-xs font-black text-white bg-blue-600 hover:bg-blue-700 rounded-xl disabled:opacity-50 shadow-lg shadow-blue-200 transition-all active:scale-95">{isSubmittingReply ? 'Sending...' : 'Post Reply'}</button>
                            </div>
                        </div>
                    </div>
                )}
                {displayReplies.length > 0 && (
                    <div className="mt-5 flex flex-col gap-5">
                        <AnimatePresence initial={false}>
                            {displayReplies.map(reply => (
                                <ReplyItem 
                                    key={reply.id} 
                                    reply={reply} 
                                    postId={postId} 
                                    commentId={comment.id} 
                                    currentUser={currentUser} 
                                    isPostAuthor={postAuthorId === reply.authorId} 
                                    isAdmin={isAdmin} 
                                    onViewUser={onViewUser} 
                                    showToast={showToast} 
                                />
                            ))}
                        </AnimatePresence>
                    </div>
                )}
            </div>

            {/* Premium Long Press Comment Options Drawer/Modal */}
            <AnimatePresence>
                {showOptionsModal && (
                    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[150] flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={() => setShowOptionsModal(false)}>
                        <motion.div 
                            initial={{ y: "100%", opacity: 0.5 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: "100%", opacity: 0.5 }}
                            transition={{ type: "spring", damping: 25, stiffness: 220 }}
                            className="bg-white dark:bg-slate-900 w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center bg-gray-50 dark:bg-slate-850">
                                <h4 className="text-sm font-black uppercase tracking-wider text-gray-500 flex items-center gap-2">
                                    <span className="material-symbols-outlined text-lg">forum</span>
                                    Comment Options
                                </h4>
                                <button onClick={() => setShowOptionsModal(false)} className="w-8 h-8 rounded-full bg-gray-200/50 hover:bg-gray-200 flex items-center justify-center text-gray-700">
                                    <span className="material-symbols-outlined text-lg">close</span>
                                </button>
                            </div>
                            <div className="p-3 space-y-1.5">
                                <button 
                                    onClick={handlePinComment}
                                    className="w-full flex items-center gap-3.5 px-4 py-3.5 text-sm font-bold text-gray-700 hover:bg-red-50 hover:text-red-600 rounded-2xl transition-all"
                                >
                                    <span className="material-symbols-outlined text-red-500">push_pin</span>
                                    {comment.isPinned ? 'Unpin this Comment' : 'Pin Comment to Top'}
                                </button>
                                <button 
                                    onClick={() => { setShowOptionsModal(false); onDelete(comment.id); }}
                                    className="w-full flex items-center gap-3.5 px-4 py-3.5 text-sm font-bold text-red-600 hover:bg-red-50 rounded-2xl transition-all"
                                >
                                    <span className="material-symbols-outlined text-red-600">delete</span>
                                    Delete Comment permanently
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </motion.div>
    );
};

const PostDetailPage: React.FC<PostDetailPageProps> = ({ postId, currentUser, onBack, onLogin, onNavigate, onViewUser, onViewPost, onEditPost, focusComment }) => {
    const cachedPost = appCacheService.getPost(postId);
    const [post, setPost] = useState<Post | null>(() => cachedPost);
    const [liveAuthor, setLiveAuthor] = useState<User | null>(null);
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');
    const [loading, setLoading] = useState(() => !cachedPost);
    const [error, setError] = useState<string | null>(null);
    const [isSubmittingComment, setIsSubmittingComment] = useState(false);
    const [likeCount, setLikeCount] = useState(0);
    const [shareCount, setShareCount] = useState(0);
    const [isLiked, setIsLiked] = useState(false);
    const [isFollowing, setIsFollowing] = useState<boolean>(() => (currentUser && cachedPost) ? appCacheService.isFollowing(currentUser.uid, cachedPost.authorId) : false);
    const [relatedPosts, setRelatedPosts] = useState<Post[]>([]);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isDeleteCommentModalOpen, setIsDeleteCommentModalOpen] = useState(false);
    const [commentToDeleteId, setCommentToDeleteId] = useState<string | null>(null);
    const [isLinkCopied, setIsLinkCopied] = useState(false);
    const [isPlayingAudio, setIsPlayingAudio] = useState(false);
    const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
    const [showImageLightbox, setShowImageLightbox] = useState(false);
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    
    const commentSectionRef = useRef<HTMLDivElement>(null);
    const commentInputRef = useRef<HTMLTextAreaElement>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
    const lastIncrementedPostId = useRef<string | null>(null);
    const hasAutoPlayed = useRef<boolean>(false);
    const isMounted = useRef<boolean>(true);

    const { t } = useLanguage();
    const { showToast } = useToast();

    useEffect(() => { 
        if (postId && lastIncrementedPostId.current !== postId && post?.authorId) { 
            const authorId = post.authorId;
            const currentUserId = currentUser?.uid;

            const incrementView = async () => {
                lastIncrementedPostId.current = postId; 
                try {
                    const batch = db.batch();
                    const postRef = db.collection('posts').doc(postId);
                    const authorRef = db.collection('users').doc(authorId);
                    
                    batch.update(postRef, { viewCount: increment(1) });
                    
                    // Fetch author data to check monetization status
                    const authorSnap = await authorRef.get();
                    const authorData = authorSnap.data();
                    const isMonetizedApproved = authorData?.isMonetized === true || authorData?.monetizationStatus === 'approved';
                    
                    const updateObj: any = {};
                    
                    if (isMonetizedApproved) {
                        const creatorEarningPerView = 0.01; 
                        updateObj.walletBalance = increment(creatorEarningPerView);
                        updateObj.totalEarnings = increment(creatorEarningPerView);
                    }

                    // Audience tracking (Follower vs Non-Follower)
                    let audienceKey = 'analytics.audience.NonFollowers';
                    if (currentUserId) {
                        const followingDoc = await db.collection('users').doc(currentUserId).collection('following').doc(authorId).get();
                        if (followingDoc.exists) { audienceKey = 'analytics.audience.Followers'; }
                    } else {
                        audienceKey = 'analytics.audience.Guest';
                    }
                    updateObj[audienceKey] = increment(1);
        
                    if (currentUser) {
                        const genderKey = `analytics.gender.${currentUser.gender || 'Unknown'}`;
                        const ageKey = `analytics.age.${currentUser.ageGroup || 'Unknown'}`;
                        const locationKey = `analytics.location.${currentUser.preferredState || 'Unknown'}`;
                        updateObj[genderKey] = increment(1);
                        updateObj[ageKey] = increment(1);
                        updateObj[locationKey] = increment(1);
                    } else {
                        updateObj['analytics.gender.Unknown'] = increment(1);
                        updateObj['analytics.age.Unknown'] = increment(1);
                        updateObj['analytics.location.Unknown'] = increment(1);
                    }
        
                    batch.update(authorRef, updateObj);
                    await batch.commit();
                } catch (err) { console.warn("Analytics failed:", err); }
            };
            incrementView();
        } 
    }, [postId, post?.authorId, currentUser?.uid]);

    const stopAudio = () => {
        if (audioSourceRef.current) {
            try { audioSourceRef.current.stop(); } catch(e) {}
            audioSourceRef.current = null;
        }
        if (audioContextRef.current) {
            try { if (audioContextRef.current.state !== 'closed') audioContextRef.current.close(); } catch(e) {}
            audioContextRef.current = null;
        }
        try {
            window.speechSynthesis.cancel();
        } catch(e) {}
        setIsPlayingAudio(false);
    };

    const [retryCount, setRetryCount] = useState(0);

    useEffect(() => {
        isMounted.current = true;
        const cleanId = decodeURIComponent(postId || '').trim().replace(/[/?#].*$/, '');
        if (!cleanId) {
            setError("अमान्य लिंक (Invalid post link)");
            setLoading(false);
            return;
        }

        const cached = appCacheService.getPost(cleanId);
        if (cached) {
            setPost(cached);
            setLoading(false);
        } else {
            setLoading(true);
        }
        setError(null);
        hasAutoPlayed.current = false;

        const postRef = db.collection('posts').doc(cleanId);
        let hasReceivedDoc = false;

        const handleDocSnapshot = (docSnap: any) => {
            if (!isMounted.current) return;
            if (docSnap.exists) {
                hasReceivedDoc = true;
                const data = docSnap.data();
                if (data) {
                    const fullPost = {
                        id: docSnap.id,
                        ...data,
                        category: data.category || 'General',
                        createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null
                    } as Post;
                    setPost(fullPost);
                    appCacheService.setPost(fullPost);
                    setError(null);
                    setLoading(false);
                }
            } else {
                if (!hasReceivedDoc) {
                    setError("यह खबर उपलब्ध नहीं है या हटा दी गई है।");
                    setLoading(false);
                }
            }
        };

        const unsubPost = postRef.onSnapshot(handleDocSnapshot, (err) => {
            console.warn("Post snapshot error, attempting direct get:", err);
            postRef.get().then(handleDocSnapshot).catch((getErr) => {
                if (isMounted.current) {
                    if (!cached) {
                        setError("खबर लोड करने में विफल। कृपया पुनः प्रयास करें।");
                    }
                    setLoading(false);
                }
            });
        });

        const unsubComments = postRef.collection('comments').onSnapshot(snapshot => {
            const fetched = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    ...data,
                    isPinned: !!data.isPinned,
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date()
                } as Comment;
            });
            fetched.sort((a, b) => {
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                const timeA = a.createdAt ? a.createdAt.getTime() : 0;
                const timeB = b.createdAt ? b.createdAt.getTime() : 0;
                return timeB - timeA;
            });
            if (isMounted.current) setComments(fetched);
        }, () => {});

        const unsubLikes = postRef.collection('likes').onSnapshot(snapshot => {
            if (isMounted.current) {
                setLikeCount(snapshot.size);
                if (currentUser) setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid));
            }
        }, () => {});

        const unsubShares = postRef.collection('shares').onSnapshot(snapshot => {
            if (isMounted.current) {
                setShareCount(prev => Math.max(prev, snapshot.size));
            }
        }, () => {});

        return () => {
            isMounted.current = false;
            unsubPost();
            unsubComments();
            unsubLikes();
            unsubShares();
            stopAudio();
        };
    }, [postId, currentUser?.uid, retryCount]);

    useEffect(() => {
        if (!post) return;
        
        // Fetch live author data to ensure verified badge shows even for old posts
        const unsubAuthor = db.collection('users').doc(post.authorId).onSnapshot(doc => {
            if (doc.exists) {
                setLiveAuthor({ uid: doc.id, ...doc.data() } as User);
            }
        }, err => console.error("Error fetching live author:", err));

        db.collection('posts').where('category', '==', post.category).limit(5).get().then(snapshot => { if (!isMounted.current) return; const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data(), createdAt: doc.data().createdAt?.toDate ? doc.data().createdAt.toDate() : null } as Post)).filter(p => p.id !== post.id); setRelatedPosts(list.slice(0, 3)); });
        if (currentUser && post.authorId !== currentUser.uid) {
            setIsFollowing(appCacheService.isFollowing(currentUser.uid, post.authorId));
            db.collection('users').doc(currentUser.uid).collection('following').doc(post.authorId).onSnapshot(doc => {
                if (isMounted.current) {
                    setIsFollowing(doc.exists);
                    if (doc.exists) {
                        appCacheService.addFollow(currentUser.uid, post.authorId);
                    } else {
                        appCacheService.removeFollow(currentUser.uid, post.authorId);
                    }
                }
            });
        }
        
        return () => unsubAuthor();
    }, [post, currentUser]);

    useEffect(() => { if (focusComment && !loading && post) { setTimeout(() => { if (isMounted.current) { commentSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }); commentInputRef.current?.focus({ preventScroll: true }); } }, 600); } }, [focusComment, loading, post]);

    // Auto-play news reading
    useEffect(() => {
        let timer: NodeJS.Timeout | null = null;
        if (!loading && post && !hasAutoPlayed.current && isMounted.current) {
            hasAutoPlayed.current = true;
            // Delay slightly to ensure user is "settled" on the page immediately
            timer = setTimeout(() => {
                if (isMounted.current) {
                    handleReadAloud(true);
                }
            }, 100);
        }
        return () => {
            if (timer) clearTimeout(timer);
        };
    }, [loading, post]);

    const handleReadAloud = async (isAutoStart: boolean = false) => {
        if (!isAutoStart && isPlayingAudio) { 
            stopAudio(); 
            window.speechSynthesis.cancel();
            return; 
        }
        if (!post || isGeneratingAudio) return;
        
        // KILL PREVIOUS SPEECH BEFORE STARTING NEW
        stopAudio(); 
        window.speechSynthesis.cancel();
        setIsGeneratingAudio(true);
        
        const titleToRead = post.title.replace(/<[^>]+>/g, ' ');
        const contentToRead = post.content
            .replace(/<[^>]+>/g, ' ')
            .replace(/[*#_\[\]]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        const textToReadRaw = `${titleToRead}. ${contentToRead}`;

        // Attempt Gemini TTS first
        try {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            audioContextRef.current = ctx;
            if (ctx.state === 'suspended') await ctx.resume();

            let apiKey: string | undefined;
            try {
                const key = process.env.API_KEY;
                if (typeof key === 'string' && key.trim() !== '') {
                    apiKey = key;
                }
            } catch (e) {}

            if (!apiKey) {
                throw new Error("Gemini API key not available for client-side TTS");
            }

            const ai = new GoogleGenAI({ apiKey });
            const promptToRead = `Say this news naturally in a professional Indian female reporter voice: ${titleToRead}. ${contentToRead.substring(0, 1500)}`;
            
            const response = await ai.models.generateContent({ 
                model: "gemini-3.1-flash-tts-preview", 
                contents: [{ parts: [{ text: promptToRead }] }], 
                config: { 
                    responseModalities: [Modality.AUDIO], 
                    speechConfig: { 
                        voiceConfig: { 
                            prebuiltVoiceConfig: { voiceName: 'Aoede' } 
                        } 
                    } 
                }
            });

            if (!isMounted.current) return;
            const base64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            
            if (base64) {
                const buffer = await decodeAudioData(decode(base64), ctx, 24000, 1); 
                const source = ctx.createBufferSource(); 
                source.buffer = buffer; 
                source.connect(ctx.destination); 
                source.onended = () => { if (isMounted.current) setIsPlayingAudio(false); }; 
                source.start(); 
                audioSourceRef.current = source; 
                setIsPlayingAudio(true);
                setIsGeneratingAudio(false);
                return; // Success with Gemini
            }
        } catch (e) { 
            console.warn("Gemini TTS failed, falling back to Web Speech API", e); 
        }

        // --- Web Speech API Fallback ---
        try {
            const utterance = new SpeechSynthesisUtterance(textToReadRaw);
            utterance.lang = 'hi-IN';
            
            // Try to find a good Female Hindi voice
            const voices = window.speechSynthesis.getVoices();
            const femaleHiVoice = voices.find(v => 
                v.lang.includes('hi') && (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('girl') || v.name.includes('Kalpana') || v.name.includes('Swara'))
            ) || voices.find(v => v.lang.includes('hi'));
            
            if (femaleHiVoice) utterance.voice = femaleHiVoice;
            utterance.rate = 0.95;
            utterance.pitch = 1.05;
            
            utterance.onstart = () => { if (isMounted.current) setIsPlayingAudio(true); };
            utterance.onend = () => { if (isMounted.current) setIsPlayingAudio(false); };
            utterance.onerror = () => { if (isMounted.current) setIsPlayingAudio(false); };

            window.speechSynthesis.speak(utterance);
        } catch (e) {
            console.error("Web Speech fallback failed", e);
            if (!isAutoStart && isMounted.current) showToast("Voice playback failed.", "error"); 
        } finally {
            if (isMounted.current) setIsGeneratingAudio(false); 
        }
    };

    useEffect(() => {
        if (post?.shareCount !== undefined) {
            setShareCount(prev => Math.max(prev, post.shareCount || 0));
        }
    }, [post?.shareCount]);

    const getBaseOrigin = () => {
        return typeof window !== 'undefined' && window.location.origin && !window.location.hostname.includes('localhost') && !window.location.hostname.includes('run.app')
            ? 'https://www.publictak.app'
            : (typeof window !== 'undefined' && window.location.origin ? window.location.origin : 'https://www.publictak.app');
    };

    const handleWhatsAppShare = async () => {
        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }
        if (!post) return;
        const shareText = buildPostShareText({
            id: post.id,
            title: post.title,
            content: post.content
        });
        const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
        window.open(waUrl, '_blank');

        const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
        if (!alreadyShared && isMounted.current) {
            setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
        }
        await recordShareCountOnce('posts', post.id, currentUser);
    };

    const handleFacebookShare = async () => {
        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }
        if (!post) return;
        const postLink = `${getBaseOrigin()}/?postId=${encodeURIComponent(post.id)}`;
        const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postLink)}`;
        window.open(fbUrl, '_blank', 'width=620,height=550,scrollbars=yes,resizable=yes');

        const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
        if (!alreadyShared && isMounted.current) {
            setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
        }
        await recordShareCountOnce('posts', post.id, currentUser);
    };

    const handleTwitterShare = async () => {
        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }
        if (!post) return;
        const postLink = `${getBaseOrigin()}/?postId=${encodeURIComponent(post.id)}`;
        const title = post.title;
        const twUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(postLink)}`;
        window.open(twUrl, '_blank', 'width=620,height=550,scrollbars=yes,resizable=yes');

        const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
        if (!alreadyShared && isMounted.current) {
            setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
        }
        await recordShareCountOnce('posts', post.id, currentUser);
    };

    const handleTelegramShare = async () => {
        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }
        if (!post) return;
        const postLink = `${getBaseOrigin()}/?postId=${encodeURIComponent(post.id)}`;
        const title = post.title;
        const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(postLink)}&text=${encodeURIComponent(title)}`;
        window.open(tgUrl, '_blank', 'width=620,height=550,scrollbars=yes,resizable=yes');

        const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
        if (!alreadyShared && isMounted.current) {
            setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
        }
        await recordShareCountOnce('posts', post.id, currentUser);
    };

    const handleCopyLink = async () => {
        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }
        if (!post) return;
        const postLink = `${getBaseOrigin()}/?postId=${encodeURIComponent(post.id)}`;
        const success = await copyTextToClipboard(postLink);
        if (success) {
            setIsLinkCopied(true);
            showToast("खबर का लिंक कॉपी हो गया!", "success");
            setTimeout(() => {
                if (isMounted.current) setIsLinkCopied(false);
            }, 2500);

            const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
            if (!alreadyShared && isMounted.current) {
                setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
            }
            await recordShareCountOnce('posts', post.id, currentUser);
        } else {
            showToast("लिंक कॉपी नहीं हो सका।", "error");
        }
    };

    const handleShare = async () => {
        if (!currentUser) {
            showToast("कृपया शेयर करने के लिए लॉग इन करें।", "info");
            onLogin();
            return;
        }
        if (!post) return;

        const alreadyShared = hasUserSharedLocally('posts', post.id, currentUser);
        if (!alreadyShared && isMounted.current) {
            setShareCount(prev => Math.max(prev, (post.shareCount || 0) + 1));
        }

        const isNewShare = await sharePost({
            post,
            currentUser,
            showToast,
        });

        if (!isNewShare && !alreadyShared && isMounted.current) {
            setShareCount(post.shareCount || 0);
        }
    };

    const handleLike = async () => {
        if (!currentUser || !post) { onLogin(); return; }
        const prevLiked = isLiked; setIsLiked(!prevLiked); setLikeCount(prev => prevLiked ? prev - 1 : prev + 1);
        const ref = db.collection('posts').doc(postId).collection('likes').doc(currentUser.uid);
        try {
            if (prevLiked) await ref.delete();
            else { 
                const batch = db.batch(); 
                batch.set(ref, { likedAt: serverTimestamp(), userId: currentUser.uid }); 
                if (currentUser.uid !== post.authorId) { 
                    const notifRef = db.collection('users').doc(post.authorId).collection('notifications').doc(); 
                    batch.set(notifRef, { 
                        type: 'new_like', 
                        fromUserId: currentUser.uid, 
                        fromUserName: currentUser.name, 
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '', 
                        fromUserIsVerified: currentUser.isVerified || false, 
                        postId, 
                        postTitle: post.title, 
                        postThumbnailUrl: post.thumbnailUrl || '',
                        createdAt: serverTimestamp(), 
                        read: false 
                    }); 
                } 
                await batch.commit(); 
            }
        } catch (e) { setIsLiked(prevLiked); setLikeCount(prev => prev + 1); showToast("Action failed", "error"); }
    };

    const handleFollowToggle = async () => {
        if (!currentUser || !post) { onLogin(); return; }
        
        const wasFollowing = isFollowing;
        const newFollowingState = !wasFollowing;
        setIsFollowing(newFollowingState);
        if (newFollowingState) {
            appCacheService.addFollow(currentUser.uid, post.authorId);
        } else {
            appCacheService.removeFollow(currentUser.uid, post.authorId);
        }
        
        const currentUserRef = db.collection('users').doc(currentUser.uid);
        const authorRef = db.collection('users').doc(post.authorId);
        const followRef = currentUserRef.collection('following').doc(post.authorId);
        const followerRef = authorRef.collection('followers').doc(currentUser.uid);
        
        try {
            if (wasFollowing) {
                await Promise.allSettled([
                    followRef.delete(),
                    followerRef.delete(),
                    currentUserRef.update({ followingCount: increment(-1) }),
                    authorRef.update({ followerCount: increment(-1) })
                ]);
                showToast(`Unfollowed ${post.authorName || 'Author'}`, "info");
            } else {
                await Promise.allSettled([
                    followRef.set({ followedAt: serverTimestamp() }),
                    followerRef.set({ 
                        followedAt: serverTimestamp(),
                        followerId: currentUser.uid,
                        followerName: currentUser.name || '',
                        followerProfilePicUrl: currentUser.profilePicUrl || ''
                    }),
                    currentUserRef.update({ followingCount: increment(1) }),
                    authorRef.update({ followerCount: increment(1) }),
                    authorRef.collection('notifications').add({
                        type: 'new_follower',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name,
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        fromUserIsVerified: currentUser.isVerified || false,
                        createdAt: serverTimestamp(),
                        read: false
                    })
                ]);
                showToast(`Following ${post.authorName || 'Author'}`, "success");
            }
        } catch (e) {
            console.error("Follow action error:", e);
        }
    };

    if (loading) {
        return (
            <div className="flex flex-col h-full bg-white">
                <Header title={t('post')} showBackButton onBack={onBack} />
                <div className="flex-grow overflow-y-auto w-full max-w-7xl mx-auto md:px-4 py-0 md:py-6 animate-pulse">
                    <div className="bg-white rounded-none md:rounded-2xl border border-gray-100 p-4 space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gray-200 rounded-full" />
                            <div className="flex-1 space-y-2">
                                <div className="h-3 bg-gray-200 rounded w-1/4" />
                                <div className="h-2 bg-gray-200 rounded w-1/6" />
                            </div>
                        </div>
                        <div className="w-full aspect-video bg-gray-200 rounded-xl" />
                        <div className="space-y-3 pt-4">
                            <div className="h-8 bg-gray-200 rounded w-3/4" />
                            <div className="h-4 bg-gray-200 rounded w-full" />
                            <div className="h-4 bg-gray-200 rounded w-full" />
                            <div className="h-4 bg-gray-200 rounded w-5/6" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    if (error || !post) {
        return (
            <div className="flex flex-col h-full bg-white">
                <Header title={t('post')} showBackButton onBack={onBack} />
                <div className="flex-grow flex flex-col items-center justify-center p-6 text-center max-w-md mx-auto">
                    <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-4 ring-8 ring-red-50/50">
                        <span className="material-symbols-outlined text-3xl">article_shortcut</span>
                    </div>
                    <h2 className="text-xl font-bold text-gray-900 mb-2">
                        खबर उपलब्ध नहीं है
                    </h2>
                    <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                        {error || "यह खबर हटा दी गई है या लिंक अमान्य हो सकता है। आप मुख्य पृष्ठ पर अन्य ताज़ा समाचार पढ़ सकते हैं।"}
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3 w-full justify-center">
                        <button
                            onClick={() => {
                                setError(null);
                                setLoading(true);
                                setRetryCount(prev => prev + 1);
                            }}
                            className="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl font-medium text-sm transition-colors flex items-center justify-center gap-2"
                        >
                            <span className="material-symbols-outlined text-base">refresh</span>
                            पुनः प्रयास करें
                        </button>
                        <button
                            onClick={() => onNavigate(View.Main)}
                            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-sm shadow-md transition-colors flex items-center justify-center gap-2"
                        >
                            <span className="material-symbols-outlined text-base">home</span>
                            होम पेज पर जाएं
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    const authorName = currentUser?.uid === post.authorId ? currentUser.name : post.authorName;
    const authorPic = currentUser?.uid === post.authorId ? currentUser.profilePicUrl : post.authorProfilePicUrl;

    return (
        <div className="flex flex-col h-full bg-white">
            <SEO 
                title={post.title} 
                description={post.content} 
                image={post.thumbnailUrl} 
                url={`https://publictak.app/?postId=${post.id}`} 
                type="article"
                author={authorName}
                publishedAt={post.createdAt ? post.createdAt.toISOString() : undefined}
            />
            <Header title={t('post')} showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto pb-20 md:pb-10">
                <div className="w-full max-w-7xl mx-auto md:px-4 py-0 md:py-6">
                    <div className="glass-card mb-8 overflow-hidden rounded-none md:rounded-2xl border-x-0 md:border border-gray-100 bg-white shadow-sm">
                        <div className="px-4 py-3 flex items-center gap-3 border-b border-gray-100 bg-white sticky top-0 z-10">
                            <UserAvatar 
                                userId={post.authorId} 
                                src={post.authorProfilePicUrl} 
                                name={authorName} 
                                currentUser={currentUser} 
                                className="w-10 h-10 rounded-full object-cover cursor-pointer ring-2 ring-gray-100" 
                                onClick={() => onViewUser(post.authorId)} 
                            />
                            <div className="flex-grow min-w-0">
                                <div className="flex items-center gap-1">
                                    <p onClick={() => onViewUser(post.authorId)} className="font-bold text-gray-800 cursor-pointer truncate">
                                        {authorName}
                                    </p>
                                    {(post.authorIsVerified || liveAuthor?.isVerified) && (
                                        <span className="material-symbols-outlined text-blue-500 text-[16px] font-bold shrink-0" style={{ fontVariationSettings: "'FILL' 1" }} title="Verified Creator">verified</span>
                                    )}
                                </div>
                                <p className="text-xs text-gray-500">{timeAgo(post.createdAt)}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                {(!currentUser || currentUser.uid !== post.authorId) && (
                                <button 
                                    onClick={handleFollowToggle} 
                                    className={`px-5 py-2 text-xs font-black uppercase tracking-widest rounded-full transition-all duration-300 shadow-sm active:scale-95 ${
                                        isFollowing 
                                        ? 'bg-gray-100 text-gray-500 border border-gray-200' 
                                        : 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white border border-red-500 animate-follow-blink shadow-md shadow-red-500/40'
                                    }`}
                                >
                                    {isFollowing ? (
                                        <div className="flex items-center gap-1">
                                            <span className="material-symbols-outlined text-[14px] font-black">done</span>
                                            {t('following')}
                                        </div>
                                    ) : (
                                        <div className="flex items-center gap-1.5">
                                            <span className="material-symbols-outlined text-[15px] font-black">person_add</span>
                                            {t('follow')}
                                        </div>
                                    )}
                                </button>
                            )}
                        </div>
                    </div>
                    {post.thumbnailUrl && (
                            <div className="relative group bg-gray-50 flex justify-center border-b border-gray-100">
                                <img 
                                    src={post.thumbnailUrl} 
                                    className="w-full h-auto max-h-[550px] object-contain cursor-zoom-in transition-all" 
                                    onClick={() => setShowImageLightbox(true)} 
                                    alt={post.title} 
                                />
                                <button onClick={() => setShowImageLightbox(true)} className="absolute bottom-4 right-4 bg-black/40 backdrop-blur-md text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all">
                                    <span className="material-symbols-outlined">fullscreen</span>
                                </button>
                            </div>
                        )}
                        <div className="p-5 md:p-10">
                            <div className="flex flex-wrap items-center gap-3 mb-4 text-sm">
                                <span className="bg-red-100 text-red-700 px-2 py-1 rounded font-bold uppercase text-xs">{post.category}</span>
                                <span className="text-gray-500 flex items-center gap-1 font-medium"><span className="material-symbols-outlined text-[16px]">calendar_today</span>{post.createdAt ? new Date(post.createdAt).toLocaleDateString() : ''}</span>
                                
                                <button onClick={() => handleReadAloud(false)} disabled={isGeneratingAudio} className={`p-1.5 transition-colors ${isPlayingAudio ? 'text-red-600' : 'text-gray-500 hover:text-blue-600'}`} title={isPlayingAudio ? "Stop Reading" : "Read News Aloud"}>{isGeneratingAudio ? <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> : <span className="material-symbols-outlined text-lg">{isPlayingAudio ? 'stop_circle' : 'volume_up'}</span>}</button>
                            </div>

                            <h1 className="text-2xl md:text-4xl font-extrabold text-gray-900 mb-5 leading-tight">{post.title}</h1>

                            {/* Quick Share Handle - Centered below Title */}
                            <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-3 my-5 py-3 px-4 bg-gradient-to-r from-gray-50 via-white to-gray-50 border border-gray-200/80 rounded-2xl shadow-2xs">
                                <div className="flex items-center gap-1.5 text-xs font-bold text-gray-600 uppercase tracking-wider">
                                    <span className="material-symbols-outlined text-[18px] text-red-600 animate-pulse">share</span>
                                    <span>Quick Share:</span>
                                </div>

                                <div className="flex items-center flex-wrap justify-center gap-2">
                                    {/* WhatsApp */}
                                    <button
                                        type="button"
                                        onClick={handleWhatsAppShare}
                                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full text-xs font-bold shadow-2xs hover:shadow-md transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                                        title="WhatsApp पर शेयर करें"
                                    >
                                        <i className="fa-brands fa-whatsapp text-sm"></i>
                                        <span>WhatsApp</span>
                                    </button>

                                    {/* Facebook */}
                                    <button
                                        type="button"
                                        onClick={handleFacebookShare}
                                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1877F2] hover:bg-[#166fe5] text-white rounded-full text-xs font-bold shadow-2xs hover:shadow-md transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                                        title="Facebook पर शेयर करें"
                                    >
                                        <i className="fa-brands fa-facebook-f text-xs"></i>
                                        <span>Facebook</span>
                                    </button>

                                    {/* Twitter / X */}
                                    <button
                                        type="button"
                                        onClick={handleTwitterShare}
                                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-black hover:bg-gray-800 text-white rounded-full text-xs font-bold shadow-2xs hover:shadow-md transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                                        title="X (Twitter) पर शेयर करें"
                                    >
                                        <i className="fa-brands fa-x-twitter text-xs"></i>
                                        <span className="hidden xs:inline">Twitter / X</span>
                                    </button>

                                    {/* Telegram */}
                                    <button
                                        type="button"
                                        onClick={handleTelegramShare}
                                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#229ED9] hover:bg-[#1e8bc0] text-white rounded-full text-xs font-bold shadow-2xs hover:shadow-md transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
                                        title="Telegram पर शेयर करें"
                                    >
                                        <i className="fa-brands fa-telegram text-xs"></i>
                                        <span className="hidden xs:inline">Telegram</span>
                                    </button>

                                    {/* Copy Link */}
                                    <button
                                        type="button"
                                        onClick={handleCopyLink}
                                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer border shadow-2xs ${
                                            isLinkCopied 
                                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                                                : 'bg-white hover:bg-gray-50 text-gray-700 border-gray-200'
                                        }`}
                                        title="खबर का लिंक कॉपी करें"
                                    >
                                        <span className="material-symbols-outlined text-[15px] text-gray-600">
                                            {isLinkCopied ? 'check' : 'content_copy'}
                                        </span>
                                        <span>{isLinkCopied ? 'कॉपी हुआ!' : 'Copy Link'}</span>
                                    </button>

                                    {/* More Apps */}
                                    <button
                                        type="button"
                                        onClick={handleShare}
                                        className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-white hover:bg-gray-100 text-gray-600 border border-gray-200 transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer shadow-2xs"
                                        title="अन्य ऐप्स पर शेयर करें"
                                    >
                                        <span className="material-symbols-outlined text-[17px]">more_horiz</span>
                                    </button>
                                </div>
                            </div>
                            <div className="prose prose-lg max-w-none text-gray-700 prose-img:rounded-xl" dangerouslySetInnerHTML={{ __html: post.content }} />
                        </div>
                        <div className="px-5 py-4 bg-gray-50 border-t flex justify-between items-center text-gray-500">
                            <div className="flex gap-4 md:gap-8">
                                <div className="flex items-center gap-1.5 px-1 py-1"><span className="material-symbols-outlined text-[20px]">visibility</span> <span className="text-xs font-bold">{formatCount(post.viewCount)}</span></div>
                                <button onClick={handleLike} className={`flex items-center gap-1.5 px-2 py-1 rounded-full hover:bg-red-100 transition-colors ${isLiked ? 'text-red-500' : 'hover:text-red-500'}`}><span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}` }}>favorite</span> <span className="text-xs font-bold">{formatCount(likeCount)}</span></button>
                                <button onClick={() => commentSectionRef.current?.scrollIntoView({ behavior: 'smooth' })} className="flex items-center gap-1.5 px-2 py-1 rounded-full hover:bg-blue-100 hover:text-blue-600 transition-colors"><span className="material-symbols-outlined text-[20px]">chat_bubble</span> <span className="text-xs font-bold">{formatCount(comments.length)}</span></button>
                                <button onClick={handleShare} className="text-blue-600 flex items-center gap-1.5 px-2 py-1 rounded-full hover:bg-blue-100 transition-colors" title="Share"><span className="material-symbols-outlined text-[20px]">share</span> <span className="text-xs font-bold">{formatCount(shareCount)}</span></button>
                            </div>
                            <div className="relative"><button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 rounded-full hover:bg-gray-200 transition-colors"><span className="material-symbols-outlined">more_vert</span></button>{isMenuOpen && <div className="absolute bottom-full right-0 mb-2 w-48 bg-white rounded-xl shadow-xl border overflow-hidden z-20">{(currentUser?.uid === post.authorId || currentUser?.role === 'admin') && <button onClick={() => onEditPost(post.id)} className="w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center gap-2"><span className="material-symbols-outlined text-lg">edit</span> Edit</button>}<button onClick={() => { setIsMenuOpen(false); if (!currentUser) { showToast("कृपया रिपोर्ट करने के लिए लॉग इन करें।", "info"); onLogin(); return; } setIsReportModalOpen(true); }} className="w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"><span className="material-symbols-outlined text-lg">flag</span> Report (शिकायत करें)</button></div>}</div>
                        </div>
                    </div>
                    <AdBanner slotType="post" className="mb-8" />
                    {relatedPosts.length > 0 && (
                        <div className="mb-12 px-4 md:px-0">
                            <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center gap-2">
                                <span className="w-1 h-8 bg-red-600 rounded-full"></span>Related News
                            </h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {relatedPosts.map(rp => (
                                    <div key={rp.id} onClick={() => onViewPost(rp.id)} className="glass-card overflow-hidden cursor-pointer group hover:shadow-lg transition-all border border-gray-100 bg-white flex flex-col">
                                        <div className="w-full aspect-[16/10] overflow-hidden relative bg-gray-50 flex items-center justify-center">
                                            {rp.thumbnailUrl && (
                                                <div 
                                                    className="absolute inset-0 bg-cover bg-center blur-md opacity-25 scale-105 pointer-events-none"
                                                    style={{ backgroundImage: `url(${rp.thumbnailUrl})` }}
                                                />
                                            )}
                                            <img src={rp.thumbnailUrl} alt={rp.title} className="w-full h-full object-contain relative z-10 transition-all group-hover:scale-105 duration-500" />
                                        </div>
                                        <div className="p-4 flex-grow flex flex-col">
                                            <div className="flex items-center gap-2 mb-2">
                                                <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-[10px] uppercase font-bold rounded tracking-wider">{rp.category}</span>
                                                <span className="text-xs text-gray-400">• {timeAgo(rp.createdAt)}</span>
                                            </div>
                                            <h3 className="font-bold text-lg text-gray-800 leading-snug line-clamp-2 group-hover:text-red-600 transition-colors mb-2">{rp.title}</h3>
                                            <div className="mt-auto pt-3 border-t border-gray-50 flex items-center justify-between text-xs text-gray-500">
                                                <span>By {rp.authorName}</span>
                                                <div className="flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[14px]">visibility</span> {formatCount(rp.viewCount)}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    <div ref={commentSectionRef} className="mt-8 px-4 md:px-0">
                        <div className="glass-card p-6 md:p-8 bg-white border border-gray-100 shadow-md">
                            <h2 className="text-2xl font-black mb-8 flex items-center gap-3 text-gray-900">
                                <span className="material-symbols-outlined text-blue-600 text-3xl">forum</span> 
                                Comments 
                                <span className="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-sm font-bold">{formatCount(comments.length)}</span>
                            </h2>
                            
                            {currentUser ? (
                                <form onSubmit={async (e) => { 
                                    e.preventDefault(); 
                                    if (!newComment.trim()) return; 
                                    setIsSubmittingComment(true); 
                                    try { 
                                        const commentTextClean = newComment.trim();
                                        await db.collection('posts').doc(postId).collection('comments').add({ 
                                            content: commentTextClean, 
                                            authorId: currentUser.uid, 
                                            authorName: currentUser.name || '', 
                                            authorProfilePicUrl: currentUser.profilePicUrl || '', 
                                            createdAt: serverTimestamp(),
                                            authorIsVerified: currentUser.isVerified || false
                                        }); 

                                        if (post && currentUser.uid !== post.authorId) {
                                            db.collection('users').doc(post.authorId).collection('notifications').add({
                                                type: 'new_comment',
                                                fromUserId: currentUser.uid,
                                                fromUserName: currentUser.name || '',
                                                fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                                                fromUserIsVerified: currentUser.isVerified || false,
                                                postId: post.id,
                                                postTitle: post.title || '',
                                                postThumbnailUrl: post.thumbnailUrl || '',
                                                commentText: commentTextClean.substring(0, 80),
                                                createdAt: serverTimestamp(),
                                                read: false
                                            }).catch(err => console.error("Comment notification failed:", err));
                                        }

                                        setNewComment(''); 
                                        showToast("Comment posted!", "success");
                                    } catch (e) { 
                                        showToast("Failed to post comment", "error"); 
                                    } finally { 
                                        setIsSubmittingComment(false); 
                                    } 
                                }} className="mb-12 flex gap-4 bg-gray-50 p-4 md:p-6 rounded-3xl border border-gray-100">
                                    <UserAvatar 
                                        userId={currentUser.uid} 
                                        src={currentUser.profilePicUrl} 
                                        name={currentUser.name} 
                                        currentUser={currentUser} 
                                        className="w-12 h-12 rounded-full flex-shrink-0 object-cover aspect-square border-2 border-white shadow-sm" 
                                    />
                                    <div className="flex-grow flex flex-col gap-3">
                                        <textarea 
                                            ref={commentInputRef} 
                                            value={newComment} 
                                            onChange={e => setNewComment(e.target.value)} 
                                            placeholder="Write a thoughtful comment..." 
                                            className="w-full p-4 border border-gray-200 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all bg-white text-gray-800 placeholder-gray-400" 
                                            rows={3} 
                                        />
                                        <div className="flex justify-end">
                                            <button 
                                                type="submit" 
                                                disabled={isSubmittingComment || !newComment.trim()} 
                                                className="px-8 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black disabled:opacity-50 shadow-lg shadow-blue-200 transition-all active:scale-95 flex items-center gap-2"
                                            >
                                                {isSubmittingComment ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <span className="material-symbols-outlined text-xl">send</span>}
                                                {isSubmittingComment ? 'Posting...' : 'Post Comment'}
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            ) : (
                                <div className="mb-12 p-8 bg-blue-50 rounded-3xl border border-blue-100 text-center">
                                    <p className="text-blue-800 font-bold mb-4">Sign in to join the conversation</p>
                                    <button onClick={onLogin} className="px-8 py-2.5 bg-blue-600 text-white rounded-xl font-black shadow-md hover:bg-blue-700 active:scale-95 transition-all">Login / Sign Up</button>
                                </div>
                            )}

                            <div className="space-y-12">
                                <AnimatePresence initial={false}>
                                    {comments.length > 0 ? (
                                        comments.map(c => (
                                            <CommentItem 
                                                key={c.id} 
                                                comment={c} 
                                                postId={postId} 
                                                currentUser={currentUser} 
                                                postAuthorId={post.authorId} 
                                                isAdmin={currentUser?.role === 'admin'} 
                                                onViewUser={onViewUser} 
                                                onDelete={id => { setCommentToDeleteId(id); setIsDeleteCommentModalOpen(true); }} 
                                                onLogin={onLogin} 
                                                showToast={showToast} 
                                            />
                                        ))
                                    ) : (
                                        <motion.div 
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            className="text-center py-16"
                                        >
                                            <span className="material-symbols-outlined text-6xl text-gray-200 mb-4 block">forum_off</span>
                                            <p className="text-gray-400 font-medium italic">Be the first to spark a conversation!</p>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            {showImageLightbox && <ImageLightbox imageUrl={post.thumbnailUrl} onClose={() => setShowImageLightbox(false)} />}
            <ConfirmationModal isOpen={isDeleteCommentModalOpen} onClose={() => setIsDeleteCommentModalOpen(false)} onConfirm={async () => { if (commentToDeleteId) { await db.collection('posts').doc(postId).collection('comments').doc(commentToDeleteId).delete(); setCommentToDeleteId(null); setIsDeleteCommentModalOpen(false); showToast("Comment deleted", "success"); } }} title="Delete Comment" message="Are you sure you want to permanently delete this comment?" />
            {isReportModalOpen && post && currentUser && (
                <ReportModal
                    post={post}
                    user={currentUser}
                    onClose={() => setIsReportModalOpen(false)}
                    onSuccess={() => setIsReportModalOpen(false)}
                />
            )}
        </div>
    );
};

export default PostDetailPage;
