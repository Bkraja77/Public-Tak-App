
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { db } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';

interface KYCRequest {
    id: string;
    userId: string;
    userName: string;
    panNumber: string;
    panPhotoUrl: string;
    status: 'pending' | 'verified' | 'rejected';
    submittedAt: any;
    rejectReason?: string;
}

const ManageKYCPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const { showToast } = useToast();
    const [requests, setRequests] = useState<KYCRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedRequest, setSelectedRequest] = useState<KYCRequest | null>(null);
    const [rejectReason, setRejectReason] = useState('');
    const [showRejectModal, setShowRejectModal] = useState(false);

    useEffect(() => {
        const unsubscribe = db.collection('kyc_requests')
            .where('status', '==', 'pending')
            .orderBy('submittedAt', 'desc')
            .onSnapshot(snapshot => {
                const list = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                    submittedAt: doc.data().submittedAt?.toDate() || new Date()
                } as KYCRequest));
                setRequests(list);
                setLoading(false);
            }, err => {
                console.error("Error fetching KYC requests:", err);
                setLoading(false);
            });

        return () => unsubscribe();
    }, []);

    const handleApprove = async (req: KYCRequest) => {
        try {
            const batch = db.batch();
            
            // 1. Update request status
            const reqRef = db.collection('kyc_requests').doc(req.id);
            batch.update(reqRef, { status: 'verified', approvedAt: new Date() });
            
            // 2. Update user status
            const userRef = db.collection('users').doc(req.userId);
            batch.update(userRef, { kycStatus: 'verified' });
            
            await batch.commit();
            showToast(`KYC for ${req.userName} approved!`, "success");
            setSelectedRequest(null);
        } catch (error) {
            showToast("Approval failed", "error");
        }
    };

    const handleReject = async () => {
        if (!selectedRequest || !rejectReason) return;
        
        try {
            const batch = db.batch();
            
            // 1. Update request status
            const reqRef = db.collection('kyc_requests').doc(selectedRequest.id);
            batch.update(reqRef, { 
                status: 'rejected', 
                rejectedAt: new Date(),
                rejectReason: rejectReason 
            });
            
            // 2. Update user status
            const userRef = db.collection('users').doc(selectedRequest.userId);
            batch.update(userRef, { 
                kycStatus: 'rejected',
                kycRejectReason: rejectReason 
            });
            
            await batch.commit();
            showToast(`KYC for ${selectedRequest.userName} rejected.`, "info");
            setShowRejectModal(false);
            setSelectedRequest(null);
            setRejectReason('');
        } catch (error) {
            showToast("Rejection failed", "error");
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Manage KYC Requests" showBackButton onBack={onBack} />
            
            <main className="flex-grow overflow-y-auto p-4 md:p-8">
                <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* List Section */}
                    <div className="lg:col-span-1 space-y-4">
                        <h3 className="text-sm font-bold text-gray-500 uppercase tracking-[0.2em] px-1">Pending Requests ({requests.length})</h3>
                        {loading ? (
                            <div className="p-12 flex justify-center"><div className="w-8 h-8 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div></div>
                        ) : requests.length === 0 ? (
                            <div className="glass-card p-12 text-center text-gray-400">
                                <span className="material-symbols-outlined text-5xl mb-3 opacity-20">fact_check</span>
                                <p>All caught up!</p>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {requests.map(req => (
                                    <button 
                                        key={req.id}
                                        onClick={() => setSelectedRequest(req)}
                                        className={`w-full text-left glass-card p-4 transition-all ${selectedRequest?.id === req.id ? 'ring-2 ring-red-500 bg-red-50/20' : 'hover:bg-white'}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                                                <span className="material-symbols-outlined">person</span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="font-bold text-gray-900 truncate">{req.userName}</p>
                                                <p className="text-[10px] text-gray-500 flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[10px]">timer</span>
                                                    {req.submittedAt.toLocaleDateString()}
                                                </p>
                                            </div>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Detail Section */}
                    <div className="lg:col-span-2">
                        <AnimatePresence mode="wait">
                            {selectedRequest ? (
                                <motion.div 
                                    key={selectedRequest.id}
                                    initial={{ opacity: 0, scale: 0.98 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.98 }}
                                    className="glass-card overflow-hidden"
                                >
                                    <div className="bg-gray-900 p-6 text-white flex justify-between items-center">
                                        <div>
                                            <h2 className="text-xl font-bold">{selectedRequest.userName}</h2>
                                            <p className="text-gray-400 text-xs">PAN: {selectedRequest.panNumber}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-[10px] text-gray-400 uppercase tracking-widest">Submitted At</p>
                                            <p className="text-xs font-bold">{selectedRequest.submittedAt.toLocaleString()}</p>
                                        </div>
                                    </div>
                                    
                                    <div className="p-8 space-y-8">
                                        <div className="space-y-4">
                                            <h4 className="text-sm font-bold text-gray-700 uppercase">Uploaded Document</h4>
                                            <div className="bg-gray-100 rounded-2xl overflow-hidden border border-gray-200">
                                                <img 
                                                    src={selectedRequest.panPhotoUrl} 
                                                    alt="PAN Card" 
                                                    className="max-w-full mx-auto" 
                                                    referrerPolicy="no-referrer"
                                                />
                                            </div>
                                        </div>

                                        <div className="flex flex-col md:flex-row gap-4 pt-4 border-t border-gray-100">
                                            <button 
                                                onClick={() => handleApprove(selectedRequest)}
                                                className="flex-1 py-4 bg-emerald-600 text-white font-black rounded-2xl hover:bg-emerald-700 shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all transform active:scale-95"
                                            >
                                                <span className="material-symbols-outlined">verified</span>
                                                Approve Verification
                                            </button>
                                            <button 
                                                onClick={() => setShowRejectModal(true)}
                                                className="flex-1 py-4 bg-red-50 text-red-600 font-bold rounded-2xl hover:bg-red-100 flex items-center justify-center gap-2 transition-all"
                                            >
                                                <span className="material-symbols-outlined">cancel</span>
                                                Reject Request
                                            </button>
                                        </div>
                                    </div>
                                </motion.div>
                            ) : (
                                <div className="h-full min-h-[400px] flex flex-col items-center justify-center glass-card text-gray-400 p-12 text-center">
                                    <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6 border border-gray-100">
                                        <span className="material-symbols-outlined text-6xl opacity-30">account_balance_wallet</span>
                                    </div>
                                    <h2 className="text-xl font-bold text-gray-800 mb-2">Verification Desk</h2>
                                    <p className="max-w-sm">Select a user request from the sidebar to review their PAN document and update their verification status.</p>
                                </div>
                            )}
                        </AnimatePresence>
                    </div>
                </div>
            </main>

            {/* Rejection Reason Modal */}
            <AnimatePresence>
                {showRejectModal && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                        <motion.div 
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
                        >
                            <h3 className="text-xl font-bold text-gray-900 mb-4">Reject Verification</h3>
                            <p className="text-gray-500 text-sm mb-4">Please provide a reason why this request is being rejected. This will be shown to the user.</p>
                            <textarea 
                                value={rejectReason}
                                onChange={(e) => setRejectReason(e.target.value)}
                                placeholder="e.g. Photo is blurry, PAN number does not match"
                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl mb-6 min-h-[120px] focus:ring-2 focus:ring-red-500 transition-all outline-none"
                            ></textarea>
                            <div className="flex gap-4">
                                <button 
                                    onClick={() => setShowRejectModal(false)}
                                    className="flex-1 py-3 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200"
                                >
                                    Cancel
                                </button>
                                <button 
                                    onClick={handleReject}
                                    disabled={!rejectReason}
                                    className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 disabled:opacity-50"
                                >
                                    Confirm Reject
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default ManageKYCPage;
