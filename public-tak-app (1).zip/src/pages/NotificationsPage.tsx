import React, { useState, useEffect, useRef, useMemo } from 'react';
import Header from '../components/Header';
import { db, serverTimestamp, increment } from '../firebaseConfig';
import { User, Notification } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from '../components/ConfirmationModal';
import UserAvatar from '../components/UserAvatar';
import { 
  Heart, 
  MessageSquare, 
  UserPlus, 
  UserCheck, 
  Sparkles, 
  FileText, 
  AlertTriangle, 
  Trash2, 
  CheckCheck, 
  Check, 
  Clock, 
  Play, 
  Bell, 
  BellOff, 
  BadgeCheck,
  Compass
} from 'lucide-react';
import appCacheService from '../services/appCacheService';

interface NotificationsPageProps {
  onBack: () => void;
  currentUser: User | null;
  onViewPost: (postId: string) => void;
  onViewUser: (userId: string) => void;
  onViewVideo?: (videoId: string) => void;
}

type FilterType = 'all' | 'like' | 'comment' | 'follower' | 'updates';

const SkeletonNotification = () => (
  <div className="p-4 sm:p-5 flex items-center gap-3.5 sm:gap-4 animate-pulse bg-white/60 dark:bg-slate-900/60 rounded-2xl border border-gray-100 dark:border-slate-800/80 shadow-xs">
    <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-slate-800 flex-shrink-0"></div>
    <div className="flex-1 space-y-2.5">
      <div className="h-4 w-3/5 bg-gray-200 dark:bg-slate-800 rounded-md"></div>
      <div className="h-3 w-2/5 bg-gray-150 dark:bg-slate-850 rounded-md"></div>
    </div>
    <div className="w-12 h-12 rounded-xl bg-gray-200 dark:bg-slate-800 flex-shrink-0"></div>
  </div>
);

// --- Swipeable Notification Item Component ---
interface SwipeableItemProps {
  notification: Notification;
  currentUser?: User | null;
  isHindi: boolean;
  onClick: (notification: Notification) => void;
  onDelete: (id: string) => void;
  onToggleRead: (e: React.MouseEvent, notification: Notification) => void;
  timeAgo: (d: Date) => string;
  isFollowing: boolean;
  onFollowBack: (userId: string, userName: string, userPic: string) => void;
  onViewUser: (userId: string) => void;
}

const SwipeableNotificationItem: React.FC<SwipeableItemProps> = ({ 
  notification, 
  currentUser, 
  isHindi,
  onClick, 
  onDelete, 
  onToggleRead,
  timeAgo, 
  isFollowing, 
  onFollowBack, 
  onViewUser
}) => {
  const [offsetX, setOffsetX] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const startX = useRef<number | null>(null);
  const startY = useRef<number | null>(null);
  const isHorizontalSwipe = useRef<boolean | null>(null);
  const itemRef = useRef<HTMLDivElement>(null);

  const DELETE_BTN_WIDTH = 84;

  const handleTouchStart = (e: React.TouchEvent) => {
    startX.current = e.touches[0].clientX;
    startY.current = e.touches[0].clientY;
    isHorizontalSwipe.current = null;
    setIsSwiping(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (startX.current === null || startY.current === null) return;
    if (isHorizontalSwipe.current === false) return;

    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const diffX = currentX - startX.current;
    const diffY = currentY - startY.current;

    if (isHorizontalSwipe.current === null) {
      const absX = Math.abs(diffX);
      const absY = Math.abs(diffY);
      
      if (absX > 8 || absY > 8) {
        if (absX > absY * 1.5) {
          isHorizontalSwipe.current = true;
        } else {
          isHorizontalSwipe.current = false;
          return;
        }
      } else {
        return;
      }
    }

    let newOffset = diffX;
    if (offsetX < 0) {
      newOffset = -DELETE_BTN_WIDTH + diffX;
    }

    if (newOffset > 0) newOffset = 0;
    if (newOffset < -DELETE_BTN_WIDTH * 1.5) newOffset = -DELETE_BTN_WIDTH * 1.5;

    setOffsetX(newOffset);
  };

  const handleTouchEnd = () => {
    setIsSwiping(false);
    startX.current = null;
    startY.current = null;
    isHorizontalSwipe.current = null;

    if (offsetX < -(DELETE_BTN_WIDTH / 2)) {
      setOffsetX(-DELETE_BTN_WIDTH);
    } else {
      setOffsetX(0);
    }
  };

  const handleContentClick = () => {
    if (offsetX !== 0) {
      setOffsetX(0);
    } else {
      onClick(notification);
    }
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(notification.id);
    setOffsetX(0);
  };

  // Themed visual configurations per notification type
  const getTypeConfig = (type: string) => {
    switch (type) {
      case 'new_like':
        return {
          icon: <Heart className="w-3.5 h-3.5 text-white fill-white" />,
          badgeGradient: 'bg-gradient-to-tr from-rose-500 to-pink-500 shadow-rose-500/40',
          accentBorder: 'border-l-rose-500',
          unreadBg: 'bg-gradient-to-r from-rose-50/80 via-white to-white dark:from-rose-950/20 dark:via-slate-900 dark:to-slate-900',
          textColor: 'text-rose-600 dark:text-rose-400',
        };
      case 'new_comment':
      case 'reply':
        return {
          icon: <MessageSquare className="w-3.5 h-3.5 text-white fill-white" />,
          badgeGradient: 'bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 shadow-blue-500/40',
          accentBorder: 'border-l-blue-500',
          unreadBg: 'bg-gradient-to-r from-blue-50/80 via-white to-white dark:from-blue-950/20 dark:via-slate-900 dark:to-slate-900',
          textColor: 'text-blue-600 dark:text-blue-400',
        };
      case 'new_follower':
        return {
          icon: <UserPlus className="w-3.5 h-3.5 text-white" />,
          badgeGradient: 'bg-gradient-to-tr from-emerald-500 to-teal-500 shadow-emerald-500/40',
          accentBorder: 'border-l-emerald-500',
          unreadBg: 'bg-gradient-to-r from-emerald-50/80 via-white to-white dark:from-emerald-950/20 dark:via-slate-900 dark:to-slate-900',
          textColor: 'text-emerald-600 dark:text-emerald-400',
        };
      case 'new_post':
        return {
          icon: <Sparkles className="w-3.5 h-3.5 text-white fill-white" />,
          badgeGradient: 'bg-gradient-to-tr from-violet-600 via-purple-600 to-fuchsia-500 shadow-violet-500/40',
          accentBorder: 'border-l-purple-500',
          unreadBg: 'bg-gradient-to-r from-purple-50/80 via-white to-white dark:from-purple-950/20 dark:via-slate-900 dark:to-slate-900',
          textColor: 'text-purple-600 dark:text-purple-400',
        };
      case 'post_reported':
      case 'content_reported':
        return {
          icon: <AlertTriangle className="w-3.5 h-3.5 text-white" />,
          badgeGradient: 'bg-gradient-to-tr from-amber-500 to-orange-600 shadow-amber-500/40',
          accentBorder: 'border-l-amber-500',
          unreadBg: 'bg-gradient-to-r from-amber-50/80 via-white to-white dark:from-amber-950/20 dark:via-slate-900 dark:to-slate-900',
          textColor: 'text-amber-600 dark:text-amber-400',
        };
      default:
        return {
          icon: <Bell className="w-3.5 h-3.5 text-white" />,
          badgeGradient: 'bg-gradient-to-tr from-slate-600 to-slate-700 shadow-slate-500/30',
          accentBorder: 'border-l-blue-500',
          unreadBg: 'bg-gradient-to-r from-blue-50/70 via-white to-white dark:from-slate-800 dark:via-slate-900 dark:to-slate-900',
          textColor: 'text-slate-600 dark:text-slate-400',
        };
    }
  };

  const config = getTypeConfig(notification.type);

  const getActionPhrase = () => {
    const title = notification.postTitle ? `"${notification.postTitle}"` : (isHindi ? 'आपकी पोस्ट' : 'your post');
    const isVideo = notification.contentType === 'video' || (notification as any).postType === 'video' || notification.videoId;

    if (isHindi) {
      switch (notification.type) {
        case 'new_like':
          return <>ने आपकी पोस्ट <span className="font-semibold text-gray-900 dark:text-white">{title}</span> को पसंद (Like) किया</>;
        case 'new_comment':
          return <>ने आपकी पोस्ट <span className="font-semibold text-gray-900 dark:text-white">{title}</span> पर कमेंट किया</>;
        case 'reply':
          return <>ने आपके कमेंट का जवाब दिया</>;
        case 'new_follower':
          return <>ने आपको फॉलो करना शुरू किया</>;
        case 'new_post':
          return <>ने नया {isVideo ? 'वीडियो' : 'पोस्ट'} <span className="font-semibold text-gray-900 dark:text-white">{title}</span> साझा किया</>;
        case 'post_reported':
        case 'content_reported':
          return <>ने आपके {isVideo ? 'वीडियो' : 'पोस्ट'} <span className="font-semibold text-gray-900 dark:text-white">{title}</span> की रिपोर्ट की</>;
        default:
          return <>ने आपके साथ बातचीत की</>;
      }
    } else {
      switch (notification.type) {
        case 'new_like':
          return <>liked your post <span className="font-semibold text-gray-900 dark:text-white">{title}</span></>;
        case 'new_comment':
          return <>commented on your post <span className="font-semibold text-gray-900 dark:text-white">{title}</span></>;
        case 'reply':
          return <>replied to your comment</>;
        case 'new_follower':
          return <>started following you</>;
        case 'new_post':
          return <>published a new {isVideo ? 'video' : 'post'} <span className="font-semibold text-gray-900 dark:text-white">{title}</span></>;
        case 'post_reported':
        case 'content_reported':
          return <>reported your {isVideo ? 'video' : 'post'} <span className="font-semibold text-gray-900 dark:text-white">{title}</span></>;
        default:
          return <>interacted with your content</>;
      }
    }
  };

  const isUnread = !notification.read;
  const isVideo = notification.contentType === 'video' || (notification as any).postType === 'video' || notification.videoId;
  const thumbnail = notification.postThumbnailUrl || (notification as any).thumbnailUrl;

  return (
    <div className="relative overflow-hidden rounded-2xl border border-gray-100 dark:border-slate-800 shadow-xs hover:shadow-md transition-all duration-200 select-none group">
      {/* Swipe Delete Action Layer */}
      <div 
        className={`absolute inset-y-0 right-0 w-full bg-gradient-to-l from-rose-600 via-rose-500 to-red-600 flex justify-end items-center z-0 transition-opacity duration-150 ${
          offsetX < 0 || isSwiping ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <button 
          onClick={handleDeleteClick}
          className="h-full flex flex-col items-center justify-center text-white px-6 active:scale-95 transition-transform"
          style={{ width: `${DELETE_BTN_WIDTH}px` }}
          aria-label="Delete notification"
        >
          <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center mb-1">
            <Trash2 className="w-5 h-5 text-white" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-wider">
            {isHindi ? 'हटाएं' : 'Delete'}
          </span>
        </button>
      </div>

      {/* Foreground Interactive Card */}
      <div 
        ref={itemRef}
        className={`relative z-10 w-full p-3.5 sm:p-4 md:p-5 flex items-start sm:items-center gap-3.5 sm:gap-4 transition-colors cursor-pointer border-l-[4px] ${
          isUnread 
            ? `${config.unreadBg} ${config.accentBorder}` 
            : 'bg-white/95 dark:bg-slate-900/95 border-l-transparent hover:border-l-gray-300 dark:hover:border-l-slate-700'
        }`}
        style={{ 
          transform: `translateX(${offsetX}px)`,
          transition: isSwiping ? 'none' : 'transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)' 
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onClick={handleContentClick}
      >
        {/* Avatar with Floating Action Badge */}
        <div 
          onClick={(e) => {
            e.stopPropagation();
            onViewUser(notification.fromUserId);
          }}
          className="relative flex-shrink-0 cursor-pointer hover:scale-105 active:scale-95 transition-transform z-20"
        >
          <div className={`p-0.5 rounded-full ${isUnread ? 'bg-gradient-to-tr from-rose-500 via-amber-400 to-blue-500' : 'bg-gray-100 dark:bg-slate-800'}`}>
            <UserAvatar 
              userId={notification.fromUserId}
              src={notification.fromUserProfilePicUrl}
              name={notification.fromUserName}
              currentUser={currentUser}
              className="w-12 h-12 rounded-full object-cover border-2 border-white dark:border-slate-900 shadow-sm"
            />
          </div>
          
          {/* Action icon bubble */}
          <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-md ${config.badgeGradient}`}>
            {config.icon}
          </div>
        </div>
        
        {/* Center Content */}
        <div className="flex-1 min-w-0 pr-1">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span 
              onClick={(e) => {
                e.stopPropagation();
                onViewUser(notification.fromUserId);
              }}
              className="font-bold text-sm sm:text-base text-gray-900 dark:text-white hover:underline cursor-pointer flex items-center gap-1"
            >
              {notification.fromUserName}
              {notification.fromUserIsVerified && (
                <BadgeCheck className="w-4 h-4 text-blue-500 fill-blue-500 text-white" />
              )}
            </span>

            {isUnread && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-600 text-white shadow-xs animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                {isHindi ? 'नया' : 'NEW'}
              </span>
            )}
          </div>

          <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 leading-relaxed mt-0.5">
            {getActionPhrase()}
          </p>

          {/* Comment/Reply Bubble */}
          {(notification.commentText || (notification as any).replyText) && (
            <div className="mt-2 text-xs text-gray-800 dark:text-gray-200 bg-blue-50/70 dark:bg-blue-950/30 border-l-[3px] border-blue-500 dark:border-blue-400 p-2.5 rounded-r-xl shadow-2xs line-clamp-2">
              <span className="font-semibold text-blue-600 dark:text-blue-400 mr-1">“</span>
              <span className="italic">{notification.commentText || (notification as any).replyText}</span>
              <span className="font-semibold text-blue-600 dark:text-blue-400 ml-1">”</span>
            </div>
          )}

          {/* Report Reason */}
          {notification.reportReason && (
            <div className="mt-2 text-xs text-amber-900 dark:text-amber-200 bg-amber-50/90 dark:bg-amber-950/40 border-l-[3px] border-amber-500 px-3 py-2 rounded-r-xl">
              <span className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1 text-[11px]">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                {isHindi ? 'शिकायत का कारण (Report Reason):' : 'Report Reason:'}
              </span>
              <span className="italic mt-0.5 block">{notification.reportReason}</span>
            </div>
          )}

          {/* Follow Back Action Button */}
          {notification.type === 'new_follower' && (
            <div className="mt-2.5 flex items-center gap-2">
              {!isFollowing ? (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onFollowBack(notification.fromUserId, notification.fromUserName, notification.fromUserProfilePicUrl);
                  }}
                  className="px-4 py-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-600 text-white text-xs font-black rounded-xl border border-blue-500 animate-follow-back-blink shadow-md shadow-blue-500/30 hover:scale-105 active:scale-95 transition-all inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'फॉलो बैक करें' : 'Follow Back'}</span>
                </button>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 px-3 py-1 rounded-full">
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{isHindi ? 'फॉलो किया गया' : 'Following'}</span>
                </span>
              )}
            </div>
          )}

          {/* Timestamp */}
          <div className="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400 mt-2 font-medium">
            <Clock className="w-3 h-3 text-gray-400" />
            <span>{timeAgo(notification.createdAt)}</span>
          </div>
        </div>
        
        {/* Right Thumbnail Preview (if applicable) */}
        {thumbnail && (
          <div className="relative w-14 h-14 sm:w-16 sm:h-16 min-w-[56px] min-h-[56px] sm:min-w-[64px] sm:min-h-[64px] max-w-[56px] max-h-[56px] sm:max-w-[64px] sm:max-h-[64px] rounded-xl sm:rounded-2xl overflow-hidden shrink-0 border border-gray-200/90 dark:border-slate-700/80 bg-gray-100 dark:bg-slate-800 shadow-2xs group-hover:scale-105 group-hover:shadow-md transition-all self-center ml-1">
            <img 
              src={thumbnail} 
              alt="Post Thumbnail" 
              className="w-full h-full object-cover aspect-square"
              referrerPolicy="no-referrer"
              loading="lazy"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            {isVideo && (
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center pointer-events-none">
                <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-red-600/95 text-white flex items-center justify-center shadow-md">
                  <Play className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-white ml-0.5" />
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* Desktop Quick Actions */}
        <div className="hidden md:flex items-center gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
          <button 
            onClick={(e) => onToggleRead(e, notification)}
            className={`p-2 rounded-full transition-colors ${
              isUnread 
                ? 'text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800' 
                : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-slate-800'
            }`}
            title={isUnread ? (isHindi ? 'पढ़ा हुआ चिह्नित करें' : 'Mark as read') : (isHindi ? 'अनपढ़ा चिह्नित करें' : 'Mark as unread')}
          >
            {isUnread ? <Check className="w-4 h-4" /> : <CheckCheck className="w-4 h-4 text-blue-500" />}
          </button>
          
          <button 
            onClick={handleDeleteClick}
            className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 rounded-full transition-colors"
            title={isHindi ? 'हटाएं' : 'Delete'}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};


const NotificationsPage: React.FC<NotificationsPageProps> = ({ 
  onBack, 
  currentUser, 
  onViewPost, 
  onViewUser, 
  onViewVideo 
}) => {
  const cachedNotifs = currentUser ? appCacheService.getNotifications(currentUser.uid) : [];
  const [notifications, setNotifications] = useState<Notification[]>(() => cachedNotifs);
  const [loading, setLoading] = useState(() => cachedNotifs.length === 0);
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isMarkingAllRead, setIsMarkingAllRead] = useState(false);
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set());
  
  const { t, language } = useLanguage();
  const isHindi = language === 'hi';
  const { showToast } = useToast();

  useEffect(() => {
    if (!currentUser) return;

    const unsubscribeFollowing = db.collection('users')
      .doc(currentUser.uid)
      .collection('following')
      .onSnapshot(snapshot => {
        const ids = new Set(snapshot.docs.map(doc => doc.id));
        setFollowingIds(ids);
      }, err => {
        console.error("Error subscribing to following:", err);
      });

    return () => unsubscribeFollowing();
  }, [currentUser]);

  const handleFollowBack = async (targetUserId: string, targetUserName: string, targetUserPic: string) => {
    if (!currentUser) return;

    try {
      const batch = db.batch();
      const followRef = db.collection('users').doc(currentUser.uid).collection('following').doc(targetUserId);
      const followerRef = db.collection('users').doc(targetUserId).collection('followers').doc(currentUser.uid);
      
      const currentUserRef = db.collection('users').doc(currentUser.uid);
      const authorRef = db.collection('users').doc(targetUserId);

      batch.set(followRef, { createdAt: serverTimestamp() });
      batch.set(followerRef, { createdAt: serverTimestamp() });
      
      batch.update(currentUserRef, { followingCount: increment(1) });
      batch.update(authorRef, { followerCount: increment(1) });

      // Add notification for the other user
      const notificationRef = db.collection('users').doc(targetUserId).collection('notifications').doc();
      batch.set(notificationRef, {
        type: 'new_follower',
        fromUserId: currentUser.uid,
        fromUserName: currentUser.name,
        fromUserProfilePicUrl: currentUser.profilePicUrl || targetUserPic || '',
        fromUserIsVerified: currentUser.isVerified || false,
        createdAt: serverTimestamp(),
        read: false
      });

      await batch.commit();
      showToast(isHindi ? `अब आप ${targetUserName} को फॉलो कर रहे हैं` : `You are now following ${targetUserName}`, "success");
    } catch (error) {
      console.error("Error following back:", error);
      showToast(isHindi ? "फॉलो करने में विफल" : "Failed to follow back", "error");
    }
  };

  useEffect(() => {
    if (!currentUser) {
      setLoading(false);
      return;
    }

    const unsubscribe = db.collection('users')
      .doc(currentUser.uid)
      .collection('notifications')
      .orderBy('createdAt', 'desc')
      .limit(60)
      .onSnapshot(snapshot => {
        const fetchedNotifications = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate() || new Date(),
        } as Notification));
        setNotifications(fetchedNotifications);
        if (currentUser) {
          appCacheService.setNotifications(currentUser.uid, fetchedNotifications);
        }
        setLoading(false);
      }, error => {
        console.error("Error fetching notifications:", error);
        setLoading(false);
      });

    return () => unsubscribe();
  }, [currentUser]);

  const handleNotificationClick = async (notification: Notification) => {
    if (!currentUser) return;

    // Mark as read
    if (!notification.read) {
      try {
        await db.collection('users')
          .doc(currentUser.uid)
          .collection('notifications')
          .doc(notification.id)
          .update({ read: true });
      } catch (error) {
        console.error("Error marking notification as read:", error);
      }
    }

    // Navigate if applicable
    const targetVideoId = (notification as any).videoId || 
                          ((notification as any).postType === 'video' ? notification.postId : null) ||
                          (notification.postTitle?.toLowerCase().includes('video') ? notification.postId : null);

    if (targetVideoId && onViewVideo) {
      onViewVideo(targetVideoId);
    } else if (notification.postId) {
      onViewPost(notification.postId);
    } else if (notification.type === 'new_follower' && notification.fromUserId) {
      onViewUser(notification.fromUserId);
    }
  };

  const handleToggleRead = async (e: React.MouseEvent, notification: Notification) => {
    e.stopPropagation();
    if (!currentUser) return;
    try {
      await db.collection('users')
        .doc(currentUser.uid)
        .collection('notifications')
        .doc(notification.id)
        .update({ read: !notification.read });
    } catch (error) {
      console.error("Error toggling read status:", error);
    }
  };

  const handleDeleteOne = async (notificationId: string) => {
    if (!currentUser) return;

    try {
      await db.collection('users')
        .doc(currentUser.uid)
        .collection('notifications')
        .doc(notificationId)
        .delete();
      showToast(isHindi ? "सूचना हटा दी गई" : "Notification removed", "success");
    } catch (error) {
      console.error("Error deleting notification:", error);
      showToast(isHindi ? "हटाने में विफल" : "Failed to delete notification", "error");
    }
  };

  const handleMarkAllAsRead = async () => {
    if (!currentUser) return;
    const unreadNotifications = notifications.filter(n => !n.read);
    if (unreadNotifications.length === 0) return;

    setIsMarkingAllRead(true);
    try {
      const batch = db.batch();
      unreadNotifications.forEach(notif => {
        const ref = db.collection('users').doc(currentUser.uid).collection('notifications').doc(notif.id);
        batch.update(ref, { read: true });
      });

      await batch.commit();
      showToast(isHindi ? "सभी सूचनाएं पढ़ी हुई चिह्नित की गईं" : "All marked as read", "success");
    } catch (error) {
      console.error("Error marking all read:", error);
      showToast(isHindi ? "विफल हुआ" : "Failed to mark all as read", "error");
    } finally {
      setIsMarkingAllRead(false);
    }
  };

  const handleClearAll = async () => {
    if (!currentUser || notifications.length === 0) return;
    setIsDeleting(true);
    
    try {
      const batch = db.batch();
      notifications.forEach(notif => {
        const ref = db.collection('users').doc(currentUser.uid).collection('notifications').doc(notif.id);
        batch.delete(ref);
      });
      
      await batch.commit();
      showToast(isHindi ? "सभी सूचनाएं साफ कर दी गईं" : "All notifications cleared", "success");
    } catch (error) {
      console.error("Error clearing notifications:", error);
      showToast(isHindi ? "हटाने में विफल" : "Failed to clear notifications", "error");
    } finally {
      setIsDeleting(false);
      setIsClearModalOpen(false);
    }
  };

  const timeAgo = (date: Date) => {
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (seconds < 60) return isHindi ? 'अभी-अभी' : 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}${isHindi ? ' मि. पहले' : 'm ago'}`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}${isHindi ? ' घं. पहले' : 'h ago'}`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}${isHindi ? ' दिन पहले' : 'd ago'}`;
    return date.toLocaleDateString(isHindi ? 'hi-IN' : 'en-US', { day: 'numeric', month: 'short' });
  };

  // Filter and metrics calculation
  const counts = useMemo(() => {
    let unread = 0;
    let like = 0;
    let comment = 0;
    let follower = 0;
    let updates = 0;

    notifications.forEach(n => {
      if (!n.read) unread++;
      if (n.type === 'new_like') like++;
      else if (n.type === 'new_comment' || n.type === 'reply') comment++;
      else if (n.type === 'new_follower') follower++;
      else updates++;
    });

    return {
      all: notifications.length,
      unread,
      like,
      comment,
      follower,
      updates
    };
  }, [notifications]);

  const filteredNotifications = useMemo(() => {
    switch (activeFilter) {
      case 'like':
        return notifications.filter(n => n.type === 'new_like');
      case 'comment':
        return notifications.filter(n => n.type === 'new_comment' || n.type === 'reply');
      case 'follower':
        return notifications.filter(n => n.type === 'new_follower');
      case 'updates':
        return notifications.filter(n => 
          n.type !== 'new_like' && 
          n.type !== 'new_comment' && 
          n.type !== 'reply' && 
          n.type !== 'new_follower'
        );
      case 'all':
      default:
        return notifications;
    }
  }, [notifications, activeFilter]);

  const filterTabs: { id: FilterType; label: string; count: number; icon: React.ReactNode }[] = [
    { id: 'all', label: isHindi ? 'सभी' : 'All', count: counts.all, icon: <Bell className="w-3.5 h-3.5" /> },
    { id: 'like', label: isHindi ? 'लाइक्स' : 'Likes', count: counts.like, icon: <Heart className="w-3.5 h-3.5 fill-current" /> },
    { id: 'comment', label: isHindi ? 'कमेंट्स' : 'Comments', count: counts.comment, icon: <MessageSquare className="w-3.5 h-3.5 fill-current" /> },
    { id: 'follower', label: isHindi ? 'फॉलोअर्स' : 'Followers', count: counts.follower, icon: <UserPlus className="w-3.5 h-3.5" /> },
    { id: 'updates', label: isHindi ? 'अपडेट्स' : 'Updates', count: counts.updates, icon: <Sparkles className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-slate-50 via-white to-slate-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <Header title={t('notifications')} showBackButton onBack={onBack} />
      
      <main className="flex-grow overflow-y-auto px-3 sm:px-4 md:px-6 py-4 pb-24 scrollbar-hide">
        <div className="max-w-3xl mx-auto w-full space-y-4">
          
          {!currentUser ? (
            <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-8 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-gray-100 dark:border-slate-800 shadow-sm">
              <div className="w-20 h-20 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-4 shadow-inner">
                <Bell className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {isHindi ? 'कृपया लॉगिन करें' : 'Please Sign In'}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 max-w-sm mt-1.5">
                {isHindi 
                  ? 'अपनी पोस्ट्स पर लाइक्स, कमेंट्स और नए फॉलोअर्स की सूचनाएं देखने के लिए लॉगिन करें।' 
                  : 'Log in to view notifications when people like your posts, comment, or start following you.'}
              </p>
            </div>
          ) : loading && notifications.length === 0 ? (
            <div className="space-y-3">
              {[...Array(6)].map((_, i) => <SkeletonNotification key={i} />)}
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[55vh] text-center p-8 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-3xl border border-gray-100 dark:border-slate-800 shadow-sm">
              <div className="relative mb-5">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-rose-500/15 via-red-500/10 to-amber-500/15 flex items-center justify-center ring-8 ring-rose-50/50 dark:ring-rose-950/20">
                  <BellOff className="w-12 h-12 text-rose-500" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-md">
                  <Sparkles className="w-4 h-4 fill-white" />
                </div>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">
                {isHindi ? 'सब कुछ अपडेट है! 🎉' : 'All Caught Up! 🎉'}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md mt-2 leading-relaxed">
                {isHindi 
                  ? 'आपके पास अभी कोई नई सूचना नहीं है। जब भी कोई आपकी पोस्ट को पसंद करेगा, कमेंट करेगा या आपको फॉलो करेगा, तो यहां दिखाई देगा।'
                  : "You don't have any notifications right now. When someone likes your post, comments, or follows you, you'll see it here."}
              </p>
              
              <button 
                onClick={onBack}
                className="mt-6 px-5 py-2.5 rounded-full bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-sm shadow-md shadow-red-500/30 hover:shadow-lg hover:scale-105 active:scale-95 transition-all inline-flex items-center gap-2 cursor-pointer"
              >
                <Compass className="w-4 h-4" />
                <span>{isHindi ? 'ताज़ा खबरें देखें' : 'Explore News'}</span>
              </button>
            </div>
          ) : (
            <>
              {/* Premium Control Center Header Bar */}
              <div className="p-4 sm:p-5 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl rounded-3xl border border-gray-100 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
                
                {/* Left: Title & Counters */}
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-red-600 via-rose-600 to-amber-500 text-white flex items-center justify-center shadow-md shadow-red-500/25 flex-shrink-0">
                    <Bell className="w-5 h-5 fill-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-black text-gray-900 dark:text-white flex items-center gap-2">
                      <span>{isHindi ? 'सूचना केंद्र' : 'Notifications'}</span>
                      <span className="text-xs font-extrabold px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300">
                        {counts.all}
                      </span>
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mt-0.5">
                      {counts.unread > 0 ? (
                        <span className="inline-flex items-center gap-1 font-bold text-blue-600 dark:text-blue-400">
                          <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping"></span>
                          {counts.unread} {isHindi ? 'अनपढ़ी सूचनाएं' : 'unread updates'}
                        </span>
                      ) : (
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                          <CheckCheck className="w-3.5 h-3.5" />
                          {isHindi ? 'सभी पढ़ी जा चुकी हैं' : 'All caught up'}
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                {/* Right: Quick Action Controls */}
                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {counts.unread > 0 && (
                    <button 
                      onClick={handleMarkAllAsRead}
                      disabled={isMarkingAllRead}
                      className="px-3.5 py-1.5 rounded-full text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200/80 dark:border-blue-800/80 transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      title={isHindi ? 'सभी को पढ़ा हुआ चिह्नित करें' : 'Mark all as read'}
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      <span>{isMarkingAllRead ? (isHindi ? 'हो रहा है...' : 'Reading...') : (isHindi ? 'सभी पढ़ें' : 'Mark Read')}</span>
                    </button>
                  )}

                  <button 
                    onClick={() => setIsClearModalOpen(true)}
                    className="px-3.5 py-1.5 rounded-full text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200/80 dark:border-rose-800/80 transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
                    title={isHindi ? 'सभी सूचनाएं हटाएं' : 'Clear all notifications'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isHindi ? 'साफ करें' : 'Clear All'}</span>
                  </button>
                </div>
              </div>

              {/* Categorized Filter Tabs (Horizontal Pill Bar) */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide select-none pt-0.5">
                {filterTabs.map(tab => {
                  const isActive = activeFilter === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveFilter(tab.id)}
                      className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all duration-200 cursor-pointer ${
                        isActive
                          ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-md shadow-red-500/25 scale-[1.02]'
                          : 'bg-white/90 dark:bg-slate-900/90 text-gray-600 dark:text-gray-300 border border-gray-200/80 dark:border-slate-800 hover:bg-gray-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>{tab.icon}</span>
                      <span>{tab.label}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                        isActive 
                          ? 'bg-white/25 text-white' 
                          : 'bg-gray-150 dark:bg-slate-800 text-gray-600 dark:text-gray-400'
                      }`}>
                        {tab.count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Notification Items List */}
              {filteredNotifications.length === 0 ? (
                <div className="p-8 text-center bg-white/70 dark:bg-slate-900/70 backdrop-blur-md rounded-2xl border border-gray-100 dark:border-slate-800">
                  <p className="text-sm font-semibold text-gray-500 dark:text-gray-400">
                    {isHindi ? 'इस श्रेणी में कोई सूचना नहीं है।' : 'No notifications found in this category.'}
                  </p>
                  <button 
                    onClick={() => setActiveFilter('all')}
                    className="mt-3 text-xs font-bold text-red-600 hover:text-red-700 hover:underline cursor-pointer"
                  >
                    {isHindi ? 'सभी सूचनाएं देखें' : 'View all notifications'}
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredNotifications.map(notification => (
                    <SwipeableNotificationItem
                      key={notification.id}
                      notification={notification}
                      currentUser={currentUser}
                      isHindi={isHindi}
                      onClick={handleNotificationClick}
                      onDelete={handleDeleteOne}
                      onToggleRead={handleToggleRead}
                      timeAgo={timeAgo}
                      isFollowing={followingIds.has(notification.fromUserId)}
                      onFollowBack={handleFollowBack}
                      onViewUser={onViewUser}
                    />
                  ))}
                </div>
              )}
            </>
          )}

        </div>
      </main>

      {/* Clear Confirmation Modal */}
      <ConfirmationModal 
        isOpen={isClearModalOpen}
        onClose={() => setIsClearModalOpen(false)}
        onConfirm={handleClearAll}
        title={isHindi ? "सभी सूचनाएं हटाएं" : "Clear All Notifications"}
        message={isHindi 
          ? "क्या आप वाकई सभी सूचनाएं हटाना चाहते हैं? यह क्रिया वापस नहीं ली जा सकती।" 
          : "Are you sure you want to delete all notifications? This action cannot be undone."}
        confirmButtonText={isDeleting ? (isHindi ? "हटाया जा रहा है..." : "Clearing...") : (isHindi ? "हाँ, हटाएं" : "Clear All")}
        confirmButtonColor="bg-red-600 hover:bg-red-700"
      />
    </div>
  );
};

export default NotificationsPage;
