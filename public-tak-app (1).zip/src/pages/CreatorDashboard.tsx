
import * as React from 'react';
import { User, View, Post } from '../types';
import Header from '../components/Header';
import { db } from '../firebaseConfig';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { formatCount } from '../utils/formatters';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Chart as ChartJS, 
    ArcElement, 
    Tooltip, 
    Legend, 
    CategoryScale, 
    LinearScale, 
    BarElement, 
    PointElement, 
    LineElement,
    Title
} from 'chart.js';
import { Pie, Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(
    ArcElement, 
    Tooltip, 
    Legend, 
    CategoryScale, 
    LinearScale, 
    BarElement, 
    PointElement, 
    LineElement,
    Title
);

interface CreatorDashboardProps {
  onBack: () => void;
  currentUser: User | null;
  onNavigate: (view: View, params?: any) => void;
}

const StatCard: React.FC<{ title: string; value: string | number; icon: string; color: string; trend?: string }> = ({ title, value, icon, color, trend }) => (
    <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6 flex flex-col justify-between"
    >
        <div className="flex justify-between items-start">
            <div className={`p-3 rounded-2xl bg-gradient-to-br ${color} shadow-lg text-white`}>
                <span className="material-symbols-outlined text-2xl">{icon}</span>
            </div>
            {trend && (
                <div className="flex items-center gap-1 text-green-600 text-xs font-bold bg-green-50 px-2 py-1 rounded-full border border-green-100">
                    <span className="material-symbols-outlined text-xs">trending_up</span>
                    {trend}
                </div>
            )}
        </div>
        <div className="mt-4">
            <p className="text-gray-500 text-sm font-medium uppercase tracking-wider">{title}</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">{value}</h3>
        </div>
    </motion.div>
);

const CreatorDashboard: React.FC<CreatorDashboardProps> = ({ onBack, currentUser, onNavigate }) => {
    const [stats, setStats] = React.useState({
        totalViews: 0,
        totalLikes: 0,
        totalEarnings: 0,
        walletBalance: 0,
        postCount: 0,
        videoCount: 0,
        followerCount: 0,
        analytics: {
            gender: { Male: 0, Female: 0, Other: 0, Unknown: 0 } as Record<string, number>,
            age: { '13-17': 0, '18-24': 0, '25-34': 0, '35-44': 0, '45-54': 0, '55+': 0, Unknown: 0 } as Record<string, number>,
            audience: { Followers: 0, NonFollowers: 0, Guest: 0 } as Record<string, number>,
            location: {} as Record<string, number>
        }
    });
    const [recentPosts, setRecentPosts] = React.useState<any[]>([]);
    const [campaigns, setCampaigns] = React.useState<any[]>([]);
    const [loading, setLoading] = React.useState(true);
    const { t } = useLanguage();
    const { showToast } = useToast();

    React.useEffect(() => {
        if (!currentUser) return;

        const unsubscribeUser = db.collection('users').doc(currentUser.uid).onSnapshot(doc => {
            if (doc.exists) {
                const data = doc.data();
                setStats(prev => ({
                    ...prev,
                    walletBalance: data?.walletBalance || 0,
                    totalEarnings: data?.totalEarnings || 0,
                    // We'll prioritize the subcollection listener for 100% accuracy
                    analytics: data?.analytics || prev.analytics
                }));
            }
        });

        // Dedicated listener for "Real" Followers
        const unsubscribeFollowers = db.collection('users').doc(currentUser.uid).collection('followers').onSnapshot(snapshot => {
            setStats(prev => ({
                ...prev,
                followerCount: snapshot.size
            }));
        });

        // Listen for Push Notification Campaigns & Analytics
        const unsubscribeCampaigns = db.collection('notification_history')
            .where('publisherId', '==', currentUser.uid)
            .orderBy('createdAt', 'desc')
            .limit(20)
            .onSnapshot(snapshot => {
                const fetched = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                    createdAt: doc.data().createdAt?.toDate() || new Date()
                }));
                setCampaigns(fetched);
            }, error => {
                console.error("Error loading notification history:", error);
            });

        let postsData: any[] = [];
        let videosData: any[] = [];

        const updateStats = () => {
            let views = 0;
            let likes = 0;

            postsData.forEach(p => {
                views += (p.viewCount || 0);
                likes += (p.likeCount || 0);
            });
            videosData.forEach(v => {
                views += (v.viewCount || 0);
                likes += (v.likeCount || 0);
            });

            const combined = [
                ...postsData.map(p => ({ ...p, type: 'article' })),
                ...videosData.map(v => ({ ...v, type: 'video' }))
            ];
            combined.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0));

            setStats(prev => ({
                ...prev,
                totalViews: views,
                totalLikes: likes,
                postCount: postsData.length,
                videoCount: videosData.length
            }));
            setRecentPosts(combined.slice(0, 5));
            setLoading(false);
        };

        const unsubscribePosts = db.collection('posts').where('authorId', '==', currentUser.uid).onSnapshot(snapshot => {
            postsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            updateStats();
        }, error => {
            console.error("Error loading posts stats:", error);
        });

        const unsubscribeVideos = db.collection('videos').where('authorId', '==', currentUser.uid).onSnapshot(snapshot => {
            videosData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            updateStats();
        }, error => {
            console.error("Error loading videos stats:", error);
        });

        return () => {
            unsubscribeUser();
            unsubscribeFollowers();
            unsubscribeCampaigns();
            unsubscribePosts();
            unsubscribeVideos();
        };
    }, [currentUser]);

    const handleWithdraw = () => {
        onNavigate(View.Withdrawal);
    };

    if (!currentUser) return null;

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Creator Hub" showBackButton onBack={onBack} currentUser={currentUser} />
            
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-24">
                <div className="max-w-7xl mx-auto space-y-8">
                    
                    {/* Welcome Section */}
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                            <div>
                                <div className="flex items-center gap-2">
                                    <h2 className="text-3xl font-bold text-gray-900">Namaste, {currentUser.name}!</h2>
                                    <div className="flex items-center gap-1.5 px-2 py-0.5 bg-green-50 border border-green-100 rounded-full">
                                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                                        <span className="text-[10px] font-bold text-green-600 uppercase tracking-wider">Live Stats</span>
                                    </div>
                                </div>
                                <p className="text-gray-500 mt-1">Here's how your content is performing today.</p>
                            </div>
                        <div className="flex flex-wrap gap-3">
                            <button onClick={() => onNavigate(View.Referral)} className="px-4 py-2 bg-gradient-to-r from-red-600 to-orange-500 text-white font-bold rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-2 transform active:scale-95">
                                <span className="material-symbols-outlined mb-0.5">celebration</span>
                                Refer & Earn ₹5
                            </button>
                            <button onClick={() => onNavigate(View.Leaderboard)} className="px-5 py-2.5 bg-[#f8f9fa] border-2 border-gray-100 text-gray-800 font-black rounded-2xl shadow-sm hover:shadow-md hover:border-blue-100 transition-all flex items-center gap-2 transform active:scale-95">
                                <span className="material-symbols-outlined text-yellow-500 text-xl">military_tech</span>
                                View Leaderboard
                            </button>
                            <button onClick={() => onNavigate(View.CreatePost)} className="px-6 py-2 bg-red-600 text-white font-bold rounded-xl shadow-md hover:bg-red-700 transition-all flex items-center gap-2">
                                <span className="material-symbols-outlined">add</span>
                                New Post
                            </button>
                        </div>
                    </div>

                    {/* Earnings & Wallet Section */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <motion.div 
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="lg:col-span-2 bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl p-8 text-white relative overflow-hidden shadow-2xl"
                        >
                            {/* Decorative elements */}
                            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                            <div className="absolute bottom-0 left-0 w-64 h-64 bg-red-500/10 rounded-full blur-3xl -ml-32 -mb-32"></div>

                            <div className="relative z-10">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="text-gray-400 font-medium tracking-widest uppercase text-xs">Wallet Balance</p>
                                        <h1 className="text-5xl md:text-6xl font-black mt-2">₹{stats.walletBalance.toFixed(2)}</h1>
                                    </div>
                                    <div className="flex flex-col items-end">
                                        <span className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-bold border border-white/10">Creator ID: #{currentUser.uid.substring(0,6).toUpperCase()}</span>
                                        {currentUser.isVerified && (
                                            <div className="flex items-center gap-1 mt-3 text-blue-400 font-bold">
                                                <span className="material-symbols-outlined text-sm">verified</span>
                                                Verified Creator
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className="mt-12 flex flex-wrap gap-4">
                                    <button 
                                        onClick={handleWithdraw}
                                        className="px-10 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-black rounded-[1.25rem] hover:shadow-xl hover:shadow-emerald-500/20 transition-all transform active:scale-95 flex items-center gap-2"
                                    >
                                        <span className="material-symbols-outlined">payments</span>
                                        Withdraw Earnings
                                    </button>
                                    <button className="px-10 py-4 bg-white/10 hover:bg-white/20 text-white font-black rounded-[1.25rem] backdrop-blur-md transition-all border border-white/20 flex items-center gap-2 transform active:scale-95">
                                        <span className="material-symbols-outlined">receipt_long</span>
                                        History
                                    </button>
                                </div>

                                <div className="grid grid-cols-2 mt-12 pt-8 border-t border-white/10 gap-8">
                                    <div>
                                        <p className="text-gray-400 text-xs font-medium uppercase">Lifetime Earnings</p>
                                        <p className="text-xl font-bold mt-1">₹{stats.totalEarnings.toFixed(2)}</p>
                                    </div>
                                    <div>
                                        <p className="text-gray-400 text-xs font-medium uppercase">Revenue Share (10%)</p>
                                        <p className="text-xl font-bold mt-1">
                                            ₹{(stats.totalEarnings * 10).toFixed(1)} 
                                            <span className="text-[10px] text-gray-400 ml-1 block">Total Ad Rev Generated</span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </motion.div>

                        <div className="flex flex-col gap-6">
                             <StatCard title="Total Views" value={formatCount(stats.totalViews)} icon="visibility" color="from-blue-500 to-indigo-600" trend="+12% this week" />
                             <StatCard title="Followers" value={formatCount(stats.followerCount)} icon="person_add" color="from-pink-500 to-rose-600" trend="+3 today" />
                        </div>
                    </div>

                    {/* Detailed Stats Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <StatCard title="Applauses" value={formatCount(stats.totalLikes)} icon="thumb_up" color="from-orange-400 to-red-500" />
                        <StatCard title="Total Articles" value={stats.postCount} icon="article" color="from-emerald-400 to-teal-500" />
                        <StatCard title="Total Videos" value={stats.videoCount} icon="videocam" color="from-blue-400 to-indigo-500" />
                        <StatCard title="Creator Tier" value="Elite" icon="workspace_premium" color="from-indigo-400 to-purple-500" />
                    </div>

                    {/* Top Performing Content */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-6">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-blue-600">pie_chart</span>
                                Audience Analytics
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                <div className="glass-card p-6 border border-gray-100 bg-white">
                                    <h4 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">Audience Reach</h4>
                                    <div className="h-[250px] flex items-center justify-center">
                                        <Doughnut 
                                            data={{
                                                labels: Object.keys(stats.analytics.audience || {}),
                                                datasets: [{
                                                    data: Object.values(stats.analytics.audience || {}),
                                                    backgroundColor: ['#10b981', '#f59e0b', '#64748b'],
                                                    borderWidth: 0,
                                                    hoverOffset: 10
                                                }]
                                            }}
                                            options={{
                                                cutout: '70%',
                                                plugins: { 
                                                    legend: { position: 'bottom', labels: { usePointStyle: true, padding: 20, font: { weight: 'bold' } } },
                                                    tooltip: {
                                                        callbacks: {
                                                            label: (context) => {
                                                                const total = (context.dataset.data as number[]).reduce((a, b) => a + b, 0);
                                                                const value = context.parsed as number;
                                                                const percentage = ((value / total) * 100).toFixed(1);
                                                                return ` ${context.label}: ${formatCount(value)} (${percentage}%)`;
                                                            }
                                                        }
                                                    }
                                                }
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="glass-card p-6 border border-gray-100 bg-white">
                                    <h4 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">Gender Distribution</h4>
                                    <div className="h-[250px] flex items-center justify-center">
                                        <Doughnut 
                                            data={{
                                                labels: Object.keys(stats.analytics.gender),
                                                datasets: [{
                                                    data: Object.values(stats.analytics.gender),
                                                    backgroundColor: ['#3b82f6', '#ec4899', '#8b5cf6', '#94a3b8'],
                                                    borderWidth: 0,
                                                    hoverOffset: 10
                                                }]
                                            }}
                                            options={{
                                                cutout: '70%',
                                                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 20 } } }
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="glass-card p-6 border border-gray-100 bg-white">
                                    <h4 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">Age Groups</h4>
                                    <div className="h-[250px] flex items-center justify-center">
                                        <Bar 
                                            data={{
                                                labels: Object.keys(stats.analytics.age),
                                                datasets: [{
                                                    label: 'Viewers',
                                                    data: Object.values(stats.analytics.age),
                                                    backgroundColor: '#3b82f6',
                                                    borderRadius: 8,
                                                }]
                                            }}
                                            options={{
                                                responsive: true,
                                                plugins: { legend: { display: false } },
                                                scales: { y: { beginAtZero: true, grid: { display: false } }, x: { grid: { display: false } } }
                                            }}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-6">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600">map</span>
                                Top Locations
                            </h3>
                            <div className="glass-card p-6 border border-gray-100 bg-white">
                                <div className="space-y-4">
                                    {Object.entries(stats.analytics.location || {})
                                        .sort(([, a], [, b]) => b - a)
                                        .slice(0, 5)
                                        .map(([loc, count], i) => (
                                            <div key={loc} className="space-y-1">
                                                <div className="flex justify-between text-sm font-bold">
                                                    <span className="text-gray-700">{loc}</span>
                                                    <span className="text-blue-600">{formatCount(count)}</span>
                                                </div>
                                                <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                                                    <motion.div 
                                                        initial={{ width: 0 }}
                                                        animate={{ width: `${Math.min((count / (stats.totalViews || 1)) * 100, 100)}%` }}
                                                        className={`h-full ${i === 0 ? 'bg-blue-600' : 'bg-blue-400'}`}
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    {Object.keys(stats.analytics.location || {}).length === 0 && (
                                        <p className="text-center py-10 text-gray-400 text-sm">No location data available yet.</p>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Push Notification Campaigns & Analytics */}
                    <div className="space-y-6">
                        <div className="flex items-center justify-between">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-blue-600">campaign</span>
                                Push Notification Campaigns & Analytics
                            </h3>
                            <div className="text-xs text-gray-500 font-medium">
                                Sent to active & opted-in followers
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {campaigns.map((camp) => {
                                const stats = camp.stats || { delivered: 0, opened: 0, clicked: 0, failed: 0, dismissed: 0 };
                                const recipients = camp.recipientCount || 0;
                                const ctr = recipients > 0 ? ((stats.opened / recipients) * 100).toFixed(1) : "0.0";
                                const deliveryRate = recipients > 0 ? ((stats.delivered / recipients) * 100).toFixed(1) : "0.0";
                                
                                return (
                                    <div key={camp.id} className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm flex flex-col justify-between hover:border-blue-100 transition-all">
                                        <div>
                                            <div className="flex justify-between items-start gap-4">
                                                <div className="flex-grow">
                                                    <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${camp.type === 'video' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-blue-50 text-blue-600 border border-blue-100'}`}>
                                                        {camp.type} notification
                                                    </span>
                                                    <h4 className="text-base font-bold text-gray-800 mt-2 line-clamp-1">{camp.title}</h4>
                                                    <p className="text-xs text-gray-500 mt-1 line-clamp-2">{camp.body}</p>
                                                </div>
                                                {camp.thumbnailUrl && (
                                                    <img 
                                                        src={camp.thumbnailUrl} 
                                                        alt="Thumbnail" 
                                                        className="w-16 h-16 rounded-xl object-cover border border-gray-100 flex-shrink-0"
                                                        referrerPolicy="no-referrer"
                                                    />
                                                )}
                                            </div>

                                            {/* Key Metrics Grid */}
                                            <div className="grid grid-cols-3 gap-2 mt-4 bg-gray-50/50 p-3 rounded-2xl border border-gray-100/50">
                                                <div className="text-center">
                                                    <p className="text-[10px] font-bold text-gray-400 uppercase">Recipients</p>
                                                    <p className="text-sm font-black text-gray-700 mt-0.5">{recipients}</p>
                                                </div>
                                                <div className="text-center">
                                                    <p className="text-[10px] font-bold text-gray-400 uppercase">Delivered</p>
                                                    <p className="text-sm font-black text-green-600 mt-0.5">{stats.delivered || 0}</p>
                                                </div>
                                                <div className="text-center">
                                                    <p className="text-[10px] font-bold text-gray-400 uppercase">CTR (Clicks)</p>
                                                    <p className="text-sm font-black text-blue-600 mt-0.5">{ctr}% <span className="text-[10px] font-normal text-gray-400">({stats.opened || 0})</span></p>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Delivery Progress Bar */}
                                        <div className="mt-4 space-y-1.5">
                                            <div className="flex justify-between text-xs font-bold text-gray-500">
                                                <span>Delivery Success</span>
                                                <span className="text-green-600">{deliveryRate}%</span>
                                            </div>
                                            <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                                                <div 
                                                    style={{ width: `${deliveryRate}%` }} 
                                                    className="bg-green-500 h-full rounded-full transition-all duration-500"
                                                />
                                            </div>
                                            <div className="flex justify-between items-center text-[10px] text-gray-400 mt-1 pt-1 border-t border-gray-50">
                                                <span className="flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[12px]">schedule</span>
                                                    {camp.createdAt.toLocaleDateString()} at {camp.createdAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                </span>
                                                <span className="flex items-center gap-1 text-red-500">
                                                    Failed: {stats.failed || 0} | Dismissed: {stats.dismissed || 0}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}

                            {campaigns.length === 0 && (
                                <div className="md:col-span-2 bg-white rounded-3xl border border-gray-100 p-12 text-center shadow-sm">
                                    <div className="p-4 bg-blue-50 text-blue-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                                        <span className="material-symbols-outlined text-3xl">notifications_active</span>
                                    </div>
                                    <h4 className="font-bold text-gray-800 text-lg">No Push Campaigns Yet</h4>
                                    <p className="text-gray-500 text-sm mt-1 max-w-md mx-auto">When you publish a news article or video as a verified publisher, your followers receive interactive premium push alerts, and real-time delivery performance shows here.</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Top Performing Content */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-6">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600">trending_up</span>
                                Top Performing Content
                            </h3>
                            <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="bg-gray-50 border-b border-gray-100">
                                            <tr>
                                                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Title</th>
                                                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Views</th>
                                                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Earnings</th>
                                                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-100">
                                            {recentPosts.map((post) => (
                                                <tr 
                                                    key={post.id} 
                                                    className="hover:bg-gray-50 transition-colors cursor-pointer" 
                                                    onClick={() => {
                                                        if (post.type === 'article') {
                                                            onNavigate(View.PostDetail, { id: post.id });
                                                        } else {
                                                            onNavigate(View.VideoHome, { selectedVideoId: post.id });
                                                        }
                                                    }}
                                                >
                                                    <td className="px-6 py-4">
                                                        <p className="text-sm font-bold text-gray-800 line-clamp-1">{post.title}</p>
                                                        <p className="text-[10px] text-gray-400 font-medium uppercase">
                                                            <span className={`inline-block mr-2 px-1.5 py-0.5 rounded text-[8px] font-black ${post.type === 'article' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'}`}>
                                                                {post.type.toUpperCase()}
                                                            </span>
                                                            {post.category}
                                                        </p>
                                                    </td>
                                                    <td className="px-6 py-4 text-sm font-medium text-gray-600">{formatCount(post.viewCount)}</td>
                                                    <td className="px-6 py-4 text-sm font-bold text-green-600">₹{((post.viewCount || 0) * 0.01).toFixed(2)}</td>
                                                    <td className="px-6 py-4">
                                                        <span className="px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded-full uppercase">Monetized</span>
                                                    </td>
                                                </tr>
                                            ))}
                                            {recentPosts.length === 0 && (
                                                <tr>
                                                    <td colSpan={4} className="px-6 py-12 text-center text-gray-400">No data available yet. Start posting to see stats!</td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        {/* Support Center & Other Tools */}
                        <div className="space-y-6">
                            <div className="glass-card p-6 border-dashed border-2 border-gray-200 bg-white">
                                <h4 className="font-bold text-gray-800">Support Center</h4>
                                <p className="text-gray-500 text-sm mt-1">Need help with earnings or moderation? Our creator support is here.</p>
                                <a 
                                    href="mailto:support@publictakapp.com?subject=Creator Support Request"
                                    className="mt-4 w-full py-2.5 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition-all flex items-center justify-center gap-2"
                                >
                                    <span className="material-symbols-outlined text-sm">mail</span>
                                    Contact Support
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    );
};

export default CreatorDashboard;
