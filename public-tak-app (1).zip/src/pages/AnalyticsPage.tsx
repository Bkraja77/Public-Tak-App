
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { User, Post, View, Video } from '../types';
import { db } from '../firebaseConfig';
import { formatCount } from '../utils/formatters';
import { motion, AnimatePresence } from 'framer-motion';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface AnalyticsPageProps {
    onBack: () => void;
    currentUser: User;
    onViewPost: (postId: string) => void;
    onNavigate?: (view: View, params?: any) => void;
}

const StatCard: React.FC<{ title: string; value: string | number; icon: string; color: string }> = ({ title, value, icon, color }) => (
    <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6 flex flex-col justify-between"
    >
        <div className="flex justify-between items-start">
            <div className={`p-3 rounded-2xl bg-gradient-to-br ${color} shadow-lg text-white`}>
                <span className="material-symbols-outlined text-2xl">{icon}</span>
            </div>
        </div>
        <div className="mt-4">
            <p className="text-gray-500 text-sm font-medium uppercase tracking-wider">{title}</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">{value}</h3>
        </div>
    </motion.div>
);

const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ onBack, currentUser, onViewPost, onNavigate }) => {
    const [contentType, setContentType] = useState<'articles' | 'videos'>('articles');
    const [scope, setScope] = useState<'my' | 'platform'>('my');
    const [posts, setPosts] = useState<any[]>([]); // Generic array for posts/videos
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        totalViews: 0,
        totalLikes: 0,
        postCount: 0,
        followerCount: 0,
        analytics: {
            gender: { Male: 0, Female: 0, Other: 0, Unknown: 0 } as Record<string, number>,
            age: { '13-17': 0, '18-24': 0, '25-34': 0, '35-44': 0, '45-54': 0, '55+': 0, Unknown: 0 } as Record<string, number>,
            audience: { Followers: 0, NonFollowers: 0, Guest: 0 } as Record<string, number>,
            location: {} as Record<string, number>
        }
    });

    useEffect(() => {
        if (!currentUser) return;
        setLoading(true);

        let unsubscribeUser: () => void = () => {};
        let unsubscribeContent: () => void = () => {};
        let unsubscribePlatformUsers: () => void = () => {};

        // 1. Listen to user document for followerCount & user-specific demographics
        unsubscribeUser = db.collection('users').doc(currentUser.uid).onSnapshot(doc => {
            if (doc.exists) {
                const data = doc.data();
                if (scope === 'my') {
                    setStats(prev => ({
                        ...prev,
                        analytics: data?.analytics || prev.analytics,
                        followerCount: data?.followerCount || 0
                    }));
                }
            }
        });

        // 2. Fetch total platform users/demographics if scope is platform
        if (scope === 'platform') {
            unsubscribePlatformUsers = db.collection('users').onSnapshot(snapshot => {
                const totalUsers = snapshot.size;
                const gender = { Male: 0, Female: 0, Other: 0, Unknown: 0 } as Record<string, number>;
                const age = { '13-17': 0, '18-24': 0, '25-34': 0, '35-44': 0, '45-54': 0, '55+': 0, Unknown: 0 } as Record<string, number>;
                const audience = { Followers: 0, NonFollowers: 0, Guest: 0 } as Record<string, number>;
                const location: Record<string, number> = {};

                snapshot.docs.forEach(doc => {
                    const data = doc.data();
                    const userAnalytics = data?.analytics;
                    
                    // Aggregate gender
                    if (userAnalytics?.gender) {
                        Object.entries(userAnalytics.gender).forEach(([k, v]) => {
                            gender[k] = (gender[k] || 0) + (v as number);
                        });
                    } else {
                        gender['Unknown'] = (gender['Unknown'] || 0) + 1;
                    }

                    // Aggregate age
                    if (userAnalytics?.age) {
                        Object.entries(userAnalytics.age).forEach(([k, v]) => {
                            age[k] = (age[k] || 0) + (v as number);
                        });
                    } else {
                        age['Unknown'] = (age['Unknown'] || 0) + 1;
                    }

                    // Aggregate audience
                    if (userAnalytics?.audience) {
                        Object.entries(userAnalytics.audience).forEach(([k, v]) => {
                            audience[k] = (audience[k] || 0) + (v as number);
                        });
                    } else {
                        audience['Guest'] = (audience['Guest'] || 0) + 1;
                    }

                    // Aggregate locations
                    const loc = data?.preferredDistrict || data?.preferredState || 'Unknown';
                    if (loc) {
                        location[loc] = (location[loc] || 0) + 1;
                    }
                });

                // Ensure non-zero fallback for empty system
                if (snapshot.size === 0) {
                    gender['Unknown'] = 1;
                    age['Unknown'] = 1;
                    audience['Guest'] = 1;
                }

                setStats(prev => ({
                    ...prev,
                    followerCount: totalUsers, // For platform, followerCount acts as "Total Users"
                    analytics: { gender, age, audience, location }
                }));
            });
        }

        // 3. Listen to posts or videos based on selected contentType and scope
        const collectionName = contentType === 'articles' ? 'posts' : 'videos';
        let query: any = db.collection(collectionName);

        if (scope === 'my') {
            query = query.where('authorId', '==', currentUser.uid);
        }

        unsubscribeContent = query.onSnapshot((snapshot: any) => {
            let views = 0;
            let likes = 0;
            const fetchedItems: any[] = snapshot.docs.map((doc: any) => {
                const data = doc.data();
                views += (data.viewCount || 0);
                likes += (data.likeCount || 0);
                return { id: doc.id, ...data };
            });

            // Sort by views desc for Top Content
            fetchedItems.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0));

            setStats(prev => ({
                ...prev,
                totalViews: views,
                totalLikes: likes,
                postCount: snapshot.size // This represents content count (total articles or total videos)
            }));
            
            // Re-using the posts array state for generic items
            setPosts(fetchedItems);
            setLoading(false);
        }, (error: any) => {
            console.error(`Error loading ${collectionName} analytics:`, error);
            setLoading(false);
        });

        return () => {
            unsubscribeUser();
            unsubscribePlatformUsers();
            unsubscribeContent();
        };
    }, [currentUser?.uid, contentType, scope]);

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Analytics" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-32">
                <div className="max-w-7xl mx-auto space-y-8">
                    
                    {/* Welcome */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                            <h2 className="text-3xl font-bold text-gray-900">Content Performance</h2>
                            <p className="text-gray-500 mt-1">Real-time insights across your digital network.</p>
                        </div>
                        
                        {/* Scope & Type selectors */}
                        <div className="flex flex-wrap gap-3">
                            <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
                                <button
                                    onClick={() => setContentType('articles')}
                                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                        contentType === 'articles'
                                            ? 'bg-white text-gray-900 shadow-sm'
                                            : 'text-gray-500 hover:text-gray-900'
                                    }`}
                                >
                                    <span className="material-symbols-outlined text-sm">article</span>
                                    Articles
                                </button>
                                <button
                                    onClick={() => setContentType('videos')}
                                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                        contentType === 'videos'
                                            ? 'bg-white text-gray-900 shadow-sm'
                                            : 'text-gray-500 hover:text-gray-900'
                                    }`}
                                >
                                    <span className="material-symbols-outlined text-sm">videocam</span>
                                    Videos
                                </button>
                            </div>

                            {currentUser.role === 'admin' && (
                                <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
                                    <button
                                        onClick={() => setScope('my')}
                                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                            scope === 'my'
                                                ? 'bg-white text-gray-900 shadow-sm'
                                                : 'text-gray-500 hover:text-gray-900'
                                        }`}
                                    >
                                        <span className="material-symbols-outlined text-sm">person</span>
                                        My stats
                                    </button>
                                    <button
                                        onClick={() => setScope('platform')}
                                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                            scope === 'platform'
                                                ? 'bg-white text-gray-900 shadow-sm'
                                                : 'text-gray-500 hover:text-gray-900'
                                        }`}
                                    >
                                        <span className="material-symbols-outlined text-sm">public</span>
                                        Platform stats
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* High Level Stats */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <StatCard title="Total Views" value={formatCount(stats.totalViews)} icon="visibility" color="from-blue-500 to-indigo-600" />
                        <StatCard title={contentType === 'articles' ? 'Applauses' : 'Video Likes'} value={formatCount(stats.totalLikes)} icon={contentType === 'articles' ? 'thumb_up' : 'favorite'} color="from-orange-400 to-red-500" />
                        <StatCard title={scope === 'platform' ? 'Total Users' : 'Followers'} value={formatCount(stats.followerCount)} icon="group" color="from-pink-500 to-rose-600" />
                        <StatCard title={contentType === 'articles' ? 'Total Articles' : 'Total Videos'} value={stats.postCount} icon={contentType === 'articles' ? 'article' : 'videocam'} color="from-emerald-400 to-teal-500" />
                    </div>

                    {/* Charts Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 space-y-6">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-blue-600">pie_chart</span>
                                Audience Reach
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="glass-card p-6 bg-white">
                                    <h4 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">Gender Distribution</h4>
                                    <div className="h-[250px] flex items-center justify-center">
                                        <Doughnut 
                                            data={{
                                                labels: Object.keys(stats.analytics.gender),
                                                datasets: [{
                                                    data: Object.values(stats.analytics.gender),
                                                    backgroundColor: ['#3b82f6', '#ec4899', '#8b5cf6', '#94a3b8'],
                                                    borderWidth: 0
                                                }]
                                            }}
                                            options={{ cutout: '70%', plugins: { legend: { position: 'bottom' } } }}
                                        />
                                    </div>
                                </div>
                                <div className="glass-card p-6 bg-white">
                                    <h4 className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">Age Groups</h4>
                                    <div className="h-[250px] flex items-center justify-center">
                                        <Bar 
                                            data={{
                                                labels: Object.keys(stats.analytics.age),
                                                datasets: [{
                                                    label: 'Viewers',
                                                    data: Object.values(stats.analytics.age),
                                                    backgroundColor: '#3b82f6',
                                                    borderRadius: 8,
                                                }]
                                            }}
                                            options={{
                                                responsive: true,
                                                plugins: { legend: { display: false } },
                                                scales: { y: { beginAtZero: true, grid: { display: false } }, x: { grid: { display: false } } }
                                            }}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-6">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600">map</span>
                                Top Locations
                            </h3>
                            <div className="glass-card p-6 bg-white">
                                <div className="space-y-4">
                                    {Object.entries(stats.analytics.location || {})
                                        .sort(([, a], [, b]) => b - a)
                                        .slice(0, 5)
                                        .map(([loc, count], i) => (
                                            <div key={loc} className="space-y-1">
                                                <div className="flex justify-between text-sm font-bold">
                                                    <span className="text-gray-700">{loc}</span>
                                                    <span className="text-blue-600">{formatCount(count)}</span>
                                                </div>
                                                <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                                                    <motion.div 
                                                        initial={{ width: 0 }}
                                                        animate={{ width: `${Math.min((count / (stats.totalViews || 1)) * 100, 100)}%` }}
                                                        className={`h-full ${i === 0 ? 'bg-blue-600' : 'bg-blue-400'}`}
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    {Object.keys(stats.analytics.location || {}).length === 0 && (
                                        <p className="text-center py-10 text-gray-400 text-sm">No location data available yet.</p>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Top Content Table */}
                    <div className="space-y-6">
                        <div className="flex justify-between items-center">
                            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600">trending_up</span>
                                {contentType === 'articles' ? 'Top Articles' : 'Top Videos'}
                            </h3>
                            <button 
                                onClick={() => onNavigate?.(View.User, { initialTab: contentType === 'articles' ? 'posts' : 'videos' })}
                                className="text-sm font-bold text-blue-600 hover:underline"
                            >
                                {contentType === 'articles' ? 'View All Posts' : 'View All Videos'}
                            </button>
                        </div>
                        <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left">
                                    <thead className="bg-gray-50 border-b border-gray-100">
                                        <tr>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">{contentType === 'articles' ? 'Article Title' : 'Video Title'}</th>
                                            <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Views</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {loading ? (
                                            <tr>
                                                <td colSpan={2} className="px-6 py-12 text-center text-gray-400 italic animate-pulse">Syncing real-time data...</td>
                                            </tr>
                                        ) : posts.slice(0, 10).map((post) => (
                                            <tr 
                                                key={post.id} 
                                                className="hover:bg-gray-50 transition-colors cursor-pointer group" 
                                                onClick={() => {
                                                    if (contentType === 'articles') {
                                                        onViewPost(post.id);
                                                    } else {
                                                        // Navigate to Video page and play this video
                                                        onNavigate?.(View.VideoHome, { selectedVideoId: post.id });
                                                    }
                                                }}
                                            >
                                                <td className="px-6 py-4">
                                                    <p className="text-sm font-bold text-gray-800 line-clamp-1 group-hover:text-blue-600">{post.title}</p>
                                                    <p className="text-[10px] text-gray-400 font-medium uppercase">{post.category}</p>
                                                </td>
                                                <td className="px-6 py-4 text-right">
                                                    <span className="text-sm font-black text-gray-900">{formatCount(post.viewCount)}</span>
                                                </td>
                                            </tr>
                                        ))}
                                        {!loading && posts.length === 0 && (
                                            <tr>
                                                <td colSpan={2} className="px-6 py-12 text-center text-gray-400">No content data available.</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    );
};

export default AnalyticsPage;
