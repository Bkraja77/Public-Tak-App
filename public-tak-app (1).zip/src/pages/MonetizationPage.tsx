
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { User, MonetizationRequest } from '../types';
import { db, serverTimestamp } from '../firebaseConfig';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';

interface MonetizationPageProps {
    onBack: () => void;
    currentUser: User;
}

const MonetizationPage: React.FC<MonetizationPageProps> = ({ onBack, currentUser }) => {
    const { showToast } = useToast();
    const [isLoading, setIsLoading] = useState(false);
    const [request, setRequest] = useState<MonetizationRequest | null>(null);
    const [fetchingRequest, setFetchingRequest] = useState(true);
    
    // Form fields
    const [channelPhilosophy, setChannelPhilosophy] = useState('');
    const [socialLinks, setSocialLinks] = useState('');
    const [isAcceptedTerms, setIsAcceptedTerms] = useState(false);

    // Requirements
    const MIN_FOLLOWERS = 5000;
    const MIN_VIEWS = 100000;

    const followerCount = currentUser.followerCount || 0;
    const totalViews = currentUser.totalViews || 0;
    const hasMetRequirements = followerCount >= MIN_FOLLOWERS && totalViews >= MIN_VIEWS;

    useEffect(() => {
        const fetchRequest = async () => {
            try {
                const snapshot = await db.collection('monetizationRequests')
                    .where('userId', '==', currentUser.uid)
                    .get();
                
                if (!snapshot.empty) {
                    const allReqs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MonetizationRequest));
                    // Client-side sort: newest first
                    allReqs.sort((a, b) => {
                        const timeA = a.requestedAt?.toMillis ? a.requestedAt.toMillis() : 0;
                        const timeB = b.requestedAt?.toMillis ? b.requestedAt.toMillis() : 0;
                        return timeB - timeA;
                    });
                    setRequest(allReqs[0]);
                }
            } catch (error) {
                console.error("Error fetching monetization request:", error);
            } finally {
                setFetchingRequest(false);
            }
        };

        fetchRequest();
    }, [currentUser.uid]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!isAcceptedTerms) {
            showToast("Please accept the terms and conditions", "error");
            return;
        }

        setIsLoading(true);
        try {
            const linksArray = socialLinks.split(',').map(link => link.trim()).filter(link => link !== '');
            
            const newRequest = {
                userId: currentUser.uid,
                userName: currentUser.name,
                userEmail: currentUser.email || '',
                followerCount: followerCount,
                totalViews: totalViews,
                channelPhilosophy,
                socialLinks: linksArray,
                status: 'pending' as const,
                requestedAt: serverTimestamp(),
            };

            await db.collection('monetizationRequests').add(newRequest);
            await db.collection('users').doc(currentUser.uid).update({
                monetizationStatus: 'pending'
            });

            showToast("Request sent successfully!", "success");
            onBack();
        } catch (error) {
            console.error("Error submitting monetization request:", error);
            showToast("Failed to submit request", "error");
        } finally {
            setIsLoading(false);
        }
    };

    if (fetchingRequest) {
        return (
            <div className="flex flex-col h-full bg-transparent">
                <Header title="Monetization" showBackButton onBack={onBack} />
                <div className="flex-grow flex items-center justify-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header title="Monetization" showBackButton onBack={onBack} />
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-24">
                <div className="max-w-3xl mx-auto space-y-6">
                    {/* Status Header */}
                    <div className="glass-card p-6 md:p-8 text-center text-white bg-gradient-to-br from-slate-900 to-slate-800 border-none">
                        <motion.div 
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="bg-white/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
                        >
                            <span className="material-symbols-outlined text-4xl text-red-500">monetization_on</span>
                        </motion.div>
                        <h2 className="text-3xl font-black mb-2 tracking-tight">Creator Monetization</h2>
                        <p className="text-gray-400 max-w-md mx-auto">Turn your passion into profit. Reach the milestones and start earning today.</p>
                    </div>

                    {request ? (
                        <div className="glass-card p-8 border-t-4 border-red-600">
                            <div className="flex items-center gap-4 mb-6">
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                                    request.status === 'approved' ? 'bg-green-100 text-green-600' : 
                                    request.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
                                }`}>
                                    <span className="material-symbols-outlined">
                                        {request.status === 'approved' ? 'check_circle' : 
                                         request.status === 'rejected' ? 'cancel' : 'hourglass_top'}
                                    </span>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500 font-bold uppercase tracking-wider">Current Status</p>
                                    <h3 className="text-2xl font-black capitalize">{request.status}</h3>
                                </div>
                            </div>
                            
                            <div className="p-4 bg-gray-50 rounded-xl space-y-2 border border-gray-100">
                                <p className="text-gray-700">
                                    {request.status === 'pending' && "Your application is currently being reviewed by our admin team. This usually takes 3-5 business days."}
                                    {request.status === 'approved' && "Congratulations! Your account is now monetized. You can now access the Creator Hub from your profile."}
                                    {request.status === 'rejected' && `Your application was not approved at this time. Admin Remarks: ${request.adminRemarks || "No remarks provided."}`}
                                </p>
                            </div>
                            
                            {request.status === 'rejected' && (
                                <button 
                                    onClick={() => setRequest(null)}
                                    className="mt-6 w-full py-4 bg-slate-900 text-white font-bold rounded-xl active:scale-95 transition-all"
                                >
                                    Re-apply for Monetization
                                </button>
                            )}
                        </div>
                    ) : (
                        <>
                            {/* Requirements Checklist */}
                            <div className="glass-card p-6 md:p-8">
                                <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                                    <span className="material-symbols-outlined text-red-600">military_tech</span>
                                    Eligibility Requirements
                                </h3>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className={`p-4 rounded-2xl border-2 transition-all ${followerCount >= MIN_FOLLOWERS ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-100'}`}>
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-sm font-bold text-gray-500 uppercase">Followers</span>
                                            {followerCount >= MIN_FOLLOWERS && <span className="material-symbols-outlined text-green-600">check_circle</span>}
                                        </div>
                                        <div className="flex items-baseline gap-1">
                                            <span className="text-2xl font-black">{followerCount.toLocaleString()}</span>
                                            <span className="text-gray-400 text-sm">/ {MIN_FOLLOWERS.toLocaleString()}</span>
                                        </div>
                                        <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                                            <div 
                                                className={`h-full transition-all duration-1000 ${followerCount >= MIN_FOLLOWERS ? 'bg-green-500' : 'bg-red-500'}`}
                                                style={{ width: `${Math.min(100, (followerCount / MIN_FOLLOWERS) * 100)}%` }}
                                            ></div>
                                        </div>
                                    </div>

                                    <div className={`p-4 rounded-2xl border-2 transition-all ${totalViews >= MIN_VIEWS ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-100'}`}>
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-sm font-bold text-gray-500 uppercase">Total Views</span>
                                            {totalViews >= MIN_VIEWS && <span className="material-symbols-outlined text-green-600">check_circle</span>}
                                        </div>
                                        <div className="flex items-baseline gap-1">
                                            <span className="text-2xl font-black">{totalViews.toLocaleString()}</span>
                                            <span className="text-gray-400 text-sm">/ {MIN_VIEWS.toLocaleString()}</span>
                                        </div>
                                        <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                                            <div 
                                                className={`h-full transition-all duration-1000 ${totalViews >= MIN_VIEWS ? 'bg-green-500' : 'bg-red-500'}`}
                                                style={{ width: `${Math.min(100, (totalViews / MIN_VIEWS) * 100)}%` }}
                                            ></div>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-xl flex gap-3">
                                    <span className="material-symbols-outlined text-blue-600">info</span>
                                    <p className="text-sm text-blue-800 leading-relaxed">
                                        Once you meet both requirements, you can submit your application for standard review. We verify for <strong>original content</strong> and community guideline adherence.
                                    </p>
                                </div>
                            </div>

                            {/* Application Form */}
                            <AnimatePresence>
                                {hasMetRequirements && (
                                    <motion.form 
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        onSubmit={handleSubmit} 
                                        className="glass-card p-6 md:p-8 space-y-6"
                                    >
                                        <h3 className="text-xl font-bold border-b pb-4">Submit Application</h3>
                                        
                                        <div className="space-y-4">
                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Channel Philosophy & Content Type</label>
                                                <textarea 
                                                    value={channelPhilosophy}
                                                    onChange={(e) => setChannelPhilosophy(e.target.value)}
                                                    placeholder="Describe what kind of news/content you post and your commitment to original reporting..."
                                                    className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 outline-none h-32"
                                                    required
                                                ></textarea>
                                            </div>

                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Social Media Links (Optional)</label>
                                                <input 
                                                    type="text"
                                                    value={socialLinks}
                                                    onChange={(e) => setSocialLinks(e.target.value)}
                                                    placeholder="Facebook URL, Twitter handle, etc. (comma separated)"
                                                    className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 outline-none"
                                                />
                                            </div>

                                            <div className="flex items-start gap-3 pt-2">
                                                <input 
                                                    type="checkbox" 
                                                    id="terms" 
                                                    checked={isAcceptedTerms}
                                                    onChange={(e) => setIsAcceptedTerms(e.target.checked)}
                                                    className="mt-1 w-5 h-5 rounded border-gray-300 text-red-600 focus:ring-red-500"
                                                />
                                                <label htmlFor="terms" className="text-sm text-gray-600 cursor-pointer select-none">
                                                    I certify that all my content is <strong>original</strong> and I have full rights to publish the news articles on Public Tak App. I understand that any plagiarism will lead to immediate account termination.
                                                </label>
                                            </div>
                                        </div>

                                        <button 
                                            type="submit"
                                            disabled={isLoading}
                                            className="w-full py-4 bg-gradient-to-r from-red-600 to-orange-500 text-white font-black rounded-xl shadow-lg hover:shadow-xl transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                                        >
                                            {isLoading ? (
                                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                                            ) : (
                                                <span className="material-symbols-outlined font-bold">send</span>
                                            )}
                                            SUBMIT REQUEST
                                        </button>
                                    </motion.form>
                                )}
                            </AnimatePresence>
                        </>
                    )}
                </div>
            </main>
        </div>
    );
};

export default MonetizationPage;
