import React, { useState, useEffect, useMemo } from 'react';
import Header from '../components/Header';
import { db, serverTimestamp } from '../firebaseConfig';
import { User } from '../types';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from '../components/ConfirmationModal';

interface ManageUsersPageProps {
    onBack: () => void;
    currentUser: User | null;
    onEditUser: (userId: string) => void;
}

const BAN_REASON_OPTIONS = [
    { id: 'guidelines', label: 'नियम व शर्तों का उल्लंघन (Community Guidelines Violation)' },
    { id: 'fake_news', label: 'फर्जी या भ्रामक खबरें फैलाना (Fake / Misleading News)' },
    { id: 'hate_speech', label: 'आपत्तिजनक या अभद्र भाषा/सामग्री (Hate Speech / Abuse)' },
    { id: 'spam_fraud', label: 'स्पैम अथवा धोखाधड़ी (Spam or Fraud Activity)' },
    { id: 'copyright', label: 'कॉपीराइट व बौद्धिक संपदा उल्लंघन (Copyright Infringement)' },
    { id: 'other', label: 'अन्य गंभीर कारण (Other Violation)' },
];

const SkeletonRow = () => (
  <tr className="animate-pulse border-b border-gray-100">
    <td className="px-5 py-4">
      <div className="flex items-center">
        <div className="h-10 w-10 rounded-full bg-gray-200 shrink-0"></div>
        <div className="ml-3 space-y-2">
          <div className="h-4 w-28 bg-gray-200 rounded"></div>
          <div className="h-3 w-36 bg-gray-200 rounded"></div>
        </div>
      </div>
    </td>
    <td className="px-5 py-4">
      <div className="h-6 w-20 bg-gray-200 rounded-full"></div>
    </td>
    <td className="px-5 py-4">
      <div className="h-4 w-16 bg-gray-200 rounded"></div>
    </td>
    <td className="px-5 py-4">
      <div className="h-6 w-16 bg-gray-200 rounded-full"></div>
    </td>
    <td className="px-5 py-4">
      <div className="h-8 w-28 bg-gray-200 rounded-lg"></div>
    </td>
  </tr>
);

const ManageUsersPage: React.FC<ManageUsersPageProps> = ({ onBack, currentUser, onEditUser }) => {
    const { showToast } = useToast();
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [activeFilter, setActiveFilter] = useState<'all' | 'active' | 'banned' | 'reporters' | 'admins'>('all');

    // Ban Modal State
    const [isBanModalOpen, setIsBanModalOpen] = useState(false);
    const [userToBan, setUserToBan] = useState<User | null>(null);
    const [selectedBanReason, setSelectedBanReason] = useState(BAN_REASON_OPTIONS[0].label);
    const [customBanNote, setCustomBanNote] = useState("");
    const [isBanning, setIsBanning] = useState(false);

    // Unban Modal State
    const [isUnbanModalOpen, setIsUnbanModalOpen] = useState(false);
    const [userToUnban, setUserToUnban] = useState<User | null>(null);
    const [isUnbanning, setIsUnbanning] = useState(false);

    // Role Change Modal State
    const [isRoleChangeModalOpen, setIsRoleChangeModalOpen] = useState(false);
    const [userToChangeRole, setUserToChangeRole] = useState<{ uid: string; newRole: 'user' | 'admin'; name?: string } | null>(null);

    useEffect(() => {
        if (currentUser?.role !== 'admin') {
            setLoading(false);
            return;
        }
        const unsubscribe = db.collection('users').onSnapshot((snapshot) => {
            const usersData = snapshot.docs.map(doc => ({
                uid: doc.id,
                ...doc.data()
            } as User));
            setUsers(usersData);
            setLoading(false);
            setError(null);
        }, (err) => {
            console.error("Firestore error in ManageUsersPage:", err);
            setError("Failed to load users. Ensure your Firestore security rules grant admin access.");
            setLoading(false);
        });
        return () => unsubscribe();
    }, [currentUser]);

    // Role Change Logic
    const openRoleChangeModal = (user: User) => {
        const newRole = user.role === 'admin' ? 'user' : 'admin';
        setUserToChangeRole({ uid: user.uid, newRole, name: user.name });
        setIsRoleChangeModalOpen(true);
    };

    const handleConfirmRoleChange = async () => {
        if (!userToChangeRole) return;
        try {
            const userDocRef = db.collection('users').doc(userToChangeRole.uid);
            await userDocRef.update({ 
                role: userToChangeRole.newRole,
                roleUpdatedAt: new Date()
            });

            // Synchronize with /admins collection for Firestore security rules and instant access
            const adminDocRef = db.collection('admins').doc(userToChangeRole.uid);
            if (userToChangeRole.newRole === 'admin') {
                await adminDocRef.set({
                    uid: userToChangeRole.uid,
                    name: userToChangeRole.name || '',
                    role: 'admin',
                    assignedAt: new Date(),
                    assignedBy: currentUser?.uid || currentUser?.email || 'admin'
                }, { merge: true });

                // Send notification to the newly promoted admin
                try {
                    await db.collection('users').doc(userToChangeRole.uid).collection('notifications').add({
                        type: 'admin_promoted',
                        title: '👑 एडमिन अधिकार प्राप्त (Admin Access Granted)',
                        body: 'बधाई हो! आपको पब्लिक तक ऐप का एडमिन (Administrator) बना दिया गया है। अब आपके पास संपूर्ण एडमिन पैनल और सभी सुविधाओं का पूरा एक्सेस है।',
                        read: false,
                        createdAt: new Date()
                    });
                } catch (nErr) {
                    console.warn("Could not dispatch admin promotion notification:", nErr);
                }
            } else {
                try {
                    await adminDocRef.delete();
                } catch (delErr) {
                    console.warn("Could not delete from admins collection:", delErr);
                }
            }

            showToast(`User role updated to ${userToChangeRole.newRole.toUpperCase()} successfully. Admin privileges active.`, 'success');
        } catch (err) {
            console.error("Error changing user role:", err);
            showToast("Failed to change user role. Please try again.", "error");
        } finally {
            setIsRoleChangeModalOpen(false);
            setUserToChangeRole(null);
        }
    };

    // Open Ban Modal
    const openBanModal = (user: User) => {
        if (user.uid === currentUser?.uid) {
            showToast("आप स्वयं अपने एडमिन खाते को बैन नहीं कर सकते। (Cannot ban your own admin account)", "error");
            return;
        }
        setUserToBan(user);
        setSelectedBanReason(BAN_REASON_OPTIONS[0].label);
        setCustomBanNote("");
        setIsBanModalOpen(true);
    };

    // Confirm Ban Action
    const handleConfirmBan = async () => {
        if (!userToBan || !currentUser) return;
        if (userToBan.uid === currentUser.uid) {
            showToast("आप स्वयं अपने एडमिन खाते को बैन नहीं कर सकते।", "error");
            return;
        }

        const finalReason = customBanNote.trim() 
            ? `${selectedBanReason} - ${customBanNote.trim()}`
            : selectedBanReason;

        setIsBanning(true);
        try {
            // 1. Update user document with isBanned = true
            await db.collection('users').doc(userToBan.uid).update({
                isBanned: true,
                banReason: finalReason,
                bannedAt: serverTimestamp(),
                bannedBy: currentUser.uid,
            });

            // 2. Write official notification in user's notifications subcollection
            try {
                await db.collection('users').doc(userToBan.uid).collection('notifications').add({
                    type: 'account_banned',
                    title: '🚫 आपका खाता प्रतिबंधित किया गया (Account Banned)',
                    body: `नियमों के उल्लंघन के कारण आपका खाता एडमिनिस्ट्रेशन द्वारा प्रतिबंधित कर दिया गया है। कारण: "${finalReason}". प्रतिबंध अवधि के दौरान आप कोई पोस्ट, कमेंट या गतिविधि नहीं कर सकेंगे।`,
                    read: false,
                    createdAt: serverTimestamp(),
                });
            } catch (notifErr) {
                console.warn("Could not write ban notification to subcollection:", notifErr);
            }

            showToast(`${userToBan.name || 'उपयोगकर्ता'} का खाता सफलतापूर्वक बैन (प्रतिबंधित) कर दिया गया है।`, "success");
            setIsBanModalOpen(false);
            setUserToBan(null);
        } catch (err: any) {
            console.error("Error banning user:", err);
            showToast(`खाता बैन करने में समस्या आई: ${err.message || 'पुनः प्रयास करें'}`, "error");
        } finally {
            setIsBanning(false);
        }
    };

    // Open Unban Modal
    const openUnbanModal = (user: User) => {
        setUserToUnban(user);
        setIsUnbanModalOpen(true);
    };

    // Confirm Unban Action
    const handleConfirmUnban = async () => {
        if (!userToUnban || !currentUser) return;

        setIsUnbanning(true);
        try {
            // 1. Update user document with isBanned = false
            await db.collection('users').doc(userToUnban.uid).update({
                isBanned: false,
                banReason: '',
                unbannedAt: serverTimestamp(),
                unbannedBy: currentUser.uid,
            });

            // 2. Write official notification in user's notifications subcollection
            try {
                await db.collection('users').doc(userToUnban.uid).collection('notifications').add({
                    type: 'account_unbanned',
                    title: '✅ आपका खाता पुनः सक्रिय किया गया (Account Unbanned)',
                    body: 'एडमिनिस्ट्रेशन द्वारा आपके खाते पर लगा प्रतिबंध हटा दिया गया है। अब आप सामान्य रूप से ऐप की सभी सुविधाओं का उपयोग कर सकते हैं।',
                    read: false,
                    createdAt: serverTimestamp(),
                });
            } catch (notifErr) {
                console.warn("Could not write unban notification to subcollection:", notifErr);
            }

            showToast(`${userToUnban.name || 'उपयोगकर्ता'} का खाता सफलतापूर्वक अनबैन (सक्रिय) कर दिया गया है।`, "success");
            setIsUnbanModalOpen(false);
            setUserToUnban(null);
        } catch (err: any) {
            console.error("Error unbanning user:", err);
            showToast(`खाता अनबैन करने में समस्या आई: ${err.message || 'पुनः प्रयास करें'}`, "error");
        } finally {
            setIsUnbanning(false);
        }
    };

    // Filter and search logic
    const filteredUsers = useMemo(() => {
        return users.filter(user => {
            const query = searchTerm.toLowerCase().trim();
            const matchesSearch = !query || 
                (user.name || '').toLowerCase().includes(query) ||
                (user.email || '').toLowerCase().includes(query) ||
                (user.username || '').toLowerCase().includes(query) ||
                (user.phone || '').toLowerCase().includes(query) ||
                (user.uid || '').toLowerCase().includes(query);

            if (!matchesSearch) return false;

            if (activeFilter === 'active') return !user.isBanned;
            if (activeFilter === 'banned') return !!user.isBanned;
            if (activeFilter === 'reporters') return user.reporterStatus === 'approved' || !!user.reporterIdNumber;
            if (activeFilter === 'admins') return user.role === 'admin';
            return true;
        });
    }, [users, searchTerm, activeFilter]);

    // Statistics counts
    const stats = useMemo(() => {
        const total = users.length;
        const banned = users.filter(u => u.isBanned).length;
        const active = total - banned;
        const reporters = users.filter(u => u.reporterStatus === 'approved' || u.reporterIdNumber).length;
        const admins = users.filter(u => u.role === 'admin').length;
        return { total, banned, active, reporters, admins };
    }, [users]);

    if (currentUser?.role !== 'admin') {
        return (
            <div className="flex flex-col h-full bg-transparent">
                <Header title="Manage Users" showBackButton onBack={onBack} />
                <main className="flex-grow flex items-center justify-center p-5 text-center">
                    <div className="glass-card p-10 max-w-md w-full bg-white shadow-xl rounded-2xl border border-red-100">
                        <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <span className="material-symbols-outlined text-4xl">lock</span>
                        </div>
                        <h2 className="text-2xl font-black text-gray-900 mb-2">Access Denied</h2>
                        <p className="text-gray-500 font-medium text-sm">You do not have permission to access the user management command center.</p>
                    </div>
                </main>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full bg-gray-50/50">
            <Header title="Manage Users" showBackButton onBack={onBack} />

            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-28">
                <div className="w-full max-w-7xl mx-auto space-y-6">
                    
                    {/* Top Headline & Quick Stats */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                            <h1 className="text-2xl md:text-3xl font-black text-gray-900 tracking-tight flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600 text-3xl">manage_accounts</span>
                                User Accounts Management
                            </h1>
                            <p className="text-gray-500 font-medium text-xs md:text-sm mt-1">
                                उपयोगकर्ताओं की सूची, बैन व अनबैन सुरक्षा नियंत्रण (Account Ban & Unban System)
                            </p>
                        </div>
                    </div>

                    {/* Stats Cards */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
                        <div 
                            onClick={() => setActiveFilter('all')}
                            className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                                activeFilter === 'all' 
                                ? 'bg-blue-50/80 border-blue-300 ring-2 ring-blue-500/20' 
                                : 'bg-white border-gray-200 hover:border-gray-300'
                            }`}
                        >
                            <div className="flex items-center justify-between">
                                <span className="text-xs font-bold uppercase tracking-wider text-gray-500">कुल यूजर्स (Total)</span>
                                <span className="material-symbols-outlined text-blue-600 text-xl">group</span>
                            </div>
                            <p className="text-2xl md:text-3xl font-black text-gray-900 mt-2">{stats.total}</p>
                        </div>

                        <div 
                            onClick={() => setActiveFilter('active')}
                            className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                                activeFilter === 'active' 
                                ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-500/20' 
                                : 'bg-white border-gray-200 hover:border-gray-300'
                            }`}
                        >
                            <div className="flex items-center justify-between">
                                <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">सक्रिय (Active)</span>
                                <span className="material-symbols-outlined text-emerald-600 text-xl">check_circle</span>
                            </div>
                            <p className="text-2xl md:text-3xl font-black text-emerald-700 mt-2">{stats.active}</p>
                        </div>

                        <div 
                            onClick={() => setActiveFilter('banned')}
                            className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                                activeFilter === 'banned' 
                                ? 'bg-red-50/90 border-red-300 ring-2 ring-red-500/20' 
                                : 'bg-white border-gray-200 hover:border-gray-300'
                            }`}
                        >
                            <div className="flex items-center justify-between">
                                <span className="text-xs font-bold uppercase tracking-wider text-red-600">प्रतिबंधित (Banned)</span>
                                <span className="material-symbols-outlined text-red-600 text-xl">block</span>
                            </div>
                            <p className="text-2xl md:text-3xl font-black text-red-600 mt-2">{stats.banned}</p>
                        </div>

                        <div 
                            onClick={() => setActiveFilter('reporters')}
                            className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
                                activeFilter === 'reporters' 
                                ? 'bg-indigo-50/80 border-indigo-300 ring-2 ring-indigo-500/20' 
                                : 'bg-white border-gray-200 hover:border-gray-300'
                            }`}
                        >
                            <div className="flex items-center justify-between">
                                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">पत्रकार (Reporters)</span>
                                <span className="material-symbols-outlined text-indigo-600 text-xl">badge</span>
                            </div>
                            <p className="text-2xl md:text-3xl font-black text-indigo-900 mt-2">{stats.reporters}</p>
                        </div>
                    </div>

                    {/* Filter and Search Bar */}
                    <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                        <div className="flex flex-col sm:flex-row items-center gap-3">
                            <div className="relative flex-1 w-full">
                                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-400 text-xl pointer-events-none">
                                    search
                                </span>
                                <input
                                    type="text"
                                    placeholder="Search by name, email, username, phone or UID..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full pl-10 pr-10 py-2.5 border border-gray-200 bg-gray-50/50 rounded-xl text-sm text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all placeholder:text-gray-400 font-medium"
                                />
                                {searchTerm && (
                                    <button 
                                        onClick={() => setSearchTerm("")}
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-1"
                                    >
                                        <span className="material-symbols-outlined text-base">close</span>
                                    </button>
                                )}
                            </div>

                            {/* Filter Chips */}
                            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
                                <button
                                    onClick={() => setActiveFilter('all')}
                                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                                        activeFilter === 'all' 
                                        ? 'bg-gray-900 text-white' 
                                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                    }`}
                                >
                                    सभी ({stats.total})
                                </button>
                                <button
                                    onClick={() => setActiveFilter('active')}
                                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                                        activeFilter === 'active' 
                                        ? 'bg-emerald-600 text-white' 
                                        : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                    }`}
                                >
                                    सक्रिय ({stats.active})
                                </button>
                                <button
                                    onClick={() => setActiveFilter('banned')}
                                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                                        activeFilter === 'banned' 
                                        ? 'bg-red-600 text-white' 
                                        : 'bg-red-50 text-red-700 hover:bg-red-100'
                                    }`}
                                >
                                    प्रतिबंधित ({stats.banned})
                                </button>
                                <button
                                    onClick={() => setActiveFilter('reporters')}
                                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                                        activeFilter === 'reporters' 
                                        ? 'bg-indigo-600 text-white' 
                                        : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
                                    }`}
                                >
                                    पत्रकार ({stats.reporters})
                                </button>
                                <button
                                    onClick={() => setActiveFilter('admins')}
                                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                                        activeFilter === 'admins' 
                                        ? 'bg-blue-600 text-white' 
                                        : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                                    }`}
                                >
                                    एडमिन ({stats.admins})
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Table / Card View */}
                    {loading ? (
                        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-5 py-3.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">User</th>
                                        <th className="px-5 py-3.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                                        <th className="px-5 py-3.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Balance</th>
                                        <th className="px-5 py-3.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Role</th>
                                        <th className="px-5 py-3.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-100">
                                    {[...Array(5)].map((_, i) => <SkeletonRow key={i} />)}
                                </tbody>
                            </table>
                        </div>
                    ) : error ? (
                        <div className="p-6 text-center bg-red-50 rounded-2xl border border-red-200 text-red-700">
                            <span className="material-symbols-outlined text-4xl mb-2">error</span>
                            <p className="font-bold">{error}</p>
                        </div>
                    ) : filteredUsers.length === 0 ? (
                        <div className="p-12 text-center bg-white rounded-2xl border border-gray-200 shadow-sm">
                            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3 text-gray-400">
                                <span className="material-symbols-outlined text-3xl">person_off</span>
                            </div>
                            <h3 className="text-base font-bold text-gray-800">कोई यूजर नहीं मिला (No Users Found)</h3>
                            <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
                                आपके द्वारा खोजे गए शब्द या फिल्टर के अनुसार कोई परिणाम नहीं मिला। कृपया दूसरा कीवर्ड खोजें।
                            </p>
                        </div>
                    ) : (
                        <>
                            {/* Desktop Table View */}
                            <div className="hidden md:block bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
                                <div className="overflow-x-auto">
                                    <table className="min-w-full divide-y divide-gray-200">
                                        <thead className="bg-gray-50/80">
                                            <tr>
                                                <th scope="col" className="px-5 py-3.5 text-left text-xs font-extrabold text-gray-500 uppercase tracking-wider">User Details</th>
                                                <th scope="col" className="px-5 py-3.5 text-left text-xs font-extrabold text-gray-500 uppercase tracking-wider">Account Status</th>
                                                <th scope="col" className="px-5 py-3.5 text-left text-xs font-extrabold text-gray-500 uppercase tracking-wider">Wallet</th>
                                                <th scope="col" className="px-5 py-3.5 text-left text-xs font-extrabold text-gray-500 uppercase tracking-wider">Role</th>
                                                <th scope="col" className="px-5 py-3.5 text-right text-xs font-extrabold text-gray-500 uppercase tracking-wider">Ban / Unban Controls</th>
                                            </tr>
                                        </thead>
                                        <tbody className="bg-white divide-y divide-gray-100">
                                            {filteredUsers.map(user => {
                                                const isSelf = user.uid === currentUser?.uid;
                                                const isUserBanned = !!user.isBanned;

                                                return (
                                                    <tr key={user.uid} className={`hover:bg-gray-50/80 transition-colors ${isUserBanned ? 'bg-red-50/30' : ''}`}>
                                                        {/* User Info */}
                                                        <td className="px-5 py-4 whitespace-nowrap">
                                                            <div className="flex items-center">
                                                                <div className="relative shrink-0 h-11 w-11">
                                                                    <img 
                                                                        className={`h-11 w-11 rounded-full object-cover ring-2 ${
                                                                            isUserBanned ? 'ring-red-400 grayscale' : 'ring-gray-200'
                                                                        }`} 
                                                                        src={user.profilePicUrl || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(user.email || user.uid)}`} 
                                                                        alt={user.name} 
                                                                    />
                                                                    {isUserBanned && (
                                                                        <span className="absolute -bottom-1 -right-1 bg-red-600 text-white rounded-full p-0.5" title="Banned">
                                                                            <span className="material-symbols-outlined text-[13px] block">block</span>
                                                                        </span>
                                                                    )}
                                                                </div>
                                                                <div className="ml-3.5 min-w-0">
                                                                    <div className="flex items-center gap-1.5">
                                                                        <span className="text-sm font-bold text-gray-900 truncate">{user.name || 'Anonymous User'}</span>
                                                                        {user.isVerified && (
                                                                            <span className="material-symbols-outlined text-blue-500 text-base" title="Verified Creator">verified</span>
                                                                        )}
                                                                        {(user.reporterStatus === 'approved' || user.reporterIdNumber) && (
                                                                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-black bg-indigo-100 text-indigo-800">
                                                                                REPORTER
                                                                            </span>
                                                                        )}
                                                                        {isSelf && (
                                                                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-black bg-gray-200 text-gray-700">
                                                                                YOU
                                                                            </span>
                                                                        )}
                                                                    </div>
                                                                    <div className="text-xs text-gray-500 truncate flex items-center gap-2 mt-0.5">
                                                                        <span>{user.email || user.phone || 'No email/phone'}</span>
                                                                        {user.username && <span className="text-gray-400">@{user.username}</span>}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>

                                                        {/* Status */}
                                                        <td className="px-5 py-4">
                                                            {isUserBanned ? (
                                                                <div className="space-y-1">
                                                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black bg-red-100 text-red-800 border border-red-200">
                                                                        <span className="material-symbols-outlined text-sm">block</span>
                                                                        BANNED (प्रतिबंधित)
                                                                    </span>
                                                                    {user.banReason && (
                                                                        <p className="text-[11px] text-red-600 font-medium max-w-xs truncate" title={user.banReason}>
                                                                            कारण: {user.banReason}
                                                                        </p>
                                                                    )}
                                                                </div>
                                                            ) : (
                                                                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                                                    <span className="material-symbols-outlined text-sm">check_circle</span>
                                                                    ACTIVE (सक्रिय)
                                                                </span>
                                                            )}
                                                        </td>

                                                        {/* Balance */}
                                                        <td className="px-5 py-4 whitespace-nowrap text-sm text-gray-800 font-bold font-mono">
                                                            ₹{(user.walletBalance || 0).toFixed(2)}
                                                        </td>

                                                        {/* Role */}
                                                        <td className="px-5 py-4 whitespace-nowrap">
                                                            <span className={`px-2.5 py-1 inline-flex text-xs leading-4 font-extrabold rounded-full ${
                                                                user.role === 'admin' 
                                                                ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                                                                : 'bg-blue-50 text-blue-700 border border-blue-200'
                                                            }`}>
                                                                {user.role === 'admin' ? 'ADMIN' : 'USER'}
                                                            </span>
                                                        </td>

                                                        {/* Actions: Edit, Change Role, and BAN / UNBAN */}
                                                        <td className="px-5 py-4 whitespace-nowrap text-right">
                                                            <div className="flex items-center justify-end gap-2">
                                                                <button 
                                                                    onClick={() => onEditUser(user.uid)} 
                                                                    className="px-2.5 py-1.5 text-xs font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors inline-flex items-center gap-1"
                                                                    title="Edit profile & user settings"
                                                                >
                                                                    <span className="material-symbols-outlined text-sm">edit</span>
                                                                    <span>Edit</span>
                                                                </button>

                                                                <button 
                                                                    onClick={() => openRoleChangeModal(user)} 
                                                                    disabled={isSelf}
                                                                    className={`px-2.5 py-1.5 text-xs font-bold rounded-lg transition-colors inline-flex items-center gap-1 ${
                                                                        isSelf 
                                                                        ? 'opacity-40 cursor-not-allowed bg-gray-100 text-gray-400' 
                                                                        : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200'
                                                                    }`}
                                                                    title="Toggle admin/user privileges"
                                                                >
                                                                    <span className="material-symbols-outlined text-sm">swap_horiz</span>
                                                                    <span>Role</span>
                                                                </button>

                                                                {/* BAN / UNBAN BUTTON - Replaces Delete */}
                                                                {isUserBanned ? (
                                                                    <button 
                                                                        onClick={() => openUnbanModal(user)}
                                                                        className="px-3 py-1.5 text-xs font-black text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-all active:scale-95 shadow-xs inline-flex items-center gap-1.5"
                                                                        title="Unban this user account"
                                                                    >
                                                                        <span className="material-symbols-outlined text-sm text-emerald-600 font-bold">verified_user</span>
                                                                        <span>Unban Account</span>
                                                                    </button>
                                                                ) : (
                                                                    <button 
                                                                        onClick={() => openBanModal(user)}
                                                                        disabled={isSelf}
                                                                        className={`px-3 py-1.5 text-xs font-black rounded-lg transition-all inline-flex items-center gap-1.5 shadow-xs ${
                                                                            isSelf 
                                                                            ? 'opacity-40 cursor-not-allowed bg-gray-100 text-gray-400 border border-gray-200' 
                                                                            : 'text-red-700 bg-red-50 hover:bg-red-100 hover:border-red-300 border border-red-200 active:scale-95'
                                                                        }`}
                                                                        title={isSelf ? "You cannot ban your own account" : "Ban and restrict this user account"}
                                                                    >
                                                                        <span className="material-symbols-outlined text-sm text-red-600 font-bold">block</span>
                                                                        <span>Ban Account</span>
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            {/* Mobile Card List View (< md screens) */}
                            <div className="md:hidden space-y-3">
                                {filteredUsers.map(user => {
                                    const isSelf = user.uid === currentUser?.uid;
                                    const isUserBanned = !!user.isBanned;

                                    return (
                                        <div 
                                            key={user.uid} 
                                            className={`p-4 rounded-2xl border transition-all bg-white shadow-xs ${
                                                isUserBanned ? 'border-red-200 bg-red-50/20' : 'border-gray-200'
                                            }`}
                                        >
                                            <div className="flex items-start justify-between gap-3">
                                                <div className="flex items-center gap-3 min-w-0">
                                                    <div className="relative shrink-0">
                                                        <img 
                                                            className={`h-12 w-12 rounded-full object-cover ring-2 ${
                                                                isUserBanned ? 'ring-red-400 grayscale' : 'ring-gray-200'
                                                            }`} 
                                                            src={user.profilePicUrl || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(user.email || user.uid)}`} 
                                                            alt={user.name} 
                                                        />
                                                        {isUserBanned && (
                                                            <span className="absolute -bottom-1 -right-1 bg-red-600 text-white rounded-full p-0.5">
                                                                <span className="material-symbols-outlined text-[12px] block">block</span>
                                                            </span>
                                                        )}
                                                    </div>
                                                    <div className="min-w-0">
                                                        <div className="flex items-center gap-1.5 flex-wrap">
                                                            <span className="font-bold text-gray-900 text-sm truncate">{user.name || 'Anonymous User'}</span>
                                                            {user.isVerified && (
                                                                <span className="material-symbols-outlined text-blue-500 text-sm">verified</span>
                                                            )}
                                                            {isSelf && (
                                                                <span className="text-[10px] font-black bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded">
                                                                    YOU
                                                                </span>
                                                            )}
                                                        </div>
                                                        <p className="text-xs text-gray-500 truncate">{user.email || user.phone || 'No email/phone'}</p>
                                                        {user.username && <p className="text-[11px] text-gray-400">@{user.username}</p>}
                                                    </div>
                                                </div>

                                                {/* Status badge */}
                                                <div>
                                                    {isUserBanned ? (
                                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-red-100 text-red-800 border border-red-200">
                                                            <span className="material-symbols-outlined text-[12px]">block</span>
                                                            BANNED
                                                        </span>
                                                    ) : (
                                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                                            <span className="material-symbols-outlined text-[12px]">check_circle</span>
                                                            ACTIVE
                                                        </span>
                                                    )}
                                                </div>
                                            </div>

                                            {/* Ban Reason Sub-card on mobile */}
                                            {isUserBanned && user.banReason && (
                                                <div className="mt-2.5 p-2 bg-red-50 border border-red-100 rounded-xl text-xs text-red-700">
                                                    <span className="font-black">कारण: </span>{user.banReason}
                                                </div>
                                            )}

                                            {/* Details Bar */}
                                            <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-600">
                                                <div>
                                                    <span className="text-gray-400">Balance: </span>
                                                    <span className="font-bold text-gray-900 font-mono">₹{(user.walletBalance || 0).toFixed(2)}</span>
                                                </div>
                                                <div>
                                                    <span className="text-gray-400">Role: </span>
                                                    <span className={`font-bold uppercase ${user.role === 'admin' ? 'text-purple-600' : 'text-blue-600'}`}>
                                                        {user.role}
                                                    </span>
                                                </div>
                                                {(user.reporterStatus === 'approved' || user.reporterIdNumber) && (
                                                    <span className="text-[10px] font-black bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded">
                                                        REPORTER
                                                    </span>
                                                )}
                                            </div>

                                            {/* Actions Bar */}
                                            <div className="mt-3 pt-3 border-t border-gray-100 grid grid-cols-3 gap-2">
                                                <button
                                                    onClick={() => onEditUser(user.uid)}
                                                    className="py-2 px-2 text-xs font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl text-center flex items-center justify-center gap-1"
                                                >
                                                    <span className="material-symbols-outlined text-sm">edit</span>
                                                    <span>Edit</span>
                                                </button>

                                                <button
                                                    onClick={() => openRoleChangeModal(user)}
                                                    disabled={isSelf}
                                                    className={`py-2 px-2 text-xs font-bold rounded-xl text-center flex items-center justify-center gap-1 ${
                                                        isSelf ? 'opacity-30 bg-gray-100 text-gray-400' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
                                                    }`}
                                                >
                                                    <span className="material-symbols-outlined text-sm">swap_horiz</span>
                                                    <span>Role</span>
                                                </button>

                                                {/* Mobile Ban / Unban Button */}
                                                {isUserBanned ? (
                                                    <button
                                                        onClick={() => openUnbanModal(user)}
                                                        className="py-2 px-2 text-xs font-black bg-emerald-600 text-white hover:bg-emerald-700 rounded-xl text-center flex items-center justify-center gap-1 active:scale-95 shadow-xs"
                                                    >
                                                        <span className="material-symbols-outlined text-sm">verified_user</span>
                                                        <span>Unban</span>
                                                    </button>
                                                ) : (
                                                    <button
                                                        onClick={() => openBanModal(user)}
                                                        disabled={isSelf}
                                                        className={`py-2 px-2 text-xs font-black rounded-xl text-center flex items-center justify-center gap-1 ${
                                                            isSelf 
                                                            ? 'opacity-30 bg-gray-100 text-gray-400' 
                                                            : 'bg-red-600 text-white hover:bg-red-700 active:scale-95 shadow-xs'
                                                        }`}
                                                    >
                                                        <span className="material-symbols-outlined text-sm">block</span>
                                                        <span>Ban</span>
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </>
                    )}
                </div>
            </main>

            {/* ========================================================= */}
            {/* BAN ACCOUNT MODAL                                         */}
            {/* ========================================================= */}
            {isBanModalOpen && userToBan && (
                <div 
                    className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in"
                    onClick={() => !isBanning && setIsBanModalOpen(false)}
                >
                    <div 
                        className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-red-100 transform transition-all text-left space-y-5"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Header */}
                        <div className="flex items-start justify-between pb-3 border-b border-gray-100">
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center shrink-0">
                                    <span className="material-symbols-outlined text-2xl font-bold">gavel</span>
                                </div>
                                <div>
                                    <h3 className="text-xl font-black text-gray-900 tracking-tight">खाता बैन करें (Ban Account)</h3>
                                    <p className="text-xs text-gray-500 mt-0.5">इस यूजर के सभी एक्सेस तुरंत ब्लॉक कर दिए जाएंगे</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => !isBanning && setIsBanModalOpen(false)}
                                className="text-gray-400 hover:text-gray-600 p-1.5 rounded-full hover:bg-gray-100"
                            >
                                <span className="material-symbols-outlined text-xl">close</span>
                            </button>
                        </div>

                        {/* User Summary Card */}
                        <div className="p-3.5 bg-gray-50 rounded-2xl border border-gray-200 flex items-center gap-3.5">
                            <img 
                                src={userToBan.profilePicUrl || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(userToBan.email || userToBan.uid)}`} 
                                alt={userToBan.name} 
                                className="w-12 h-12 rounded-full object-cover ring-2 ring-red-200"
                            />
                            <div className="min-w-0 flex-1">
                                <p className="font-extrabold text-sm text-gray-900 truncate">{userToBan.name || 'Anonymous User'}</p>
                                <p className="text-xs text-gray-500 truncate">{userToBan.email || userToBan.phone || 'No email'}</p>
                                <p className="text-[11px] text-gray-400 font-mono truncate">UID: {userToBan.uid}</p>
                            </div>
                        </div>

                        {/* Ban Reason Selector */}
                        <div className="space-y-2">
                            <label className="block text-xs font-black text-gray-700 uppercase tracking-wider">
                                प्रतिबंध का मुख्य कारण (Select Ban Reason) *
                            </label>
                            <div className="space-y-2">
                                {BAN_REASON_OPTIONS.map((opt) => (
                                    <label 
                                        key={opt.id} 
                                        className={`flex items-center gap-3 p-2.5 rounded-xl border text-xs font-semibold cursor-pointer transition-colors ${
                                            selectedBanReason === opt.label 
                                            ? 'bg-red-50/80 border-red-400 text-red-900 ring-1 ring-red-400' 
                                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                                        }`}
                                    >
                                        <input 
                                            type="radio" 
                                            name="banReason" 
                                            value={opt.label}
                                            checked={selectedBanReason === opt.label}
                                            onChange={() => setSelectedBanReason(opt.label)}
                                            className="text-red-600 focus:ring-red-500"
                                        />
                                        <span>{opt.label}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        {/* Custom Ban Note */}
                        <div className="space-y-1.5">
                            <label className="block text-xs font-black text-gray-700 uppercase tracking-wider">
                                अतिरिक्त विवरण / टिप्पणी (Optional Remarks)
                            </label>
                            <textarea
                                rows={2}
                                value={customBanNote}
                                onChange={(e) => setCustomBanNote(e.target.value)}
                                placeholder="यूजर को दिखने वाला कारण या एडमिन रिकॉर्ड हेतु टिप्पणी लिखें..."
                                className="w-full p-3 border border-gray-200 rounded-xl text-xs text-gray-900 focus:ring-2 focus:ring-red-500 focus:outline-none"
                            />
                        </div>

                        {/* Warning Box */}
                        <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-xs text-red-700">
                            <span className="material-symbols-outlined text-lg shrink-0 mt-0.5">warning</span>
                            <div className="leading-relaxed">
                                <strong className="font-black">अहम सूचना:</strong> खाता बैन होने के बाद यह यूजर ऐप में कोई भी पोस्ट, वीडियो, कमेंट, प्रोफाइल या वॉलेट गतिविधि नहीं कर सकेगा। ऐप खोलते ही लॉक स्क्रीन दिखाई देगी।
                            </div>
                        </div>

                        {/* Modal Action Buttons */}
                        <div className="flex items-center justify-end gap-3 pt-2">
                            <button
                                type="button"
                                onClick={() => setIsBanModalOpen(false)}
                                disabled={isBanning}
                                className="px-5 py-2.5 rounded-xl font-bold text-xs text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
                            >
                                रद्द करें (Cancel)
                            </button>
                            <button
                                type="button"
                                onClick={handleConfirmBan}
                                disabled={isBanning}
                                className="px-6 py-2.5 rounded-xl font-black text-xs text-white bg-red-600 hover:bg-red-700 transition-all active:scale-95 shadow-md shadow-red-200 flex items-center gap-1.5"
                            >
                                {isBanning ? (
                                    <>
                                        <span className="inline-block w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                                        <span>बैन किया जा रहा है...</span>
                                    </>
                                ) : (
                                    <>
                                        <span className="material-symbols-outlined text-base">block</span>
                                        <span>खाता बैन करें (Confirm Ban)</span>
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ========================================================= */}
            {/* UNBAN ACCOUNT MODAL                                       */}
            {/* ========================================================= */}
            {isUnbanModalOpen && userToUnban && (
                <div 
                    className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fade-in"
                    onClick={() => !isUnbanning && setIsUnbanModalOpen(false)}
                >
                    <div 
                        className="bg-white rounded-3xl p-6 w-full max-w-md shadow-2xl border border-emerald-100 transform transition-all text-left space-y-5"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {/* Header */}
                        <div className="flex items-start justify-between pb-3 border-b border-gray-100">
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center shrink-0">
                                    <span className="material-symbols-outlined text-2xl font-bold">verified_user</span>
                                </div>
                                <div>
                                    <h3 className="text-xl font-black text-gray-900 tracking-tight">खाता अनबैन करें (Unban User)</h3>
                                    <p className="text-xs text-gray-500 mt-0.5">प्रतिबंध हटाकर खाते को पुनः सक्रिय करें</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => !isUnbanning && setIsUnbanModalOpen(false)}
                                className="text-gray-400 hover:text-gray-600 p-1.5 rounded-full hover:bg-gray-100"
                            >
                                <span className="material-symbols-outlined text-xl">close</span>
                            </button>
                        </div>

                        {/* User Summary Card */}
                        <div className="p-3.5 bg-gray-50 rounded-2xl border border-gray-200 flex items-center gap-3.5">
                            <img 
                                src={userToUnban.profilePicUrl || `https://api.dicebear.com/8.x/identicon/svg?seed=${encodeURIComponent(userToUnban.email || userToUnban.uid)}`} 
                                alt={userToUnban.name} 
                                className="w-12 h-12 rounded-full object-cover ring-2 ring-emerald-300"
                            />
                            <div className="min-w-0 flex-1">
                                <p className="font-extrabold text-sm text-gray-900 truncate">{userToUnban.name || 'Anonymous User'}</p>
                                <p className="text-xs text-gray-500 truncate">{userToUnban.email || userToUnban.phone || 'No email'}</p>
                                <p className="text-[11px] text-gray-400 font-mono truncate">UID: {userToUnban.uid}</p>
                            </div>
                        </div>

                        {/* Previous Ban Reason Info */}
                        {userToUnban.banReason && (
                            <div className="p-3 bg-red-50/70 border border-red-200 rounded-2xl text-xs">
                                <span className="font-black text-red-800">मौजूदा बैन कारण: </span>
                                <span className="text-red-700">{userToUnban.banReason}</span>
                            </div>
                        )}

                        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-2.5 text-xs text-emerald-800">
                            <span className="material-symbols-outlined text-lg shrink-0 mt-0.5 text-emerald-600">check_circle</span>
                            <div className="leading-relaxed">
                                क्या आप सचमुच <strong>{userToUnban.name}</strong> का प्रतिबंध हटाना चाहते हैं? अनबैन होने के बाद यह यूजर सामान्य रूप से ऐप में पोस्टिंग, कमेंट्स और अन्य गतिविधियों का उपयोग कर सकेगा।
                            </div>
                        </div>

                        {/* Modal Action Buttons */}
                        <div className="flex items-center justify-end gap-3 pt-2">
                            <button
                                type="button"
                                onClick={() => setIsUnbanModalOpen(false)}
                                disabled={isUnbanning}
                                className="px-5 py-2.5 rounded-xl font-bold text-xs text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors"
                            >
                                रद्द करें (Cancel)
                            </button>
                            <button
                                type="button"
                                onClick={handleConfirmUnban}
                                disabled={isUnbanning}
                                className="px-6 py-2.5 rounded-xl font-black text-xs text-white bg-emerald-600 hover:bg-emerald-700 transition-all active:scale-95 shadow-md shadow-emerald-200 flex items-center gap-1.5"
                            >
                                {isUnbanning ? (
                                    <>
                                        <span className="inline-block w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                                        <span>अनबैन किया जा रहा है...</span>
                                    </>
                                ) : (
                                    <>
                                        <span className="material-symbols-outlined text-base">verified_user</span>
                                        <span>खाता अनबैन करें (Confirm Unban)</span>
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Role Change Modal */}
            <ConfirmationModal
                isOpen={isRoleChangeModalOpen}
                onClose={() => setIsRoleChangeModalOpen(false)}
                onConfirm={handleConfirmRoleChange}
                title={userToChangeRole?.newRole === 'admin' ? "👑 एडमिन अधिकार प्रदान करें (Grant Admin Access)" : "यूजर रोल बदलें (Demote to User)"}
                message={
                    userToChangeRole?.newRole === 'admin'
                        ? `क्या आप सचमुच "${userToChangeRole?.name || 'इस यूजर'}" को ADMIN बनाना चाहते हैं? एडमिन बनने के बाद इस यूजर को एडमिन पैनल, यूजर प्रबंधन, बैन/अनबैन, कंटेंट मॉडरेशन, मोनेटाइजेशन, विड्रॉल व केवाईसी जैसी सभी चीजों का पूर्ण एक्सेस (Full Administrative Access) प्राप्त हो जाएगा।`
                        : `क्या आप सचमुच "${userToChangeRole?.name || 'इस यूजर'}" से एडमिन अधिकार हटाकर सामान्य USER बनाना चाहते हैं? इसके बाद यह यूजर एडमिन पैनल का एक्सेस नहीं कर सकेगा।`
                }
                confirmButtonText={userToChangeRole?.newRole === 'admin' ? "हाँ, एडमिन बनाएं (Make Admin)" : "Change to User"}
                confirmButtonColor={userToChangeRole?.newRole === 'admin' ? "bg-purple-600 hover:bg-purple-700" : "bg-gray-700 hover:bg-gray-800"}
            />
        </div>
    );
};

export default ManageUsersPage;
