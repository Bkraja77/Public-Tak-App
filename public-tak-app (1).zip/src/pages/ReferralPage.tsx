
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import { User, View } from '../types';
import { db, serverTimestamp, firebase } from '../firebaseConfig';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';

interface ReferralPageProps {
    onBack: () => void;
    currentUser: User | null;
    onNavigate: (view: View) => void;
}

const ReferralPage: React.FC<ReferralPageProps> = ({ onBack, currentUser, onNavigate }) => {
    const { t } = useLanguage();
    const { showToast } = useToast();
    const [referrals, setReferrals] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!currentUser) return;

        const unsubscribe = db.collection('users')
            .doc(currentUser.uid)
            .collection('referrals')
            .orderBy('timestamp', 'desc')
            .limit(20)
            .onSnapshot(snapshot => {
                const list = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                    timestamp: doc.data().timestamp?.toDate() || new Date()
                }));
                setReferrals(list);
                setLoading(false);
            }, err => {
                console.error("Error fetching referrals:", err);
                setLoading(false);
            });

        return () => unsubscribe();
    }, [currentUser]);

    const handleCopyLink = () => {
        if (!currentUser) return;
        const link = `${window.location.origin}?ref=${currentUser.referralCode}`;
        navigator.clipboard.writeText(link);
        showToast("Referral link copied to clipboard!", "success");
    };

    if (!currentUser) return null;

    return (
        <div className="flex flex-col h-full bg-gray-50/30">
            <Header title="Refer & Earn" showBackButton onBack={onBack} />
            
            <main className="flex-grow overflow-y-auto p-4 md:p-8 pb-32">
                <div className="max-w-4xl mx-auto space-y-8">
                    
                    {/* Hero Section */}
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-gradient-to-br from-red-600 to-orange-500 rounded-[2.5rem] p-8 md:p-12 text-white relative overflow-hidden shadow-2xl shadow-red-200"
                    >
                        {/* Decorative background pattern */}
                        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                        <div className="absolute bottom-0 left-0 w-32 h-32 bg-black/10 rounded-full blur-2xl -ml-16 -mb-16"></div>

                        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
                            <div className="flex-1 space-y-6 text-center md:text-left">
                                <span className="inline-block px-4 py-1.5 bg-white/20 backdrop-blur-md rounded-full text-xs font-black uppercase tracking-widest border border-white/20">Growth Program 3.0</span>
                                <h1 className="text-4xl md:text-6xl font-black leading-tight tracking-tighter">Invite Friends,<br/>Earn Up to <span className="text-yellow-300">₹15+</span></h1>
                                <p className="text-red-50/80 text-lg font-medium max-w-md">Help Public Tak App grow! Get rewarded for every stage of your friend's journey.</p>
                                
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-6">
                                    <div className="bg-white/10 p-4 rounded-3xl border border-white/10 backdrop-blur-sm">
                                        <p className="text-[10px] font-black uppercase opacity-60">Stage 1</p>
                                        <p className="text-xl font-black">₹2.00</p>
                                        <p className="text-[9px] font-bold opacity-80 uppercase">On Join</p>
                                    </div>
                                    <div className="bg-white/10 p-4 rounded-3xl border border-white/10 backdrop-blur-sm">
                                        <p className="text-[10px] font-black uppercase opacity-60">Stage 2</p>
                                        <p className="text-xl font-black">₹3.00</p>
                                        <p className="text-[9px] font-bold opacity-80 uppercase">First News Post</p>
                                    </div>
                                    <div className="bg-white/10 p-4 rounded-3xl border border-white/10 backdrop-blur-sm">
                                        <p className="text-[10px] font-black uppercase opacity-60">Milestone</p>
                                        <p className="text-xl font-black">+₹10.00</p>
                                        <p className="text-[9px] font-bold opacity-80 uppercase">Every 10 Friends</p>
                                    </div>
                                </div>

                                <div className="flex flex-col sm:flex-row gap-4 pt-8">
                                    <button 
                                        onClick={handleCopyLink}
                                        className="px-8 py-4 bg-gradient-to-br from-red-600 to-red-700 text-white font-black rounded-2xl shadow-xl shadow-red-500/20 hover:shadow-red-500/30 hover:scale-[1.02] transition-all flex items-center justify-center gap-2 transform active:scale-95"
                                    >
                                        <span className="material-symbols-outlined">content_copy</span>
                                        Copy Link
                                    </button>
                                    <button 
                                        onClick={async () => {
                                            const link = `${window.location.origin}?ref=${currentUser.referralCode}`;
                                            const text = `🔥 *Public Tak App: Local News App* 🔥\n\nAb local news dekho aur paisa kamao! 💰\n\nMeray link se join karo aur instant bonus pao: \n\n👉 ${link}\n\n*Code:* ${currentUser.referralCode}`;
                                            if (navigator.share) {
                                                try {
                                                    await navigator.share({
                                                        title: 'Public Tak App - Referral',
                                                        text: text,
                                                    });
                                                } catch (err: any) {
                                                    if (err?.name !== 'AbortError') {
                                                        window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                                                    }
                                                }
                                            } else {
                                                window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                                            }
                                        }}
                                        className="px-8 py-4 bg-gradient-to-br from-blue-600 to-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:shadow-blue-500/30 hover:scale-[1.02] transition-all flex items-center justify-center gap-2 transform active:scale-95"
                                    >
                                        <span className="material-symbols-outlined text-xl">share</span>
                                        Share
                                    </button>
                                </div>
                            </div>
                            
                            <div className="w-48 h-48 md:w-64 md:h-64 bg-white/10 backdrop-blur-xl rounded-full flex flex-col items-center justify-center border-4 border-white/20 shadow-2xl relative">
                                <div className="absolute inset-0 border-8 border-yellow-300/20 rounded-full animate-ping"></div>
                                <span className="material-symbols-outlined text-6xl md:text-8xl text-yellow-300">workspace_premium</span>
                                <div className="text-center mt-2 relative z-10">
                                    <p className="text-[10px] uppercase font-black tracking-widest opacity-80">Total Earnings</p>
                                    <p className="text-3xl md:text-4xl font-black">₹{currentUser.totalEarnings?.toFixed(2) || '0.00'}</p>
                                </div>
                            </div>
                        </div>
                    </motion.div>

                    {/* Milestone Progress */}
                    <div className="glass-card p-8 bg-white border border-gray-100 overflow-hidden relative">
                         <div className="absolute top-0 right-0 p-8 opacity-5 transform rotate-12">
                            <span className="material-symbols-outlined text-9xl">military_tech</span>
                         </div>
                         <div className="flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
                            <div>
                                <h3 className="text-xl font-black text-gray-900">Referral Milestone</h3>
                                <p className="text-sm text-gray-500 font-medium mt-1">Get an extra <span className="text-red-600 font-bold">₹10 bonus</span> for every 10 successful referrals.</p>
                            </div>
                            <div className="flex items-center gap-4">
                                <div className="text-right">
                                    <p className="text-[10px] font-black text-gray-400 uppercase">Progress</p>
                                    <p className="text-xl font-black text-gray-900">{(currentUser.referralCount || 0) % 10}/10</p>
                                </div>
                                <div className="w-48 h-4 bg-gray-100 rounded-full overflow-hidden border border-gray-50">
                                    <motion.div 
                                        initial={{ width: 0 }}
                                        animate={{ width: `${((currentUser.referralCount || 0) % 10) * 10}%` }}
                                        className="h-full bg-gradient-to-r from-red-500 to-orange-400"
                                    />
                                </div>
                            </div>
                         </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="glass-card p-6 bg-white border border-gray-100 shadow-sm">
                            <p className="text-gray-400 text-xs font-black uppercase tracking-widest">Total Earned</p>
                            <h3 className="text-3xl font-black text-gray-900 mt-2">₹{currentUser.totalEarnings?.toFixed(2) || '0.00'}</h3>
                            <div className="mt-4 flex items-center gap-1.5 text-green-600">
                                <span className="material-symbols-outlined text-sm">trending_up</span>
                                <span className="text-xs font-bold">Instantly credited</span>
                            </div>
                        </div>
                        <div className="glass-card p-6 bg-white border border-gray-100 shadow-sm">
                            <p className="text-gray-400 text-xs font-black uppercase tracking-widest">Successful Joins</p>
                            <h3 className="text-3xl font-black text-gray-900 mt-2">{currentUser.referralCount || 0}</h3>
                            <div className="mt-4 flex items-center gap-1.5 text-blue-600">
                                <span className="material-symbols-outlined text-sm">groups</span>
                                <span className="text-xs font-bold font-mono">#{currentUser.referralCode}</span>
                            </div>
                        </div>
                        <div className="glass-card p-6 bg-white border border-gray-100 shadow-sm">
                            <p className="text-gray-400 text-xs font-black uppercase tracking-widest">Program Status</p>
                            <h3 className="text-3xl font-black text-green-600 mt-2">Active</h3>
                            <div className="mt-4 flex items-center gap-1.5 text-gray-400">
                                <span className="material-symbols-outlined text-sm">check_circle</span>
                                <span className="text-xs font-bold">Limit: UNLIMITED</span>
                            </div>
                        </div>
                    </div>

                    {/* History Section */}
                    <div className="space-y-6">
                        <h3 className="text-xl font-black text-gray-900 flex items-center gap-2">
                            <span className="material-symbols-outlined text-red-600">history</span>
                            Recent Referral Credits
                        </h3>
                        
                        <div className="bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-sm">
                            <div className="overflow-x-auto">
                                <table className="w-full text-left">
                                    <thead className="bg-gray-50/50 border-b border-gray-100">
                                        <tr>
                                            <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">User</th>
                                            <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Type & Date</th>
                                            <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Reward</th>
                                            <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-50">
                                        {referrals.map((ref) => (
                                            <tr key={ref.id} className="hover:bg-gray-50 transition-colors">
                                                <td className="px-6 py-4">
                                                    <div className="flex flex-col items-center gap-1">
                                                        <img src={ref.newUserPic || `https://api.dicebear.com/8.x/identicon/svg?seed=${ref.newUserId}`} alt="" className="w-8 h-8 rounded-full border shadow-sm" />
                                                        <p className="text-[10px] font-black text-gray-900 truncate max-w-[80px]">{ref.newUserName || 'User'}</p>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[9px] font-black uppercase tracking-wider mb-1 ${
                                                        ref.type === 'post_bonus' ? 'bg-purple-50 text-purple-600' : 
                                                        ref.type === 'join_with_milestone' ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'
                                                    }`}>
                                                        <span className="material-symbols-outlined text-[12px]">
                                                            {ref.type === 'post_bonus' ? 'article' : ref.type === 'join_with_milestone' ? 'stars' : 'person_add'}
                                                        </span>
                                                        {ref.type?.replace(/_/g, ' ') || 'Join'}
                                                    </div>
                                                    <p className="text-[10px] text-gray-400 font-bold uppercase">{ref.timestamp.toLocaleDateString()} {ref.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <p className="text-sm font-black text-green-600">+₹{ref.amount?.toFixed(2) || '2.00'}</p>
                                                </td>
                                                <td className="px-6 py-4 text-right">
                                                    <span className="inline-block px-2 py-1 bg-green-50 text-green-600 text-[10px] font-black rounded-lg uppercase border border-green-100">Settled</span>
                                                </td>
                                            </tr>
                                        ))}
                                        {referrals.length === 0 && !loading && (
                                            <tr>
                                                <td colSpan={4} className="px-6 py-16 text-center">
                                                    <div className="flex flex-col items-center justify-center gap-4 text-gray-400">
                                                        <span className="material-symbols-outlined text-6xl opacity-20">rocket_launch</span>
                                                        <p className="font-bold">No referrals yet. Start sharing to earn!</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        )}
                                        {loading && (
                                            <tr>
                                                <td colSpan={4} className="px-6 py-16 text-center">
                                                    <div className="w-8 h-8 border-4 border-red-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    {/* Referral Info / FAQ */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="glass-card p-8 bg-gray-900 text-white space-y-4">
                            <h4 className="text-lg font-black flex items-center gap-2">
                                <span className="material-symbols-outlined text-yellow-400">info</span>
                                How it works?
                            </h4>
                            <p className="text-gray-400 text-sm leading-relaxed font-medium">
                                Share your link with friends. You get <span className="text-white font-bold">₹2</span> as soon as they sign up. You get an additional <span className="text-white font-bold">₹3</span> when they publish their first news post. Plus, for every 10 friends you refer, we give you a <span className="text-yellow-400 font-bold">₹10 Milestone Bonus</span>!
                            </p>
                        </div>
                        <div className="glass-card p-8 bg-red-50 border border-red-100 space-y-4">
                            <h4 className="text-lg font-black text-red-600 flex items-center gap-2">
                                <span className="material-symbols-outlined">security</span>
                                Fair Play Policy
                            </h4>
                            <p className="text-red-900/60 text-sm leading-relaxed font-medium">
                                To maintain the health of our community, only real user sign-ups are eligible for the bonus. Any attempt to use bots, fake accounts, or multiple IDs to exploit the program will result in immediate account termination and forfeiture of earnings.
                            </p>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    );
};

export default ReferralPage;
