
import React, { useState, useEffect, useRef } from 'react';
import { User, View, Post, Draft, Video } from '../types';
import { motion } from 'motion/react';
import Header from '../components/Header';
import { auth, db, storage } from '../firebaseConfig';
import ConfirmationModal from '../components/ConfirmationModal';
import UserListModal from '../components/UserListModal';
import UserAvatar from '../components/UserAvatar';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import { formatCount } from '../utils/formatters';
import { useUploadingVideos, uploadManager } from '../services/uploadManager';
import appCacheService from '../services/appCacheService';

interface UserPageProps {
  onBack: () => void;
  currentUser: User | null;
  onLogout: () => void;
  onNavigate: (view: View, params?: any) => void;
  onEditPost: (postId: string) => void;
  onViewPost: (postId: string) => void;
  onViewUser: (userId: string) => void;
  initialTab?: 'posts' | 'drafts';
}

const StatBox: React.FC<{ value: number; label: string; onClick?: () => void }> = ({ value, label, onClick }) => (
    <div 
        onClick={onClick}
        className={`flex flex-col items-center justify-center p-3 bg-gray-50 rounded-xl min-w-[80px] border border-gray-100 transition-all duration-200 ${onClick ? 'cursor-pointer hover:bg-blue-50 hover:border-blue-100 hover:scale-105 active:scale-95' : ''}`}
    >
        <p className={`text-2xl font-bold ${onClick ? 'text-blue-900' : 'text-gray-900'}`}>{formatCount(value)}</p>
        <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</p>
    </div>
);

const SkeletonPost = () => (
    <div className="glass-card flex flex-col overflow-hidden h-full animate-pulse border border-gray-100">
        <div className="h-40 w-full bg-gray-200"></div>
        <div className="p-4 space-y-2">
            <div className="h-4 w-3/4 bg-gray-200 rounded"></div>
            <div className="h-3 w-1/2 bg-gray-200 rounded"></div>
        </div>
        <div className="p-3 border-t border-gray-100 bg-gray-50 flex justify-end gap-2">
            <div className="h-8 w-8 bg-gray-200 rounded-full"></div>
            <div className="h-8 w-8 bg-gray-200 rounded-full"></div>
        </div>
    </div>
);

const UserPage: React.FC<UserPageProps> = ({ onBack, currentUser, onLogout, onNavigate, onEditPost, onViewPost, onViewUser, initialTab }) => {
    const cachedPosts = currentUser ? appCacheService.getUserPosts(currentUser.uid) : [];
    const cachedDrafts = currentUser ? appCacheService.getUserDrafts(currentUser.uid) : [];
    const cachedVideos = currentUser ? appCacheService.getUserVideos(currentUser.uid) : [];

    const [posts, setPosts] = useState<Post[]>(() => cachedPosts);
    const [drafts, setDrafts] = useState<Draft[]>(() => cachedDrafts);
    const [userVideos, setUserVideos] = useState<Video[]>(() => cachedVideos);
    const uploadingVideos = useUploadingVideos();
    const [followersCount, setFollowersCount] = useState(() => currentUser?.followerCount || 0);
    const [followingCount, setFollowingCount] = useState(() => currentUser?.followingCount || 0);
    const [loading, setLoading] = useState(() => cachedPosts.length === 0 && cachedVideos.length === 0);
    
    // Modals
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [postToDelete, setPostToDelete] = useState<{ id: string; thumbnailUrl: string } | null>(null);
    
    const [isDeleteDraftModalOpen, setIsDeleteDraftModalOpen] = useState(false);
    const [draftToDelete, setDraftToDelete] = useState<{ id: string; thumbnailUrl: string } | null>(null);

    const [isDeleteVideoModalOpen, setIsDeleteVideoModalOpen] = useState(false);
    const [videoToDelete, setVideoToDelete] = useState<{ id: string; videoUrl: string; thumbnailUrl: string } | null>(null);
    const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);

    // Video editing states
    const [isEditVideoModalOpen, setIsEditVideoModalOpen] = useState(false);
    const [videoToEdit, setVideoToEdit] = useState<Video | null>(null);
    const [editVideoTitle, setEditVideoTitle] = useState('');
    const [editVideoDescription, setEditVideoDescription] = useState('');
    const [editVideoCategory, setEditVideoCategory] = useState('');
    const [isSavingVideoEdit, setIsSavingVideoEdit] = useState(false);

    // State for User List Modal
    const [activeList, setActiveList] = useState<'followers' | 'following' | null>(null);
    
    // Tab State: 'posts', 'videos' or 'drafts'
    const [activeTab, setActiveTab] = useState<'posts' | 'videos' | 'drafts'>('posts');

    // Long press options states
    const [longPressedItem, setLongPressedItem] = useState<{
        type: 'post' | 'video';
        id: string;
        isPinned: boolean;
        thumbnailUrl?: string;
        title: string;
    } | null>(null);

    const timerRef = useRef<NodeJS.Timeout | null>(null);
    const isLongPress = useRef(false);
    const touchStartCoords = useRef<{ x: number; y: number } | null>(null);
    const hasMoved = useRef(false);

    const handlePressStart = (item: { type: 'post' | 'video'; id: string; isPinned: boolean; thumbnailUrl?: string; title: string }) => {
        isLongPress.current = false;
        timerRef.current = setTimeout(() => {
            isLongPress.current = true;
            setLongPressedItem(item);
            if (navigator.vibrate) {
                navigator.vibrate(50);
            }
        }, 600);
    };

    const handleTouchStartCustom = (e: React.TouchEvent, item: { type: 'post' | 'video'; id: string; isPinned: boolean; thumbnailUrl?: string; title: string }) => {
        const touch = e.touches[0];
        touchStartCoords.current = { x: touch.clientX, y: touch.clientY };
        hasMoved.current = false;
        handlePressStart(item);
    };

    const handleTouchMoveCustom = (e: React.TouchEvent) => {
        if (!touchStartCoords.current) return;
        const touch = e.touches[0];
        const dx = Math.abs(touch.clientX - touchStartCoords.current.x);
        const dy = Math.abs(touch.clientY - touchStartCoords.current.y);
        if (dx > 10 || dy > 10) {
            hasMoved.current = true;
            if (timerRef.current) {
                clearTimeout(timerRef.current);
            }
        }
    };

    const handleMouseDownCustom = (e: React.MouseEvent, item: { type: 'post' | 'video'; id: string; isPinned: boolean; thumbnailUrl?: string; title: string }) => {
        touchStartCoords.current = { x: e.clientX, y: e.clientY };
        hasMoved.current = false;
        handlePressStart(item);
    };

    const handleMouseMoveCustom = (e: React.MouseEvent) => {
        if (!touchStartCoords.current) return;
        const dx = Math.abs(e.clientX - touchStartCoords.current.x);
        const dy = Math.abs(e.clientY - touchStartCoords.current.y);
        if (dx > 10 || dy > 10) {
            hasMoved.current = true;
            if (timerRef.current) {
                clearTimeout(timerRef.current);
            }
        }
    };

    const handlePressEnd = (e: React.MouseEvent | React.TouchEvent | React.PointerEvent, onClick: () => void) => {
        if (timerRef.current) {
            clearTimeout(timerRef.current);
        }
        touchStartCoords.current = null;
        if (hasMoved.current) {
            hasMoved.current = false;
            return;
        }
        if (!isLongPress.current) {
            onClick();
        } else {
            e.preventDefault();
            e.stopPropagation();
        }
    };

    const handlePinToggle = async (item: { type: 'post' | 'video'; id: string; isPinned: boolean }) => {
        if (!currentUser) return;
        
        if (item.isPinned) {
            try {
                const collection = item.type === 'post' ? 'posts' : 'videos';
                await db.collection(collection).doc(item.id).update({ isPinned: false });
                showToast("Item unpinned successfully!", "success");
            } catch (err: any) {
                console.error("Error unpinning item:", err);
                showToast("Failed to unpin item.", "error");
            }
            setLongPressedItem(null);
            return;
        }

        // Constraints: max 3 total pins, max 2 of any single type
        const pinnedPostsCount = posts.filter(p => p.isPinned).length;
        const pinnedVideosCount = userVideos.filter(v => v.isPinned).length;
        const totalPinned = pinnedPostsCount + pinnedVideosCount;

        if (totalPinned >= 3) {
            showToast("Maximum of 3 pinned items allowed on profile.", "error");
            setLongPressedItem(null);
            return;
        }

        if (item.type === 'post' && pinnedPostsCount >= 2) {
            showToast("Maximum of 2 pinned articles allowed.", "error");
            setLongPressedItem(null);
            return;
        }

        if (item.type === 'video' && pinnedVideosCount >= 2) {
            showToast("Maximum of 2 pinned videos allowed.", "error");
            setLongPressedItem(null);
            return;
        }

        try {
            const collection = item.type === 'post' ? 'posts' : 'videos';
            await db.collection(collection).doc(item.id).update({ isPinned: true });
            showToast("Item pinned to top of profile!", "success");
        } catch (err: any) {
            console.error("Error pinning item:", err);
            showToast("Failed to pin item.", "error");
        }
        setLongPressedItem(null);
    };

    const { t } = useLanguage();
    const { showToast } = useToast();

    // Sync total views for monetization eligibility
    useEffect(() => {
        if (!currentUser || posts.length === 0) return;
        const total = posts.reduce((sum, post) => sum + (post.viewCount || 0), 0);
        if (total !== currentUser.totalViews) {
            db.collection('users').doc(currentUser.uid).update({ totalViews: total });
        }
    }, [posts, currentUser?.uid]);

    // Handle initial tab from props
    useEffect(() => {
        if (initialTab) {
            setActiveTab(initialTab);
        }
    }, [initialTab]);
    
    useEffect(() => {
        if (!currentUser) return;
        if (posts.length === 0 && userVideos.length === 0) {
            setLoading(true);
        }

        // Real-time posts
        const postsQuery = db.collection("posts").where("authorId", "==", currentUser.uid);

        const unsubscribePosts = postsQuery.onSnapshot((snapshot) => {
            const userPosts = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title,
                    content: data.content,
                    thumbnailUrl: data.thumbnailUrl,
                    authorId: data.authorId,
                    authorName: data.authorName,
                    authorProfilePicUrl: data.authorProfilePicUrl,
                    viewCount: data.viewCount || 0,
                    shareCount: data.shareCount || 0,
                    category: data.category || 'General',
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
                    locationType: data.locationType || 'Overall',
                    state: data.state || '',
                    district: data.district || '',
                    block: data.block || '',
                    isPinned: data.isPinned || false,
                } as Post
            });
            
            userPosts.sort((a, b) => {
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                const dateA = a.createdAt ? a.createdAt.getTime() : 0;
                const dateB = b.createdAt ? b.createdAt.getTime() : 0;
                return dateB - dateA;
            });

            setPosts(userPosts);
            appCacheService.setUserPosts(currentUser.uid, userPosts);
            setLoading(false);
        }, (error) => {
            console.error("Error fetching user posts:", error);
            showToast("Could not load your posts.", "error");
            setLoading(false);
        });

        // Real-time drafts
        const draftsQuery = db.collection("users").doc(currentUser.uid).collection("drafts");
        const unsubscribeDrafts = draftsQuery.onSnapshot((snapshot) => {
            const userDrafts = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title,
                    content: data.content,
                    category: data.category,
                    thumbnailUrl: data.thumbnailUrl,
                    state: data.state,
                    district: data.district,
                    block: data.block,
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
                    updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : null,
                } as Draft
            });
            // Sort drafts by updated or created date, newest first
            userDrafts.sort((a, b) => {
                const dateA = a.updatedAt ? a.updatedAt.getTime() : (a.createdAt ? a.createdAt.getTime() : 0);
                const dateB = b.updatedAt ? b.updatedAt.getTime() : (b.createdAt ? b.createdAt.getTime() : 0);
                return dateB - dateA;
            });
            setDrafts(userDrafts);
            appCacheService.setUserDrafts(currentUser.uid, userDrafts);
        }, (error) => {
            console.error("Error fetching drafts:", error);
            if (error.code === 'permission-denied') {
                console.warn("Permission denied for drafts. Check Firestore rules.");
            }
        });

        // Real-time followers count
        const followersQuery = db.collection("users").doc(currentUser.uid).collection("followers");
        const unsubscribeFollowers = followersQuery.onSnapshot((snapshot) => {
            setFollowersCount(snapshot.size);
        }, (error) => {
            console.error("Error fetching followers count:", error);
        });

        // Real-time following count
        const followingQuery = db.collection("users").doc(currentUser.uid).collection("following");
        const unsubscribeFollowing = followingQuery.onSnapshot((snapshot) => {
            setFollowingCount(snapshot.size);
        }, (error) => {
            console.error("Error fetching following count:", error);
        });

        // Real-time videos
        const videosQuery = db.collection("videos").where("authorId", "==", currentUser.uid);
        const unsubscribeVideos = videosQuery.onSnapshot((snapshot) => {
            const fetchedVideos = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title || '',
                    description: data.description || '',
                    videoUrl: data.videoUrl || '',
                    thumbnailUrl: data.thumbnailUrl || '',
                    authorId: data.authorId || '',
                    authorName: data.authorName || '',
                    authorProfilePicUrl: data.authorProfilePicUrl || '',
                    viewCount: data.viewCount || 0,
                    likeCount: data.likeCount || 0,
                    commentCount: data.commentCount || 0,
                    shareCount: data.shareCount || 0,
                    category: data.category || 'General',
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
                    locationType: data.locationType || 'Overall',
                    state: data.state || '',
                    district: data.district || '',
                    block: data.block || '',
                    isPinned: data.isPinned || false,
                } as Video;
            });
            
            fetchedVideos.sort((a, b) => {
                if (a.isPinned && !b.isPinned) return -1;
                if (!a.isPinned && b.isPinned) return 1;
                const dateA = a.createdAt ? a.createdAt.getTime() : 0;
                const dateB = b.createdAt ? b.createdAt.getTime() : 0;
                return dateB - dateA;
            });

            setUserVideos(fetchedVideos);
            appCacheService.setUserVideos(currentUser.uid, fetchedVideos);
        }, (error) => {
            console.error("Error fetching user videos:", error);
        });

        return () => {
            unsubscribePosts();
            unsubscribeDrafts();
            unsubscribeFollowers();
            unsubscribeFollowing();
            unsubscribeVideos();
        };
    }, [currentUser]);
    
    // --- Post Deletion ---
    const handleDeletePost = async () => {
        if (!postToDelete) return;

        try {
            // 1. Delete Firestore Document (Priority)
            await db.collection("posts").doc(postToDelete.id).delete();
            
            // 2. Try to delete Storage Image (Best Effort)
            if (postToDelete.thumbnailUrl && postToDelete.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                try {
                    const storageRef = storage.refFromURL(postToDelete.thumbnailUrl);
                    await storageRef.delete();
                } catch (storageErr) {
                    console.warn("Post deleted but thumbnail cleanup failed (likely permission):", storageErr);
                }
            }
            showToast("Post deleted successfully.", "success");

        } catch (error: any) {
            console.error("Error deleting post:", error);
            showToast(`Failed to delete post: ${error.message || "Unknown error"}`, "error");
        } finally {
            setIsDeleteModalOpen(false);
            setPostToDelete(null);
        }
    };
    
    const openDeleteModal = (postId: string, thumbnailUrl: string) => {
        setPostToDelete({ id: postId, thumbnailUrl });
        setIsDeleteModalOpen(true);
    };

    // --- Draft Deletion ---
    const handleDeleteDraft = async () => {
        if (!draftToDelete || !currentUser) return;
        try {
            await db.collection("users").doc(currentUser.uid).collection("drafts").doc(draftToDelete.id).delete();
            // Try to delete thumbnail, but don't block if it fails or doesn't exist
            if (draftToDelete.thumbnailUrl && draftToDelete.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                 const storageRef = storage.refFromURL(draftToDelete.thumbnailUrl);
                 await storageRef.delete().catch(err => console.warn("Failed to delete draft image", err));
            }
            showToast("Draft discarded.", "success");
        } catch (error: any) {
            console.error("Error deleting draft:", error);
            showToast(`Failed to delete draft: ${error.message}`, "error");
        } finally {
            setIsDeleteDraftModalOpen(false);
            setDraftToDelete(null);
        }
    };

    const openDeleteDraftModal = (draftId: string, thumbnailUrl: string) => {
        setDraftToDelete({ id: draftId, thumbnailUrl });
        setIsDeleteDraftModalOpen(true);
    };

    // --- Video Deletion ---
    const handleDeleteVideo = async () => {
        if (!videoToDelete) return;

        try {
            await db.collection("videos").doc(videoToDelete.id).delete();
            
            if (videoToDelete.videoUrl && videoToDelete.videoUrl.includes('firebasestorage.googleapis.com')) {
                try {
                    const storageRef = storage.refFromURL(videoToDelete.videoUrl);
                    await storageRef.delete();
                } catch (err) {
                    console.warn("Video deleted but file cleanup failed:", err);
                }
            }
            if (videoToDelete.thumbnailUrl && videoToDelete.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                try {
                    const storageRef = storage.refFromURL(videoToDelete.thumbnailUrl);
                    await storageRef.delete();
                } catch (err) {
                    console.warn("Video deleted but thumbnail cleanup failed:", err);
                }
            }
            showToast("Video deleted successfully.", "success");
        } catch (error: any) {
            console.error("Error deleting video:", error);
            showToast(`Failed to delete video: ${error.message}`, "error");
        } finally {
            setIsDeleteVideoModalOpen(false);
            setVideoToDelete(null);
        }
    };

    const openDeleteVideoModal = (videoId: string, videoUrl: string, thumbnailUrl: string) => {
        setVideoToDelete({ id: videoId, videoUrl, thumbnailUrl });
        setIsDeleteVideoModalOpen(true);
    };

    const handleSaveVideoEdit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!videoToEdit) return;
        if (!editVideoTitle.trim()) {
            showToast("Title is required", "error");
            return;
        }

        setIsSavingVideoEdit(true);
        try {
            await db.collection("videos").doc(videoToEdit.id).update({
                title: editVideoTitle.trim(),
                description: editVideoDescription.trim(),
                category: editVideoCategory
            });
            showToast("Video updated successfully.", "success");
            setIsEditVideoModalOpen(false);
            setVideoToEdit(null);
        } catch (error: any) {
            console.error("Error updating video:", error);
            showToast(`Failed to update video: ${error.message}`, "error");
        } finally {
            setIsSavingVideoEdit(false);
        }
    };

    const openEditVideoModal = (video: Video) => {
        setVideoToEdit(video);
        setEditVideoTitle(video.title);
        setEditVideoDescription(video.description || '');
        setEditVideoCategory(video.category);
        setIsEditVideoModalOpen(true);
    };

    const handleShareProfile = async () => {
        if (!currentUser) return;
        const shareUrl = `${window.location.origin}/?userId=${currentUser.uid}`;
        const text = `👤 *${currentUser.name}* - Public Tak App\n\nपब्लिक तक ऍप पर ${currentUser.name} की प्रोफ़ाइल देखें और उनके द्वारा पोस्ट की गई ताज़ा ख़बरों से जुड़े रहें।\n\n👉 *यहाँ देखें:* \n${shareUrl}`;
        
        if (navigator.share) {
            try {
                await navigator.share({
                    title: `${currentUser.name} - Public Tak App`,
                    text: text,
                });
            } catch (err: any) {
                if (err?.name !== 'AbortError') {
                    if (navigator.clipboard) {
                        try {
                            await navigator.clipboard.writeText(text);
                            showToast("प्रोफाइल लिंक कॉपी हो गया है!", "success");
                        } catch (_) {}
                    }
                    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
                    window.open(whatsappUrl, '_blank');
                }
            }
        } else {
            if (navigator.clipboard) {
                try {
                    await navigator.clipboard.writeText(text);
                    showToast("प्रोफाइल लिंक कॉपी हो गया है!", "success");
                } catch (_) {}
            }
            const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
            window.open(whatsappUrl, '_blank');
        }
    };


    if (!currentUser) {
        return (
            <div className="flex flex-col h-full bg-transparent">
                <Header title={t('profile')} showBackButton onBack={onBack} />
                <main className="flex-grow flex items-center justify-center">
                    <p className="text-gray-500">Please log in to view your profile.</p>
                </main>
            </div>
        )
    }

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header 
                title={t('myProfile')} 
                showBackButton 
                onBack={onBack} 
                showSettingsButton 
                onSettings={() => onNavigate(View.Settings)}
                onEPaper={() => onNavigate(View.EPaper)}
            />
            <main className="flex-grow overflow-y-auto pb-20 md:pb-0">
                <div className="max-w-7xl mx-auto w-full md:px-4 md:py-6">
                    
                    {/* Full Width Profile Header */}
                    <div className="glass-card overflow-hidden mb-8 mx-0 md:mx-0 rounded-none md:rounded-2xl border-x-0 md:border">
                        <div className="relative h-32 md:h-48 bg-gradient-to-r from-blue-600 to-indigo-600">
                             <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-black/30 to-transparent"></div>
                        </div>
                        
                        <div className="px-6 pb-6 md:px-8 md:pb-8 relative">
                            <div className="flex flex-col md:flex-row items-center md:items-end -mt-12 md:-mt-16 gap-4 md:gap-8">
                                {/* Avatar */}
                                <div className="relative group">
                                    <UserAvatar 
                                        userId={currentUser.uid}
                                        src={currentUser.profilePicUrl} 
                                        name={currentUser.name} 
                                        currentUser={currentUser}
                                        className="h-24 w-24 md:h-40 md:w-40 rounded-full object-cover ring-4 ring-white shadow-lg bg-white"
                                        alt={`${currentUser.name}'s profile picture`} 
                                    />
                                    <button 
                                        onClick={() => onNavigate(View.EditProfile)}
                                        className="absolute bottom-1 right-1 bg-white text-gray-700 p-1.5 rounded-full shadow-md hover:bg-gray-100 transition-colors border border-gray-200"
                                        title="Edit Photo"
                                    >
                                        <span className="material-symbols-outlined text-sm">edit</span>
                                    </button>
                                </div>
                                
                                {/* Info */}
                                <div className="flex-grow text-center md:text-left mb-2 md:mb-4">
                                    <div className="flex items-center justify-center md:justify-start gap-1">
                                        <h1 className="text-2xl md:text-4xl font-bold text-gray-900">{currentUser.name}</h1>
                                        {currentUser.isVerified && (
                                            <span className="material-symbols-outlined text-blue-500 text-2xl md:text-3xl font-bold" title="Verified Creator">verified</span>
                                        )}
                                    </div>
                                    <p className="text-blue-600 font-medium">@{currentUser.username}</p>
                                    
                                    <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mt-3">
                                        {currentUser.preferredState && (
                                            <div className="flex items-center gap-1 text-sm text-gray-500">
                                                <span className="material-symbols-outlined text-base">location_on</span>
                                                <span>{currentUser.preferredDistrict}, {currentUser.preferredState}</span>
                                            </div>
                                        )}
                                        {currentUser.kycStatus === 'verified' && (
                                            <div className="flex items-center gap-1 text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full border border-green-100 uppercase tracking-wider">
                                                <span className="material-symbols-outlined text-sm">verified_user</span>
                                                KYC Verified
                                            </div>
                                        )}
                                    </div>
                                    {currentUser.bio && <p className="mt-3 text-sm text-gray-600 max-w-prose line-clamp-2 md:line-clamp-none whitespace-pre-wrap">{currentUser.bio}</p>}
                                </div>

                                {/* Stats & Actions (Desktop) */}
                                <div className="flex flex-col items-end gap-4 w-full md:w-auto">
                                    <div className="flex justify-center w-full md:w-auto gap-4 md:gap-8 bg-white md:bg-transparent p-2 md:p-0 rounded-xl shadow-sm md:shadow-none border md:border-none border-gray-100">
                                        <StatBox value={posts.length} label={t('post')} />
                                        <StatBox value={userVideos.length} label={t('video') || 'Video'} />
                                        <StatBox 
                                            value={followersCount} 
                                            label={t('follow')} 
                                            onClick={() => setActiveList('followers')}
                                        />
                                        <StatBox 
                                            value={followingCount} 
                                            label={t('following')} 
                                            onClick={() => setActiveList('following')}
                                        />
                                    </div>
                                    
                                    <div className="hidden md:flex gap-3 w-full">
                                        <button 
                                            onClick={handleShareProfile}
                                            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-semibold rounded-lg transition-all shadow-sm"
                                        >
                                            <span className="material-symbols-outlined text-xl">share</span>
                                            Share Profile
                                        </button>

                                        <button 
                                            onClick={() => onNavigate(View.EditProfile)}
                                            className="flex-1 px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold rounded-lg transition-all"
                                        >
                                            {t('editProfile')}
                                        </button>
                                        {currentUser.role === 'admin' && (
                                            <button
                                                onClick={() => onNavigate(View.Admin)}
                                                className="flex-1 px-5 py-2.5 bg-gray-800 hover:bg-gray-900 text-white font-semibold rounded-lg transition-all shadow-md"
                                            >
                                                {t('adminPanel')}
                                            </button>
                                        )}
                                        {(currentUser.isMonetized || currentUser.role === 'admin') && (
                                            <button 
                                                onClick={() => onNavigate(View.CreatorDashboard)}
                                                className="px-5 py-2.5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold rounded-lg transition-all shadow-md flex items-center justify-center gap-2"
                                            >
                                                <span className="material-symbols-outlined text-[20px]">hub</span>
                                                Creator Hub
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                             
                             {/* Mobile Actions */}
                            <div className="mt-6 flex flex-wrap md:hidden gap-3">
                                 <button 
                                    onClick={handleShareProfile}
                                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-semibold rounded-lg shadow-sm transition-colors"
                                >
                                    <span className="material-symbols-outlined text-lg">share</span>
                                    Share
                                </button>

                                 <button 
                                    onClick={() => onNavigate(View.EditProfile)}
                                    className="flex-1 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold rounded-lg shadow-sm"
                                >
                                    {t('editProfile')}
                                </button>
                                 {currentUser.role === 'admin' && (
                                    <button
                                        onClick={() => onNavigate(View.Admin)}
                                        className="flex-1 px-4 py-2.5 bg-gray-800 text-white font-semibold rounded-lg shadow-sm"
                                    >
                                        {t('adminPanel')}
                                    </button>
                                 )}
                                 {(currentUser.isMonetized || currentUser.role === 'admin') && (
                                     <button 
                                         onClick={() => onNavigate(View.CreatorDashboard)}
                                         className="flex-1 px-4 py-2.5 bg-red-600 text-white font-bold rounded-lg shadow-sm flex items-center justify-center gap-1"
                                     >
                                         <span className="material-symbols-outlined text-sm">hub</span>
                                         Hub
                                     </button>
                                 )}
                                 <button 
                                     onClick={() => onNavigate(View.Referral)}
                                     className="hidden md:flex px-4 py-2.5 bg-yellow-400 text-gray-900 font-bold rounded-lg shadow-sm items-center justify-center gap-1"
                                 >
                                     <span className="material-symbols-outlined text-sm">celebration</span>
                                     Refer
                                 </button>
                                 <button 
                                     onClick={() => onNavigate(View.Withdrawal)}
                                     className="flex-1 px-4 py-2.5 bg-[#f0f2f5] hover:bg-red-50 text-gray-800 hover:text-red-600 font-bold rounded-xl shadow-sm flex items-center justify-center gap-1.5 transition-all transform active:scale-95 border border-gray-100"
                                 >
                                     <span className="material-symbols-outlined text-lg">account_balance_wallet</span>
                                     Wallet
                                 </button>
                            </div>
                        </div>
                    </div>

                    {/* Digital Media Reporter Card */}
                    <div className="px-4 md:px-0 mb-6">
                        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 rounded-3xl p-5 md:p-6 text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-5 border border-blue-800/60">
                            <div className="flex items-center gap-4 w-full md:w-auto">
                                <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center flex-shrink-0 text-amber-400">
                                    <span className="material-symbols-outlined text-3xl">badge</span>
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                        <span className="text-[10px] font-black uppercase tracking-wider bg-red-600 px-2 py-0.5 rounded-full text-white">
                                            DIGITAL MEDIA
                                        </span>
                                        {currentUser.reporterStatus === 'approved' && (
                                            <span className="text-[10px] font-bold bg-emerald-500 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                                                <span className="material-symbols-outlined text-[12px]">verified</span> Active
                                            </span>
                                        )}
                                        {currentUser.reporterStatus === 'pending' && (
                                            <span className="text-[10px] font-bold bg-amber-500 text-white px-2 py-0.5 rounded-full">
                                                Under e-KYC Review
                                            </span>
                                        )}
                                    </div>
                                    <h3 className="text-lg md:text-xl font-black text-white mt-1">
                                        {currentUser.reporterStatus === 'approved' 
                                            ? `${currentUser.reporterDesignation || 'Digital Media Reporter'}`
                                            : 'डिजिटल मीडिया रिपोर्टर पहचान पत्र'}
                                    </h3>
                                    <div className="flex items-center flex-wrap gap-1.5 mt-1">
                                        <p className="text-xs font-semibold text-blue-100 flex items-center gap-1.5">
                                            {currentUser.reporterStatus === 'approved' ? (
                                                `Reporter ID: ${currentUser.reporterIdNumber || 'PT-DM-VERIFIED'} • Valid ID Card`
                                            ) : (
                                                <>
                                                    <span className="inline-flex items-center gap-1 bg-amber-400/20 text-amber-300 font-bold px-2 py-0.5 rounded-md text-[11px] border border-amber-400/30">
                                                        <span className="material-symbols-outlined text-[13px]">verified_user</span> आधार + पैन e-KYC
                                                    </span>
                                                    <span>से 2 मिनट में आधिकारिक ID Card प्राप्त करें</span>
                                                </>
                                            )}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="flex flex-wrap gap-2.5 w-full md:w-auto">
                                {currentUser.reporterStatus === 'approved' ? (
                                    <button 
                                        onClick={() => onNavigate(View.ReporterIdCard)}
                                        className="w-full md:w-auto px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-black text-xs md:text-sm rounded-2xl shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        <span className="material-symbols-outlined text-lg">badge</span>
                                        ID Card डाउनलोड करें
                                    </button>
                                ) : currentUser.reporterStatus === 'pending' ? (
                                    <div className="flex gap-2 w-full md:w-auto">
                                        <button 
                                            onClick={() => onNavigate(View.ReporterIdCard)}
                                            className="flex-1 md:flex-none px-4 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl border border-white/20 transition-all flex items-center justify-center gap-1.5"
                                        >
                                            <span className="material-symbols-outlined text-base">visibility</span>
                                            ID Card प्रीव्यू
                                        </button>
                                        <button 
                                            onClick={() => onNavigate(View.ReporterRegistration)}
                                            className="flex-1 md:flex-none px-5 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-2xl shadow-md transition-all flex items-center justify-center gap-1.5"
                                        >
                                            <span className="material-symbols-outlined text-base">hourglass_top</span>
                                            स्टेटस देखें
                                        </button>
                                    </div>
                                ) : (
                                    <button 
                                        onClick={() => onNavigate(View.ReporterRegistration)}
                                        className="w-full md:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs md:text-sm rounded-2xl shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        <span className="material-symbols-outlined text-lg">how_to_reg</span>
                                        ID Card आवेदन करें (Apply)
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Digital Wallet Card - MOVED BELOW HEADER ACTIONS */}
                    <div className="px-4 md:px-0 mb-8 animate-in fade-in slide-in-from-top-4 duration-700">
                        <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-black rounded-3xl p-6 text-white shadow-2xl relative overflow-hidden group">
                            {/* Decorative background patterns */}
                            <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                            <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl -ml-24 -mb-24"></div>
                            
                            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
                                <div className="flex-grow space-y-1 text-center md:text-left w-full md:w-auto">
                                    <p className="text-gray-400 text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">Available balance</p>
                                    <div className="flex items-baseline justify-center md:justify-start gap-2">
                                        <span className="text-4xl md:text-5xl font-black tracking-tight">₹{currentUser.walletBalance?.toFixed(2) || '0.00'}</span>
                                        <div className="flex items-center gap-1 px-2 py-0.5 bg-green-500/20 text-green-400 text-[10px] font-bold rounded-full border border-green-500/30">
                                            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
                                            LIVE
                                        </div>
                                    </div>
                                    <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-3">
                                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-2xl text-xs font-semibold border border-white/5 backdrop-blur-md">
                                            <span className="material-symbols-outlined text-[18px] text-yellow-400">payments</span>
                                            Earned: ₹{currentUser.totalEarnings?.toFixed(2) || '0.00'}
                                        </div>
                                        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-2xl text-xs font-semibold border border-white/5 backdrop-blur-md">
                                            <span className="material-symbols-outlined text-[18px] text-blue-400">group</span>
                                            {currentUser.referralCount || 0} Referrals
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="flex flex-col sm:flex-row justify-center gap-3 w-full md:w-auto mt-2 md:mt-0">
                                    <button 
                                        onClick={() => onNavigate(View.Withdrawal)}
                                        className="flex-1 md:flex-none px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl shadow-xl transition-all transform active:scale-95 flex items-center justify-center gap-2"
                                    >
                                        <span className="material-symbols-outlined">account_balance_wallet</span>
                                        Withdrawal & KYC
                                    </button>
                                    <button 
                                        onClick={() => onNavigate(View.Referral)}
                                        className="hidden md:flex px-8 py-3.5 bg-white text-gray-900 font-black rounded-2xl shadow-xl transition-all transform active:scale-95 items-center justify-center gap-2"
                                    >
                                        <span className="material-symbols-outlined text-yellow-500">celebration</span>
                                        Refer & Earn
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {/* Content Section */}
                    <div className="px-4 md:px-0">
                        <div className="flex flex-row justify-between items-center mb-6 gap-3">
                             {/* Tabs */}
                             <div className="flex p-1 bg-gray-200 rounded-xl w-auto overflow-x-auto no-scrollbar">
                                <button 
                                    onClick={() => setActiveTab('posts')}
                                    className={`whitespace-nowrap px-4 sm:px-6 py-1.5 rounded-lg text-sm font-black transition-all ${
                                        activeTab === 'posts' 
                                        ? 'bg-white text-red-600 shadow-sm' 
                                        : 'text-gray-500 hover:text-gray-700'
                                    }`}
                                >
                                    {t('myPosts')} ({formatCount(posts.length)})
                                </button>
                                <button 
                                    onClick={() => setActiveTab('videos')}
                                    className={`whitespace-nowrap px-4 sm:px-6 py-1.5 rounded-lg text-sm font-black transition-all ${
                                        activeTab === 'videos' 
                                        ? 'bg-white text-red-600 shadow-sm' 
                                        : 'text-gray-500 hover:text-gray-700'
                                    }`}
                                >
                                    {t('video') || 'Video'} ({formatCount(userVideos.length)})
                                </button>
                                <button 
                                    onClick={() => setActiveTab('drafts')}
                                    className={`whitespace-nowrap px-4 sm:px-6 py-1.5 rounded-lg text-sm font-black transition-all ${
                                        activeTab === 'drafts' 
                                        ? 'bg-white text-red-600 shadow-sm' 
                                        : 'text-gray-500 hover:text-gray-700'
                                    }`}
                                >
                                    Drafts ({formatCount(drafts.length)})
                                </button>
                             </div>

                             <button
                                onClick={() => onNavigate(View.CreatePost)}
                                className="flex items-center gap-2 px-4 sm:px-6 py-2.5 bg-gradient-to-r from-red-600 to-red-700 text-white font-black rounded-xl shadow-lg shadow-red-500/20 hover:shadow-red-200 hover:scale-[1.05] transition-all transform active:scale-95 text-xs sm:text-sm whitespace-nowrap"
                             >
                                <span className="material-symbols-outlined text-[18px] sm:text-[20px]">add_circle</span>
                                {t('newPost')}
                             </button>
                        </div>
                        {/* POSTS TAB */}
                        {activeTab === 'posts' && (
                            <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-500">
                                {loading && posts.length === 0 ? (
                                    [...Array(6)].map((_, i) => (
                                        <div key={i} className="aspect-[3/4] bg-gray-200 animate-pulse rounded-2xl" />
                                    ))
                                ) : posts.length > 0 ? (
                                    posts.map((post, index) => (
                                        <div 
                                            key={post.id} 
                                            onMouseDown={(e) => handleMouseDownCustom(e, { type: 'post', id: post.id, isPinned: !!post.isPinned, thumbnailUrl: post.thumbnailUrl, title: post.title })}
                                            onMouseMove={handleMouseMoveCustom}
                                            onMouseUp={(e) => handlePressEnd(e, () => onViewPost(post.id))}
                                            onMouseLeave={() => { if (timerRef.current) clearTimeout(timerRef.current); }}
                                            onTouchStart={(e) => handleTouchStartCustom(e, { type: 'post', id: post.id, isPinned: !!post.isPinned, thumbnailUrl: post.thumbnailUrl, title: post.title })}
                                            onTouchMove={handleTouchMoveCustom}
                                            onTouchEnd={(e) => handlePressEnd(e, () => onViewPost(post.id))}
                                            className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-gray-950 cursor-pointer shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 select-none"
                                        >
                                            {post.thumbnailUrl ? (
                                                <img 
                                                    src={post.thumbnailUrl} 
                                                    alt={post.title} 
                                                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                                                />
                                            ) : (
                                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 gap-1 bg-gray-950">
                                                    <span className="material-symbols-outlined text-4xl">article</span>
                                                    <span className="text-[10px] font-bold text-gray-500">Article</span>
                                                </div>
                                            )}
                                            
                                            {/* Text and stats overlay on bottom half */}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-2 md:p-3 opacity-100">
                                                <h3 className="text-white text-[10px] sm:text-xs font-black line-clamp-2 leading-tight mb-1">{post.title}</h3>
                                                <div className="flex items-center justify-between text-[8px] sm:text-[10px] text-gray-300">
                                                     <span>{post.createdAt ? post.createdAt.toLocaleDateString() : 'N/A'}</span>
                                                     <div className="flex items-center gap-0.5">
                                                         <span className="material-symbols-outlined text-[10px] sm:text-xs text-gray-300">visibility</span>
                                                         <span>{formatCount(post.viewCount)}</span>
                                                     </div>
                                                </div>
                                            </div>

                                            {/* Pinned Badge */}
                                            {post.isPinned && (
                                                <div className="absolute top-2 left-2 bg-red-600 text-white p-1 rounded-full shadow-md flex items-center justify-center animate-pulse z-10" title="Pinned Post">
                                                    <span className="material-symbols-outlined text-[10px] sm:text-xs font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>push_pin</span>
                                                </div>
                                            )}

                                            {/* Category Badge */}
                                            <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md text-white/90 px-2 py-0.5 rounded text-[8px] sm:text-[10px] font-black uppercase tracking-wider">
                                                {post.category}
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="col-span-full text-center py-16 glass-card">
                                        <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-red-100 shadow-inner group">
                                             <span className="material-symbols-outlined text-5xl text-red-500 animate-pulse">post_add</span>
                                        </div>
                                        <h3 className="text-lg font-bold text-gray-800">No posts yet</h3>
                                        <p className="text-gray-500 mb-6">Share your first news with the community!</p>
                                        <button
                                            onClick={() => onNavigate(View.CreatePost)}
                                            className="px-8 py-3 bg-gradient-to-br from-red-600 to-red-700 text-white font-black rounded-2xl shadow-xl shadow-red-500/20 hover:shadow-red-500/30 hover:scale-[1.05] transition-all flex items-center justify-center gap-2 transform active:scale-95 mx-auto"
                                        >
                                            <span className="material-symbols-outlined">add_circle</span>
                                            Create First Post
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                        {/* VIDEOS TAB */}
                        {activeTab === 'videos' && (
                            <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-500">
                                {loading && userVideos.length === 0 && uploadingVideos.length === 0 ? (
                                    [...Array(6)].map((_, i) => (
                                        <div key={i} className="aspect-[3/4] bg-gray-200 animate-pulse rounded-2xl" />
                                    ))
                                ) : (userVideos.length > 0 || uploadingVideos.length > 0) ? (
                                    <>
                                        {/* Background Uploading Videos */}
                                        {uploadingVideos.map((upload) => {
                                            const radius = 22;
                                            const circumference = 2 * Math.PI * radius;
                                            const strokeDashoffset = circumference - (upload.progress / 100) * circumference;

                                            return (
                                                <div 
                                                    key={upload.id} 
                                                    className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 select-none cursor-default shadow-sm hover:shadow-md transition-all duration-300"
                                                >
                                                    {upload.thumbnailUrl ? (
                                                        <img 
                                                            src={upload.thumbnailUrl} 
                                                            alt={upload.title} 
                                                            className="w-full h-full object-cover opacity-40 blur-[0.5px]" 
                                                        />
                                                    ) : (
                                                        <div className="w-full h-full bg-slate-950 flex items-center justify-center opacity-30">
                                                            <span className="material-symbols-outlined text-4xl text-gray-500">movie</span>
                                                        </div>
                                                    )}

                                                    {/* Top Right Quick Cancel Button */}
                                                    <button 
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            e.preventDefault();
                                                            uploadManager.cancelUpload(upload.id);
                                                            showToast("Video upload cancelled", "info");
                                                        }}
                                                        className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-red-600 active:scale-90 text-white rounded-full transition-all duration-200 shadow-md hover:shadow-red-900/40 flex items-center justify-center z-20"
                                                        title="Cancel Upload"
                                                    >
                                                        <span className="material-symbols-outlined text-[12px] sm:text-[14px] font-bold">close</span>
                                                    </button>

                                                    {/* Central Loader and Circular Progress */}
                                                    <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[1px] flex flex-col items-center justify-center p-2 text-center gap-1.5 sm:gap-2">
                                                        
                                                        {/* Status Badge */}
                                                        <div className="bg-red-600/90 text-white font-black text-[8px] sm:text-[9px] uppercase px-2 py-0.5 rounded-full tracking-wider animate-pulse flex items-center gap-1">
                                                            <span className="material-symbols-outlined text-[10px] animate-spin">sync</span>
                                                            <span>{upload.stage || 'Uploading'}</span>
                                                        </div>

                                                        {/* Circular Progress SVG */}
                                                        <div className="relative w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center">
                                                            <svg className="w-full h-full transform -rotate-90">
                                                                <circle 
                                                                    cx="24" 
                                                                    cy="24" 
                                                                    r={radius} 
                                                                    className="stroke-gray-700/60" 
                                                                    strokeWidth="3.5" 
                                                                    fill="transparent" 
                                                                />
                                                                <circle 
                                                                    cx="24" 
                                                                    cy="24" 
                                                                    r={radius} 
                                                                    className="stroke-red-500 transition-all duration-300" 
                                                                    strokeWidth="3.5" 
                                                                    fill="transparent" 
                                                                    strokeDasharray={circumference}
                                                                    strokeDashoffset={strokeDashoffset}
                                                                    strokeLinecap="round"
                                                                />
                                                            </svg>
                                                            {/* Percent Text */}
                                                            <span className="absolute text-[9px] sm:text-[10px] font-black text-white">{upload.progress || 0}%</span>
                                                        </div>

                                                        {/* Title */}
                                                        <p className="text-[9px] sm:text-[10px] font-black text-white line-clamp-1 w-full px-1">{upload.title}</p>
                                                        
                                                        {upload.error && (
                                                            <span className="text-[7px] sm:text-[8px] font-bold text-red-400 bg-red-950/40 p-1 rounded border border-red-900/20 line-clamp-1 w-full leading-tight">
                                                                {upload.error}
                                                            </span>
                                                        )}

                                                        {/* Cancel Text Button */}
                                                        <button 
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                e.preventDefault();
                                                                uploadManager.cancelUpload(upload.id);
                                                                showToast("Video upload cancelled", "info");
                                                            }}
                                                            className="text-[8px] sm:text-[9px] text-gray-300 hover:text-white font-bold tracking-wide uppercase transition-all duration-200 px-2 py-0.5 rounded bg-red-600/20 hover:bg-red-600 border border-red-900/30 hover:border-red-500 active:scale-95 flex items-center gap-0.5"
                                                        >
                                                            <span className="material-symbols-outlined text-[10px] font-black">close</span>
                                                            <span>Cancel</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            );
                                        })}

                                        {/* Published Videos */}
                                        {userVideos.map((video) => (
                                            <div 
                                                key={video.id} 
                                                onMouseDown={(e) => handleMouseDownCustom(e, { type: 'video', id: video.id, isPinned: !!video.isPinned, thumbnailUrl: video.thumbnailUrl, title: video.title })}
                                                onMouseMove={handleMouseMoveCustom}
                                                onMouseUp={(e) => handlePressEnd(e, () => onNavigate(View.VideoHome, { videoId: video.id }))}
                                                onMouseLeave={() => { if (timerRef.current) clearTimeout(timerRef.current); }}
                                                onTouchStart={(e) => handleTouchStartCustom(e, { type: 'video', id: video.id, isPinned: !!video.isPinned, thumbnailUrl: video.thumbnailUrl, title: video.title })}
                                                onTouchMove={handleTouchMoveCustom}
                                                onTouchEnd={(e) => handlePressEnd(e, () => onNavigate(View.VideoHome, { videoId: video.id }))}
                                                className="group relative aspect-[3/4] rounded-2xl overflow-hidden bg-gray-900 cursor-pointer shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 select-none"
                                            >
                                                {video.thumbnailUrl ? (
                                                    <img 
                                                        src={video.thumbnailUrl} 
                                                        alt={video.title} 
                                                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                                                    />
                                                ) : (
                                                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 gap-1 bg-gray-950">
                                                        <span className="material-symbols-outlined text-4xl">movie</span>
                                                        <span className="text-[10px] font-bold text-gray-500">Bulletin</span>
                                                    </div>
                                                )}
                                                
                                                {/* Video Play Overlay Icon */}
                                                <div className="absolute inset-0 bg-black/25 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                                    <div className="bg-white/95 text-red-600 p-2 md:p-3 rounded-full shadow-lg transform scale-90 group-hover:scale-100 transition-transform duration-300 flex items-center justify-center">
                                                        <span className="material-symbols-outlined text-xl md:text-2xl font-bold fill-current">play_arrow</span>
                                                    </div>
                                                </div>

                                                {/* Pinned Badge */}
                                                {video.isPinned && (
                                                    <div className="absolute top-2 left-2 bg-red-600 text-white p-1 rounded-full shadow-md flex items-center justify-center animate-pulse z-10" title="Pinned Video">
                                                        <span className="material-symbols-outlined text-[10px] sm:text-xs font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>push_pin</span>
                                                    </div>
                                                )}

                                                {/* Top Category Badge */}
                                                <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md text-white/90 px-2 py-0.5 rounded text-[8px] md:text-[10px] font-black uppercase tracking-wider">
                                                    {video.category}
                                                </div>

                                                {/* Bottom Left View Count Overlay */}
                                                <div className="absolute bottom-2 left-2 bg-black/40 backdrop-blur-md text-white px-2 py-1 rounded-lg text-[9px] md:text-[11px] font-black flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[10px] md:text-xs text-white font-black">visibility</span>
                                                    <span>{formatCount(video.viewCount)}</span>
                                                </div>
                                            </div>
                                        ))}
                                    </>
                                ) : (
                                    <div className="col-span-full text-center py-16 glass-card">
                                        <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-red-100 shadow-inner group">
                                             <span className="material-symbols-outlined text-5xl text-red-500 animate-pulse">movie</span>
                                        </div>
                                        <h3 className="text-lg font-bold text-gray-800">No videos yet</h3>
                                        <p className="text-gray-500 mb-6">Create and upload your first video bulletin to your channel!</p>
                                        <button
                                            onClick={() => onNavigate(View.CreatePost)}
                                            className="px-8 py-3 bg-gradient-to-br from-red-600 to-red-700 text-white font-black rounded-2xl shadow-xl shadow-red-500/20 hover:shadow-red-500/30 hover:scale-[1.05] transition-all flex items-center justify-center gap-2 transform active:scale-95 mx-auto"
                                        >
                                            <span className="material-symbols-outlined">add_circle</span>
                                            Upload Video
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* DRAFTS TAB */}
                        {activeTab === 'drafts' && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
                                {drafts.length > 0 ? (
                                    drafts.map((draft) => (
                                        <div key={draft.id} className="glass-card flex flex-col overflow-hidden h-full group border border-dashed border-gray-300 bg-gray-50/50 hover:border-blue-300 hover:shadow-md transition-all">
                                            <div 
                                                onClick={() => onNavigate(View.CreatePost, { draftId: draft.id })} 
                                                className="cursor-pointer flex-grow relative"
                                            >
                                                <div className="overflow-hidden h-40 w-full bg-gray-200 relative group-hover:opacity-100 transition-all">
                                                    {draft.thumbnailUrl ? (
                                                        <img 
                                                            src={draft.thumbnailUrl} 
                                                            alt={draft.title} 
                                                            className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-300" 
                                                        />
                                                    ) : (
                                                        <div className="w-full h-full flex items-center justify-center text-gray-400 bg-gray-100">
                                                            <span className="material-symbols-outlined text-4xl opacity-50">draft</span>
                                                        </div>
                                                    )}
                                                    <div className="absolute top-2 left-2 bg-yellow-100/90 text-yellow-800 px-2 py-0.5 rounded text-xs font-bold border border-yellow-200 shadow-sm flex items-center gap-1">
                                                        <span className="material-symbols-outlined text-xs">edit_note</span>
                                                        Draft
                                                    </div>
                                                </div>
                                                
                                                <div className="p-4">
                                                    <h3 className="font-bold text-base text-gray-700 line-clamp-2 mb-2 group-hover:text-blue-600 transition-colors">
                                                        {draft.title || <span className="italic text-gray-400">Untitled Draft</span>}
                                                    </h3>
                                                    <div className="flex items-center text-xs text-gray-500 gap-1">
                                                        <span className="material-symbols-outlined text-[14px]">update</span>
                                                        <span>
                                                            {draft.updatedAt 
                                                                ? `Updated: ${new Date(draft.updatedAt).toLocaleDateString()}` 
                                                                : (draft.createdAt ? `Created: ${new Date(draft.createdAt).toLocaleDateString()}` : 'Just now')}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="p-3 border-t border-gray-200 flex justify-between items-center bg-white/50">
                                                <button 
                                                    onClick={() => onNavigate(View.CreatePost, { draftId: draft.id })} 
                                                    className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 px-3 py-1.5 rounded hover:bg-blue-50 transition-colors"
                                                >
                                                    <span className="material-symbols-outlined text-base">edit</span>
                                                    Resume
                                                </button>
                                                <button 
                                                    onClick={() => openDeleteDraftModal(draft.id, draft.thumbnailUrl)} 
                                                    className="p-2 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors"
                                                    title="Discard Draft"
                                                >
                                                    <span className="material-symbols-outlined text-lg">delete</span>
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="col-span-full text-center py-16 glass-card border border-dashed border-gray-300">
                                        <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-blue-100 shadow-inner group">
                                             <span className="material-symbols-outlined text-5xl text-blue-500 animate-pulse">drafts</span>
                                        </div>
                                        <h3 className="text-lg font-bold text-gray-800">No drafts saved</h3>
                                        <p className="text-gray-500 mb-6">Start writing a new post and save it for later.</p>
                                        <button
                                            onClick={() => onNavigate(View.CreatePost)}
                                            className="px-8 py-3 bg-gradient-to-br from-blue-600 to-indigo-700 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:shadow-blue-500/30 hover:scale-[1.05] transition-all flex items-center justify-center gap-2 transform active:scale-95 mx-auto"
                                        >
                                            <span className="material-symbols-outlined">edit_note</span>
                                            Start Writing News
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                    </div>
                </div>
            </main>
            
            {/* Post Delete Modal */}
            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleDeletePost}
                title="Confirm Deletion"
                message="Are you sure you want to delete this post? This action cannot be undone."
                confirmButtonText="Delete"
            />

            {/* Draft Delete Modal */}
            <ConfirmationModal
                isOpen={isDeleteDraftModalOpen}
                onClose={() => setIsDeleteDraftModalOpen(false)}
                onConfirm={handleDeleteDraft}
                title="Discard Draft"
                message="Are you sure you want to discard this draft? This action cannot be undone."
                confirmButtonText="Discard"
                confirmButtonColor="bg-red-600 hover:bg-red-700"
            />
            
            {/* User List Modal */}
            {activeList && currentUser && (
                <UserListModal
                    userId={currentUser.uid}
                    currentUser={currentUser}
                    type={activeList}
                    onClose={() => setActiveList(null)}
                    onViewUser={onViewUser}
                />
            )}

            {/* Custom Video Player Modal */}
            {selectedVideo && (
                <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-md animate-fade-in">
                    <div className="relative bg-gray-900 rounded-3xl overflow-hidden max-w-4xl w-full flex flex-col md:flex-row h-auto md:h-[600px] border border-gray-800 shadow-2xl">
                        {/* Close button */}
                        <button 
                            onClick={() => setSelectedVideo(null)}
                            className="absolute top-4 right-4 bg-black/50 hover:bg-black/85 text-white w-10 h-10 rounded-full flex items-center justify-center transition-colors z-10"
                        >
                            <span className="material-symbols-outlined">close</span>
                        </button>

                        {/* Video Section */}
                        <div className="flex-1 bg-black flex items-center justify-center h-[300px] md:h-full relative group">
                            <video 
                                src={selectedVideo.videoUrl} 
                                controls 
                                autoPlay 
                                className="w-full h-full object-contain"
                            />
                        </div>

                        {/* Info Section */}
                        <div className="w-full md:w-[350px] bg-gray-950 p-6 flex flex-col justify-between text-white border-t md:border-t-0 md:border-l border-gray-800 h-auto md:h-full">
                            <div className="space-y-4">
                                <div className="flex items-center gap-2">
                                    <span className="bg-red-600 text-white px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wider">
                                        {selectedVideo.category}
                                    </span>
                                    <span className="text-xs text-gray-400">
                                        {selectedVideo.createdAt ? new Date(selectedVideo.createdAt).toLocaleDateString() : 'N/A'}
                                    </span>
                                </div>
                                <h3 className="text-xl font-bold line-clamp-3 leading-snug">{selectedVideo.title}</h3>
                                {selectedVideo.description && (
                                    <p className="text-sm text-gray-400 line-clamp-6 leading-relaxed whitespace-pre-wrap overflow-y-auto max-h-[150px]">
                                        {selectedVideo.description}
                                    </p>
                                )}
                            </div>

                            <div className="border-t border-gray-800 pt-4 mt-6 space-y-4">
                                {/* Creator Info */}
                                <div className="flex items-center gap-3">
                                    <UserAvatar 
                                        userId={selectedVideo.authorId}
                                        src={selectedVideo.authorProfilePicUrl} 
                                        name={selectedVideo.authorName} 
                                        currentUser={currentUser}
                                        className="w-10 h-10 rounded-full object-cover border border-gray-800"
                                    />
                                    <div>
                                        <h4 className="font-bold text-sm text-white flex items-center gap-1">
                                            {selectedVideo.authorName}
                                            {selectedVideo.authorIsVerified && (
                                                <span className="material-symbols-outlined text-blue-500 text-sm font-bold">verified</span>
                                            )}
                                        </h4>
                                        <p className="text-xs text-gray-500">Video Creator</p>
                                    </div>
                                </div>

                                {/* Stats */}
                                <div className="flex items-center justify-between text-xs text-gray-400 bg-gray-900/50 p-3 rounded-xl border border-gray-800">
                                    <div className="flex items-center gap-1.5">
                                        <span className="material-symbols-outlined text-base text-gray-400">visibility</span>
                                        <span>{formatCount(selectedVideo.viewCount)} {t('views') || 'Views'}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <span className="material-symbols-outlined text-base text-red-500">favorite</span>
                                        <span>{formatCount(selectedVideo.likeCount || 0)} Likes</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <span className="material-symbols-outlined text-base text-blue-400">comment</span>
                                        <span>{formatCount(selectedVideo.commentCount || 0)}</span>
                                    </div>
                                </div>

                                {/* Edit & Delete Controls for Video Owner */}
                                <div className="grid grid-cols-2 gap-3 pt-2">
                                    <button
                                        onClick={() => {
                                            openEditVideoModal(selectedVideo);
                                            setSelectedVideo(null); // Close viewer to focus on editing modal
                                        }}
                                        className="flex items-center justify-center gap-1.5 py-2.5 px-4 bg-gray-800 hover:bg-gray-700 active:scale-95 transition-all text-white font-black rounded-xl text-xs border border-gray-700 shadow-lg"
                                    >
                                        <span className="material-symbols-outlined text-base">edit</span>
                                        Edit Details
                                    </button>
                                    <button
                                        onClick={() => {
                                            openDeleteVideoModal(selectedVideo.id, selectedVideo.videoUrl, selectedVideo.thumbnailUrl || '');
                                            setSelectedVideo(null); // Close viewer to let deletion modal be focused
                                        }}
                                        className="flex items-center justify-center gap-1.5 py-2.5 px-4 bg-red-600/90 hover:bg-red-700 active:scale-95 transition-all text-white font-black rounded-xl text-xs shadow-lg shadow-red-600/20"
                                    >
                                        <span className="material-symbols-outlined text-base">delete</span>
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Video Delete Modal */}
            <ConfirmationModal
                isOpen={isDeleteVideoModalOpen}
                onClose={() => setIsDeleteVideoModalOpen(false)}
                onConfirm={handleDeleteVideo}
                title="Delete Video Bulletin"
                message="Are you sure you want to delete this video bulletin? This action cannot be undone."
                confirmButtonText="Delete"
            />

            {/* Edit Video Modal */}
            {isEditVideoModalOpen && videoToEdit && (
                <div className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4 backdrop-blur-md animate-fade-in">
                    <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-gray-100 flex flex-col space-y-4 text-gray-800">
                        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                            <h3 className="text-xl font-bold flex items-center gap-2">
                                <span className="material-symbols-outlined text-red-600 font-bold">edit_square</span>
                                Edit Video Details
                            </h3>
                            <button 
                                onClick={() => {
                                    setIsEditVideoModalOpen(false);
                                    setVideoToEdit(null);
                                }}
                                className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-colors"
                            >
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>

                        <form onSubmit={handleSaveVideoEdit} className="space-y-4">
                            <div>
                                <label className="block text-xs font-black uppercase tracking-wider text-gray-500 mb-1.5">
                                    Video Title
                                </label>
                                <input
                                    type="text"
                                    value={editVideoTitle}
                                    onChange={(e) => setEditVideoTitle(e.target.value)}
                                    maxLength={200}
                                    placeholder="Enter video title..."
                                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:outline-none focus:border-red-500 focus:bg-white text-sm font-medium transition-all"
                                    required
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-black uppercase tracking-wider text-gray-500 mb-1.5">
                                    Description (Optional)
                                </label>
                                <textarea
                                    value={editVideoDescription}
                                    onChange={(e) => setEditVideoDescription(e.target.value)}
                                    rows={4}
                                    placeholder="Tell viewers about your video bulletin..."
                                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:outline-none focus:border-red-500 focus:bg-white text-sm font-medium transition-all resize-none"
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-black uppercase tracking-wider text-gray-500 mb-1.5">
                                    Category
                                </label>
                                <select
                                    value={editVideoCategory}
                                    onChange={(e) => setEditVideoCategory(e.target.value)}
                                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:outline-none focus:border-red-500 focus:bg-white text-sm font-bold transition-all"
                                >
                                    {['General', 'Politics', 'Crime', 'Sports', 'Entertainment', 'Business', 'Technology', 'Health', 'World'].map((cat) => (
                                        <option key={cat} value={cat}>{cat}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="flex gap-3 pt-2 border-t border-gray-100">
                                <button
                                    type="button"
                                    onClick={() => {
                                        setIsEditVideoModalOpen(false);
                                        setVideoToEdit(null);
                                    }}
                                    className="flex-1 py-3 px-4 bg-gray-100 hover:bg-gray-200 active:scale-95 text-gray-700 font-bold rounded-2xl text-sm transition-all"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={isSavingVideoEdit}
                                    className="flex-1 py-3 px-4 bg-gradient-to-r from-red-600 to-red-700 text-white font-black rounded-2xl text-sm shadow-lg shadow-red-500/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                                >
                                    {isSavingVideoEdit ? (
                                        <>
                                            <span className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                                            Saving...
                                        </>
                                    ) : (
                                        'Save Changes'
                                    )}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Long Press Options Modal */}
            {longPressedItem && (
                <div 
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in"
                    onClick={() => setLongPressedItem(null)}
                >
                    <div 
                        className="bg-white rounded-t-[32px] sm:rounded-3xl w-full sm:max-w-md p-6 shadow-2xl border-t sm:border border-gray-100 flex flex-col space-y-5 text-gray-800 animate-slide-up select-none"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                            <div className="flex items-center gap-3">
                                {longPressedItem.thumbnailUrl ? (
                                    <img 
                                        src={longPressedItem.thumbnailUrl} 
                                        alt="" 
                                        className="w-12 h-12 rounded-xl object-cover border border-gray-200"
                                    />
                                ) : (
                                    <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center text-gray-400">
                                        <span className="material-symbols-outlined">
                                            {longPressedItem.type === 'video' ? 'movie' : 'article'}
                                        </span>
                                    </div>
                                )}
                                <div className="max-w-[200px] sm:max-w-[240px]">
                                    <span className="text-[10px] font-black uppercase tracking-wider text-red-600 block">
                                        {longPressedItem.type === 'video' ? 'Video Bulletin' : 'Article Post'}
                                    </span>
                                    <h4 className="font-extrabold text-sm text-gray-900 line-clamp-1">
                                        {longPressedItem.title}
                                    </h4>
                                </div>
                            </div>
                            <button 
                                onClick={() => setLongPressedItem(null)}
                                className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
                            >
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>

                        <div className="flex flex-col gap-2">
                            {/* Pin / Unpin Button */}
                            <button
                                onClick={() => handlePinToggle(longPressedItem)}
                                className="w-full py-3 px-4 bg-gradient-to-r from-gray-50 to-gray-100/50 hover:from-red-50 hover:to-red-50/50 hover:text-red-600 font-extrabold rounded-2xl text-xs sm:text-sm transition-all flex items-center justify-between group border border-gray-100"
                            >
                                <div className="flex items-center gap-3">
                                    <span className={`material-symbols-outlined text-lg ${longPressedItem.isPinned ? 'text-red-600 animate-bounce' : 'text-gray-500 group-hover:text-red-600'}`}>
                                        push_pin
                                    </span>
                                    <span>{longPressedItem.isPinned ? 'Unpin from Top' : 'Pin to Top'}</span>
                                </div>
                                <span className="material-symbols-outlined text-sm text-gray-400 group-hover:translate-x-1 transition-transform">chevron_right</span>
                            </button>

                            {/* Edit Button */}
                            <button
                                onClick={() => {
                                    const itemId = longPressedItem.id;
                                    const itemType = longPressedItem.type;
                                    setLongPressedItem(null);
                                    if (itemType === 'post') {
                                        onEditPost(itemId);
                                    } else {
                                        const videoObj = userVideos.find(v => v.id === itemId);
                                        if (videoObj) {
                                            openEditVideoModal(videoObj);
                                        }
                                    }
                                }}
                                className="w-full py-3 px-4 bg-gradient-to-r from-gray-50 to-gray-100/50 hover:from-blue-50 hover:to-blue-50/50 hover:text-blue-600 font-extrabold rounded-2xl text-xs sm:text-sm transition-all flex items-center justify-between group border border-gray-100"
                            >
                                <div className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-lg text-gray-500 group-hover:text-blue-600">
                                        edit_square
                                    </span>
                                    <span>Edit Details</span>
                                </div>
                                <span className="material-symbols-outlined text-sm text-gray-400 group-hover:translate-x-1 transition-transform">chevron_right</span>
                            </button>

                            {/* Delete Button */}
                            <button
                                onClick={() => {
                                    const itemId = longPressedItem.id;
                                    const itemType = longPressedItem.type;
                                    const itemThumb = longPressedItem.thumbnailUrl || '';
                                    setLongPressedItem(null);
                                    if (itemType === 'post') {
                                        openDeleteModal(itemId, itemThumb);
                                    } else {
                                        const videoObj = userVideos.find(v => v.id === itemId);
                                        if (videoObj) {
                                            openDeleteVideoModal(videoObj.id, videoObj.videoUrl, videoObj.thumbnailUrl);
                                        }
                                    }
                                }}
                                className="w-full py-3 px-4 bg-gradient-to-r from-gray-50 to-gray-100/50 hover:from-red-50 hover:to-red-50/50 hover:text-red-600 font-extrabold rounded-2xl text-xs sm:text-sm transition-all flex items-center justify-between group border border-gray-100 text-red-600"
                            >
                                <div className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-lg text-red-600 font-bold">
                                        delete
                                    </span>
                                    <span>Delete Permanently</span>
                                </div>
                                <span className="material-symbols-outlined text-sm text-gray-400 group-hover:translate-x-1 transition-transform">chevron_right</span>
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserPage;
