import React, { useState, useEffect, useRef, useMemo, useLayoutEffect } from 'react';
import Header from '../components/Header';
import SEO from '../components/SEO';
import { User, EPaper, Post } from '../types';
import { db, storage, firebase } from '../firebaseConfig';
import { v4 as uuidv4 } from 'uuid';
import { useLanguage } from '../contexts/LanguageContext';
import { indianLocations } from '../utils/locations';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// @ts-ignore

interface EPaperPageProps {
  onBack: () => void;
  currentUser: User | null;
}

// Premium Newspaper Thumbnail fitting helper without any background blur
const renderPremiumThumbnail = (url: string | undefined, title: string, heightClass: string) => {
  if (!url) return null;
  return (
    <div className={`w-full ${heightClass} overflow-hidden rounded border border-gray-200 relative bg-white flex items-center justify-center mb-1.5 shrink-0`}>
      {/* Crisp centered foreground layer to show the FULL image without cropping and no blur background */}
      <img 
        src={url} 
        alt={title} 
        className="relative max-w-full max-h-full object-contain select-text z-10 p-0.5" 
        referrerPolicy="no-referrer"
      />
    </div>
  );
};

// Truncates text and appends a clickable [पूरा देखें] link to avoid scrolling
const renderArticleContent = (post: any, maxChars: number) => {
  const content = post.content || '';
  const cleanContent = content.replace(/<[^>]*>/g, '').trim();
  
  if (cleanContent.length <= maxChars) {
    return (
      <>
        {cleanContent}
        <a 
          href={`${window.location.origin}/?postId=${post.id}`} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="text-red-600 font-extrabold hover:underline ml-1 inline-flex items-center gap-0.5"
          style={{ textDecoration: 'none', color: '#dc2626' }}
        >
          [पूरा देखें]
        </a>
      </>
    );
  }
  
  const truncated = cleanContent.substring(0, maxChars);
  return (
    <>
      {truncated}...
      <a 
        href={`${window.location.origin}/?postId=${post.id}`} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-red-600 font-extrabold hover:underline ml-1 inline-flex items-center gap-0.5"
        style={{ textDecoration: 'none', color: '#dc2626' }}
      >
        [पूरा देखें]
      </a>
    </>
  );
};

// Dynamic font sizing based on Hindi text length to make sure text is fully visible in set layouts
const getS0Font = (text: string | undefined, hasThumb: boolean) => {
  const len = text ? text.length : 0;
  if (hasThumb) {
    if (len > 1200) return 'text-[6.5px] leading-tight';
    if (len > 800) return 'text-[7.5px] leading-snug';
    if (len > 500) return 'text-[8.5px] leading-normal';
    return 'text-[9.5px] leading-relaxed';
  } else {
    if (len > 1600) return 'text-[7px] leading-tight';
    if (len > 1000) return 'text-[8.5px] leading-snug';
    if (len > 600) return 'text-[9.5px] leading-normal';
    return 'text-[11px] leading-relaxed';
  }
};

const getS1Font = (text: string | undefined, hasThumb: boolean) => {
  const len = text ? text.length : 0;
  if (hasThumb) {
    if (len > 1000) return 'text-[6.5px] leading-tight';
    if (len > 700) return 'text-[7.5px] leading-snug';
    if (len > 400) return 'text-[8.5px] leading-normal';
    return 'text-[9.5px] leading-relaxed';
  } else {
    if (len > 1500) return 'text-[7px] leading-tight';
    if (len > 900) return 'text-[8.5px] leading-snug';
    if (len > 500) return 'text-[9.5px] leading-normal';
    return 'text-[11px] leading-relaxed';
  }
};

const getS2Font = (text: string | undefined, hasThumb: boolean) => {
  const len = text ? text.length : 0;
  if (hasThumb) {
    if (len > 900) return 'text-[6.5px] leading-tight';
    if (len > 600) return 'text-[7.5px] leading-snug';
    if (len > 400) return 'text-[8.5px] leading-normal';
    return 'text-[9.5px] leading-relaxed';
  } else {
    if (len > 1200) return 'text-[7px] leading-tight';
    if (len > 800) return 'text-[8.5px] leading-snug';
    if (len > 500) return 'text-[9.5px] leading-normal';
    return 'text-[11px] leading-relaxed';
  }
};

const getS3Font = (text: string | undefined, hasThumb: boolean) => {
  const len = text ? text.length : 0;
  if (hasThumb) {
    if (len > 800) return 'text-[6.5px] leading-tight';
    if (len > 500) return 'text-[7.5px] leading-snug';
    if (len > 300) return 'text-[8.5px] leading-normal';
    return 'text-[9.5px] leading-relaxed';
  } else {
    if (len > 1000) return 'text-[7px] leading-tight';
    if (len > 600) return 'text-[8px] leading-snug';
    if (len > 400) return 'text-[9px] leading-normal';
    return 'text-[10px] leading-relaxed';
  }
};

const getBottomFont = (text: string | undefined, hasThumb: boolean) => {
  const len = text ? text.length : 0;
  if (hasThumb) {
    if (len > 800) return 'text-[6.5px] leading-tight';
    if (len > 500) return 'text-[7.5px] leading-snug';
    if (len > 300) return 'text-[8.5px] leading-normal';
    return 'text-[9px] leading-relaxed';
  } else {
    if (len > 1000) return 'text-[7px] leading-tight';
    if (len > 600) return 'text-[8px] leading-snug';
    if (len > 400) return 'text-[9px] leading-normal';
    return 'text-[10px] leading-relaxed';
  }
};

// --- DYNAMIC GRID & BOX LAYOUT HELPERS (Module Level) ---
const getPageRows = (pageLayout: any) => {
  if (pageLayout.rows && pageLayout.rows.length > 0) {
    return pageLayout.rows;
  }
  // Backward compatibility conversion of old fixed 3-row layout structure
  const r1Height = pageLayout.row1Height || 320;
  const r2Height = pageLayout.row2Height || 320;
  const r3Height = pageLayout.row3Height || 312;
  const split = pageLayout.row2Split || 50;

  return [
    {
      id: 'row-1',
      height: r1Height,
      cols: [
        { id: 'slot1', width: 100 }
      ]
    },
    {
      id: 'row-2',
      height: r2Height,
      cols: [
        { id: 'slot2', width: split },
        { id: 'slot3', width: 100 - split }
      ]
    },
    {
      id: 'row-3',
      height: r3Height,
      cols: [
        { id: 'slot4', width: 100 }
      ]
    }
  ];
};

const getPageFloatingBoxes = (pageLayout: any) => {
  if (pageLayout.floatingBoxes && pageLayout.floatingBoxes.length > 0) {
    return pageLayout.floatingBoxes;
  }
  return [];
};

// Auto-sizing text component to automatically scale content to fit its box
const AutoFitText: React.FC<{
  columnCount: number;
  maxFontSize?: number;
  minFontSize?: number;
  lineHeight?: string;
  containerWidth: number;
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}> = ({ 
  columnCount, 
  maxFontSize = 18, 
  minFontSize = 3.5, 
  lineHeight = '1.35', 
  containerWidth, 
  children, 
  onClick, 
  className 
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [fontSize, setFontSize] = useState<number>(10);

  useLayoutEffect(() => {
    const el = containerRef.current;
    if (!el || el.clientWidth === 0 || el.clientHeight === 0) return;

    let low = minFontSize;
    let high = Math.max(maxFontSize, 24);
    let bestSize = minFontSize;

    const checkOverflow = (size: number) => {
      el.style.fontSize = `${size}px`;
      if (columnCount > 1) {
        return el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1;
      } else {
        return el.scrollHeight > el.clientHeight + 1;
      }
    };

    // 10 iterations of binary search for high accuracy (approx 0.02px steps)
    for (let i = 0; i < 10; i++) {
      const mid = (low + high) / 2;
      if (checkOverflow(mid)) {
        high = mid;
      } else {
        bestSize = mid;
        low = mid;
      }
    }

    setFontSize(bestSize);
    el.style.fontSize = `${bestSize}px`;
  }, [children, columnCount, maxFontSize, minFontSize, containerWidth]);

  return (
    <div 
      ref={containerRef}
      style={{
        fontSize: `${fontSize}px`,
        lineHeight: lineHeight,
        columnCount: columnCount,
        columnGap: '12px',
        columnRule: columnCount > 1 ? '1px solid rgba(0, 0, 0, 0.15)' : 'none',
        columnFill: 'auto',
        height: '100%',
        width: '100%',
        overflow: 'hidden',
      }}
      onClick={onClick}
      className={className}
    >
      {children}
    </div>
  );
};

const EPaperPage: React.FC<EPaperPageProps> = ({ onBack, currentUser }) => {
  const { t, language } = useLanguage();
  const isAdmin = currentUser?.role === 'admin';
  const [selectedPageNum, setSelectedPageNum] = useState<number>(0); // Page index in auto mode

  // --- EPAPER DYNAMIC LAYOUT ENGINE ---
  const [layouts, setLayouts] = useState<Record<string, any>>({});
  const [loadingLayouts, setLoadingLayouts] = useState<boolean>(true);
  const [isEditingLayout, setIsEditingLayout] = useState<boolean>(false);
  const [selectedEditSlot, setSelectedEditSlot] = useState<string | null>('slot1');
  const [uploadingAdSlotKey, setUploadingAdSlotKey] = useState<string | null>(null);
  const [adUploadProgress, setAdUploadProgress] = useState<number | null>(null);

  const getDefaultLayout = (pageId: string) => ({
    pageId,
    row1Height: 320,
    row2Height: 320,
    row3Height: 312,
    row2Split: 50,
    slots: {
      slot1: {
        type: 'article',
        postId: '',
        fontSizeTitle: 14,
        fontSizeBody: 9.5,
        columnCount: 3,
        showThumbnail: true,
        thumbnailWidth: 35,
        thumbnailPosition: 'right',
      },
      slot2: {
        type: 'article',
        postId: '',
        fontSizeTitle: 12.5,
        fontSizeBody: 8.5,
        columnCount: 1,
        showThumbnail: true,
        thumbnailWidth: 100,
        thumbnailPosition: 'top',
      },
      slot3: {
        type: 'article',
        postId: '',
        fontSizeTitle: 12.5,
        fontSizeBody: 8.5,
        columnCount: 1,
        showThumbnail: true,
        thumbnailWidth: 100,
        thumbnailPosition: 'top',
      },
      slot4: {
        type: 'article',
        postId: '',
        fontSizeTitle: 13,
        fontSizeBody: 9.5,
        columnCount: 3,
        showThumbnail: true,
        thumbnailWidth: 35,
        thumbnailPosition: 'right',
      },
    }
  });

  const activePageId = `page_${selectedPageNum}`;
  const layout = useMemo(() => {
    return layouts[activePageId] || (selectedPageNum > 0 ? layouts['page_1'] : null) || getDefaultLayout(activePageId);
  }, [layouts, activePageId, selectedPageNum]);

  const pageRows = getPageRows(layout);

  const updateActiveLayout = (updates: Partial<any> | ((prevLayout: any) => Partial<any>)) => {
    setLayouts((prev) => {
      const currentLayout = prev[activePageId] || getDefaultLayout(activePageId);
      const resolvedUpdates = typeof updates === 'function' ? updates(currentLayout) : updates;
      return {
        ...prev,
        [activePageId]: {
          ...currentLayout,
          ...resolvedUpdates,
        }
      };
    });
  };

  const updateSlotConf = (slotKey: string, slotUpdates: Partial<any>) => {
    updateActiveLayout((currentLayout) => {
      const currentSlots = currentLayout.slots || {};
      const currentSlot = currentSlots[slotKey] || getDefaultLayout(activePageId).slots[slotKey];
      return {
        slots: {
          ...currentSlots,
          [slotKey]: {
            ...currentSlot,
            ...slotUpdates,
          }
        }
      };
    });
  };

  // Keep a ref of the active layout to avoid stale state in mouse handlers and auto-saving
  const activeLayoutRef = useRef<any>(null);
  useEffect(() => {
    activeLayoutRef.current = layout;
  }, [layout]);

  // Debounced autosave effect to save the layout hamesha ke liye (forever)
  useEffect(() => {
    if (!isAdmin || !isEditingLayout || !layout) return;

    const timer = setTimeout(async () => {
      try {
        await db.collection('epaper_layouts').doc(activePageId).set({
          ...layout,
          updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
        });
        console.log(`Autosaved layout for ${activePageId} to Firestore successfully`);
      } catch (err) {
        console.error("Autosave layout failed:", err);
      }
    }, 1000); // 1 second debounce

    return () => clearTimeout(timer);
  }, [layout, activePageId, isAdmin, isEditingLayout]);

  const handleAdImageUpload = async (file: File, slotKey: string) => {
    if (!file) return;
    setUploadingAdSlotKey(slotKey);
    setAdUploadProgress(0);
    try {
      const fileExt = file.name.split('.').pop() || 'jpg';
      const fileRef = storage.ref(`epapers/ads/${uuidv4()}_ad.${fileExt}`);
      const uploadTask = fileRef.put(file);
      
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
          setAdUploadProgress(progress);
        },
        (error) => {
          console.error("Ad upload error:", error);
          alert("विज्ञापन अपलोड करने में त्रुटि हुई!");
          setUploadingAdSlotKey(null);
          setAdUploadProgress(null);
        },
        async () => {
          const downloadUrl = await uploadTask.snapshot.ref.getDownloadURL();
          updateSlotConf(slotKey, { adImageUrl: downloadUrl });
          setUploadingAdSlotKey(null);
          setAdUploadProgress(null);
        }
      );
    } catch (err) {
      console.error(err);
      alert("विज्ञापन अपलोड करने में त्रुटि हुई!");
      setUploadingAdSlotKey(null);
      setAdUploadProgress(null);
    }
  };

  // Listen to epaper layouts collection from firestore
  useEffect(() => {
    setLoadingLayouts(true);
    const unsubscribe = db.collection('epaper_layouts').onSnapshot(
      (snapshot) => {
        const layoutMap: Record<string, any> = {};
        snapshot.forEach((doc) => {
          layoutMap[doc.id] = doc.data();
        });
        setLayouts(layoutMap);
        setLoadingLayouts(false);
      },
      (error) => {
        console.error("Error fetching layouts:", error);
        setLoadingLayouts(false);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleSaveLayout = async () => {
    try {
      await db.collection('epaper_layouts').doc(activePageId).set({
        ...layout,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
      });
      alert(`पेज ${selectedPageNum + 1} का लेआउट सफलतापूर्वक सहेज लिया गया है!`);
    } catch (err) {
      console.error("Error saving layout:", err);
      alert("लेआउट सहेजने में त्रुटि हुई।");
    }
  };

  const handleResetLayout = async () => {
    if (window.confirm("क्या आप इस पेज के लेआउट को मूल डिफ़ॉल्ट पर रीसेट करना चाहते हैं?")) {
      const defaultL = getDefaultLayout(activePageId);
      updateActiveLayout(defaultL);
      try {
        await db.collection('epaper_layouts').doc(activePageId).set({
          ...defaultL,
          updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
        });
      } catch (err) {
        console.error("Error resetting layout:", err);
      }
    }
  };

  const handleAddRow = () => {
    const pageRows = [...getPageRows(layout)];
    const newRowId = `row_${Date.now()}`;
    const newSlotId = `slot_${Date.now()}`;
    
    const newRow = {
      id: newRowId,
      height: 250,
      cols: [
        { id: newSlotId, width: 100 }
      ]
    };
    
    const newSlots = {
      ...(layout.slots || {}),
      [newSlotId]: {
        type: 'news',
        postId: '',
        fontSizeTitle: 13,
        fontSizeBody: 9,
        columnCount: 1,
        showThumbnail: true,
        thumbnailWidth: 35,
        thumbnailPosition: 'right',
      }
    };
    
    updateActiveLayout({
      rows: [...pageRows, newRow],
      slots: newSlots
    });
  };

  const handleAddColumn = (rowIndex: number) => {
    const pageRows = [...getPageRows(layout)];
    if (!pageRows[rowIndex]) return;
    
    const row = pageRows[rowIndex];
    const newSlotId = `slot_${Date.now()}`;
    const newCol = { id: newSlotId, width: 0 };
    
    const newCols = [...row.cols, newCol];
    const equalWidth = Math.floor(100 / newCols.length);
    
    newCols.forEach((col, idx) => {
      col.width = idx === newCols.length - 1 ? 100 - (equalWidth * (newCols.length - 1)) : equalWidth;
    });
    
    pageRows[rowIndex] = {
      ...row,
      cols: newCols
    };
    
    const newSlots = {
      ...(layout.slots || {}),
      [newSlotId]: {
        type: 'news',
        postId: '',
        fontSizeTitle: 12,
        fontSizeBody: 8.5,
        columnCount: 1,
        showThumbnail: true,
        thumbnailWidth: 35,
        thumbnailPosition: 'right',
      }
    };
    
    updateActiveLayout({
      rows: pageRows,
      slots: newSlots
    });
  };

  const handleDeleteColumn = (rowIndex: number, colIndex: number) => {
    const pageRows = [...getPageRows(layout)];
    if (!pageRows[rowIndex]) return;
    
    const row = pageRows[rowIndex];
    const cols = [...row.cols];
    cols.splice(colIndex, 1);
    
    if (cols.length === 0) {
      pageRows.splice(rowIndex, 1);
    } else {
      const equalWidth = Math.floor(100 / cols.length);
      cols.forEach((col, idx) => {
        col.width = idx === cols.length - 1 ? 100 - (equalWidth * (cols.length - 1)) : equalWidth;
      });
      pageRows[rowIndex] = {
        ...row,
        cols
      };
    }
    
    updateActiveLayout({
      rows: pageRows
    });
  };

  const handleDeleteRow = (rowIndex: number) => {
    const pageRows = [...getPageRows(layout)];
    if (!pageRows[rowIndex]) return;
    pageRows.splice(rowIndex, 1);
    updateActiveLayout({
      rows: pageRows
    });
  };

  // Drag Thumbnail Free Position (Absolute Position)
  const startDragThumbnailFreePosition = (e: React.MouseEvent, slotKey: string) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    
    const startLayout = layouts[activePageId] || getDefaultLayout(activePageId);
    const slotConf = startLayout.slots?.[slotKey] || getDefaultLayout(activePageId).slots[slotKey];
    const startThumbX = slotConf.thumbnailX !== undefined ? slotConf.thumbnailX : 120;
    const startThumbY = slotConf.thumbnailY !== undefined ? slotConf.thumbnailY : 60;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const getSlotWidthPercent = (slotKeyStr: string, currentLayout: any) => {
      const rows = getPageRows(currentLayout);
      for (const r of rows) {
        if (r.cols) {
          const col = r.cols.find((c: any) => c.id === slotKeyStr);
          if (col) return col.width;
        }
      }
      const boxes = getPageFloatingBoxes(currentLayout);
      const box = boxes.find((b: any) => b.slotKey === slotKeyStr);
      if (box) return (box.width || 300) / 9.12;
      return 100;
    };

    const slotWidthPercent = getSlotWidthPercent(slotKey, startLayout);
    const colWidth = 912 * (slotWidthPercent / 100);

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = (moveEvent.clientX - startX) / scale;
      const deltaY = (moveEvent.clientY - startY) / scale;
      
      const newX = Math.max(-50, Math.min(colWidth + 50, startThumbX + deltaX));
      const newY = Math.max(-50, Math.min(800, startThumbY + deltaY));
      
      // Automatic alignment detection:
      // Left zone (X < 33% of colWidth): float left (text wraps right)
      // Right zone (X > 66% of colWidth): float right (text wraps left)
      // Center zone (in between): float none (displays as a block, text flows on both sides above/below)
      let floatVal: 'left' | 'none' | 'right' = 'left';
      if (newX < colWidth * 0.33) {
        floatVal = 'left';
      } else if (newX > colWidth * 0.66) {
        floatVal = 'right';
      } else {
        floatVal = 'none';
      }

      updateActiveLayout((currentLayout) => {
        const currentSlots = currentLayout.slots || {};
        const currentSlot = currentSlots[slotKey] || {};
        return {
          slots: {
            ...currentSlots,
            [slotKey]: {
              ...currentSlot,
              thumbnailX: Math.round(newX),
              thumbnailY: Math.round(newY),
              thumbnailFloat: floatVal
            }
          }
        };
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  // Resize Thumbnail Edge (Top, Bottom, Left, Right)
  const startResizeThumbnailEdge = (e: React.MouseEvent, slotKey: string, edge: 'top' | 'bottom' | 'left' | 'right') => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    
    const startLayout = layouts[activePageId] || getDefaultLayout(activePageId);
    const slotConf = startLayout.slots?.[slotKey] || getDefaultLayout(activePageId).slots[slotKey];
    const startThumbX = slotConf.thumbnailX !== undefined ? slotConf.thumbnailX : 120;
    const startThumbY = slotConf.thumbnailY !== undefined ? slotConf.thumbnailY : 60;
    const startThumbW = slotConf.thumbnailWidth !== undefined ? slotConf.thumbnailWidth : 140;
    const startThumbH = slotConf.thumbnailHeight !== undefined ? slotConf.thumbnailHeight : 100;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = (moveEvent.clientX - startX) / scale;
      const deltaY = (moveEvent.clientY - startY) / scale;
      
      let newX = startThumbX;
      let newY = startThumbY;
      let newW = startThumbW;
      let newH = startThumbH;

      if (edge === 'left') {
        newW = Math.max(30, startThumbW - deltaX);
        newX = startThumbX + (startThumbW - newW);
      } else if (edge === 'right') {
        newW = Math.max(30, startThumbW + deltaX);
      } else if (edge === 'top') {
        newH = Math.max(30, startThumbH - deltaY);
        newY = startThumbY + (startThumbH - newH);
      } else if (edge === 'bottom') {
        newH = Math.max(30, startThumbH + deltaY);
      }

      updateActiveLayout((currentLayout) => {
        const currentSlots = currentLayout.slots || {};
        const currentSlot = currentSlots[slotKey] || {};
        return {
          slots: {
            ...currentSlots,
            [slotKey]: {
              ...currentSlot,
              thumbnailX: Math.round(newX),
              thumbnailY: Math.round(newY),
              thumbnailWidth: Math.round(newW),
              thumbnailHeight: Math.round(newH),
            }
          }
        };
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleAddFloatingBox = () => {
    const pageFloatingBoxes = [...getPageFloatingBoxes(layout)];
    const newBoxId = `box_${Date.now()}`;
    const newSlotId = `slot_box_${Date.now()}`;
    
    const newBox = {
      id: newBoxId,
      x: 100,
      y: 400,
      width: 300,
      height: 250,
      slotKey: newSlotId
    };
    
    const newSlots = {
      ...(layout.slots || {}),
      [newSlotId]: {
        type: 'news',
        postId: '',
        fontSizeTitle: 12,
        fontSizeBody: 8.5,
        columnCount: 1,
        showThumbnail: true,
        thumbnailWidth: 35,
        thumbnailPosition: 'right',
      }
    };
    
    updateActiveLayout({
      floatingBoxes: [...pageFloatingBoxes, newBox],
      slots: newSlots
    });
  };

  const handleDeleteFloatingBox = (boxId: string) => {
    const pageFloatingBoxes = [...getPageFloatingBoxes(layout)];
    const updatedBoxes = pageFloatingBoxes.filter(box => box.id !== boxId);
    updateActiveLayout({
      floatingBoxes: updatedBoxes
    });
  };

  const startDragRowHeight = (e: React.MouseEvent, rowIndex: number) => {
    e.preventDefault();
    const startY = e.clientY;
    const pageRows = [...getPageRows(layout)];
    const row = pageRows[rowIndex];
    const startHeight = row.height;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaY = (moveEvent.clientY - startY) / scale;
      const newHeight = Math.max(100, Math.min(700, startHeight + deltaY));
      pageRows[rowIndex] = {
        ...row,
        height: Math.round(newHeight)
      };
      updateActiveLayout({
        rows: pageRows
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const startDragColumnWidth = (e: React.MouseEvent, rowIndex: number, colIndex: number) => {
    e.preventDefault();
    const startX = e.clientX;
    const pageRows = [...getPageRows(layout)];
    const row = pageRows[rowIndex];
    const cols = [...row.cols];
    
    const colLeft = cols[colIndex];
    const colRight = cols[colIndex + 1];
    if (!colLeft || !colRight) return;
    
    const startWidthLeft = colLeft.width;
    const startWidthRight = colRight.width;
    const totalWidthCombined = startWidthLeft + startWidthRight;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = (moveEvent.clientX - startX) / scale;
      const deltaPercent = (deltaX / 912) * 100;
      
      const newWidthLeft = Math.max(10, Math.min(totalWidthCombined - 10, startWidthLeft + deltaPercent));
      const newWidthRight = totalWidthCombined - newWidthLeft;
      
      cols[colIndex] = { ...colLeft, width: Math.round(newWidthLeft) };
      cols[colIndex + 1] = { ...colRight, width: Math.round(newWidthRight) };
      
      pageRows[rowIndex] = {
        ...row,
        cols
      };
      
      updateActiveLayout({
        rows: pageRows
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const startDragFloatingBox = (e: React.MouseEvent, boxId: string) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    
    const pageFloatingBoxes = [...getPageFloatingBoxes(layout)];
    const boxIndex = pageFloatingBoxes.findIndex(b => b.id === boxId);
    if (boxIndex === -1) return;
    
    const box = pageFloatingBoxes[boxIndex];
    const startBoxX = box.x;
    const startBoxY = box.y;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = (moveEvent.clientX - startX) / scale;
      const deltaY = (moveEvent.clientY - startY) / scale;
      
      const newX = Math.max(0, Math.min(960 - box.width, startBoxX + deltaX));
      const newY = Math.max(0, Math.min(1242 - box.height, startBoxY + deltaY));
      
      pageFloatingBoxes[boxIndex] = {
        ...box,
        x: Math.round(newX),
        y: Math.round(newY)
      };
      
      updateActiveLayout({
        floatingBoxes: pageFloatingBoxes
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const startResizeFloatingBox = (e: React.MouseEvent, boxId: string) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    
    const pageFloatingBoxes = [...getPageFloatingBoxes(layout)];
    const boxIndex = pageFloatingBoxes.findIndex(b => b.id === boxId);
    if (boxIndex === -1) return;
    
    const box = pageFloatingBoxes[boxIndex];
    const startWidth = box.width;
    const startHeight = box.height;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = (moveEvent.clientX - startX) / scale;
      const deltaY = (moveEvent.clientY - startY) / scale;
      
      const newWidth = Math.max(120, Math.min(912 - box.x, startWidth + deltaX));
      const newHeight = Math.max(100, Math.min(1150 - box.y, startHeight + deltaY));
      
      pageFloatingBoxes[boxIndex] = {
        ...box,
        width: Math.round(newWidth),
        height: Math.round(newHeight)
      };
      
      updateActiveLayout({
        floatingBoxes: pageFloatingBoxes
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  // Drag Thumbnail Width
  const startDragThumbnailWidth = (e: React.MouseEvent, slotKey: string) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startLayout = layouts[activePageId] || getDefaultLayout(activePageId);
    const startWidth = startLayout.slots[slotKey]?.thumbnailWidth || 35;
    const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = (moveEvent.clientX - startX) / scale;
      const deltaPercent = (deltaX / 450) * 100;
      
      updateActiveLayout((currentLayout) => {
        const currentSlots = currentLayout.slots || {};
        const currentSlot = currentSlots[slotKey] || {};
        const directionMultiplier = currentSlot.thumbnailPosition === 'left' ? -1 : 1;
        const newWidth = Math.max(15, Math.min(75, startWidth + deltaPercent * directionMultiplier));
        return {
          slots: {
            ...currentSlots,
            [slotKey]: {
              ...currentSlot,
              thumbnailWidth: Math.round(newWidth),
            }
          }
        };
      });
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const renderEpaperPostBox = (post: any, colIndex: number) => {
    if (!post) return null;

    const plainContent = post.content ? post.content.replace(/<[^>]*>/g, '').trim() : 'विस्तृत रिपोर्ट उपलब्ध नहीं है।';
    const isLongArticle = plainContent.length > 350;

    let themeColor = 'text-red-600';
    let authorLabel = 'संवाददाता';
    let defaultCategory = 'विशेष समाचार';

    if (colIndex === 3) {
      themeColor = 'text-sky-600';
      defaultCategory = 'संपादकीय';
      authorLabel = 'संपादक';
    } else if (colIndex === 4) {
      themeColor = 'text-teal-700';
      defaultCategory = 'प्रादेशिक';
      authorLabel = 'संवाददाता';
    }

    return (
      <div 
        key={post.id} 
        style={{
          height: `${post.estimatedHeight - 8}px`,
          maxHeight: `${post.estimatedHeight - 8}px`,
        }}
        className="flex flex-col justify-between overflow-hidden min-h-0 bg-white border border-gray-300 p-3 rounded-sm shadow-[0_1px_2px_rgba(0,0,0,0.03)] transition-all hover:bg-gray-50/30 shrink-0"
      >
        <div className="flex flex-col h-full overflow-hidden justify-between">
          <div className="flex flex-col overflow-hidden">
            {/* Category with clean padding */}
            <div className={`flex justify-between items-center text-[8.5px] mt-0 mb-1.5 font-serif font-bold ${themeColor} shrink-0 leading-normal`}>
              <span className="uppercase tracking-wide block w-full truncate" title={post.category || defaultCategory}>
                ★ {post.category || defaultCategory} ★
              </span>
            </div>
            
            {/* Title - Fully visible, wrapped cleanly */}
            <h3 
              onClick={() => {
                window.open(`${window.location.origin}?postId=${post.id}`, '_blank');
              }}
              className="text-[10px] font-extrabold text-black mt-0.5 mb-2 font-serif hover:text-red-600 cursor-pointer text-justify leading-snug line-clamp-none"
            >
              {post.title}
            </h3>

            {/* User name/Reporter with nice padding */}
            <div className="text-[7.5px] text-gray-800 bg-gray-50 border-y border-gray-200 py-1 px-1.5 font-serif flex items-center shrink-0 leading-normal my-1">
              <span className="font-bold truncate w-full block" title={post.authorName || 'पब्लिक रिपोर्टर'}>
                {authorLabel}: <span className="font-extrabold text-black">{post.authorName || 'पब्लिक रिपोर्टर'}</span>
              </span>
            </div>
          </div>

          {/* Thumbnail and Article text with beautiful spacing */}
          <div className="flex flex-col overflow-hidden flex-grow min-h-0 justify-between mt-1">
            {post.thumbnailUrl && (
              <div 
                onClick={() => {
                  window.open(`${window.location.origin}?postId=${post.id}`, '_blank');
                }}
                className="w-full h-[110px] rounded-sm overflow-hidden border border-gray-200 my-1 shrink-0 bg-gray-50 flex items-center justify-center relative group cursor-pointer"
              >
                <img 
                  src={post.thumbnailUrl} 
                  alt={post.title} 
                  className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-105 p-0.5" 
                  referrerPolicy="no-referrer"
                />
              </div>
            )}
            
            {/* Article content with dynamic columns style if long article */}
            <div className="flex-grow flex flex-col justify-start overflow-hidden min-h-0">
              <p 
                style={{
                  fontSize: '8px',
                  lineHeight: '1.35',
                  columnCount: isLongArticle ? 2 : 1,
                  columnGap: '8px',
                  columnRule: isLongArticle ? '1px dashed #e5e7eb' : 'none',
                }}
                className="text-gray-950 text-justify font-serif my-1"
              >
                {plainContent}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderColumnFiller = (remainingHeight: number, colIndex: number) => {
    if (remainingHeight < 35) return null; // Too small to show anything useful
    
    return (
      <div 
        key={`filler-col${colIndex}`}
        style={{ height: `${remainingHeight - 8}px` }}
        className="flex flex-col items-center justify-center border border-dashed border-gray-300 rounded-sm p-2 bg-gray-50/20 shrink-0 overflow-hidden"
      >
        <span className="text-[7.5px] font-black text-gray-400 font-serif tracking-wider text-center uppercase">पब्लिक तक समाचार</span>
        {remainingHeight > 60 && (
          <span className="text-[6.5px] text-gray-400 font-serif text-center mt-1">विशेष कवरेज और विज्ञापन हेतु संपर्क करें</span>
        )}
        {remainingHeight > 80 && (
          <span className="text-[6px] text-gray-400 font-mono text-center mt-0.5">info@publictak.app</span>
        )}
      </div>
    );
  };

  const renderSlot = (slotKey: string, slotIndex: number, post: any, height: number, customLayout?: any, customPageId?: string) => {
    const currentLayout = customLayout || layout;
    const currentPageId = customPageId || activePageId;
    const slotConf = currentLayout.slots[slotKey] || getDefaultLayout(currentPageId).slots[slotKey];
    const showThumb = slotConf.showThumbnail && !!post.thumbnailUrl;
    const thumbPos = slotConf.thumbnailPosition || 'right';
    const thumbWidthPercent = slotConf.thumbnailWidth || (thumbPos === 'top' || thumbPos === 'bottom' ? 100 : 35);
    
    const fontSizeTitle = slotConf.fontSizeTitle ? `${slotConf.fontSizeTitle}px` : (slotIndex === 1 ? '14px' : '12.5px');
    const fontSizeBody = slotConf.fontSizeBody ? `${slotConf.fontSizeBody}px` : '9px';
    const colCount = slotConf.columnCount || (slotIndex === 1 || slotIndex === 4 ? 3 : 1);

    // Advanced slot styles
    const bgColor = slotConf.slotBgColor || 'bg-white';
    const borderStyle = slotConf.slotBorderStyle || 'border-solid';
    const borderWidth = slotConf.slotBorderWidth || 'border-2';
    const borderColor = slotConf.slotBorderColor || 'border-black';
    const titleColor = slotConf.slotTitleColor || 'text-black';
    const titleAlign = slotConf.slotTitleAlign || 'text-justify';
    const bodyLineHeight = slotConf.slotBodyLineHeight || '1.45';

    // Determine flex direction of the body (text + image)
    let bodyFlexClass = "flex gap-3 items-stretch overflow-hidden mt-1.5 flex-1 min-h-0 relative";
    if (thumbPos === 'left') {
      bodyFlexClass += " flex-row-reverse"; // text right, image left
    } else if (thumbPos === 'right') {
      bodyFlexClass += " flex-row"; // text left, image right
    } else if (thumbPos === 'top') {
      bodyFlexClass += " flex-col-reverse justify-between"; // text bottom, image top
    } else if (thumbPos === 'bottom') {
      bodyFlexClass += " flex-col justify-between"; // text top, image bottom
    } else if (thumbPos === 'free') {
      bodyFlexClass += " flex-row"; // Free flow: text is full, image is absolutely positioned
    }

    // Absolutely positioned thumbnail metrics for 'free' mode
    const thumbX = slotConf.thumbnailX !== undefined ? slotConf.thumbnailX : 120;
    const thumbY = slotConf.thumbnailY !== undefined ? slotConf.thumbnailY : 60;
    const thumbW = slotConf.thumbnailWidth !== undefined ? slotConf.thumbnailWidth : 140;
    const thumbH = slotConf.thumbnailHeight !== undefined ? slotConf.thumbnailHeight : 100;

    const isAd = slotConf.type === 'ad';
    const adImageUrl = slotConf.adImageUrl || (post?.isAd ? post.thumbnailUrl : '');

    return (
      <div 
        style={{ height: `${height}px`, maxHeight: `${height}px` }}
        className={`${bgColor} ${borderWidth} ${borderStyle} ${borderColor} ${isAd ? 'p-0' : 'p-3'} rounded-xs shadow-[0_1px_3px_rgba(0,0,0,0.05)] flex flex-col justify-between overflow-hidden relative shrink-0 group ${
          isEditingLayout ? 'ring-2 ring-blue-500/50 hover:ring-blue-500' : ''
        }`}
      >
        {/* Edit overlay/badge for Admin layout edit mode */}
        {isEditingLayout && (
          <div 
            onClick={(e) => {
              e.stopPropagation();
              setSelectedEditSlot(slotKey);
            }}
            className={`absolute inset-0 bg-blue-500/5 backdrop-blur-[0.5px] z-30 cursor-pointer border border-dashed border-blue-500 flex items-center justify-center transition-all ${
              selectedEditSlot === slotKey ? 'bg-blue-500/10 border-solid border-2 border-blue-600' : 'hover:bg-blue-500/10'
            }`}
          >
            <div className="bg-blue-600 text-white font-bold text-[10px] px-2 py-1 rounded-sm shadow flex items-center gap-1">
              <span className="material-symbols-outlined text-[11px] font-bold">edit</span>
              <span>स्लॉट {slotIndex} ({isAd ? 'विज्ञापन' : 'समाचार'})</span>
            </div>
          </div>
        )}

        {isAd ? (
          /* Advertisement mode: completely empty text, image full fills the box */
          adImageUrl ? (
            <div className="w-full h-full overflow-hidden relative bg-gray-50 flex items-center justify-center">
              <img 
                src={adImageUrl} 
                alt="विज्ञापन" 
                style={{
                  transform: `scale(${slotConf.adScale !== undefined ? slotConf.adScale : 1}) translate(${slotConf.adPosX !== undefined ? slotConf.adPosX : 0}px, ${slotConf.adPosY !== undefined ? slotConf.adPosY : 0}px)`,
                  objectFit: (slotConf.adObjectFit || 'fill') as any,
                  transformOrigin: 'center center',
                }}
                className="w-full h-full block transition-transform duration-100 ease-out" 
                referrerPolicy="no-referrer"
              />
            </div>
          ) : null
        ) : (
          /* Regular News Article mode */
          <>
            {/* Title bar */}
            <div className="shrink-0">
              <div className="flex justify-between items-start gap-4 mb-0.5">
                <h2 
                  onClick={() => !isEditingLayout && setSelectedArticle(post)}
                  style={{ 
                    fontFamily: '"Tiro Devanagari Hindi", "Noto Serif Devanagari", "serif"',
                    fontSize: fontSizeTitle,
                    lineHeight: '1.25',
                  }}
                  className={`font-black cursor-pointer hover:text-red-600 transition-colors flex-1 ${titleColor} ${titleAlign}`}
                >
                  {slotConf.customTag && (
                    <span className="text-white text-[8px] bg-red-700 px-1 py-0.5 rounded mr-1.5 font-sans font-black tracking-wider uppercase select-none">
                      {slotConf.customTag}
                    </span>
                  )}
                  {post.isAd && !slotConf.customTag && (
                    <span className="text-red-600 text-[8px] bg-red-100 border border-red-200 px-1 py-0.5 rounded mr-1 font-sans font-bold select-none uppercase">
                      AD
                    </span>
                  )}
                  {post.title}
                </h2>
                <div className="bg-red-600 text-white font-bold text-[9.5px] w-5 h-5 flex items-center justify-center shrink-0 rounded-xs select-none font-serif">
                  {String(slotIndex).padStart(2, '0')}
                </div>
              </div>

              {/* Custom subtitle / Strap line */}
              {slotConf.customSubtitle && (
                <div className="text-[10px] text-gray-600 font-serif italic border-l-2 border-red-600 pl-1.5 mt-1 mb-1 leading-tight text-justify select-none">
                  {slotConf.customSubtitle}
                </div>
              )}
              
              {/* Reporter details */}
              <div className="border-b border-gray-200 pb-0.5 mb-1.5 flex justify-between items-center text-[7.5px] text-gray-700 font-serif">
                <span>{post.isAd ? 'प्रायोजक' : 'संवाददाता'}: <span className="font-extrabold text-black">{post.authorName || 'पब्लिक तक'}</span></span>
                <span>श्रेणी: <span className="font-extrabold text-red-600">{post.category || 'विशेष समाचार'}</span></span>
              </div>
            </div>

            {/* Body containing Text and Image */}
            <div className={bodyFlexClass}>
              {/* Text Area */}
              <div className="flex-1 min-w-0 flex flex-col justify-start h-full">
                <AutoFitText 
                  columnCount={colCount}
                  maxFontSize={Math.max(parseFloat(fontSizeBody) * 2, 18)}
                  minFontSize={3.5}
                  lineHeight={bodyLineHeight}
                  containerWidth={containerWidth}
                  onClick={() => !isEditingLayout && setSelectedArticle(post)}
                  className="text-black text-justify font-serif h-full cursor-pointer hover:bg-gray-50/50 p-1.5 rounded-xs transition-colors overflow-hidden relative"
                >
                  {/* If free thumbnail, render it right here floated inside the text div so text wrapping is handled natively and text is NEVER hidden! */}
                  {showThumb && thumbPos === 'free' && (
                    <div 
                      onMouseDown={(e) => {
                        if (isEditingLayout) {
                          startDragThumbnailFreePosition(e, slotKey);
                        }
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (!isEditingLayout) setSelectedArticle(post);
                      }}
                      style={{ 
                        float: slotConf.thumbnailFloat === 'none' ? 'none' : (slotConf.thumbnailFloat || 'left'),
                        display: slotConf.thumbnailFloat === 'none' ? 'block' : 'inline-block',
                        width: `${thumbW}px`,
                        height: `${thumbH}px`,
                        marginTop: `${thumbY}px`,
                        marginLeft: slotConf.thumbnailFloat === 'none' ? 'auto' : (slotConf.thumbnailFloat === 'right' ? '0px' : `${thumbX}px`),
                        marginRight: slotConf.thumbnailFloat === 'none' ? 'auto' : (slotConf.thumbnailFloat === 'left' ? '12px' : `${thumbX}px`),
                        marginBottom: '8px',
                        shapeOutside: 'margin-box',
                        position: 'relative',
                        zIndex: isEditingLayout ? 40 : 'auto',
                      }}
                      className={`border-2 border-black p-0.5 bg-white overflow-hidden flex flex-col justify-between shadow-[2px_2px_8px_rgba(0,0,0,0.22)] rounded-xs border-dashed ${
                        isEditingLayout ? 'cursor-move ring-2 ring-blue-500 hover:ring-blue-600' : 'cursor-pointer group'
                      }`}
                    >
                      {/* Draggable handles inside free float thumbnail */}
                      {isEditingLayout && (
                        <>
                          <div 
                            onMouseDown={(e) => { e.stopPropagation(); startResizeThumbnailEdge(e, slotKey, 'top'); }}
                            className="absolute top-[-3px] left-0 right-0 h-2 bg-blue-500/10 hover:bg-blue-600 cursor-ns-resize z-50 transition-colors"
                            title="ऊपर से बढ़ाएं"
                          />
                          <div 
                            onMouseDown={(e) => { e.stopPropagation(); startResizeThumbnailEdge(e, slotKey, 'bottom'); }}
                            className="absolute bottom-[-3px] left-0 right-0 h-2 bg-blue-500/10 hover:bg-blue-600 cursor-ns-resize z-50 transition-colors"
                            title="नीचे से बढ़ाएं"
                          />
                          <div 
                            onMouseDown={(e) => { e.stopPropagation(); startResizeThumbnailEdge(e, slotKey, 'left'); }}
                            className="absolute left-[-3px] top-0 bottom-0 w-2 bg-blue-500/10 hover:bg-blue-600 cursor-ew-resize z-50 transition-colors"
                            title="बाएँ से बढ़ाएं"
                          />
                          <div 
                            onMouseDown={(e) => { e.stopPropagation(); startResizeThumbnailEdge(e, slotKey, 'right'); }}
                            className="absolute right-[-3px] top-0 bottom-0 w-2 bg-blue-500/10 hover:bg-blue-600 cursor-ew-resize z-50 transition-colors"
                            title="दाएँ से बढ़ाएं"
                          />
                        </>
                      )}

                      <div className="flex-grow overflow-hidden relative border border-gray-300 bg-white">
                        <img 
                          src={post.thumbnailUrl} 
                          alt={post.title} 
                          className="w-full h-full object-contain filter contrast-[1.08] brightness-[0.98] transition-transform duration-300 group-hover:scale-102 p-0.5" 
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="mt-0.5 text-[6.5px] leading-tight text-gray-800 font-serif italic flex justify-between border-t border-gray-300 pt-0.5 shrink-0 px-0.5 select-none bg-gray-50/50">
                        <span className="truncate max-w-[80%]">तस्वीर: {post.title}</span>
                        <span className="text-red-700 font-bold shrink-0 font-sans">पब्लिक तक</span>
                      </div>
                    </div>
                  )}

                  {!post.isAd && <strong className="text-red-700 font-bold">({selectedDistrict || 'बिहार-झारखंड'}, {post.authorName || 'विशेष संवाददाता'}): </strong>}
                  {post.content}
                </AutoFitText>
              </div>

              {/* Standard flowed Thumbnail image */}
              {showThumb && thumbPos !== 'free' && (
                <div 
                  onClick={() => !isEditingLayout && setSelectedArticle(post)}
                  style={{ 
                    width: thumbPos === 'top' || thumbPos === 'bottom' ? '100%' : `${thumbWidthPercent}%`,
                    height: thumbPos === 'top' || thumbPos === 'bottom' ? '110px' : '100%',
                  }}
                  className="shrink-0 border-2 border-black p-0.5 bg-white overflow-hidden flex flex-col justify-between cursor-pointer group shadow-[1px_1px_4px_rgba(0,0,0,0.15)] relative rounded-xs border-dashed"
                >
                  {/* Thumbnail Resize handle inside editor */}
                  {isEditingLayout && (thumbPos === 'left' || thumbPos === 'right') && (
                    <div 
                      onMouseDown={(e) => startDragThumbnailWidth(e, slotKey)}
                      className={`absolute top-0 bottom-0 w-2.5 bg-blue-500/80 hover:bg-blue-600 cursor-ew-resize z-40 flex items-center justify-center ${
                        thumbPos === 'left' ? 'right-0' : 'left-0'
                      }`}
                      title="छवि चौड़ाई बदलें"
                    >
                      <div className="w-0.5 h-4 bg-white rounded-full"></div>
                    </div>
                  )}

                  <div className="flex-grow overflow-hidden relative border border-gray-300 bg-white">
                    <img 
                      src={post.thumbnailUrl} 
                      alt={post.title} 
                      className="w-full h-full object-contain filter contrast-[1.08] brightness-[0.98] transition-transform duration-300 group-hover:scale-102 p-0.5" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="mt-0.5 text-[6.5px] leading-tight text-gray-800 font-serif italic flex justify-between border-t border-gray-300 pt-0.5 shrink-0 px-0.5 select-none bg-gray-50/50">
                    <span className="truncate max-w-[80%]">तस्वीर: {post.title}</span>
                    <span className="text-red-700 font-bold shrink-0 font-sans">पब्लिक तक</span>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    );
  };

  // Filters state
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  });
  
  const [selectedState, setSelectedState] = useState<string>(() => currentUser?.preferredState || '');
  const [selectedDistrict, setSelectedDistrict] = useState<string>(() => currentUser?.preferredDistrict || '');

  // Dynamic state/district navigation lists
  const statesList = Object.keys(indianLocations);
  const districtsList = selectedState ? Object.keys(indianLocations[selectedState] || {}) : [];

  // E-Paper lists & active E-Paper (Uploaded)
  const [epapers, setEpapers] = useState<EPaper[]>([]);
  const [loadingUploaded, setLoadingUploaded] = useState<boolean>(true);
  const [activeEPaper, setActiveEPaper] = useState<EPaper | null>(null);
  const [activePageIdx, setActivePageIdx] = useState<number>(0);
  
  // Auto-Generated Newspaper state
  const [allPosts, setAllPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState<boolean>(true);

  // UI Mode Toggle: 'uploaded' (PDF Replica) or 'auto' (Auto-compiled newsprint)
  const [ePaperMode, setEPaperMode] = useState<'uploaded' | 'auto'>('auto');

  // Detailed article modal reader state
  const [selectedArticle, setSelectedArticle] = useState<any | null>(null);

  // Download PDF progress indicator
  const [isDownloadingPDF, setIsDownloadingPDF] = useState<boolean>(false);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);
  const [pdfProgress, setPdfProgress] = useState<string>('');

  // Interactive zoom & fullscreen controls for uploaded PDF replica
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const viewerRef = useRef<HTMLDivElement>(null);

  // Interactive zoom & dynamic scaling for auto mode
  const [autoZoomMultiplier, setAutoZoomMultiplier] = useState<number>(1);
  const [containerWidth, setContainerWidth] = useState<number>(960);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.clientWidth || 960);
      }
    };
    
    updateWidth();
    
    if (typeof ResizeObserver !== 'undefined') {
      const observer = new ResizeObserver((entries) => {
        if (entries[0]) {
          setContainerWidth(entries[0].contentRect.width || entries[0].target.clientWidth || 960);
        }
      });
      observer.observe(containerRef.current);
      return () => observer.disconnect();
    } else {
      window.addEventListener('resize', updateWidth);
      return () => window.removeEventListener('resize', updateWidth);
    }
  }, [ePaperMode]);

  // Admin upload states
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [uploadTitle, setUploadTitle] = useState<string>('');
  const [uploadDate, setUploadDate] = useState<string>(selectedDate);
  const [uploadState, setUploadState] = useState<string>('');
  const [uploadDistrict, setUploadDistrict] = useState<string>('');
  const [uploadFiles, setUploadFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);

  // Rotating traditional Hindi Quotes of the Day
  const hindiQuotes = [
    "सत्य कभी पराजित नहीं हो सकता, यह केवल कुछ समय के लिए दबाया जा सकता है।",
    "राष्ट्र की उन्नति तभी संभव है जब प्रत्येक नागरिक जागरूक, सूचित और निष्पक्ष हो।",
    "ज्ञान ही वह दिव्य प्रकाश है जो समाज से अज्ञानता के अंधकार को मिटाता है।",
    "स्वतंत्र और निष्पक्ष पत्रकारिता ही किसी भी मजबूत लोकतंत्र की रीढ़ होती है।",
    "अहिंसा, करुणा और सत्य ही मानवता के सबसे बड़े आभूषण हैं।",
    "कर्म ही असली पूजा है, और निस्वार्थ समाजसेवा ही ईश्वर का सच्चा रूप है।"
  ];

  // Dynamic Hindi Traditional Calendar (Panchang) simulation
  const panchangData = useMemo(() => {
    const d = new Date(selectedDate);
    const days = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];
    const dayName = days[d.getDay()];
    
    const months = ['जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
    const monthName = months[d.getMonth()];
    
    const tithis = ['प्रतिपदा', 'द्वितीया', 'तृतीया', 'चतुर्थी', 'पंचमी', 'षष्ठी', 'सप्तमी', 'अष्टमी', 'नवमी', 'दशमी', 'एकादशी', 'द्वादशी', 'त्रयोदशी', 'चतुर्दशी', 'पूर्णिमा', 'अमावस्या'];
    const nakshatras = ['अश्विनी', 'भरणी', 'कृत्तिका', 'रोहिणी', 'मृगशिरा', 'आर्द्रा', 'पुनर्वसु', 'पुष्य', 'अश्लेषा', 'मघा', 'पूर्वाफाल्गुनी', 'उत्तराफाल्गुनी', 'हस्त', 'चित्रा', 'स्वाती', 'विशाखा', 'अनुराधा', 'ज्येष्ठा', 'मूल', 'पूर्वाषाढ़ा', 'उत्तराषाढ़ा', 'श्रवण', 'धनिष्ठा', 'शतभिषा', 'पूर्वाभाद्रपद', 'उत्तराभाद्रपद', 'रेवती'];
    
    const tithiIdx = (d.getDate() + d.getMonth() * 3) % tithis.length;
    const nakshatraIdx = (d.getDate() * 5 + d.getFullYear()) % nakshatras.length;
    const paksh = d.getDate() > 14 ? 'कृष्ण पक्ष' : 'शुक्ल पक्ष';
    const quote = hindiQuotes[(d.getDate() + d.getMonth()) % hindiQuotes.length];
    
    return {
      dayName,
      monthName,
      fullDateHindi: `${dayName}, ${d.getDate()} ${monthName} ${d.getFullYear()}`,
      tithi: tithis[tithiIdx],
      nakshatra: nakshatras[nakshatraIdx],
      paksh,
      quote,
      sunrise: "05:22 AM",
      sunset: "06:46 PM",
      samvat: 2083 + (d.getFullYear() - 2026),
    };
  }, [selectedDate]);

  // Fetch Uploaded PDF/Image E-Papers matching selected date & locations
  useEffect(() => {
    setLoadingUploaded(true);
    let query = db.collection('epapers').where('date', '==', selectedDate);

    if (selectedState) {
      query = query.where('state', '==', selectedState);
    }
    if (selectedDistrict) {
      query = query.where('district', '==', selectedDistrict);
    }

    const unsubscribe = query.onSnapshot(
      (snapshot) => {
        const list: EPaper[] = [];
        snapshot.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as EPaper);
        });
        
        list.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
        setEpapers(list);
        
        if (list.length > 0) {
          setActiveEPaper(list[0]);
          setActivePageIdx(0);
          setZoomScale(1);
          // Keep mode as 'auto' for unified smart digital daily layout experience
        } else {
          setActiveEPaper(null);
          setActivePageIdx(0);
          setEPaperMode('auto'); // Fall back to smart auto-generated newspaper!
        }
        setLoadingUploaded(false);
      },
      (error) => {
        console.error("Error fetching E-Papers:", error);
        setLoadingUploaded(false);
      }
    );

    return () => unsubscribe();
  }, [selectedDate, selectedState, selectedDistrict]);

  // Fetch All News Posts from Firestore to compile the E-Paper automatically
  useEffect(() => {
    setLoadingPosts(true);
    const unsubscribe = db.collection('posts').orderBy('createdAt', 'desc').onSnapshot(
      (snapshot) => {
        const list: Post[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          list.push({
            id: doc.id,
            ...data,
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : (data.createdAt ? new Date(data.createdAt) : null)
          } as Post);
        });
        setAllPosts(list);
        setLoadingPosts(false);
      },
      (error) => {
        console.error("Error fetching posts for E-Paper:", error);
        setLoadingPosts(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Filter posts by date, state, and district for auto-generation
  const activePosts = useMemo(() => {
    return allPosts.filter(post => {
      if (!post.createdAt) return false;
      
      // Date Filter
      const pDate = new Date(post.createdAt);
      const yyyy = pDate.getFullYear();
      const mm = String(pDate.getMonth() + 1).padStart(2, '0');
      const dd = String(pDate.getDate()).padStart(2, '0');
      const postDateStr = `${yyyy}-${mm}-${dd}`;
      if (postDateStr !== selectedDate) return false;

      // Location Filter (Overall is shown everywhere, district-wise or state-wise shown in relevant editions)
      if (post.locationType === 'Overall') return true;

      if (selectedState && post.state && post.state !== selectedState) {
        return false;
      }
      if (selectedDistrict && post.district && post.district !== selectedDistrict) {
        return false;
      }

      return true;
    });
  }, [allPosts, selectedDate, selectedState, selectedDistrict]);

  // Bulletins for the quick bytes section
  const bulletins = useMemo(() => {
    const district = selectedDistrict || 'रांची';
    return [
      {
        title: `वार्ड कार्यालय से आरसीबी हटाकर पार्क बनाने पर विवाद`,
        content: `वार्ड 13 के पार्षद ने वार्ड कार्यालय परिसर में पार्क निर्माण का विरोध किया है। उन्होंने मेयर को पत्र लिखकर मामले की जांच की मांग की है।`
      },
      {
        title: `नाबालिग ने चलती ट्रेन से लगाई छलांग, बाल-बाल बची`,
        content: `${district} रेलवे स्टेशन के पास एक नाबालिग लड़की ने डर के मारे चलती ट्रेन से छलांग लगा दी। उसे अस्पताल में भर्ती कराया गया है।`
      },
      {
        title: `ट्रेन में लावारिस बैग से भारी मात्रा में अवैध शराब बरामद`,
        content: `आरपीएफ ने हावड़ा एक्सप्रेस से लावारिस बैग में रखी 44 बोतल विदेशी शराब जब्त की। आरोपी फरार होने में सफल रहा।`
      },
      {
        title: `रेलवे स्टेशन पर चलती ट्रेन में चढ़ते समय फिसली महिला, बची जान`,
        content: `महिला यात्री चलती ट्रेन में चढ़ने का प्रयास कर रही थी, तभी पैर फिसल गया। सतर्क आरपीएफ जवान ने तुरंत खींचकर जान बचाई।`
      }
    ];
  }, [selectedDistrict]);

  // Dynamic Stories mapping (Only real user news posts!)
  const displayStories = useMemo(() => {
    return activePosts.map((post) => ({
      id: post.id,
      title: post.title,
      subtitle: (post as any).subtitle || '',
      authorName: post.authorName || 'पब्लिक रिपोर्टर',
      category: post.category || 'विशेष समाचार',
      thumbnailUrl: post.thumbnailUrl || '',
      content: post.content ? post.content.replace(/<[^>]*>/g, '').trim() : 'विस्तृत रिपोर्ट उपलब्ध नहीं है।',
      viewCount: post.viewCount || 0,
      createdAt: post.createdAt || new Date()
    }));
  }, [activePosts]);

  // Helper to calculate estimated character capacity of a slot
  const getSlotCapacity = (slotKey: string, slotConf: any, slotWidthPercent: number, slotHeight: number) => {
    const actualWidth = 912 * (slotWidthPercent / 100); // 912px is 960px broadsheet minus padding
    const fontSizeTitle = slotConf.fontSizeTitle || 12.5;
    const fontSizeBody = slotConf.fontSizeBody || 9;
    const bodyLineHeight = parseFloat(slotConf.slotBodyLineHeight || '1.45');
    
    // Title height calculation based on length and width
    const titleCharWidth = fontSizeTitle * 0.55;
    const titleTextLength = 40; // average
    const titleLines = Math.ceil((titleTextLength * titleCharWidth) / actualWidth);
    const titleHeight = titleLines * fontSizeTitle * 1.3 + 12;
    
    const metadataHeight = 15;
    const subtitleHeight = slotConf.customSubtitle ? 18 : 0;
    const padding = 24; // padding p-3 is 12px top & bottom
    
    let availableHeight = slotHeight - titleHeight - metadataHeight - subtitleHeight - padding;
    if (availableHeight < 40) availableHeight = 40;
    
    let textWidth = actualWidth;
    let deductArea = 0;
    
    const showThumb = slotConf.showThumbnail;
    const thumbPos = slotConf.thumbnailPosition || 'right';
    
    if (showThumb) {
      if (thumbPos === 'top' || thumbPos === 'bottom') {
        availableHeight -= 120; // image + caption area
      } else if (thumbPos === 'left' || thumbPos === 'right') {
        const thumbWidthPercent = slotConf.thumbnailWidth || 35;
        textWidth = actualWidth * (1 - (thumbWidthPercent / 100));
      } else if (thumbPos === 'free') {
        const thumbW = slotConf.thumbnailWidth !== undefined ? slotConf.thumbnailWidth : 140;
        const thumbH = slotConf.thumbnailHeight !== undefined ? slotConf.thumbnailHeight : 100;
        deductArea = thumbW * thumbH;
      }
    }
    
    if (availableHeight < 20) availableHeight = 20;
    
    const charHeight = fontSizeBody * bodyLineHeight;
    const charWidth = fontSizeBody * 0.55; // Noto Serif Devanagari average width ratio
    
    const totalTextArea = textWidth * availableHeight - deductArea;
    const singleCharArea = charHeight * charWidth;
    
    const maxChars = Math.floor(totalTextArea / singleCharArea);
    return Math.max(150, maxChars); // safety limit
  };

  // Organize posts dynamically into multiple newspaper pages with intelligent layout-aware content overflow flow!
  const epaperPages = useMemo(() => {
    const pagesList: any[] = [];
    
    // Copy displayStories so we can consume and manipulate it
    const storiesPool = [...displayStories];
    let pageIndex = 0;
    
    // We will simulate page creation until all stories are fully rendered
    const maxPages = Math.max(12, storiesPool.length * 3);
    
    while (storiesPool.length > 0 && pageIndex < maxPages) {
      const pageId = `page_${pageIndex}`;
      const layoutKey = `page_${pageIndex}`;
      const pageLayout = layouts[layoutKey] || (pageIndex > 0 ? layouts['page_1'] : null) || getDefaultLayout(layoutKey);
      const pageRows = getPageRows(pageLayout);
      
      // Determine the slots on this page
      const pageSlots: any[] = [];
      pageRows.forEach((row: any) => {
        row.cols.forEach((col: any) => {
          pageSlots.push({
            id: col.id,
            widthPercent: col.width,
            rowHeight: row.height,
          });
        });
      });
      
      // Also add floating boxes as slots
      const floatingBoxes = getPageFloatingBoxes(pageLayout);
      floatingBoxes.forEach((box: any) => {
        pageSlots.push({
          id: box.slotKey,
          widthPercent: 35, // estimate
          rowHeight: box.height,
          isFloating: true,
          boxWidth: box.width,
        });
      });
      
      const pagePosts: any[] = [];
      const pageSlotPosts: Record<string, any> = {};
      
      pageSlots.forEach((slot) => {
        const slotKey = slot.id;
        const slotConf = pageLayout.slots?.[slotKey] || getDefaultLayout(layoutKey).slots[slotKey] || {
          type: 'article',
          postId: '',
        };
        
        if (slotConf.type === 'ad') {
          return;
        }
        
        // Find the post for this slot
        let post: any = null;
        
        // If there's a bound postId, use it
        if (slotConf.postId) {
          post = storiesPool.find(p => p.id === slotConf.postId);
          if (!post) {
            post = displayStories.find(p => p.id === slotConf.postId);
          }
        }
        
        // Otherwise, take the next available story from the storiesPool
        if (!post && storiesPool.length > 0) {
          post = storiesPool[0];
        }
        
        if (post) {
          // Remove from storiesPool so we don't reuse it
          const poolIdx = storiesPool.indexOf(post);
          if (poolIdx > -1) {
            storiesPool.splice(poolIdx, 1);
          }
          
          const finalPost = {
            ...post,
            content: post.content,
          };
          
          pageSlotPosts[slotKey] = finalPost;
          pagePosts.push(finalPost);
        }
      });
      
      pagesList.push({
        id: pageIndex + 1,
        name: `मुख्य समाचार (Page ${pageIndex + 1})`,
        title: `मुख्य समाचार (Page ${pageIndex + 1})`,
        tagline: 'देश-विदेश एवं मुख्य ख़बरें',
        posts: pagePosts,
        slotPosts: pageSlotPosts,
        icon: 'star'
      });
      
      pageIndex++;
    }
    
    // Default fallback if there are no pages
    if (pagesList.length === 0) {
      pagesList.push({
        id: 1,
        name: `मुख्य समाचार (Page 1)`,
        title: `मुख्य समाचार (Page 1)`,
        tagline: 'देश-विदेश एवं मुख्य ख़बरें',
        posts: [],
        slotPosts: {},
        icon: 'star'
      });
    }
    
    return pagesList;
  }, [displayStories, layouts]);

  // Adjust page number if it goes out of bounds when toggling locations/dates
  useEffect(() => {
    if (selectedPageNum >= epaperPages.length) {
      setSelectedPageNum(0);
    }
  }, [epaperPages, selectedPageNum]);

  // Helper method to render a single newspaper page canvas (for both UI view and batch printing)
  const renderSingleNewspaperPage = (pageIndex: number, scale: number, isPrintOnly: boolean = false) => {
    const pageId = `page_${pageIndex}`;
    const layoutKey = `page_${pageIndex}`;
    const pageLayout = layouts[layoutKey] || (pageIndex > 0 ? layouts['page_1'] : null) || getDefaultLayout(layoutKey);
    const currentPage = epaperPages[pageIndex] || { posts: [] };
    const pagePosts = currentPage.posts || [];

    const fallbackAds = [
      {
        id: "ad-1",
        title: "पब्लिक तक विशेष विज्ञापन: अपने व्यवसाय को दें एक नई पहचान",
        category: "विशेष विज्ञापन",
        authorName: "पब्लिक तक ब्यूरो",
        content: "क्या आप अपने व्यवसाय को बिहार-झारखंड के घर-घर तक पहुँचाना चाहते हैं? पब्लिक तक ई-पेपर विज्ञापन का चयन करें। डिजिटल मीडिया में सबसे तीव्र प्रसार और विश्वसनीय पाठक वर्ग। विशेष त्योहारों एवं राष्ट्रीय अवसरों पर आकर्षक छूट उपलब्ध है। आज ही संपर्क करें: +91 9876543210, ईमेल: info@publictak.app।"
      },
      {
        id: "ad-2",
        title: "स्वतंत्र और निष्पक्ष पत्रकारिता का समर्थन करें: जन-जन की आवाज़",
        category: "संपादकीय संदेश",
        authorName: "प्रधान संपादक",
        content: "पब्लिक तक अख़बार नहीं, एक क्रांतिकारी जन आंदोलन है। हमारी टीम बिना किसी भय या पक्षपात के समाज की समस्याओं को उजागर करने और दबे-कुचले वर्गों की आवाज़ बनने के लिए पूरी तरह समर्पित है। स्वतंत्र एवं निष्पक्ष पत्रकारिता का समर्थन करने के लिए हमारे साथ जुड़ें, वेबसाइट: publictak.app पर आएं और अपने साथियों को भी जोड़ें।"
      },
      {
        id: "ad-3",
        title: "पब्लिक रिपोर्टर बनें: अपने क्षेत्र की समस्याओं को स्वयं उठाएं",
        category: "पब्लिक बुलेटिन",
        authorName: "डिजिटल डेस्क",
        content: "क्या आपके क्षेत्र में कोई जनसमस्या है? पानी, बिजली, सड़क या स्वास्थ्य सुविधाओं से जुड़ी शिकायतें हों, या फिर सामाजिक सरोकार की कोई खबर - अब आप स्वयं रिपोर्टर बन सकते हैं। publictak.app पर रिपोर्टर पैनल में पंजीकरण करें, तस्वीरें और विवरण भेजें। हमारी संपादकीय टीम उसे प्रमुखता से प्रकाशित करेगी।"
      }
    ];

    const getSlotContent = (slotKey: string, defaultPostIndex: number, fallbackAd: any) => {
      const slotConf = pageLayout.slots?.[slotKey] || getDefaultLayout(layoutKey).slots[slotKey] || {
        type: 'article',
        postId: '',
        fontSizeTitle: 12,
        fontSizeBody: 9,
        columnCount: 1,
        showThumbnail: true,
        thumbnailWidth: 35,
        thumbnailHeight: 100,
        thumbnailPosition: 'right',
        thumbnailX: 0,
        thumbnailY: 0,
        titleX: 0,
        titleY: 0,
        textX: 0,
        textY: 0,
        dragMode: 'auto',
      };
      if (slotConf.type === 'ad') {
        return {
          id: `ad-${slotKey}`,
          title: slotConf.adTitle || fallbackAd.title,
          content: slotConf.adContent || fallbackAd.content,
          category: slotConf.adCategory || fallbackAd.category,
          authorName: slotConf.adAuthor || fallbackAd.authorName,
          thumbnailUrl: slotConf.adImageUrl || fallbackAd.thumbnailUrl,
          viewCount: 0,
          isAd: true,
        };
      } else {
        // High-fidelity content continuation and auto-flow map check
        if (currentPage.slotPosts?.[slotKey]) {
          return { ...currentPage.slotPosts[slotKey], isAd: false };
        }
        if (slotConf.postId) {
          const boundPost = displayStories.find(p => p.id === slotConf.postId);
          if (boundPost) return { ...boundPost, isAd: false };
        }
        const post = pagePosts[defaultPostIndex];
        if (post) return { ...post, isAd: false };
        return {
          id: `ad-fallback-${slotKey}`,
          title: fallbackAd.title,
          content: fallbackAd.content,
          category: fallbackAd.category,
          authorName: fallbackAd.authorName,
          thumbnailUrl: fallbackAd.thumbnailUrl,
          viewCount: 0,
          isAd: true,
        };
      }
    };

    const pageNumText = `पेज ${pageIndex + 1} / ${epaperPages.length}`;
    const pageRows = getPageRows(pageLayout);
    const pageFloatingBoxes = getPageFloatingBoxes(pageLayout);

    return (
      <div 
        key={pageId}
        className={`relative flex items-start justify-start transition-all duration-150 ${isPrintOnly ? 'printable-newspaper-page shrink-0' : ''}`}
        style={{
          width: isPrintOnly ? '960px' : `${960 * scale}px`,
          height: isPrintOnly ? '1242px' : `${1242 * scale}px`,
          minWidth: isPrintOnly ? '960px' : `${960 * scale}px`,
          minHeight: isPrintOnly ? '1242px' : `${1242 * scale}px`,
        }}
      >
        {/* Dynamic Newspaper Broad-sheet Canvas Sheet */}
        <div 
          id={isPrintOnly ? undefined : "printable-newspaper-page"}
          className="w-[960px] h-[1242px] max-h-[1242px] bg-white text-black pt-3 pb-5 px-6 font-sans relative flex flex-col justify-between border-4 border-double border-gray-950 select-text shrink-0 overflow-hidden"
          style={{ 
            fontFamily: '"Tiro Devanagari Hindi", "Noto Serif Devanagari", "Georgia", "serif"',
            color: '#000000',
            backgroundColor: '#ffffff',
            transform: isPrintOnly ? 'none' : `scale(${scale})`,
            transformOrigin: 'top left',
            position: 'absolute',
            top: 0,
            left: 0,
          }}
        >
          {/* TOP MOST SMALL WEBSITE TAG */}
          <div className="flex justify-between items-center text-[9px] text-gray-500 border-b border-gray-300 pb-0.5 font-serif">
            <span>publictak.app | सच्ची ख़बरें, जनता की आवाज़</span>
            <span className="text-red-600 font-bold tracking-wide">डिजिटल दैनिक (E-Paper Version)</span>
          </div>
          
          {/* TRADITIONAL MASTHEAD HEADER */}
          <div className="border-b-4 border-double border-black pb-2 mt-3">
            <div className="grid grid-cols-12 gap-3 items-center">
              {/* Left: Panchang Block */}
              <div className="col-span-3 border border-gray-400 pt-3.5 px-2 pb-1.5 text-[8px] leading-tight text-black relative">
                <div className="absolute -top-2.5 left-2 bg-amber-400 text-black text-[7px] px-1 py-0.5 font-bold border border-black rounded shadow-xs uppercase">
                  एस्ट्रो गाइड
                </div>
                <p><span className="font-bold">तिथि:</span> पंचमी तिथि दिवा 9.50 तक उपरांत षष्ठी</p>
                <p><span className="font-bold">नक्षत्र:</span> शतभिषा नक्षत्र दिवा 12.33 तक उपरांत पू.भा.</p>
                <p><span className="font-bold">पक्ष:</span> कृष्ण पक्ष, आश्विन</p>
                <p className="border-t border-gray-300 mt-2.5 pt-2"><span className="font-bold">तारीख:</span> {panchangData.fullDateHindi}</p>
              </div>

              {/* Center: Brand Title */}
              <div className="col-span-6 text-center pt-3">
                <h1 className="text-5xl font-black text-black tracking-tight font-serif uppercase select-text leading-none pt-2" style={{ fontFamily: '"Tiro Devanagari Hindi", "Noto Serif Devanagari", "serif"' }}>
                  पब्लिक तक
                </h1>
                <p className="text-[10px] font-bold tracking-[0.15em] text-red-600 mt-1 font-serif uppercase">अख़बार नहीं आंदोलन | दैनिक विशेष संस्करण</p>
              </div>

              {/* Right: Edition Details */}
              <div className="col-span-3 text-right leading-tight text-black font-serif">
                <div className="inline-block border-b border-black pb-0.5 mb-1">
                  <h2 className="text-xl font-bold text-red-600 font-serif tracking-tight">ई-पेपर</h2>
                </div>
                <p className="text-[9px] font-bold text-gray-800">{selectedDistrict || 'बिहार-झारखंड'} संस्करण</p>
                <p className="text-[8px] text-gray-500">{panchangData.fullDateHindi}</p>
              </div>
            </div>
          </div>

          {/* Teal Colored Sun Info Bar */}
          <div className="bg-[#008f95] text-white mt-2 p-1.5 px-3 flex justify-between items-center text-[10px] font-bold shadow-inner border border-[#007b80] font-serif">
            <div className="flex items-center gap-1 text-yellow-300">
              <span className="material-symbols-outlined text-xs leading-none">pin_drop</span>
              <span className="font-bold uppercase tracking-wider">{selectedDistrict || 'बिहार-झारखंड'}</span>
            </div>
            <div className="flex items-center gap-5">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400"></span>
                आज सूर्यास्त <span className="text-yellow-200">06:39</span> बजे
              </span>
              <span className="w-px h-3 bg-white/40"></span>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400"></span>
                आज सूर्योदय <span className="text-yellow-200">05:18</span> बजे
              </span>
            </div>
          </div>

          {/* DYNAMIC CANVAS CONTENT SECTION */}
          <div className="flex flex-col gap-3.5 flex-grow mt-3.5 overflow-hidden h-[980px] w-full justify-start select-text relative">
            
            {/* RENDER DYNAMIC ROWS & COLUMNS */}
            {pageRows.map((row: any, rIdx: number) => {
              return (
                <React.Fragment key={row.id}>
                  <div 
                    style={{ height: `${row.height}px`, maxHeight: `${row.height}px` }}
                    className="flex gap-3.5 w-full overflow-hidden shrink-0 relative items-stretch"
                  >
                    {row.cols.map((col: any, cIdx: number) => {
                      const postIndex = rIdx * 2 + cIdx;
                      const fallbackAd = fallbackAds[postIndex % fallbackAds.length];
                      const colPost = getSlotContent(col.id, postIndex, fallbackAd);
                      
                      return (
                        <div 
                          key={col.id} 
                          style={{ width: `${col.width}%` }} 
                          className="h-full overflow-hidden shrink-0 relative group/col"
                        >
                          {renderSlot(col.id, postIndex + 1, colPost, row.height, pageLayout, pageId)}

                          {/* Interactive Column Management Buttons inside layout editor */}
                          {isEditingLayout && !isPrintOnly && (
                            <div className="absolute bottom-1 right-1 hidden group-hover/col:flex items-center gap-1 bg-black/85 p-1 rounded z-40 shadow">
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleDeleteColumn(rIdx, cIdx); }}
                                className="bg-red-600 hover:bg-red-700 text-white rounded px-1.5 py-0.5 text-[8px] flex items-center gap-0.5"
                                title="कॉलम हटाएं (Delete Column)"
                              >
                                <span className="material-symbols-outlined text-[10px] font-bold">delete</span>
                                <span>हटाएं</span>
                              </button>
                            </div>
                          )}

                          {/* Column Width Drag Handle */}
                          {isEditingLayout && !isPrintOnly && cIdx < row.cols.length - 1 && (
                            <div 
                              onMouseDown={(e) => startDragColumnWidth(e, rIdx, cIdx)}
                              className="absolute right-[-7px] top-0 bottom-0 w-3.5 hover:bg-blue-600/80 cursor-ew-resize z-40 flex items-center justify-center transition-colors rounded-full"
                              title="कॉलम चौड़ाई बदलें"
                            >
                              <div className="w-0.5 h-12 bg-blue-600 rounded-full group-hover/col:bg-white"></div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Row Height Drag Handle & Row Delete Button */}
                  {isEditingLayout && !isPrintOnly && (
                    <div className="flex items-center gap-2 my-[-3px] relative shrink-0 z-40 select-none">
                      <div 
                        onMouseDown={(e) => startDragRowHeight(e, rIdx)}
                        className="flex-1 h-3 bg-blue-500/10 hover:bg-blue-600/70 border border-blue-500/20 hover:border-blue-600/40 cursor-ns-resize rounded-lg flex items-center justify-center transition-all group"
                        title="पंक्ति का आकार बदलें (ऊपर-नीचे खींचें)"
                      >
                        <div className="w-24 h-1 bg-blue-600 rounded-full group-hover:bg-white transition-colors"></div>
                        <span className="text-[7.5px] text-blue-800 group-hover:text-white font-extrabold ml-2 font-sans tracking-wide">पंक्ति {rIdx+1} रिसाइज (HEIGHT)</span>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteRow(rIdx); }}
                        className="bg-red-600 hover:bg-red-700 active:scale-95 text-white font-extrabold text-[8px] px-2 py-1 rounded shadow transition-all flex items-center gap-1 shrink-0 uppercase tracking-wider"
                        title="यह पंक्ति और इसके सभी कॉलम पूरी तरह हटाएं"
                      >
                        <span className="material-symbols-outlined text-[10px] font-bold">delete_forever</span>
                        <span>पंक्ति {rIdx+1} हटाएँ</span>
                      </button>
                    </div>
                  )}
                </React.Fragment>
              );
            })}

            {/* RENDER ABSOLUTE FLOATING BOXES */}
            {pageFloatingBoxes.map((box: any, bIdx: number) => {
              const fallbackAd = fallbackAds[bIdx % fallbackAds.length];
              const boxPost = getSlotContent(box.slotKey, bIdx + 8, fallbackAd);
              const isSelectedBox = selectedEditSlot === box.slotKey;

              return (
                <div
                  key={box.id}
                  style={{
                    position: 'absolute',
                    left: `${box.x}px`,
                    top: `${box.y}px`,
                    width: `${box.width}px`,
                    height: `${box.height}px`,
                    zIndex: 45,
                  }}
                  className={`bg-white rounded border-2 border-double border-red-600 shadow-2xl transition-shadow ${
                    isEditingLayout ? 'hover:ring-2 hover:ring-blue-500/50 cursor-move' : ''
                  } ${isSelectedBox ? 'ring-4 ring-blue-600' : ''}`}
                  onMouseDown={(e) => isEditingLayout && startDragFloatingBox(e, box.id)}
                >
                  {/* Absolute box slot rendering */}
                  {renderSlot(box.slotKey, bIdx + 10, boxPost, box.height, pageLayout, pageId)}

                  {/* Absolute box administration buttons */}
                  {isEditingLayout && (
                    <>
                      {/* Close / Delete Box */}
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteFloatingBox(box.id); }}
                        className="absolute -top-3 -right-3 w-6 h-6 bg-red-600 hover:bg-red-700 text-white rounded-full flex items-center justify-center shadow-lg z-50 transition-transform hover:scale-110 border border-white"
                        title="बॉक्स हटाएं"
                      >
                        <span className="material-symbols-outlined text-xs font-bold">close</span>
                      </button>

                      {/* Resize Handle at bottom right */}
                      <div
                        onMouseDown={(e) => startResizeFloatingBox(e, box.id)}
                        className="absolute bottom-0 right-0 w-4 h-4 bg-blue-600 hover:bg-blue-700 cursor-se-resize z-50 rounded-tl-full flex items-end justify-end p-0.5 text-white"
                        title="आकार बदलें"
                      >
                        <span className="material-symbols-outlined text-[8px] font-extrabold rotate-90 leading-none">open_in_full</span>
                      </div>
                    </>
                  )}
                </div>
              );
            })}

          </div>

          {/* Dynamic Green Announcement Banner */}
          <div className="bg-[#005c53] text-white p-2 text-center text-[10px] font-bold tracking-wider leading-none shadow-sm border-y border-[#00423c] uppercase font-serif mt-2 shrink-0">
            ★ सच्ची ख़बरें, जनता की आवाज़ - हमारे सभी समाचारों को विस्तार से पढ़ने के लिए publictak.app पर आएं ★
          </div>

          {/* FOOTER CREDITS AND DATE */}
          <div className="border-t-2 border-double border-black pt-1 mt-2 flex justify-between items-center text-[8.5px] font-bold text-gray-700 font-serif leading-none shrink-0">
            <span>सत्यमेव जयते | पब्लिक तक स्वतंत्र एवं निष्पक्ष प्रेस पहल</span>
            <span>{pageNumText}</span>
            <span>ई-मूल्य: ₹ 0.00 / निःशुल्क दैनिक</span>
          </div>

        </div>
      </div>
    );
  };

  // Direct High-Fidelity Print Handler
  const handlePrint = async () => {
    try {
      setIsPrinting(true);
      const element = document.getElementById('all-printable-pages');
      if (!element) {
        alert("प्रिंट करने के लिए कोई कंटेंट नहीं मिला।");
        setIsPrinting(false);
        return;
      }

      // Open a new tab/window for responsive print preview
      const printWindow = window.open("", "_blank");
      if (!printWindow) {
        alert("कृपया पॉप-अप ब्लॉकर को अक्षम (disable) करें और पुनः प्रयास करें।");
        setIsPrinting(false);
        return;
      }

      // Extract all page styles (Tailwind styles, font imports, custom rules)
      let stylesHtml = '';
      for (const sheet of Array.from(document.styleSheets)) {
        try {
          const rules = Array.from(sheet.cssRules || sheet.rules);
          stylesHtml += `<style>${rules.map(r => r.cssText).join('\n')}</style>`;
        } catch (e) {
          if (sheet.href) {
            stylesHtml += `<link rel="stylesheet" href="${sheet.href}">`;
          }
        }
      }

      const headHtml = `
        <head>
          <title>पब्लिक तक डिजिटल दैनिक - ${selectedDate}</title>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Tiro+Devanagari+Hindi:ital@0;1&family=Noto+Serif+Devanagari:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
          ${stylesHtml}
          <style>
            /* Base Reset */
            html, body {
              margin: 0;
              padding: 0;
              background-color: #111827;
              font-family: 'Tiro Devanagari Hindi', 'Inter', 'Noto Serif Devanagari', sans-serif;
              color: #f3f4f6;
              min-height: 100vh;
              display: flex;
              flex-direction: column;
            }

            /* Responsive Preview Container */
            .print-header {
              position: sticky;
              top: 0;
              left: 0;
              right: 0;
              z-index: 1000;
              background-color: #1f2937;
              border-bottom: 1px solid #374151;
              padding: 12px 20px;
              display: flex;
              justify-content: space-between;
              align-items: center;
              box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
            }
            .print-title {
              font-size: 16px;
              font-weight: 600;
              color: #ffffff;
              display: flex;
              align-items: center;
              gap: 8px;
            }
            .print-date {
              font-size: 12px;
              color: #9ca3af;
              background-color: #374151;
              padding: 4px 8px;
              border-radius: 6px;
              font-weight: 500;
            }
            .print-btn-group {
              display: flex;
              gap: 10px;
            }
            .btn {
              padding: 8px 16px;
              font-size: 13px;
              font-weight: 600;
              border-radius: 8px;
              cursor: pointer;
              border: none;
              transition: all 0.15s ease-in-out;
              display: inline-flex;
              align-items: center;
              gap: 8px;
              color: white;
              outline: none;
            }
            .btn:active {
              transform: scale(0.96);
            }
            .btn-print {
              background-color: #16a34a;
              box-shadow: 0 2px 4px rgba(22, 163, 74, 0.2);
            }
            .btn-print:hover {
              background-color: #15803d;
            }
            .btn-close {
              background-color: #4b5563;
            }
            .btn-close:hover {
              background-color: #374151;
            }
            .preview-scroll-wrapper {
              flex: 1;
              overflow-y: auto;
              padding: 40px 16px;
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 40px;
              box-sizing: border-box;
            }

            /* Broad-sheet rendering styling (Letter Size Adjusted: 960x1242) */
            .printable-newspaper-page {
              position: relative !important;
              top: 0 !important;
              left: 0 !important;
              transform: none !important;
              box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.04) !important;
              margin: 0 auto !important;
              box-sizing: border-box !important;
              background-color: white !important;
              color: black !important;
              max-width: 960px !important;
              width: 960px !important;
              height: 1242px !important;
              flex-shrink: 0 !important;
            }

            .printable-uploaded-page {
              position: relative !important;
              margin: 0 auto !important;
              box-sizing: border-box !important;
              max-width: 800px !important;
              background-color: white !important;
              box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3) !important;
              padding: 10px !important;
              display: flex !important;
              justify-content: center !important;
              align-items: center !important;
            }
            .printable-uploaded-page img {
              width: 100% !important;
              height: auto !important;
              display: block !important;
            }

            /* Responsive scale adjustments on smaller viewports */
            @media (max-width: 992px) {
              .preview-scroll-wrapper {
                padding: 16px 8px;
              }
              .printable-newspaper-page {
                transform: scale(0.75) !important;
                transform-origin: top center !important;
                margin-bottom: -310px !important;
              }
            }
            @media (max-width: 768px) {
              .printable-newspaper-page {
                transform: scale(0.55) !important;
                transform-origin: top center !important;
                margin-bottom: -559px !important;
              }
            }
            @media (max-width: 540px) {
              .printable-newspaper-page {
                transform: scale(0.38) !important;
                transform-origin: top center !important;
                margin-bottom: -770px !important;
              }
              .print-title {
                font-size: 14px;
              }
              .print-date {
                display: none;
              }
              .btn {
                padding: 6px 12px;
                font-size: 12px;
              }
            }

            /* High-fidelity Print-only Override rules */
            @media print {
              * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              .no-print {
                display: none !important;
              }
              html, body {
                background-color: white !important;
                color: black !important;
                min-height: auto !important;
                height: 100% !important;
                display: block !important;
                overflow: visible !important;
                margin: 0 !important;
                padding: 0 !important;
              }
              .preview-scroll-wrapper {
                padding: 0 !important;
                display: block !important;
                overflow: visible !important;
                min-height: auto !important;
                height: auto !important;
                gap: 0 !important;
              }
              .printable-newspaper-page {
                transform: none !important;
                margin: 0 auto !important;
                box-shadow: none !important;
                border: 4px double black !important;
                width: 960px !important;
                height: 1242px !important;
                max-width: 100% !important;
                box-sizing: border-box !important;
                page-break-inside: avoid !important;
                page-break-after: always !important;
                zoom: 0.85 !important; /* Scale to fit standard Letter page (816px / 960px) perfectly */
              }
              .printable-newspaper-page:last-child {
                page-break-after: avoid !important;
              }

              .printable-uploaded-page {
                width: 100% !important;
                height: auto !important;
                page-break-inside: avoid !important;
                page-break-after: always !important;
                display: block !important;
                box-sizing: border-box !important;
                padding: 0 !important;
                box-shadow: none !important;
                margin: 0 !important;
              }
              .printable-uploaded-page img {
                width: 100% !important;
                max-height: 100% !important;
                object-fit: contain !important;
              }
              .printable-uploaded-page:last-child {
                page-break-after: avoid !important;
              }

              @page {
                size: letter portrait;
                margin: 0;
              }
            }
          </style>
        </head>
      `;

      // Get all pages content
      const contentHtml = element.innerHTML;

      // Build document content
      printWindow.document.open();
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          ${headHtml}
          <body>
            <div class="print-header no-print">
              <div class="print-title">
                <span>पब्लिक तक डिजिटल दैनिक</span>
                <span class="print-date">${selectedDate}</span>
              </div>
              <div class="print-btn-group">
                <button class="btn btn-print" onclick="window.print()">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h12v7"></path><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                  प्रिंट करें (Print All Pages)
                </button>
                <button class="btn btn-close" onclick="window.close()">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                  बंद करें (Close)
                </button>
              </div>
            </div>
            <div class="preview-scroll-wrapper">
              ${contentHtml}
            </div>
            <script>
              window.onload = function() {
                // Wait for high quality custom fonts to load before triggering native print dialog
                if (document.fonts) {
                  document.fonts.ready.then(function() {
                    setTimeout(function() {
                      window.focus();
                      window.print();
                    }, 600);
                  });
                } else {
                  setTimeout(function() {
                    window.focus();
                    window.print();
                  }, 1200);
                }
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
      setIsPrinting(false);

    } catch (err) {
      console.error("Print failed:", err);
      alert("प्रिंट करने में त्रुटि हुई। कृपया पुनः प्रयास करें।");
      setIsPrinting(false);
    }
  };

  // Download PDF compilation handlers
  const handleDownloadPDF = async () => {
    setIsDownloadingPDF(true);
    setPdfProgress('प्रक्रिया शुरू हो रही है...');

    try {
      if (ePaperMode === 'uploaded' && activeEPaper) {
        // Mode 1: Download PDF of Uploaded Replica Pages (Letter Size)
        const pdf = new jsPDF('p', 'mm', 'letter');
        const totalPages = activeEPaper.pages.length;
        
        for (let i = 0; i < totalPages; i++) {
          setPdfProgress(`पेज ${i + 1}/${totalPages} तैयार हो रहा है...`);
          if (i > 0) pdf.addPage();
          
          const originalImgUrl = activeEPaper.pages[i];
          // Proxy the image URL to completely bypass CORS blockages on external hosting servers
          const imgUrl = `/api/proxy-image?url=${encodeURIComponent(originalImgUrl)}`;
          
          const img = await new Promise<HTMLImageElement>((resolve, reject) => {
            const image = new Image();
            image.crossOrigin = "anonymous";
            image.src = imgUrl;
            image.onload = () => resolve(image);
            image.onerror = (e) => reject(e);
          });
          
          const imgWidth = 215.9;
          const imgHeight = (img.height * imgWidth) / img.width;
          pdf.addImage(img, 'JPEG', 0, 0, imgWidth, Math.min(imgHeight, 279.4));
        }
        
        pdf.save(`Public_Tak_EPaper_${selectedDate}_${activeEPaper.title.replace(/\s+/g, '_')}.pdf`);
      } else if (ePaperMode === 'auto') {
        // Mode 2: Download PDF of Auto-compiled newsprint page (all pages in single Premium HD Letter PDF!)
        const totalPages = epaperPages.length;
        if (totalPages === 0) {
          throw new Error("कोई डिजिटल पेज उपलब्ध नहीं है।");
        }

        const pdf = new jsPDF('p', 'mm', 'letter');
        const originalPageNum = selectedPageNum; // Save original selected page to restore later

        for (let i = 0; i < totalPages; i++) {
          setPdfProgress(`पेज ${i + 1}/${totalPages} संकलित (Compile) हो रहा है...`);
          
          // Programmatically switch to page 'i' to render its respective posts & layout
          setSelectedPageNum(i);
          
          // Allow React state & layout engine to re-render completely
          await new Promise(resolve => setTimeout(resolve, 400));
          
          const element = document.getElementById('printable-newspaper-page');
          if (!element) throw new Error(`पेज ${i + 1} कंटेनर नहीं मिला।`);

          // Find all images inside the printable container and convert to base64 via proxy to ensure offline rendering in PDF
          const imgElements = Array.from(element.querySelectorAll('img'));
          const originalSrcs = new Map<HTMLImageElement, string>();
          
          for (const img of imgElements) {
            const src = img.getAttribute('src');
            if (src && !src.startsWith('data:')) {
              try {
                originalSrcs.set(img, src);
                const fetchUrl = src.startsWith('http')
                  ? `/api/proxy-image?url=${encodeURIComponent(src)}`
                  : src;
                
                const res = await fetch(fetchUrl);
                const blob = await res.blob();
                const base64 = await new Promise<string>((resolve, reject) => {
                  const reader = new FileReader();
                  reader.onloadend = () => resolve(reader.result as string);
                  reader.onerror = reject;
                  reader.readAsDataURL(blob);
                });
                img.src = base64;
                
                // CRITICAL: Wait for the image to be completely decoded and ready for canvas rendering!
                if (typeof img.decode === 'function') {
                  await img.decode().catch(() => new Promise((res) => {
                    img.onload = res;
                    img.onerror = res;
                  }));
                } else {
                  await new Promise((resolve) => {
                    img.onload = resolve;
                    img.onerror = resolve;
                  });
                }
              } catch (err) {
                console.warn(`Failed to convert image to base64 for ${src}:`, err);
              }
            }
          }

          try {
            // Temporarily clear scaling CSS transforms & positions so html2canvas captures 100% crisp full-size broadsheet
            const originalTransform = element.style.transform;
            const originalTransformOrigin = element.style.transformOrigin;
            const originalPosition = element.style.position;
            
            element.style.transform = 'none';
            element.style.transformOrigin = 'initial';
            element.style.position = 'relative';
            
            const canvas = await html2canvas(element, {
              scale: 3, // Premium high-definition 3x scale (300 DPI equivalent)
              useCORS: true,
              allowTaint: true,
              logging: false,
              backgroundColor: '#ffffff',
              width: 960,
              height: 1242,
              scrollX: 0,
              scrollY: 0,
              windowWidth: 960,
              windowHeight: 1242
            });
            
            // Restore the layout styles immediately
            element.style.transform = originalTransform;
            element.style.transformOrigin = originalTransformOrigin;
            element.style.position = originalPosition;
            
            if (i > 0) pdf.addPage();
            
            const imgData = canvas.toDataURL('image/jpeg', 0.98); // High quality 0.98 compression
            const imgWidth = 215.9;
            const pageHeight = 279.4;
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            const finalHeight = Math.min(imgHeight, pageHeight);
            
            pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, finalHeight);

            // Add clickable link hotspots for all anchor links (पूरा देखें) on this page
            try {
              const links = element.querySelectorAll('a');
              links.forEach(link => {
                const href = link.getAttribute('href');
                if (href) {
                  // Calculate absolute offsets relative to target element 'printable-newspaper-page'
                  let x = 0;
                  let y = 0;
                  let curr: HTMLElement | null = link as HTMLElement;
                  while (curr && curr !== element) {
                    x += curr.offsetLeft || 0;
                    y += curr.offsetTop || 0;
                    curr = curr.offsetParent as HTMLElement | null;
                  }
                  const linkWidth = (link as HTMLElement).offsetWidth || 30;
                  const linkHeight = (link as HTMLElement).offsetHeight || 10;
                  
                  // Scale coordinate offsets to PDF millimeter coordinates
                  const pdfX = (x / 960) * imgWidth;
                  const pdfY = (y / 1242) * finalHeight;
                  const pdfW = (linkWidth / 960) * imgWidth;
                  const pdfH = (linkHeight / 1242) * finalHeight;
                  
                  pdf.link(pdfX, pdfY, pdfW, pdfH, { url: href });
                }
              });
            } catch (linkErr) {
              console.warn("Failed to generate PDF link annotations:", linkErr);
            }
          } finally {
            // Restore original sources so UI doesn't flicker or break
            originalSrcs.forEach((src, img) => {
              img.src = src;
            });
          }
        }

        // Restore original user selected page in broadsheet view
        setSelectedPageNum(originalPageNum);
        
        pdf.save(`Public_Tak_EPaper_${selectedDate}_${selectedDistrict || selectedState || 'National'}.pdf`);
      }
      
      setPdfProgress('');
      alert("E-Paper PDF सफलतापूर्वक डाउनलोड हो गया है!");
    } catch (err) {
      console.error("PDF generation failed:", err);
      alert("पीडीएफ डाउनलोड करने में त्रुटि हुई। कृपया पुनः प्रयास करें।");
    } finally {
      setIsDownloadingPDF(false);
    }
  };

  // Navigate Date Handler
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    setSelectedDate(`${yyyy}-${mm}-${dd}`);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    setSelectedDate(`${yyyy}-${mm}-${dd}`);
  };

  // Zooming controls for Uploaded replica
  const zoomIn = () => setZoomScale((prev) => Math.min(prev + 0.25, 3));
  const zoomOut = () => setZoomScale((prev) => Math.max(prev - 0.25, 0.5));
  const resetZoom = () => setZoomScale(1);

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      if (viewerRef.current?.requestFullscreen) {
        viewerRef.current.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Admin Upload Handlers
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setUploadFiles(Array.from(e.target.files));
    }
  };

  const handleUploadEPaper = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim() || uploadFiles.length === 0 || !currentUser) {
      alert("कृपया सभी आवश्यक फ़ील्ड भरें और कम से कम एक पृष्ठ चुनें।");
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const uploadedUrls: string[] = [];
      const totalFiles = uploadFiles.length;

      for (let i = 0; i < totalFiles; i++) {
        const file = uploadFiles[i];
        const fileExt = file.name.split('.').pop() || 'jpg';
        const fileRef = storage.ref(`epapers/${uploadDate}/${uuidv4()}_page_${i + 1}.${fileExt}`);
        const uploadTask = fileRef.put(file);
        
        await new Promise<void>((resolve, reject) => {
          uploadTask.on(
            'state_changed',
            (snapshot) => {
              const fileProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
              const overallProgress = ((i / totalFiles) * 100) + (fileProgress / totalFiles);
              setUploadProgress(Math.round(overallProgress));
            },
            (error) => reject(error),
            async () => {
              const downloadUrl = await uploadTask.snapshot.ref.getDownloadURL();
              uploadedUrls.push(downloadUrl);
              resolve();
            }
          );
        });
      }

      const epaperData: Omit<EPaper, 'id'> = {
        title: uploadTitle.trim(),
        date: uploadDate,
        state: uploadState || 'Overall',
        district: uploadDistrict || '',
        pages: uploadedUrls,
        uploadedBy: currentUser.uid,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      };

      await db.collection('epapers').add(epaperData);

      setUploadTitle('');
      setUploadFiles([]);
      setUploadState('');
      setUploadDistrict('');
      setShowUploadModal(false);
      alert("ई-पेपर सफलतापूर्वक अपलोड और प्रकाशित हो गया है!");
    } catch (err) {
      console.error("Upload failed:", err);
      alert("अपलोड विफल रहा। कृपया पुनः प्रयास करें।");
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleDeleteEPaper = async (epaperId: string, pagesUrls: string[]) => {
    if (!window.confirm("क्या आप वाकई इस ई-पेपर संस्करण को हटाना चाहते हैं?")) return;

    try {
      for (const url of pagesUrls) {
        try {
          const fileRef = storage.refFromURL(url);
          await fileRef.delete();
        } catch (storageErr) {
          console.warn("Storage delete failed:", storageErr);
        }
      }

      await db.collection('epapers').doc(epaperId).delete();
      alert("ई-पेपर सफलतापूर्वक हटा दिया गया है!");
    } catch (err) {
      console.error("Deletion failed:", err);
      alert("ई-पेपर हटाने में त्रुटि हुई।");
    }
  };

  const uploadDistricts = uploadState ? Object.keys(indianLocations[uploadState] || {}) : [];

  return (
    <div className="flex flex-col h-screen w-full bg-[#f4f5f8] text-gray-800 overflow-hidden">
      <SEO 
        title={`🗞️ दैनिक ई-पेपर (${selectedDate}) | Public Tak News`}
        description={`Public Tak का आज का डिजिटल दैनिक समाचार पत्र (${selectedDate}) ऑनलाइन पढ़ें। अपने राज्य ${selectedState || 'देश'} और जिला ${selectedDistrict || ''} की खबरें।`}
        url={`https://publictak.app/?page=epaper`}
        type="article"
      />
      {/* Light Theme Header branded for Public Tak */}
      <header className="flex-shrink-0 bg-red-600 border-b border-red-700 p-3 md:px-6 flex justify-between items-center z-20 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-full hover:bg-red-700 transition-colors text-white" title="वापस जाएं">
            <span className="material-symbols-outlined text-2xl leading-none">arrow_back</span>
          </button>
          <div>
            <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide flex items-center gap-2">
              <span className="material-symbols-outlined text-white text-xl md:text-2xl animate-pulse">newspaper</span>
              पब्लिक तक {t('epaper') || 'ई-पेपर'}
            </h1>
            <p className="text-[10px] text-red-100 hidden sm:block">लोकप्रिय डिजिटल दैनिक संस्करण</p>
          </div>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-1 bg-red-700 p-1 rounded-xl shadow-inner">
          <button 
            onClick={handlePrevDay} 
            className="p-1.5 rounded-lg hover:bg-red-800 text-white transition-colors"
            title="पिछला दिन"
          >
            <span className="material-symbols-outlined text-sm md:text-base leading-none font-bold">chevron_left</span>
          </button>
          <input 
            type="date" 
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-transparent border-none text-white text-xs md:text-sm font-bold focus:ring-0 outline-none w-28 md:w-32 cursor-pointer text-center"
          />
          <button 
            onClick={handleNextDay} 
            className="p-1.5 rounded-lg hover:bg-red-800 text-white transition-colors"
            title="अगला दिन"
          >
            <span className="material-symbols-outlined text-sm md:text-base leading-none font-bold">chevron_right</span>
          </button>
        </div>

        <div className="w-8 h-8 md:w-10 md:h-10"></div>
      </header>

      {/* Filter and Mode Control Bar */}
      <div className="flex-shrink-0 bg-white border-b border-gray-200 p-3 md:px-6 flex flex-col md:flex-row gap-3 items-center justify-between shadow-sm">
        {/* Location Dropdowns */}
        <div className="flex flex-wrap gap-2 items-center w-full md:w-auto">
          <span className="text-xs font-bold text-gray-500 flex items-center gap-1 uppercase tracking-wider">
            <span className="material-symbols-outlined text-sm text-red-600 font-bold">pin_drop</span> क्षेत्र:
          </span>
          
          <select
            value={selectedState}
            onChange={(e) => {
              setSelectedState(e.target.value);
              setSelectedDistrict('');
            }}
            className="bg-gray-100 border border-gray-300 rounded-lg text-xs md:text-sm text-gray-800 py-1.5 px-3 focus:outline-none focus:border-red-500 outline-none cursor-pointer font-semibold"
          >
            <option value="">{language === 'hi' ? 'सभी राज्य (National)' : 'All States (National)'}</option>
            {statesList.map((st) => (
              <option key={st} value={st}>{st}</option>
            ))}
          </select>

          <select
            value={selectedDistrict}
            onChange={(e) => setSelectedDistrict(e.target.value)}
            disabled={!selectedState}
            className="bg-gray-100 border border-gray-300 rounded-lg text-xs md:text-sm text-gray-800 py-1.5 px-3 focus:outline-none focus:border-red-500 outline-none cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed font-semibold"
          >
            <option value="">{language === 'hi' ? 'सभी जिले' : 'All Districts'}</option>
            {districtsList.map((dt) => (
              <option key={dt} value={dt}>{dt}</option>
            ))}
          </select>
        </div>
      </div>

      {/* PDF download progress status bar */}
      {isDownloadingPDF && (
        <div className="bg-green-50 border-b border-green-200 px-6 py-2 flex items-center justify-between text-xs text-green-800 font-bold animate-pulse">
          <div className="flex items-center gap-2">
            <span className="animate-spin h-3.5 w-3.5 border-2 border-green-800/30 border-t-green-800 rounded-full"></span>
            <span>{pdfProgress}</span>
          </div>
          <span>कृपया प्रतीक्षा करें...</span>
        </div>
      )}

      {/* Main E-Paper Display Workspace */}
      <div className="flex-grow flex flex-col md:flex-row overflow-hidden relative">
        
        {/* Left Panel: List of Uploaded Newspaper Editions (Only visible in PDF mode) */}
        {ePaperMode === 'uploaded' && (
          <div className="w-full md:w-64 bg-white border-b md:border-b-0 md:border-r border-gray-200 flex-shrink-0 flex flex-col overflow-hidden max-h-40 md:max-h-full">
            <div className="p-3 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
              <span className="text-xs font-bold text-gray-500 tracking-wider uppercase">
                उपलब्ध संस्करण ({epapers.length})
              </span>
            </div>
            <div className="flex-grow overflow-y-auto p-2 space-y-2 flex flex-row md:flex-col gap-2 md:gap-0">
              {epapers.map((paper) => (
                <div 
                  key={paper.id}
                  onClick={() => {
                    setActiveEPaper(paper);
                    setActivePageIdx(0);
                    setZoomScale(1);
                  }}
                  className={`w-48 md:w-full flex-shrink-0 rounded-xl p-3 cursor-pointer border transition-all ${
                    activeEPaper?.id === paper.id 
                      ? 'bg-red-50 border-red-500 shadow-sm text-red-900' 
                      : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className="flex justify-between items-start gap-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-red-600 bg-red-100 px-1.5 py-0.5 rounded">
                      {paper.state || 'National'}
                    </span>
                    {isAdmin && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteEPaper(paper.id, paper.pages);
                        }}
                        className="text-gray-400 hover:text-red-600 transition-colors p-1 rounded hover:bg-gray-100"
                        title="Delete Edition"
                      >
                        <span className="material-symbols-outlined text-sm leading-none font-bold">delete</span>
                      </button>
                    )}
                  </div>
                  <h3 className="text-sm font-bold mt-2 text-gray-900 line-clamp-1">{paper.title}</h3>
                  <div className="flex justify-between items-center text-[10px] text-gray-500 mt-2">
                    <span>{paper.pages.length} {paper.pages.length === 1 ? 'पेज' : 'पेजेस'}</span>
                    <span>{paper.district || (language === 'hi' ? 'मुख्य' : 'National')}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Left Panel: Auto-Generated Dynamic Newspaper Page Navigtion (Only visible in Auto mode) */}
        {ePaperMode === 'auto' && epaperPages.length > 0 && (
          <div className="w-full md:w-64 bg-white border-b md:border-b-0 md:border-r border-gray-200 flex-shrink-0 flex flex-col overflow-hidden max-h-24 md:max-h-full">
            <div className="p-3 border-b border-gray-200 bg-gray-50 hidden md:block">
              <span className="text-xs font-bold text-gray-500 tracking-wider uppercase">
                समाचार पृष्ठ (Pages)
              </span>
            </div>
            <div className="flex-grow overflow-x-auto md:overflow-y-auto p-2 flex flex-row md:flex-col gap-2">
              {epaperPages.map((page, index) => (
                <button
                  key={page.id}
                  onClick={() => setSelectedPageNum(index)}
                  className={`flex-shrink-0 rounded-xl p-2 md:p-3 text-left border transition-all flex items-center gap-2.5 w-auto md:w-full ${
                    selectedPageNum === index
                      ? 'bg-red-50 border-red-500 shadow-sm text-red-900 font-bold'
                      : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <span className="material-symbols-outlined text-red-600 text-lg leading-none">{page.icon}</span>
                  <div className="text-xs md:text-sm truncate">
                    <p className="font-bold leading-tight">{page.name}</p>
                    <p className="text-[10px] text-gray-500 hidden md:block mt-0.5">{page.title}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Right Panel: Immersive Viewer Screen */}
        <div className="flex-grow flex flex-col bg-[#e9ebef] overflow-y-auto p-4 md:p-6 select-none relative">
          
          {/* VIEW: Uploaded PDF/Image Replica Mode */}
          {ePaperMode === 'uploaded' && (
            <div className="flex-grow flex flex-col h-full justify-between overflow-hidden">
              {activeEPaper ? (
                <div className="flex-grow flex flex-col items-center justify-center relative">
                  {/* Floating Zoom Controls */}
                  <div className="absolute top-2 right-2 z-10 flex items-center gap-1 bg-white/95 backdrop-blur-sm border border-gray-200 p-1 rounded-xl shadow-lg">
                    <button onClick={zoomOut} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-700 transition-colors" title="Zoom Out">
                      <span className="material-symbols-outlined text-sm md:text-base leading-none font-bold">remove</span>
                    </button>
                    <span className="text-xs font-bold text-gray-700 px-1 w-10 text-center">{Math.round(zoomScale * 100)}%</span>
                    <button onClick={zoomIn} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-700 transition-colors" title="Zoom In">
                      <span className="material-symbols-outlined text-sm md:text-base leading-none font-bold">add</span>
                    </button>
                    <div className="w-px h-4 bg-gray-200 mx-1"></div>
                    <button onClick={resetZoom} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-700 transition-colors" title="Reset Zoom">
                      <span className="material-symbols-outlined text-sm md:text-base leading-none">restart_alt</span>
                    </button>
                    <button onClick={toggleFullscreen} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-700 transition-colors" title="Fullscreen">
                      <span className="material-symbols-outlined text-sm md:text-base leading-none">{isFullscreen ? 'fullscreen_exit' : 'fullscreen'}</span>
                    </button>
                    <div className="w-px h-4 bg-gray-200 mx-1"></div>
                    <button 
                      onClick={handlePrint}
                      disabled={isPrinting}
                      className="p-1.5 rounded-lg hover:bg-green-50 text-green-600 transition-colors disabled:opacity-50" 
                      title="Print All Pages"
                    >
                      <span className="material-symbols-outlined text-sm md:text-base leading-none font-bold">{isPrinting ? 'hourglass_empty' : 'print'}</span>
                    </button>
                  </div>

                  {/* Zoomable Image Container */}
                  <div 
                    ref={viewerRef}
                    className="w-full flex-grow overflow-auto flex items-center justify-center p-2 bg-[#e9ebef] relative"
                  >
                    <div 
                      className="transition-transform duration-150 origin-center max-w-full max-h-full flex items-center justify-center"
                      style={{ transform: `scale(${zoomScale})` }}
                    >
                      <img 
                        src={activeEPaper.pages[activePageIdx]} 
                        alt={`E-Paper Page ${activePageIdx + 1}`}
                        className="max-h-[60vh] md:max-h-[70vh] w-auto object-contain border border-gray-300 shadow-2xl rounded-sm bg-white"
                        onDragStart={(e) => e.preventDefault()}
                      />
                    </div>

                    {/* Page Flip Nav */}
                    {activePageIdx > 0 && (
                      <button 
                        onClick={() => { setActivePageIdx(prev => prev - 1); setZoomScale(1); }}
                        className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-white/90 hover:bg-white border border-gray-200 text-gray-800 rounded-full shadow-lg transition-all hover:scale-105"
                      >
                        <span className="material-symbols-outlined text-lg leading-none font-bold">chevron_left</span>
                      </button>
                    )}
                    {activePageIdx < activeEPaper.pages.length - 1 && (
                      <button 
                        onClick={() => { setActivePageIdx(prev => prev + 1); setZoomScale(1); }}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white/90 hover:bg-white border border-gray-200 text-gray-800 rounded-full shadow-lg transition-all hover:scale-105"
                      >
                        <span className="material-symbols-outlined text-lg leading-none font-bold">chevron_right</span>
                      </button>
                    )}
                  </div>

                  {/* Miniature Filmstrip Bar */}
                  <div className="w-full py-2 bg-white border-t border-gray-200 rounded-b-2xl flex flex-col items-center gap-1.5 shadow-sm mt-3">
                    <span className="text-[10px] font-bold text-gray-400">पेज {activePageIdx + 1} / {activeEPaper.pages.length}</span>
                    <div className="flex items-center gap-1.5 overflow-x-auto max-w-full px-4 pb-1">
                      {activeEPaper.pages.map((url, idx) => (
                        <button
                          key={idx}
                          onClick={() => { setActivePageIdx(idx); setZoomScale(1); }}
                          className={`relative flex-shrink-0 w-10 h-14 rounded border-2 overflow-hidden transition-all ${
                            activePageIdx === idx ? 'border-red-600 scale-105' : 'border-gray-200 opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={url} alt={`Thumb ${idx + 1}`} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Today's Top News section in PDF Mode */}
                  {activePosts.length > 0 && (
                    <div className="w-full mt-4 bg-white border border-gray-200 rounded-2xl p-4 shadow-sm text-left select-text">
                      <h3 className="text-sm font-extrabold text-gray-900 border-b border-gray-100 pb-2 mb-3 flex items-center gap-2">
                        <span className="material-symbols-outlined text-red-600 text-lg font-bold">newspaper</span>
                        आज के मुख्य समाचार (Today's Top News)
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {activePosts.slice(0, 9).map((post) => (
                          <div key={post.id} className="border border-gray-200 rounded-xl p-3.5 flex flex-col justify-between bg-gray-50/30 hover:bg-white hover:shadow-md transition-all duration-200">
                            <div>
                              <div className="flex justify-between items-start gap-2">
                                <span className="text-[9px] text-red-600 font-extrabold uppercase bg-red-50 px-2 py-0.5 rounded border border-red-100 tracking-wide">{post.category || 'विशेष समाचार'}</span>
                                <span className="text-[9px] text-gray-400 font-mono">views: {post.viewCount || 0}</span>
                              </div>
                              <h4 className="text-xs font-extrabold text-gray-900 mt-2 line-clamp-2 leading-snug">{post.title}</h4>
                              {post.thumbnailUrl && (
                                <div className="w-full h-[90px] my-2 rounded-lg overflow-hidden border border-gray-200 bg-gray-50 flex items-center justify-center">
                                  <img src={post.thumbnailUrl} alt={post.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                </div>
                              )}
                              <p className="text-[10px] text-gray-600 line-clamp-4 mt-1.5 leading-relaxed font-serif text-justify">{post.content ? post.content.replace(/<[^>]*>/g, '').trim() : ''}</p>
                            </div>
                            <div className="mt-3 pt-2.5 border-t border-gray-100 flex justify-between items-center">
                              <span className="text-[9px] font-bold text-gray-500">रिपोर्टर: {post.authorName || 'पब्लिक तक'}</span>
                              <button
                                onClick={() => {
                                  window.open(`${window.location.origin}?postId=${post.id}`, '_blank');
                                }}
                                className="text-[10px] text-red-600 font-extrabold hover:underline flex items-center gap-0.5"
                              >
                                <span>पूरा विवरण देखें</span>
                                <span className="material-symbols-outlined text-[10px] font-bold">arrow_forward</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex-grow flex flex-col items-center justify-center p-8 text-center text-gray-500 min-h-[350px] bg-white border border-gray-200 rounded-3xl shadow-xs">
                  <span className="material-symbols-outlined text-6xl text-gray-300 mb-3 animate-bounce">newspaper</span>
                  <h2 className="text-base font-bold text-gray-700">कोई अपलोड किया हुआ संस्करण नहीं मिला।</h2>
                  <p className="text-xs text-gray-400 mt-1 mb-4">आप "स्मार्ट डिजिटल दैनिक" बटन दबाकर स्वचालित संस्करण देख सकते हैं!</p>
                  <button
                    onClick={() => setEPaperMode('auto')}
                    className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-lg active:scale-95 flex items-center gap-2"
                  >
                    <span className="material-symbols-outlined text-sm">auto_stories</span>
                    <span>स्मार्ट डिजिटल दैनिक संस्करण देखें</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* VIEW: Auto-Generated HTML Broad-sheet Mode */}
          {ePaperMode === 'auto' && (
            <div className="w-full flex-grow flex flex-col items-center">
              {epaperPages.length > 0 ? (
                <div className="w-full max-w-4xl flex flex-col items-center">
                  
                  {/* Interactive zoom & controls for auto broadsheet */}
                  <div className="w-full max-w-4xl mb-3 flex flex-wrap items-center justify-between gap-3 bg-white border border-gray-200 p-2 px-3 rounded-2xl shadow-sm animate-fade-in">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">संस्करण:</span>
                      <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                        पेज {selectedPageNum + 1} / {epaperPages.length}
                      </span>
                    </div>

                    {/* Interactive Zoom & Scroll Controls */}
                    <div className="flex items-center gap-1 bg-gray-50 border border-gray-200 px-2 py-1 rounded-xl shadow-inner">
                      <button 
                        onClick={() => setAutoZoomMultiplier(prev => Math.max(0.4, prev - 0.15))}
                        className="p-1 rounded-lg hover:bg-gray-200 text-gray-800 transition-colors flex items-center justify-center" 
                        title="Zoom Out (-)"
                      >
                        <span className="material-symbols-outlined text-xs leading-none font-extrabold">remove</span>
                      </button>
                      <span className="text-[10px] font-extrabold text-gray-700 font-mono min-w-[36px] text-center">
                        {Math.round(Math.min(1.0, containerWidth / 960) * autoZoomMultiplier * 100)}%
                      </span>
                      <button 
                        onClick={() => setAutoZoomMultiplier(prev => Math.min(2.5, prev + 0.15))}
                        className="p-1 rounded-lg hover:bg-gray-200 text-gray-800 transition-colors flex items-center justify-center" 
                        title="Zoom In (+)"
                      >
                        <span className="material-symbols-outlined text-xs leading-none font-extrabold">add</span>
                      </button>
                      <div className="w-px h-3 bg-gray-300 mx-1"></div>
                      <button 
                        onClick={() => setAutoZoomMultiplier(1)}
                        className="text-[10px] px-1.5 py-0.5 rounded hover:bg-gray-200 text-gray-700 transition-colors font-extrabold"
                        title="Fit to Screen Width"
                      >
                        फ़िट
                      </button>
                      <button 
                        onClick={() => {
                          const base = Math.min(1.0, containerWidth / 960);
                          setAutoZoomMultiplier(1 / base);
                        }}
                        className="text-[10px] px-1.5 py-0.5 rounded hover:bg-gray-200 text-gray-700 transition-colors font-extrabold"
                        title="100% Full-Size Print"
                      >
                        100% आकार
                      </button>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {isAdmin && (
                        <button 
                          onClick={() => {
                            if (isEditingLayout) {
                              // Save current state when closing editor
                              handleSaveLayout();
                            }
                            setIsEditingLayout(!isEditingLayout);
                          }}
                          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 ${
                            isEditingLayout ? 'bg-blue-600 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300'
                          }`}
                        >
                          <span className="material-symbols-outlined text-sm">{isEditingLayout ? 'check_circle' : 'edit_square'}</span>
                          <span>{isEditingLayout ? 'लेआउट सहेजें (Save)' : 'लेआउट बदलें (Admin)'}</span>
                        </button>
                      )}
                      <button 
                        onClick={handlePrint}
                        disabled={isPrinting}
                        className="flex items-center gap-1.5 px-4 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 disabled:opacity-50"
                      >
                        <span className="material-symbols-outlined text-sm">print</span>
                        <span>{isPrinting ? 'तैयारी...' : 'प्रिंट करें'}</span>
                      </button>
                    </div>
                  </div>

                  {/* ADMIN DYNAMIC LAYOUT BUILDER CONTROLS */}
                  {isEditingLayout && (
                    <div className="w-full max-w-4xl mb-4 bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-2xl p-4 shadow-xl border border-blue-800 animate-in fade-in slide-in-from-top-4 duration-200">
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-3 mb-3">
                        <div className="flex items-center gap-2">
                          <span className="material-symbols-outlined text-yellow-400 font-bold text-xl">grid_view</span>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider text-white">एडवांस्ड ई-पेपर लेआउट आर्किटेक्ट</h4>
                            <p className="text-[10px] text-blue-200 mt-0.5">माउस से पंक्तियां, कॉलम और तैरते हुए बॉक्स (Floating Boxes) बनाकर अखबार का फ्रंटपेज सजाएं</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={handleResetLayout}
                            className="bg-red-500/10 hover:bg-red-500 text-red-300 text-[10px] font-extrabold px-3 py-1.5 rounded-lg border border-red-500/30 transition-all uppercase tracking-wider flex items-center gap-1"
                            title="मूल डिफ़ॉल्ट पर रीसेट करें"
                          >
                            <span className="material-symbols-outlined text-[13px] font-bold">restart_alt</span>
                            <span>मूल रीसेट</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Add Elements Section */}
                        <div className="space-y-2">
                          <span className="block text-[10px] font-extrabold uppercase tracking-widest text-blue-300">तत्व जोड़ें / नया ब्लॉक बनाएँ:</span>
                          <div className="flex flex-wrap gap-2">
                            <button
                              onClick={handleAddRow}
                              className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md active:scale-95 flex items-center gap-1.5"
                            >
                              <span className="material-symbols-outlined text-sm font-bold">add_row</span>
                              <span>नयी पंक्ति जोड़ें (+ Row)</span>
                            </button>
                            <button
                              onClick={handleAddFloatingBox}
                              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md active:scale-95 flex items-center gap-1.5"
                            >
                              <span className="material-symbols-outlined text-sm font-bold">layers</span>
                              <span>फ्लोटिंग बॉक्स जोड़ें (+ Box)</span>
                            </button>
                          </div>
                        </div>

                        {/* Row Specific Column Management */}
                        <div className="space-y-2">
                          <span className="block text-[10px] font-extrabold uppercase tracking-widest text-blue-300">पंक्तियों में कॉलम जोड़ें (Add Column):</span>
                          {pageRows.length === 0 ? (
                            <p className="text-[10px] text-gray-300 italic">कॉलम जोड़ने के लिए पहले पंक्ति जोड़ें।</p>
                          ) : (
                            <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                              {pageRows.map((row: any, rIdx: number) => (
                                <button
                                  key={row.id}
                                  onClick={() => handleAddColumn(rIdx)}
                                  className="bg-white/10 hover:bg-white/20 text-white text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition-all border border-white/10 flex items-center gap-1"
                                  title={`पंक्ति ${rIdx + 1} में नया कॉलम जोड़ें`}
                                >
                                  <span className="material-symbols-outlined text-[11px] font-bold">view_week</span>
                                  <span>पंक्ति {rIdx + 1} में (+ Col)</span>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Instructions / Interactive guides */}
                      <div className="mt-3 bg-blue-950/60 p-2.5 rounded-xl border border-blue-900 text-[10px] text-blue-200/95 leading-relaxed space-y-1">
                        <p className="font-extrabold text-blue-300 flex items-center gap-1">
                          <span className="material-symbols-outlined text-xs font-bold">info</span>
                          <span>माउस कंट्रोल गाइड्स:</span>
                        </p>
                        <ul className="list-disc pl-4 space-y-0.5">
                          <li><strong>पंक्ति की ऊंचाई (Row Height):</strong> पंक्ति के बीच के नीले बॉर्डर पर माउस दबाकर ऊपर-नीचे खींचें।</li>
                          <li><strong>कॉलम की चौड़ाई (Col Width):</strong> कॉलम के बीच के नीले वर्टिकल हैंडल पर माउस दबाकर बाएँ-दाएँ खींचें।</li>
                          <li><strong>फ्लोटिंग बॉक्स (Floating Box):</strong> लाल-बॉर्डर वाले तैरते हुए बॉक्स पर क्लिक करके उसे कहीं भी खिसकाएं, और नीचे-दाएँ कोने से आकार बदलें।</li>
                          <li><strong>समाचार / विज्ञापन एडिट:</strong> किसी भी ब्लॉक पर माउस ले जाकर "एडिट" बटन पर क्लिक करें।</li>
                        </ul>
                      </div>
                    </div>
                  )}

                  {/* Outer scroll wrapper with measurement ref and scaling container */}
                  <div 
                    ref={containerRef} 
                    className="w-full overflow-auto pb-6 pt-2 max-h-[820px] border border-gray-300 rounded-2xl bg-gray-100 shadow-inner flex justify-start items-start p-4 relative"
                  >
                    
                    {(() => {
                      const scale = Math.min(1.0, containerWidth / 960) * autoZoomMultiplier;
                      return renderSingleNewspaperPage(selectedPageNum, scale, false);
                    })()}
                  </div>

                  {/* Desktop Quick Indicator for zoom scale */}
                  <p className="text-[11px] text-gray-500 font-semibold mt-3 text-center">
                    💡 किसी भी ख़बर को विस्तार से पढ़ने के लिए उसकी <span className="text-red-600 font-bold">हेडलाइन</span> पर क्लिक करें।
                  </p>
                </div>
              ) : (
                <div className="flex-grow flex flex-col items-center justify-center p-8 text-center text-gray-500 bg-white border border-gray-200 rounded-2xl shadow-md w-full max-w-xl">
                  <span className="material-symbols-outlined text-5xl text-red-500 mb-3 animate-pulse">new_releases</span>
                  <h2 className="text-base font-bold text-gray-800">आज की कोई ख़बर पोस्ट उपलब्ध नहीं है।</h2>
                  <p className="text-xs text-gray-400 mt-1 max-w-sm">चयनित तिथि ({selectedDate}) और स्थान पर कोई समाचार पोस्ट प्रकाशित नहीं किया गया है। कृपया कोई अन्य तिथि या जिला चुनें, अथवा रिपोर्टर पैनल से नई ख़बर पोस्ट करें!</p>
                </div>
              )}
            </div>
          )}

        </div>

      </div>

      {/* DETAILED ARTICLE READER MODAL */}
      {selectedArticle && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
              <span className="text-xs font-bold text-red-600 uppercase bg-red-100 px-2 py-0.5 rounded tracking-wider">
                {selectedArticle.category || 'समाचार विवरण'}
              </span>
              <button 
                onClick={() => setSelectedArticle(null)}
                className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors"
                title="बंद करें"
              >
                <span className="material-symbols-outlined text-xl leading-none">close</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-4 flex-grow text-gray-800">
              {selectedArticle.thumbnailUrl && (
                <div className="w-full h-48 md:h-64 overflow-hidden rounded-xl bg-gray-100">
                  <img src={selectedArticle.thumbnailUrl} alt={selectedArticle.title} className="w-full h-full object-cover" />
                </div>
              )}

              <h2 className="text-xl md:text-2xl font-bold leading-tight font-serif text-gray-900 select-text">
                {selectedArticle.title}
              </h2>

              {/* Author details */}
              <div className="flex items-center gap-2 border-y border-gray-100 py-2">
                <img 
                  src={selectedArticle.authorProfilePicUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'} 
                  alt={selectedArticle.authorName} 
                  className="w-8 h-8 rounded-full border border-gray-200" 
                />
                <div className="text-xs">
                  <p className="font-bold text-gray-800 flex items-center gap-1">
                    {selectedArticle.authorName}
                    {selectedArticle.authorIsVerified && (
                      <span className="material-symbols-outlined text-blue-500 text-xs font-bold leading-none">verified</span>
                    )}
                  </p>
                  <p className="text-gray-400">क्षेत्रीय रिपोर्टर • {selectedArticle.district || selectedArticle.state || 'पब्लिक तक'}</p>
                </div>
                <span className="text-xs text-gray-400 ml-auto flex items-center gap-1">
                  <span className="material-symbols-outlined text-xs leading-none">visibility</span> {selectedArticle.viewCount || 0} व्यूज
                </span>
              </div>

              {/* Story Content */}
              <div 
                className="text-sm md:text-base leading-relaxed text-gray-700 font-serif text-justify select-text space-y-2 whitespace-pre-line"
                dangerouslySetInnerHTML={{ __html: selectedArticle.content }}
              />
            </div>

            {/* Modal Footer with quick social sharing */}
            <div className="p-4 border-t border-gray-100 bg-gray-50 flex items-center justify-between gap-3">
              <span className="text-xs text-gray-400">सच्ची पत्रकारिता, जन-जन तक</span>
              <div className="flex gap-2">
                <button
                  onClick={async () => {
                    const text = `*${selectedArticle.title}*\n\nपढ़ें पूरी ख़बर केवल पब्लिक तक ऐप पर। ऐप डाउनलोड करें और पाएँ पल-पल की अपडेट।\n${window.location.origin}`;
                    if (navigator.share) {
                      try {
                        await navigator.share({
                          title: selectedArticle.title,
                          text: text,
                          url: window.location.origin,
                        });
                      } catch (err: any) {
                        if (err?.name !== 'AbortError') {
                          window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
                        }
                      }
                    } else {
                      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
                    }
                  }}
                  className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-3 py-2 rounded-xl transition-all shadow shadow-blue-600/10"
                >
                  <span className="material-symbols-outlined text-sm leading-none font-bold">share</span>
                  <span>शेयर करें</span>
                </button>
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-700 text-xs font-bold px-4 py-2 rounded-xl transition-all"
                >
                  बंद करें
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADMIN UPLOAD MODAL */}
      {showUploadModal && isAdmin && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-gray-200 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150 text-gray-800">
            <div className="p-5 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
              <h3 className="text-base md:text-lg font-bold text-gray-900 flex items-center gap-2">
                <span className="material-symbols-outlined text-red-600 font-bold">cloud_upload</span>
                नया ई-पेपर अपलोड करें
              </h3>
              <button 
                onClick={() => setShowUploadModal(false)}
                className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
              >
                <span className="material-symbols-outlined text-xl leading-none">close</span>
              </button>
            </div>

            <form onSubmit={handleUploadEPaper} className="p-5 space-y-4 text-xs md:text-sm">
              {/* Title */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">ई-पेपर का शीर्षक (Title) *</label>
                <input 
                  type="text" 
                  required
                  placeholder="उदा. रांची विशेष संस्करण" 
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-xl px-3 py-2 focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Date */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">अखबार की तिथि (Date) *</label>
                <input 
                  type="date" 
                  required
                  value={uploadDate}
                  onChange={(e) => setUploadDate(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-xl px-3 py-2 focus:outline-none focus:border-red-500"
                />
              </div>

              {/* State */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">राज्य (State) - वैकल्पिक</label>
                <select
                  value={uploadState}
                  onChange={(e) => {
                    setUploadState(e.target.value);
                    setUploadDistrict('');
                  }}
                  className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-xl px-3 py-2 focus:outline-none focus:border-red-500"
                >
                  <option value="">राष्ट्रीय / National</option>
                  {statesList.map((st) => (
                    <option key={st} value={st}>{st}</option>
                  ))}
                </select>
              </div>

              {/* District */}
              {uploadState && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">जिला (District) - वैकल्पिक</label>
                  <select
                    value={uploadDistrict}
                    onChange={(e) => setUploadDistrict(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-xl px-3 py-2 focus:outline-none focus:border-red-500"
                  >
                    <option value="">सभी जिले</option>
                    {uploadDistricts.map((dt) => (
                      <option key={dt} value={dt}>{dt}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Multi-page Image File Input */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">अखबार के पन्नों की तस्वीरें (तस्वीरें चुनें) *</label>
                <div className="relative border-2 border-dashed border-gray-300 hover:border-gray-400 bg-gray-50 p-4 rounded-xl text-center cursor-pointer transition-colors">
                  <input 
                    type="file" 
                    multiple
                    required
                    accept="image/*"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <span className="material-symbols-outlined text-3xl text-gray-400 mb-1">image</span>
                  <p className="text-xs text-gray-700 font-semibold">इमेज फाइलें चुनें</p>
                  <p className="text-[10px] text-gray-400 mt-1">PNG, JPG, JPEG केवल</p>
                </div>

                {uploadFiles.length > 0 && (
                  <div className="mt-2.5 max-h-24 overflow-y-auto space-y-1 bg-gray-50 p-2 rounded-xl border border-gray-200">
                    <p className="text-[10px] font-bold text-gray-400 uppercase">चयनित पन्ने ({uploadFiles.length}):</p>
                    {uploadFiles.map((f, i) => (
                      <div key={i} className="text-xs text-gray-600 truncate flex items-center justify-between font-mono">
                        <span>Page {i + 1}: {f.name}</span>
                        <span>{(f.size / (1024 * 1024)).toFixed(2)} MB</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Upload Status / Progress Bar */}
              {isUploading && (
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-xs font-bold text-red-600">
                    <span>अपलोड हो रहा है...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden border border-gray-200">
                    <div className="bg-red-600 h-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                  </div>
                </div>
              )}

              {/* Submit Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  disabled={isUploading}
                  onClick={() => setShowUploadModal(false)}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 disabled:opacity-40 text-gray-700 text-sm font-bold py-2.5 rounded-xl transition-all"
                >
                  रद्द करें
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="flex-1 bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white text-sm font-bold py-2.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5"
                >
                  {isUploading ? (
                    <>
                      <span className="animate-spin h-4 w-4 border-2 border-white/30 border-t-white rounded-full"></span>
                      अपलोडिंग...
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-sm leading-none">cloud_upload</span>
                      प्रकाशित करें
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SLOT CONFIGURATION EDIT MODAL FOR ADMIN */}
      {isEditingLayout && selectedEditSlot && (() => {
        const slotKey = selectedEditSlot;
        const currentSlotConf = layout.slots[slotKey] || getDefaultLayout(activePageId).slots[slotKey];
        
        return (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 max-w-lg w-full max-h-[90vh] overflow-y-auto flex flex-col">
              {/* Header */}
              <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-2xl">
                <div>
                  <h3 className="text-sm font-black text-gray-900 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-blue-600 text-lg font-bold">settings</span>
                    <span>ई-पेपर स्लॉट {slotKey.replace('slot', '')} सेटिंग्स</span>
                  </h3>
                  <p className="text-[10px] text-gray-400 mt-0.5">माउस ड्रैग करके ऊंचाई-चौड़ाई बदलने के साथ यहां अन्य विकल्प सेट करें</p>
                </div>
                <button 
                  onClick={() => {
                    handleSaveLayout();
                    setSelectedEditSlot(null);
                  }}
                  className="p-1 hover:bg-gray-200 rounded-full text-gray-500 transition-colors"
                >
                  <span className="material-symbols-outlined text-lg leading-none font-bold">close</span>
                </button>
              </div>

              {/* Form/Options Content */}
              <div className="p-5 space-y-4 flex-grow overflow-y-auto">
                {/* 1. Slot Type Selector */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1.5">स्लॉट का प्रकार (Type)</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => updateSlotConf(slotKey, { type: 'news' })}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                        currentSlotConf.type === 'news'
                          ? 'bg-blue-50 border-blue-200 text-blue-700 shadow-sm'
                          : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <span className="material-symbols-outlined text-sm">newspaper</span>
                      <span>समाचार पोस्ट</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => updateSlotConf(slotKey, { type: 'ad' })}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                        currentSlotConf.type === 'ad'
                          ? 'bg-amber-50 border-amber-200 text-amber-700 shadow-sm'
                          : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <span className="material-symbols-outlined text-sm">campaign</span>
                      <span>विज्ञापन (Ad)</span>
                    </button>
                  </div>
                </div>

                {/* Conditional Fields based on Type */}
                {currentSlotConf.type === 'news' ? (
                  <>
                    {/* Bound Article Selector */}
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">समाचार पोस्ट बाइंडिंग</label>
                      <select
                        value={currentSlotConf.postId || ''}
                        onChange={(e) => updateSlotConf(slotKey, { postId: e.target.value || null })}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:border-blue-500"
                      >
                        <option value="">स्वचालित समाचार (Default sequential story)</option>
                        {displayStories.map((post) => (
                          <option key={post.id} value={post.id}>
                            [{post.category || 'समाचार'}] {post.title.substring(0, 50)}...
                          </option>
                        ))}
                      </select>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Ad Specific Customizations */}
                    <div className="bg-amber-50/40 p-3.5 rounded-xl border border-amber-100 space-y-3">
                      <p className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">विज्ञापन छवि सेटिंग्स (Advertisement Image)</p>
                      
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 mb-1">विज्ञापन मुख्य छवि (Ad Image Upload)</label>
                        {uploadingAdSlotKey === slotKey ? (
                          <div className="flex flex-col items-center justify-center border-2 border-dashed border-amber-300 rounded-xl p-4 bg-amber-50/50">
                            <div className="animate-spin rounded-full h-6 w-6 border-2 border-amber-600 border-t-transparent mb-2"></div>
                            <span className="text-[11px] font-semibold text-amber-700">अपलोड हो रहा है... {adUploadProgress}%</span>
                          </div>
                        ) : currentSlotConf.adImageUrl ? (
                          <div className="relative group/adimg border border-amber-200 rounded-xl p-2 bg-white flex items-center gap-3">
                            <img 
                              src={currentSlotConf.adImageUrl} 
                              alt="Ad preview" 
                              className="w-16 h-12 object-contain bg-gray-50 border border-gray-200 rounded"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-[10px] text-gray-500 truncate">{currentSlotConf.adImageUrl}</p>
                              <div className="flex gap-2 mt-1">
                                <label className="cursor-pointer text-[10px] font-extrabold text-blue-600 hover:text-blue-700">
                                  बदलें
                                  <input 
                                    type="file" 
                                    accept="image/*" 
                                    className="hidden" 
                                    onChange={(e) => {
                                      if (e.target.files && e.target.files[0]) {
                                        handleAdImageUpload(e.target.files[0], slotKey);
                                      }
                                    }}
                                  />
                                </label>
                                <button 
                                  type="button" 
                                  onClick={() => updateSlotConf(slotKey, { adImageUrl: "" })}
                                  className="text-[10px] font-extrabold text-red-600 hover:text-red-700"
                                >
                                  हटाएं
                                </button>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <label className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 hover:border-amber-500 rounded-xl p-4 cursor-pointer bg-white transition-all hover:bg-amber-50/20 group">
                            <span className="material-symbols-outlined text-gray-400 group-hover:text-amber-600 text-2xl mb-1">cloud_upload</span>
                            <span className="text-[11px] text-gray-600 font-bold group-hover:text-amber-700">विज्ञापन तस्वीर अपलोड करें</span>
                            <span className="text-[9px] text-gray-400 mt-0.5">JPEG, PNG या GIF (अधिकतम 5MB)</span>
                            <input 
                              type="file" 
                              accept="image/*" 
                              className="hidden" 
                              onChange={(e) => {
                                if (e.target.files && e.target.files[0]) {
                                  handleAdImageUpload(e.target.files[0], slotKey);
                                }
                              }}
                            />
                          </label>
                        )}
                        
                        <div className="mt-1.5">
                          <input
                            type="text"
                            value={currentSlotConf.adImageUrl || ''}
                            onChange={(e) => updateSlotConf(slotKey, { adImageUrl: e.target.value })}
                            placeholder="या तस्वीर का वेब लिंक (URL) पेस्ट करें..."
                            className="w-full bg-white border border-gray-200 rounded-lg px-2.5 py-1 text-[10px] text-gray-600 focus:outline-none focus:border-blue-500 placeholder-gray-400"
                          />
                        </div>
                      </div>

                      {/* Photo Adjustment Section (Crop/Resize/Adjust) */}
                      {currentSlotConf.adImageUrl && (
                        <div className="border-t border-amber-200/50 pt-3 space-y-3.5">
                          <p className="text-[10px] font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1">
                            <span className="material-symbols-outlined text-xs">crop_free</span>
                            <span>तस्वीर क्रॉप और पोजीशन सेटिंग्स (Crop & Adjust)</span>
                          </p>

                          {/* 1. Object Fit Mode */}
                          <div>
                            <label className="block text-[9.5px] font-bold text-gray-500 mb-1.5">तस्वीर फिट करने का तरीका (Fit Mode)</label>
                            <div className="grid grid-cols-3 gap-1.5">
                              <button
                                type="button"
                                onClick={() => updateSlotConf(slotKey, { adObjectFit: 'fill' })}
                                className={`py-1 px-1.5 rounded-lg text-[9.5px] font-extrabold border transition-all text-center ${
                                  (currentSlotConf.adObjectFit || 'fill') === 'fill'
                                    ? 'bg-amber-600 border-amber-600 text-white shadow-sm'
                                    : 'border-gray-200 text-gray-600 hover:bg-gray-50 bg-white'
                                }`}
                              >
                                खिंचाव (Fill)
                              </button>
                              <button
                                type="button"
                                onClick={() => updateSlotConf(slotKey, { adObjectFit: 'cover' })}
                                className={`py-1 px-1.5 rounded-lg text-[9.5px] font-extrabold border transition-all text-center ${
                                  currentSlotConf.adObjectFit === 'cover'
                                    ? 'bg-amber-600 border-amber-600 text-white shadow-sm'
                                    : 'border-gray-200 text-gray-600 hover:bg-gray-50 bg-white'
                                }`}
                              >
                                कटना (Cover)
                              </button>
                              <button
                                type="button"
                                onClick={() => updateSlotConf(slotKey, { adObjectFit: 'contain' })}
                                className={`py-1 px-1.5 rounded-lg text-[9.5px] font-extrabold border transition-all text-center ${
                                  currentSlotConf.adObjectFit === 'contain'
                                    ? 'bg-amber-600 border-amber-600 text-white shadow-sm'
                                    : 'border-gray-200 text-gray-600 hover:bg-gray-50 bg-white'
                                }`}
                              >
                                सुरक्षित (Contain)
                              </button>
                            </div>
                          </div>

                          {/* 2. Scale / Zoom */}
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-[9.5px] font-bold text-gray-500">तस्वीर ज़ूम / क्रॉप (Resize / Zoom)</label>
                              <span className="text-[9.5px] font-mono font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">
                                {Math.round((currentSlotConf.adScale !== undefined ? currentSlotConf.adScale : 1) * 100)}%
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="range"
                                min="0.5"
                                max="4.0"
                                step="0.05"
                                value={currentSlotConf.adScale !== undefined ? currentSlotConf.adScale : 1}
                                onChange={(e) => updateSlotConf(slotKey, { adScale: parseFloat(e.target.value) })}
                                className="flex-1 accent-amber-600 h-1 bg-gray-200 rounded-lg cursor-pointer"
                              />
                              <button
                                type="button"
                                onClick={() => updateSlotConf(slotKey, { adScale: 1 })}
                                className="text-[9px] font-bold text-gray-500 hover:text-amber-700 hover:bg-amber-100/50 bg-gray-100 px-1.5 py-0.5 rounded transition-all"
                              >
                                रीसेट
                              </button>
                            </div>
                          </div>

                          {/* 3. Shift X */}
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-[9.5px] font-bold text-gray-500">बाएँ / दाएँ खिसकाएँ (Shift X)</label>
                              <span className="text-[9.5px] font-mono font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">
                                {currentSlotConf.adPosX !== undefined ? currentSlotConf.adPosX : 0}px
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="range"
                                min="-300"
                                max="300"
                                step="1"
                                value={currentSlotConf.adPosX !== undefined ? currentSlotConf.adPosX : 0}
                                onChange={(e) => updateSlotConf(slotKey, { adPosX: parseInt(e.target.value) })}
                                className="flex-1 accent-amber-600 h-1 bg-gray-200 rounded-lg cursor-pointer"
                              />
                              <button
                                type="button"
                                onClick={() => updateSlotConf(slotKey, { adPosX: 0 })}
                                className="text-[9px] font-bold text-gray-500 hover:text-amber-700 hover:bg-amber-100/50 bg-gray-100 px-1.5 py-0.5 rounded transition-all"
                              >
                                रीसेट
                              </button>
                            </div>
                          </div>

                          {/* 4. Shift Y */}
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-[9.5px] font-bold text-gray-500">ऊपर / नीचे खिसकाएँ (Shift Y)</label>
                              <span className="text-[9.5px] font-mono font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">
                                {currentSlotConf.adPosY !== undefined ? currentSlotConf.adPosY : 0}px
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="range"
                                min="-300"
                                max="300"
                                step="1"
                                value={currentSlotConf.adPosY !== undefined ? currentSlotConf.adPosY : 0}
                                onChange={(e) => updateSlotConf(slotKey, { adPosY: parseInt(e.target.value) })}
                                className="flex-1 accent-amber-600 h-1 bg-gray-200 rounded-lg cursor-pointer"
                              />
                              <button
                                type="button"
                                onClick={() => updateSlotConf(slotKey, { adPosY: 0 })}
                                className="text-[9px] font-bold text-gray-500 hover:text-amber-700 hover:bg-amber-100/50 bg-gray-100 px-1.5 py-0.5 rounded transition-all"
                              >
                                रीसेट
                              </button>
                            </div>
                          </div>

                          {/* 5. Reset All Ad Photo adjustments */}
                          <div className="flex justify-end pt-1">
                            <button
                              type="button"
                              onClick={() => updateSlotConf(slotKey, { adScale: 1, adPosX: 0, adPosY: 0, adObjectFit: 'fill' })}
                              className="text-[9.5px] font-extrabold text-red-600 hover:text-red-700 flex items-center gap-1 hover:bg-red-50 px-2 py-1 rounded-lg border border-transparent hover:border-red-100 transition-all"
                            >
                              <span className="material-symbols-outlined text-[12px] font-bold">restart_alt</span>
                              <span>सभी सेटिंग्स रीसेट करें</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* Typography Configurations */}
                <div className="border-t border-gray-100 pt-3 space-y-3">
                  <h4 className="text-[11px] font-black text-gray-600 uppercase tracking-wider">स्टाइल और फॉन्ट सेटिंग्स</h4>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">शीर्षक फॉन्ट साइज: <span className="font-bold text-blue-600">{currentSlotConf.fontSizeTitle || (slotKey === 'slot1' ? 14 : 12)}px</span></label>
                      <input
                        type="range"
                        min="9"
                        max="24"
                        value={currentSlotConf.fontSizeTitle || (slotKey === 'slot1' ? 14 : 12)}
                        onChange={(e) => updateSlotConf(slotKey, { fontSizeTitle: parseInt(e.target.value) })}
                        className="w-full accent-blue-600 cursor-pointer h-1 bg-gray-200 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">मुख्य फॉन्ट साइज: <span className="font-bold text-blue-600">{currentSlotConf.fontSizeBody || 9}px</span></label>
                      <input
                        type="range"
                        min="6"
                        max="14"
                        value={currentSlotConf.fontSizeBody || 9}
                        onChange={(e) => updateSlotConf(slotKey, { fontSizeBody: parseInt(e.target.value) })}
                        className="w-full accent-blue-600 cursor-pointer h-1 bg-gray-200 rounded-lg"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 mb-1">कॉलमों की संख्या (Columns)</label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[1, 2, 3, 4].map((cols) => (
                        <button
                          key={cols}
                          type="button"
                          onClick={() => updateSlotConf(slotKey, { columnCount: cols })}
                          className={`py-1.5 rounded-lg text-xs font-bold border transition-all ${
                            (currentSlotConf.columnCount || (slotKey === 'slot1' || slotKey === 'slot4' ? 3 : 1)) === cols
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                          }`}
                        >
                          {cols} {cols === 1 ? 'कॉलम' : 'कॉलम'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Advanced Formatting Options */}
                <div className="border-t border-gray-100 pt-3 space-y-3">
                  <h4 className="text-[11px] font-black text-gray-600 uppercase tracking-wider flex items-center gap-1 text-blue-600">
                    <span className="material-symbols-outlined text-xs font-bold">tune</span>
                    <span>अतिरिक्त एडवांस स्टाइल सेटिंग्स</span>
                  </h4>

                  {/* Custom subtitle and custom tag */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-0.5">कस्टम टैग (जैसे BREAKING)</label>
                      <input
                        type="text"
                        value={currentSlotConf.customTag || ''}
                        onChange={(e) => updateSlotConf(slotKey, { customTag: e.target.value })}
                        placeholder="जैसे: मुख्य समाचार"
                        className="w-full bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-0.5">स्ट्रैपलाइन / उप-शीर्षक</label>
                      <input
                        type="text"
                        value={currentSlotConf.customSubtitle || ''}
                        onChange={(e) => updateSlotConf(slotKey, { customSubtitle: e.target.value })}
                        placeholder="शीर्षक के नीचे अतिरिक्त पंक्ति..."
                        className="w-full bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {/* Background Color & Borders */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">बैकग्राउंड का रंग</label>
                      <select
                        value={currentSlotConf.slotBgColor || 'bg-white'}
                        onChange={(e) => updateSlotConf(slotKey, { slotBgColor: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                      >
                        <option value="bg-white">श्वेत (Classic White)</option>
                        <option value="bg-amber-50/40">क्रीम (Vintage Newsprint)</option>
                        <option value="bg-red-50/30">हल्का लाल (Breaking Pink)</option>
                        <option value="bg-yellow-50/40">हल्का पीला (Golden Light)</option>
                        <option value="bg-blue-50/30">हल्का नीला (Special Blue)</option>
                        <option value="bg-emerald-50/30">हल्का हरा (Editorial Mint)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">बॉर्डर की स्टाइल</label>
                      <select
                        value={currentSlotConf.slotBorderStyle || 'border-solid'}
                        onChange={(e) => updateSlotConf(slotKey, { slotBorderStyle: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                      >
                        <option value="border-solid">सीधी ठोस रेखा (Solid)</option>
                        <option value="border-double">दोहरी रेखा (Elegant Double)</option>
                        <option value="border-dashed">कटी रेखा (Dashed)</option>
                        <option value="border-dotted">बिंदु रेखा (Dotted)</option>
                        <option value="border-none">कोई बॉर्डर नहीं (None)</option>
                      </select>
                    </div>
                  </div>

                  {/* Border Width & Color */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">बॉर्डर की मोटाई</label>
                      <select
                        value={currentSlotConf.slotBorderWidth || 'border-2'}
                        onChange={(e) => updateSlotConf(slotKey, { slotBorderWidth: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                      >
                        <option value="border">पतला (1px)</option>
                        <option value="border-2">मध्यम (2px)</option>
                        <option value="border-3">मोटा (3px)</option>
                        <option value="border-4">अति मोटा (4px)</option>
                        <option value="border-0">कोई बॉर्डर नहीं (None)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">बॉर्डर का रंग</label>
                      <select
                        value={currentSlotConf.slotBorderColor || 'border-black'}
                        onChange={(e) => updateSlotConf(slotKey, { slotBorderColor: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                      >
                        <option value="border-black">काला (Classic Black)</option>
                        <option value="border-red-600">लाल (Urgent Red)</option>
                        <option value="border-blue-800">नीला (Midnight Blue)</option>
                        <option value="border-gray-400">धूसर (Soft Gray)</option>
                      </select>
                    </div>
                  </div>

                  {/* Title color, align and line height */}
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">शीर्षक का रंग</label>
                      <select
                        value={currentSlotConf.slotTitleColor || 'text-black'}
                        onChange={(e) => updateSlotConf(slotKey, { slotTitleColor: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-[11px] focus:outline-none focus:border-blue-500"
                      >
                        <option value="text-black">काला (Black)</option>
                        <option value="text-red-700">लाल (Red Accent)</option>
                        <option value="text-blue-900">नीला (Royal Navy)</option>
                        <option value="text-green-800">हरा (Editorial Green)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">शीर्षक संरेखण</label>
                      <select
                        value={currentSlotConf.slotTitleAlign || 'text-justify'}
                        onChange={(e) => updateSlotConf(slotKey, { slotTitleAlign: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-[11px] focus:outline-none focus:border-blue-500"
                      >
                        <option value="text-justify">दोनों ओर (Justify)</option>
                        <option value="text-center">मध्य में (Center)</option>
                        <option value="text-left">बाएँ (Left)</option>
                        <option value="text-right">दाएँ (Right)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">समाचार लाइन स्पेसिंग</label>
                      <select
                        value={currentSlotConf.slotBodyLineHeight || '1.45'}
                        onChange={(e) => updateSlotConf(slotKey, { slotBodyLineHeight: e.target.value })}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-[11px] focus:outline-none focus:border-blue-500"
                      >
                        <option value="1.25">सघन (Compact)</option>
                        <option value="1.45">सामान्य (Normal)</option>
                        <option value="1.65">खुला (Relaxed)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Thumbnail Configuration */}
                <div className="border-t border-gray-100 pt-3 space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="text-[11px] font-black text-gray-600 uppercase tracking-wider">छवि/थंबनेल (Thumbnail)</h4>
                    <button
                      type="button"
                      onClick={() => updateSlotConf(slotKey, { showThumbnail: !currentSlotConf.showThumbnail })}
                      className={`text-xs px-2.5 py-1 rounded-full font-bold transition-colors ${
                        currentSlotConf.showThumbnail
                          ? 'bg-green-100 text-green-700 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {currentSlotConf.showThumbnail ? 'चालू (Visible)' : 'बंद (Hidden)'}
                    </button>
                  </div>

                  {currentSlotConf.showThumbnail && (
                    <div className="space-y-3 bg-gray-50 p-3 rounded-xl border border-gray-100">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 mb-1">छवि की स्थिति (Position Mode)</label>
                        <div className="grid grid-cols-5 gap-1">
                          {['top', 'right', 'bottom', 'left', 'free'].map((pos) => (
                            <button
                              key={pos}
                              type="button"
                              onClick={() => updateSlotConf(slotKey, { thumbnailPosition: pos })}
                              className={`py-1 rounded text-[10px] font-extrabold border transition-all capitalize ${
                                (currentSlotConf.thumbnailPosition || 'right') === pos
                                  ? 'bg-blue-100 border-blue-300 text-blue-700 font-extrabold shadow-sm'
                                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                              }`}
                            >
                              {pos === 'top' ? 'ऊपर' : pos === 'right' ? 'दाएँ' : pos === 'bottom' ? 'नीचे' : pos === 'left' ? 'बाएँ' : 'स्वतंत्र'}
                            </button>
                          ))}
                        </div>
                        <p className="text-[9px] text-gray-400 mt-1">
                          {currentSlotConf.thumbnailPosition === 'free' 
                            ? '💡 स्वतंत्र मोड: इमेज को माउस से पकड़कर कहीं भी खिसकाएं (Drag) और चारों किनारों से खींचकर आकार बदलें!' 
                            : '💡 स्टैंडर्ड मोड: न्यूज़ टेक्स्ट के साथ ऑटो-फ्लो होती है।'}
                        </p>
                      </div>

                      {['left', 'right'].includes(currentSlotConf.thumbnailPosition || 'right') && (
                        <div>
                          <label className="block text-[10px] font-bold text-gray-500 mb-1">छवि चौड़ाई: <span className="font-bold text-blue-600">{currentSlotConf.thumbnailWidth || 35}%</span></label>
                          <input
                            type="range"
                            min="15"
                            max="75"
                            value={currentSlotConf.thumbnailWidth || 35}
                            onChange={(e) => updateSlotConf(slotKey, { thumbnailWidth: parseInt(e.target.value) })}
                            className="w-full accent-blue-600 cursor-pointer h-1 bg-gray-200 rounded-lg"
                          />
                        </div>
                      )}

                      {currentSlotConf.thumbnailPosition === 'free' && (
                        <div className="space-y-2 border-t border-gray-200 pt-2">
                          <p className="text-[9px] font-black uppercase text-blue-700">स्वतंत्र इमेज स्थिति एवं आकार (मैनुअल कण्ट्रोल):</p>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] font-bold text-gray-500 mb-0.5">X स्थिति (बाएँ से दूरी): <span className="text-blue-600">{currentSlotConf.thumbnailX || 120}px</span></label>
                              <input
                                type="number"
                                value={currentSlotConf.thumbnailX !== undefined ? currentSlotConf.thumbnailX : 120}
                                onChange={(e) => updateSlotConf(slotKey, { thumbnailX: parseInt(e.target.value) || 0 })}
                                className="w-full bg-white border border-gray-200 rounded px-2 py-1 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Y स्थिति (ऊपर से दूरी): <span className="text-blue-600">{currentSlotConf.thumbnailY || 60}px</span></label>
                              <input
                                type="number"
                                value={currentSlotConf.thumbnailY !== undefined ? currentSlotConf.thumbnailY : 60}
                                onChange={(e) => updateSlotConf(slotKey, { thumbnailY: parseInt(e.target.value) || 0 })}
                                className="w-full bg-white border border-gray-200 rounded px-2 py-1 text-xs"
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] font-bold text-gray-500 mb-0.5">चौड़ाई (Width): <span className="text-blue-600">{currentSlotConf.thumbnailWidth || 140}px</span></label>
                              <input
                                type="number"
                                value={currentSlotConf.thumbnailWidth !== undefined ? currentSlotConf.thumbnailWidth : 140}
                                onChange={(e) => updateSlotConf(slotKey, { thumbnailWidth: parseInt(e.target.value) || 30 })}
                                className="w-full bg-white border border-gray-200 rounded px-2 py-1 text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] font-bold text-gray-500 mb-0.5">ऊंचाई (Height): <span className="text-blue-600">{currentSlotConf.thumbnailHeight || 100}px</span></label>
                              <input
                                type="number"
                                value={currentSlotConf.thumbnailHeight !== undefined ? currentSlotConf.thumbnailHeight : 100}
                                onChange={(e) => updateSlotConf(slotKey, { thumbnailHeight: parseInt(e.target.value) || 30 })}
                                className="w-full bg-white border border-gray-200 rounded px-2 py-1 text-xs"
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-gray-500 mb-1">इमेज फ्लोट एलाइनमेंट (Wrapping Direction):</label>
                            <select
                              value={currentSlotConf.thumbnailFloat || 'left'}
                              onChange={(e) => updateSlotConf(slotKey, { thumbnailFloat: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded px-2.5 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                            >
                              <option value="left">बाएँ फ्लोट (Float Left - Text on Right)</option>
                              <option value="right">दाएँ फ्लोट (Float Right - Text on Left)</option>
                            </select>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-gray-100 flex gap-2.5 bg-gray-50 rounded-b-2xl">
                <button
                  type="button"
                  onClick={() => {
                    handleSaveLayout();
                    setSelectedEditSlot(null);
                  }}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold py-2 px-4 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1"
                >
                  <span className="material-symbols-outlined text-sm">done_all</span>
                  <span>बदलाव सेव करें (Close & Apply)</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* HIDDEN CONTAINER FOR BATCH MULTI-PAGE PRINTING (Positioned offscreen so layout engine calculates accurate dimensions) */}
      <div 
        id="all-printable-pages" 
        style={{
          position: 'fixed',
          top: -20000,
          left: -20000,
          width: '960px',
          pointerEvents: 'none',
          opacity: 0,
          zIndex: -9999,
          visibility: 'visible',
        }}
      >
        {ePaperMode === 'auto' ? (
          epaperPages.map((page, index) => renderSingleNewspaperPage(index, 1.0, true))
        ) : (
          activeEPaper?.pages.map((url, idx) => (
            <div key={idx} className="printable-uploaded-page">
              <img src={url} alt={`Page ${idx + 1}`} referrerPolicy="no-referrer" />
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default EPaperPage;
