
import * as React from 'react';
import * as ReactDOM from 'react-dom/client';
import App from './App';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

try {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );
} catch (error) {
  console.error("React rendering failed:", error);
  rootElement.innerHTML = `
    <div style="padding: 20px; font-family: sans-serif; text-align: center;">
      <h2 style="color: #dc2626;">Something went wrong</h2>
      <p>The application could not be loaded. Please try refreshing the page.</p>
      <button onclick="window.location.reload()" style="background: #dc2626; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer;">Refresh App</button>
      <pre style="text-align: left; background: #f4f4f4; padding: 10px; margin-top: 20px; overflow: auto; max-width: 100%; font-size: 12px;">${error instanceof Error ? error.message : String(error)}</pre>
    </div>
  `;
}

// Register service workers for PWA and background FCM Push Notifications
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // Register Firebase Messaging SW for background FCM notifications
    navigator.serviceWorker.register('/firebase-messaging-sw.js')
      .then(registration => {
        console.log('Firebase Messaging SW registered: ', registration);
      })
      .catch(err => {
        console.log('Firebase SW registration error: ', err);
      });

    // Register Main SW for offline PWA caching
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => {
        console.log('Main SW registered: ', registration);
      })
      .catch(registrationError => {
        console.log('SW registration failed: ', registrationError);
      });
  });
}
