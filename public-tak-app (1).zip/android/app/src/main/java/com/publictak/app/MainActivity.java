package com.publictak.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
