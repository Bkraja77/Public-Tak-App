
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

const firebaseConfig = {
  apiKey: "AIzaSyBcVMGPppCWHy9sGacwXXf_gmg4kb0Dd0Y",
  authDomain: "public-tak-app.firebaseapp.com",
  projectId: "public-tak-app",
  storageBucket: "public-tak-app.firebasestorage.app",
  messagingSenderId: "323471252789",
  appId: "1:323471252789:web:a017363ff24b1174be807c",
  measurementId: "G-7E42XPLLK2"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

/**
 * Handle background messages.
 * Note: Custom sounds are not supported in the standard showNotification API 
 * for background service workers in most browsers for anti-spam reasons.
 * However, we use vibrations and high-quality images to ensure visibility.
 */
messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  
  const notificationId = payload.data?.notificationId || null;
  if (notificationId) {
    fetch('/api/notifications/track-delivered', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notificationId })
    }).catch(err => console.error('[SW] Track delivered failed:', err));
  }

  const notificationTitle = payload.notification?.title || payload.data?.postTitle || payload.data?.title || "पब्लिक तक ऐप (News Update)";
  const notificationBody = payload.notification?.body || payload.data?.body || payload.data?.description || "ताज़ा खबर पढ़ने के लिए टैप करें।";
  const notificationImage = payload.notification?.image || payload.data?.image || payload.data?.thumbnailUrl || null;
  const postId = payload.data?.postId || null;

  const notificationOptions = {
    body: notificationBody,
    icon: '/icon-192.png', 
    badge: '/icon-192.png', // Monochrome icon for Android status bar
    image: notificationImage, // Large thumbnail image in notification drawer
    vibrate: [300, 100, 300, 100, 400], // Distinctive news vibration pattern
    tag: postId ? `post-${postId}` : 'public-tak-news-alert',
    renotify: true,
    data: {
        notificationId,
        postId,
        url: payload.data?.url || (postId ? `/?postId=${postId}&notifId=${notificationId}` : '/')
    },
    actions: [
        {
            action: 'open',
            title: 'खबर पढ़ें (Read News)'
        },
        {
            action: 'close',
            title: 'हटाएं (Dismiss)'
        }
    ]
  };

  return self.registration.showNotification(notificationTitle, notificationOptions);
});

// Generic Push Listener for non-FCM web push fallback in background
self.addEventListener('push', (event) => {
  let data = { title: 'पब्लिक तक ऐप', body: 'नई खबर उपलब्ध है!' };
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const title = data.postTitle || data.title || data.notification?.title || 'पब्लिक तक ऐप';
  const body = data.body || data.notification?.body || data.description || 'ताज़ा खबर पढ़ने के लिए टैप करें।';
  const image = data.image || data.thumbnailUrl || data.notification?.image || null;
  const postId = data.postId || data.data?.postId || null;

  const options = {
    body: body,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    image: image,
    vibrate: [200, 100, 200],
    tag: postId ? `post-${postId}` : 'public-tak-push',
    renotify: true,
    data: {
      postId: postId,
      url: data.url || (postId ? `/?postId=${postId}` : '/')
    },
    actions: [
      { action: 'open', title: 'खबर पढ़ें' },
      { action: 'close', title: 'हटाएं' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

self.addEventListener('notificationclick', function(event) {
  const notificationId = event.notification.data?.notificationId;

  if (event.action === 'close') {
    event.notification.close();
    if (notificationId) {
      event.waitUntil(
        fetch('/api/notifications/track-dismissed', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ notificationId })
        }).catch(err => console.error('[SW] Track dismissed clicked failed:', err))
      );
    }
    return;
  }

  event.notification.close();
  const urlToOpen = event.notification.data?.url || '/';
  
  const trackingPromise = notificationId ? fetch('/api/notifications/track-opened', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ notificationId })
  }).catch(err => console.error('[SW] Track opened failed:', err)) : Promise.resolve();

  event.waitUntil(
    trackingPromise.then(() => 
      clients.matchAll({type: 'window', includeUncontrolled: true}).then(windowClients => {
          // Try to find an existing window and focus it
          for (let i = 0; i < windowClients.length; i++) {
              const client = windowClients[i];
              if (client.url.includes(self.location.origin) && 'focus' in client) {
                  // If it's the same URL, focus it. If different, navigate and focus.
                  if (client.url === urlToOpen) {
                      return client.focus();
                  } else {
                      return client.navigate(urlToOpen).then(c => c.focus());
                  }
              }
          }
          // If no window found, open a new one
          if (clients.openWindow) {
              return clients.openWindow(urlToOpen);
          }
      })
    )
  );
});

self.addEventListener('notificationclose', function(event) {
  const notificationId = event.notification.data?.notificationId;
  if (notificationId) {
    event.waitUntil(
      fetch('/api/notifications/track-dismissed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId })
      }).catch(err => console.error('[SW] Track dismissed closed failed:', err))
    );
  }
});
