
importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.5.4/workbox-sw.js');

const CACHE_NAME = 'public-tak-v6';

if (workbox) {
  console.log('[SW] Workbox loaded successfully');
  
  workbox.core.clientsClaim();
  workbox.core.skipWaiting();

  // Clean old caches on activation
  self.addEventListener('activate', (event) => {
    event.waitUntil(
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cache) => {
            if (cache !== CACHE_NAME && cache !== 'public-tak-assets' && cache !== 'public-tak-scripts' && cache !== 'public-tak-articles' && cache !== 'public-tak-pages') {
              console.log('[SW] Deleting old cache:', cache);
              return caches.delete(cache);
            }
          })
        );
      })
    );
  });

  // 1. Precache Core Static Assets
  workbox.precaching.precacheAndRoute([
    { url: '/manifest.json', revision: '2' },
    { url: '/icon-192.png', revision: '2' },
    { url: '/icon-512.png', revision: '2' }
  ]);

  // 2. Cache CSS, Web Fonts, and Images with StaleWhileRevalidate strategy
  workbox.routing.registerRoute(
    ({ request }) => 
      request.destination === 'style' ||
      request.destination === 'font' ||
      request.destination === 'image',
    new workbox.strategies.StaleWhileRevalidate({
      cacheName: 'public-tak-assets',
      plugins: [
        new workbox.expiration.ExpirationPlugin({
          maxEntries: 100,
          maxAgeSeconds: 30 * 24 * 60 * 60, // 30 Days
        }),
      ],
    })
  );

  // 3. JS scripts must use NetworkFirst to ensure latest code after new builds
  workbox.routing.registerRoute(
    ({ request }) => request.destination === 'script',
    new workbox.strategies.NetworkFirst({
      cacheName: 'public-tak-scripts',
      plugins: [
        new workbox.expiration.ExpirationPlugin({
          maxEntries: 50,
          maxAgeSeconds: 7 * 24 * 60 * 60,
        }),
      ],
    })
  );

  // 4. Cache viewed articles using NetworkFirst strategy
  workbox.routing.registerRoute(
    ({ url }) => url.searchParams.has('postId') || url.pathname.includes('/article') || url.pathname.includes('/posts'),
    new workbox.strategies.NetworkFirst({
      cacheName: 'public-tak-articles',
      plugins: [
        new workbox.expiration.ExpirationPlugin({
          maxEntries: 10,
          maxAgeSeconds: 7 * 24 * 60 * 60,
        }),
      ],
    })
  );

  // 5. Navigation route for main app pages with NetworkFirst
  workbox.routing.registerRoute(
    ({ request }) => request.mode === 'navigate',
    new workbox.strategies.NetworkFirst({
      cacheName: 'public-tak-pages',
      plugins: [
        new workbox.expiration.ExpirationPlugin({
          maxEntries: 20,
        }),
      ],
    })
  );

  // Set offline catch handler
  workbox.routing.setCatchHandler(async ({ event }) => {
    if (event.request.mode === 'navigate') {
      return (await caches.match('/index.html')) || (await caches.match('/'));
    }
    return Response.error();
  });

} else {
  console.log('[SW] Workbox failed to load');
}

// --- Push Notification Event Handlers ---
self.addEventListener('push', (event) => {
  let data = { title: 'पब्लिक तक ऐप', body: 'नई खबर अपडेट उपलब्ध है!' };
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const title = data.postTitle || data.title || data.notification?.title || 'पब्लिक तक ऐप';
  const body = data.body || data.notification?.body || data.description || 'ताज़ा खबर पढ़ने के लिए टैप करें।';
  const image = data.image || data.thumbnailUrl || data.notification?.image || null;
  const postId = data.postId || data.data?.postId || null;

  const options = {
    body: body,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    image: image,
    vibrate: [200, 100, 200, 100, 300],
    tag: postId ? `post-${postId}` : 'public-tak-push',
    renotify: true,
    data: {
      postId: postId,
      url: data.url || (postId ? `/?postId=${postId}` : '/')
    },
    actions: [
      { action: 'read', title: 'खबर पढ़ें (Open)', icon: '/icon-192.png' },
      { action: 'close', title: 'हटाएं (Dismiss)' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Notification Click Handler
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'close') return;

  const urlToOpen = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (let i = 0; i < windowClients.length; i++) {
        const client = windowClients[i];
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});

