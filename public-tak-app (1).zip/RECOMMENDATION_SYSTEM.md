# Public Tak App: User Engagement & Growth Recommendation Engine
## Complete Production-Ready Architecture, Algorithm Design & Technical Blueprint

This document specifies the highly advanced, scalable, AI-powered recommendation architecture and ranking algorithms designed for **Public Tak App**, a hyper-local news and short video platform supporting millions of users.

---

## 1. System Architecture Blueprint

To deliver low-latency recommendations (target p95 latency < 50ms) while continuously processing millions of user behavioral logs, we employ a **hybrid Lambda-Kappa Architecture**. This separates ingestion, scoring, ranking, and machine-learning workflows into clear hot, warm, and cold paths.

```
                           +------------------------+
                           |  User Client (Mobile)  |
                           +-----------+------------+
                                       |
                         Behavior Logs | (Scroll, Pause, Click, Watch Time)
                                       v
                           +-----------+------------+
                           |   API Ingestion Layer  |
                           +-----------+------------+
                                       |
                                       +-----------------------------------------+
                                       | (Real-time stream)                      | (Micro-batch / DB writes)
                                       v                                         v
                           +-----------+------------+              +-------------+-------------+
                           |  Kafka Stream Cluster  |              | PostgreSQL (Postgres DB)  |
                           +-----------+------------+              +-------------+-------------+
                                       |                                         |
               +-----------------------+-----------------------+                 | (Replication)
               |                                               |                 v
               v                                               v           +-----+-----+
   +-----------+------------+                      +-----------+-----------+     |  Cold     |
   | Flink Real-time Engine |                      | Spark / Batch Analytics     |  Storage  |
   |  (Session Aggregator)  |                      | (Collaborative Filtering)   |  (Parquet)|
   +-----------+------------+                      +-----------+-----------+     +-----+-----+
               |                                               |                       |
 Dynamic       | (Instant score update)       Precomputed      | (Daily / hourly       | (Offline Training)
 Profile Update|                              Vectors & Models | models)               v
               v                                               v                 +-----+-----+
   +-----------+------------+                      +-----------+------------+    | TensorFlow|
   |  Redis Cache Cluster   |                      | Vector DB (Pinecone)   |    | DLRM / GNN|
   |  (Active User Profiles)|                      | (Annoy / Milvus Index) |    +-----+-----+
   +-----------+------------+                      +-----------+------------+
               |                                               |
               +-----------------------+-----------------------+
                                       | (Retrieval request)
                                       v
                           +-----------+------------+
                           |   Ranking API Service  |
                           |   (Go / Rust / Node)   |
                           +-----------+------------+
                                       |
                                       +--> 1. Retrieval (Multi-channel Candidates)
                                       +--> 2. Filtering (Anti-Spam & Prohibited Content)
                                       +--> 3. Scoring (Hybrid Ranking Formulas)
                                       +--> 4. Re-Ranking (Diversity, Cold-Start, Fatigue)
                                       |
                                       v
                           +-----------+------------+
                           |  Response (Sorted Feed)|
                           +------------------------+
```

### Architectural Modules:
1. **Ingestion Layer (API & Gateway)**: Lightweight Node.js or Go services that ingest streaming telemetry events (e.g., `VIDEO_PLAYBACK_PROGRESS`, `CARD_PAUSED`, `USER_SCROLL_DEPTH`).
2. **Real-time Processing Pipeline (Kappa)**: Powered by Apache Flink or Kafka Streams. It processes fine-grained tracking data inside sliding 10-minute windows and directly updates the in-memory **Dynamic User Interest Profile** stored in Redis.
3. **Batch/AI Pipeline (Lambda)**: Powered by Apache Spark and PyTorch. Periodically runs heavy algorithms (e.g., matrix factorization, collaborative filtering, Graph Neural Network-based user embedding) to generate deep retrieval vectors.
4. **Vector Retrieval Store**: Milvus, pgvector, or Pinecone. Stores embeddings for both content (News/Videos) and users, enabling rapid high-dimensional nearest neighbor queries ($k$-NN) for collaborative matching.
5. **Multi-Stage Ranking Engine**: Implemented as a high-throughput, horizontally scalable API service that takes retrieved candidates and sequentially applies filtering, scoring, and re-ranking rules.

---

## 2. Database Design & Schema Specifications

The database layer utilizes a polyglot storage architecture: **Relational (PostgreSQL)** for highly integrated metadata, transactional accounts, and administrative content, and **NoSQL (Firestore / Redis)** for high-throughput user state management, tracking metrics, and dynamic interest profiles.

### 2.1 Post/Video Metadata Table (PostgreSQL)
```sql
CREATE TABLE content_metadata (
    id VARCHAR(64) PRIMARY KEY,
    type VARCHAR(16) NOT NULL, -- 'news', 'video', 'image'
    title VARCHAR(512) NOT NULL,
    category VARCHAR(32) NOT NULL, -- 'Local', 'Crime', 'Politics', etc.
    author_id VARCHAR(64) NOT NULL,
    is_verified_creator BOOLEAN DEFAULT FALSE,
    is_breaking_news BOOLEAN DEFAULT FALSE,
    location_point GEOMETRY(Point, 4326), -- For hyper-local proximity queries
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    likes_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    shares_count INT DEFAULT 0,
    saves_count INT DEFAULT 0,
    reports_count INT DEFAULT 0,
    avg_watch_time NUMERIC(8,2) DEFAULT 0.0,
    completion_rate NUMERIC(5,2) DEFAULT 0.0, -- Range: 0.00 to 100.00
    duplicate_signature VARCHAR(128), -- Perceptual image/video hash
    spam_score NUMERIC(4,3) DEFAULT 0.0, -- Spam score assigned by automatic models
    status VARCHAR(16) DEFAULT 'active' -- 'active', 'under_review', 'shadowbanned', 'removed'
);

-- Optimize retrieval and proximity searches
CREATE INDEX idx_content_type_status ON content_metadata(type, status) WHERE status = 'active';
CREATE INDEX idx_content_category ON content_metadata(category);
CREATE INDEX idx_content_location ON content_metadata USING GIST(location_point);
CREATE INDEX idx_content_created_at ON content_metadata(created_at DESC);
```

### 2.2 User Telemetry and Interaction Table (TimescaleDB / Partitioned Table)
Tracks atomic interactions to train offline models and compute growth statistics.
```sql
CREATE TABLE user_interactions (
    id BIGSERIAL,
    user_id VARCHAR(64) NOT NULL,
    content_id VARCHAR(64) NOT NULL,
    interaction_type VARCHAR(32) NOT NULL, -- 'view', 'like', 'comment', 'share', 'save', 'skip', 'report', 'watch_progress'
    watch_time_seconds NUMERIC(6,2) DEFAULT 0.0,
    completion_percent NUMERIC(5,2) DEFAULT 0.0,
    scroll_velocity NUMERIC(6,2), -- pixels per millisecond
    pause_time_ms INT DEFAULT 0,
    category VARCHAR(32),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
) PARTITION BY RANGE (created_at);
```

### 2.3 Redis Dynamic Profile Schema (Key-Value Document Store)
Stored in Redis under the key `profile:user_{userId}` with an expiration policy of 30 days of inactivity.
```json
{
  "user_id": "usr_94a82cd",
  "preferred_categories": {
    "Local": 142.5,
    "Politics": 89.2,
    "Crime": 120.4,
    "Sports": -15.0,
    "Technology": 12.4
  },
  "preferred_creators": {
    "creator_jharkhand_tak": 75.0,
    "creator_ranchi_news": 42.1
  },
  "behavioral_attributes": {
    "avg_scroll_speed": 1.25,
    "avg_video_completion_rate": 0.68,
    "active_hours_distribution": [0,0,0,0,0,0,12,24,40,15,5,1,0,0,0,10,35,80,95,70,40,10,2,0]
  },
  "recent_content_ids": ["vid_001", "news_022", "vid_055"]
}
```

---

## 3. Dynamic Interactive User Scoring System

Every action made by a user triggers a dynamic modification of their **Interest Scores** across Categories and Creators. The score updates instantaneously in memory to allow immediate adaptation of the home feed within the current session.

### 3.1 Scoring Matrix and Action Weights

| Telemetry Action | Score Modifier | Functional Explanation |
| :--- | :--- | :--- |
| **Follow Creator** | $+25$ | Absolute highest positive content affinity signal. |
| **Share Post/Video** | $+20$ | Indicates highly viral material that the user takes pride in distributing. |
| **Comment** | $+18$ | High engagement cost. Shows deep conversational interest. |
| **Save Post/Video** | $+16$ | High future utility value. The user wants to archive this for later. |
| **Video Completion** | $+15$ | Strong consumption indicator for video media. |
| **Read Full Article** | $+14$ | Strong consumption indicator for textual media (derived from reading time/scroll depth). |
| **Video Rewatch** | $+12$ | Re-viewing loops signify supreme entertainment/information value. |
| **Like Post/Video** | $+8$ | Simple low-friction endorsement. |
| **Fast Skip** | $-10$ | Video skipped within first 2 seconds; negative preference penalty. |
| **Hide Post/Video** | $-20$ | Displeasure. Immediately lowers recommendations for this category. |
| **Report Post/Video** | $-40$ | High violation / extreme dislike. Triggers automatic admin audit check. |

### 3.2 Dynamic Score Adjustment & Category Decay
Category interest scores $S_c$ adjust dynamically following interaction $i$:
$$S_c(t) = \max\left(-100, \min\left(1000, S_c(t-1) + \text{Weight}_i\right)\right)$$

To ensure old behavior does not permanently bias recommendations, dynamic scores decay overnight:
$$S_c(t_{new}) = S_c(t_{old}) \times e^{-\gamma \cdot \Delta t}$$
Where $\gamma = 0.05$ (daily decay factor) and $\Delta t$ is the elapsed days.

---

## 4. Multi-Stage Recommendation & Ranking Pipeline

```
                     +---------------------------------------+
                     | Candidates Retrieval Stage (M-Channel)|
                     |   - Location-aware candidates         |
                     |   - Category Preference retrieval     |
                     |   - Collaborative Filtering vectors   |
                     |   - Latest Breaking News & Trending   |
                     +-------------------+-------------------+
                                         | (e.g., 1000 candidates)
                                         v
                     +---------------------------------------+
                     |        Filtering Stage (Safety)       |
                     |   - Spam score removal                |
                     |   - Explicit Content / Report Filters |
                     |   - Blocked & Already Seen filter     |
                     +-------------------+-------------------+
                                         | (e.g., 500 candidates)
                                         v
                     +---------------------------------------+
                     |         Scoring Stage (Formulas)      |
                     |   - Dynamic Interest Score Alignment  |
                     |   - Location Proximity Boost          |
                     |   - Trending Score boost              |
                     +-------------------+-------------------+
                                         | (e.g., 100 candidates)
                                         v
                     +---------------------------------------+
                     |       Re-Ranking & Diversity Stage    |
                     |   - Creator cold-start allocation     |
                     |   - Category Fatigue penalty (max 2)  |
                     |   - Freshness & Time Decay application|
                     +-------------------+-------------------+
                                         | (Top 20 items returned)
                                         v
```

### 4.1 Trending Score Formula
To determine what items deserve to go viral on the platform, we utilize a multi-factor engagement formula with temporal decay:

$$\text{Trending Score} = \left[ (\text{WatchTime} \times 25\%) \times (\text{CompletionRate} \times 20\%) \times (\text{CommentQuality} \times 15\%) \times (\text{Shares} \times 20\%) \times (\text{Saves} \times 10\%) \times (\text{NewFollowers} \times 5\%) \times (\text{GrowthVelocity} \times 5\%) \right] \times \text{DecayFactor}$$

#### Parameter Definitions:
1. **WatchTime (25%)**: Total aggregated hours spent watching this item.
2. **CompletionRate (20%)**: Percentage of video plays that reached $>90\%$ completion.
3. **CommentQuality (15%)**: Weighted sum of comment activity, where longer/constructive threads score higher than low-character comments.
4. **Shares (20%)**: Counts of video and article shares.
5. **Saves (10%)**: Number of times the content is saved.
6. **NewFollowers (5%)**: Direct follows gained from this specific content page.
7. **GrowthVelocity (5%)**: Acceleration of interactions in the last 15 minutes:
   $$\text{GrowthVelocity} = \frac{\text{Interactions}_{[t_0, t_{15}]}}{\text{Interactions}_{[t_{15}, t_{30}]}}$$
8. **DecayFactor (Gravity Decay)**: To ensure old items decay naturally so fresh high-quality articles can rise to the top:
   $$\text{DecayFactor} = \frac{1}{(T + 2)^{G}}$$
   Where $T$ is the age of the content in hours, and $G = 1.8$ is the gravity exponent.

### 4.2 Proximity & Personalization Scoring Formula
The final score of a candidate content item $j$ for a user $u$ is calculated as:

$$\text{FinalScore}_{uj} = w_1 \cdot \text{DynamicPref}_{u,c(j)} + w_2 \cdot \text{CreatorAffinity}_{u,a(j)} + w_3 \cdot \text{TrendingScore}_j + w_4 \cdot \text{ProximityBoost}_{u,j} + w_5 \cdot \text{Freshness}_j$$

Where:
- **ProximityBoost**: Calculated via geodesic distance for local news:
  $$\text{ProximityBoost}_{u,j} = \max\left(0, 1 - \frac{\text{Distance}(u, j)}{50\text{ km}}\right) \times \text{Weight}_{local}$$
- **Freshness**: Expands visibility of new items:
  $$\text{Freshness}_j = e^{-\lambda \cdot T_{age}}$$

---

## 5. Creator Growth & Equal Opportunity Algorithm

Many modern algorithms permanently favor large creators, creating extreme content monopolies and disheartening small quality publishers. Public Tak App solves this via our **Cold-Start Allocation Pipeline**:

```
[ New Content Uploaded ] ---> [ Funnel Tier 1: Local Distribution ] 
                                 - Distributed to a localized group of 100 active users.
                                 - If User Engagement Ratio (Completion + Likes) >= 15% -> Promote!
                                 - Else -> Regular distribution based on search/category matching.
                                 |
                                 v
                              [ Funnel Tier 2: Category Expansion ]
                                 - Distributed to 2,000 highly active category subscribers.
                                 - If Completion Rate >= 35% AND Shares >= 2% -> Promote!
                                 - Else -> Organic distribution cap.
                                 |
                                 v
                              [ Funnel Tier 3: Viral Feed Injection ]
                                 - Injected directly into the main trending feed globally.
                                 - Expanded dynamically to 50k+ users.
```

By enforcing a **Tiered Funnel**, we guarantee every single video and post receives at least **100 guaranteed high-quality impressions** regardless of the creator's follower count.

---

## 6. Anti-Spam & Fraud Prevention Logic

Spam, engagement manipulation, and automated bots severely degrade feed quality. We deploy three core defensive mechanisms directly inside our recommendation engine:

1. **Velocity Anomaly Detection**:
   If an IP address or individual user account executes more than 25 "Likes" or "Follows" per minute, their recommendation influence score is set to zero, and they are flagged in the cache as `bot_candidate:true`.
2. **Comment Sentiment & Bot Filtering**:
   Generic comments (e.g., *"nice"*, *"great video"*, *"wow"*, *"ok"*) originating from newly registered accounts with uncompleted profiles are excluded from the **Comment Quality (15%)** metric and given a weight of $0.0$.
3. **Duplicate Content Signature Blocking**:
   We compute perceptual hash values (pHash) on incoming media. If a newly uploaded video has a similarity score $>92\%$ with an existing video, its visibility multiplier is set to $0.1$ to block duplicate repost farms.

---

## 7. AI Engine & API Integration Flows

To scale, the scoring calculations are split between **lightweight inline scoring** (implemented in TypeScript/Rust on top of DB queries) and **heavy offline deep models** (retrained asynchronously).

### API Request Schema (Feed Generation)
`POST /api/v1/recommendations/feed`
```json
{
  "userId": "usr_94a82cd",
  "location": {
    "latitude": 23.3441,
    "longitude": 85.3096
  },
  "deviceInfo": {
    "deviceType": "mobile",
    "networkSpeedMbps": 14.5
  },
  "pagination": {
    "limit": 20,
    "cursor": "c3BfZXZlbnRfMDAy"
  }
}
```

### Response Schema
```json
{
  "status": "success",
  "data": {
    "items": [
      {
        "id": "vid_29910a",
        "type": "video",
        "title": "Breaking: Local protest in Ranchi over new highway path",
        "url": "https://cdn.publictak.com/videos/v_ranchi_protest_720p.mp4",
        "category": "Local",
        "score": 892.44,
        "isBreaking": true,
        "author": {
          "id": "auth_ranchi_news",
          "name": "Ranchi Local News",
          "isVerified": true
        }
      }
    ],
    "nextCursor": "c3BfZXZlbnRfMDQw"
  }
}
```

---

## 8. Summary of Performance Goals & Benchmarks

* **Millisecond Response Times**: Realized via Redis cluster caching of individual user dynamic profiles and pre-computed candidate lists.
* **Maximized Watch Time & Retention**: Maintained by updating interest preferences in real-time within the current session.
* **Organic Creator Growth**: Maintained through our guaranteed Tiered Funnel, providing equal opportunity and blocking engagement farmers.
