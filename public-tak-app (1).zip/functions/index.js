const { onRequest } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");

if (!admin.apps.length) {
  try {
    admin.initializeApp();
  } catch (e) {
    console.error("Firebase admin init warning:", e);
  }
}

const FIREBASE_API_KEY = "AIzaSyBcVMGPppCWHy9sGacwXXf_gmg4kb0Dd0Y";
const FIREBASE_PROJECT_ID = "public-tak-app";
const DEFAULT_LOGO = "https://publictak.app/icon-512.png";
const DEFAULT_TITLE = "Public Tak App | Local News, Video Reels & Daily Hindi E-Paper";
const DEFAULT_DESC = "Public Tak App par paayein apne shehar aur rajya ki sabse tez evam taza khabrein, video reels, verified reporter updates aur daily e-paper. Desh, Bihar, Jharkhand ki har khabar sabse pehle!";
const BASE_URL = "https://www.publictak.app";

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function cleanText(str, maxLength = 180) {
  if (!str) return "";
  const cleaned = String(str)
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();

  if (cleaned.length > maxLength) {
    return cleaned.substring(0, maxLength).trim() + "...";
  }
  return cleaned;
}

function parseFirestoreValue(val) {
  if (!val) return null;
  if ("stringValue" in val) return val.stringValue;
  if ("integerValue" in val) return parseInt(val.integerValue, 10);
  if ("doubleValue" in val) return parseFloat(val.doubleValue);
  if ("booleanValue" in val) return val.booleanValue;
  if ("timestampValue" in val) return val.timestampValue;
  if ("mapValue" in val) {
    const res = {};
    for (const k in val.mapValue.fields || {}) {
      res[k] = parseFirestoreValue(val.mapValue.fields[k]);
    }
    return res;
  }
  if ("arrayValue" in val) {
    return (val.arrayValue.values || []).map(parseFirestoreValue);
  }
  return null;
}

function parseFirestoreDoc(doc) {
  if (!doc || !doc.fields) return null;
  const res = { id: (doc.name || "").split("/").pop() };
  for (const k in doc.fields) {
    res[k] = parseFirestoreValue(doc.fields[k]);
  }
  return res;
}

async function fetchDocument(collection, docId) {
  if (!docId) return null;

  // 1. First try Firestore REST API (Fastest ~50ms, works without IAM role negotiation)
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${collection}/${encodeURIComponent(docId)}?key=${FIREBASE_API_KEY}`;
    const resp = await fetch(url, { signal: AbortSignal.timeout(4000) });
    if (resp.ok) {
      const json = await resp.json();
      const parsed = parseFirestoreDoc(json);
      if (parsed) return parsed;
    }
  } catch (err) {
    // silently proceed to fallback
  }

  // 2. Fallback to Firebase Admin SDK
  if (admin.apps.length) {
    try {
      const snap = await admin.firestore().collection(collection).doc(docId).get();
      if (snap.exists) {
        return { id: snap.id, ...snap.data() };
      }
    } catch (e) {
      // ignore
    }
  }

  return null;
}

function getImageMimeType(url) {
  const lower = (url || "").toLowerCase();
  if (lower.includes(".png")) return "image/png";
  if (lower.includes(".webp")) return "image/webp";
  if (lower.includes(".gif")) return "image/gif";
  return "image/jpeg";
}

/**
 * Cloud Function ssrServer
 * Invoked by Firebase Hosting rewrites for shared links (/p/:id, /post/:id, /v/:id, /share/...)
 * Serves rich Open Graph HTML to WhatsApp, Facebook, Telegram, Google, etc.
 * And immediately redirects human users to the full web app.
 */
exports.ssrServer = onRequest({ cors: true, maxInstances: 10, timeoutSeconds: 15 }, async (req, res) => {
  try {
    const reqPath = req.path || "/";
    let postId = req.query.postId;
    let videoId = req.query.videoId;
    let userId = req.query.userId;

    // Support clean URL paths: /p/:id, /post/:id, /v/:id, /video/:id, /u/:id
    if (!postId && reqPath.startsWith("/p/")) {
      postId = reqPath.replace("/p/", "").split("/")[0].split("?")[0];
    }
    if (!postId && reqPath.startsWith("/post/")) {
      postId = reqPath.replace("/post/", "").split("/")[0].split("?")[0];
    }
    if (!videoId && reqPath.startsWith("/v/")) {
      videoId = reqPath.replace("/v/", "").split("/")[0].split("?")[0];
    }
    if (!videoId && reqPath.startsWith("/video/")) {
      videoId = reqPath.replace("/video/", "").split("/")[0].split("?")[0];
    }
    if (!userId && reqPath.startsWith("/u/")) {
      userId = reqPath.replace("/u/", "").split("/")[0].split("?")[0];
    }

    const host = req.get("x-forwarded-host") || req.get("host") || "www.publictak.app";
    const protocol = req.get("x-forwarded-proto") || (host.includes("localhost") ? "http" : "https");
    const baseUrl = `${protocol}://${host}`;

    let title = DEFAULT_TITLE;
    let description = DEFAULT_DESC;
    let image = DEFAULT_LOGO;
    let targetUrl = `${baseUrl}/`;
    let ogType = "website";
    let authorName = "Public Tak Reporter";
    let buttonText = "👉 Public Tak App में खोलें &raquo;";

    if (postId && typeof postId === "string") {
      const cleanPostId = decodeURIComponent(postId).trim().replace(/[/?#].*$/, "");
      targetUrl = `${baseUrl}/?postId=${encodeURIComponent(cleanPostId)}`;
      const post = await fetchDocument("posts", cleanPostId);
      if (post) {
        const rawTitle = (post.title || "ताज़ा खबर").trim();
        title = `${rawTitle} | Public Tak News`;
        description = cleanText(post.content, 200) || "पूरी खबर पढ़ने के लिए Public Tak App पर क्लिक करें।";
        if (post.thumbnailUrl && typeof post.thumbnailUrl === "string") {
          image = post.thumbnailUrl.trim();
        }
        ogType = "article";
        authorName = post.authorName || "Public Tak Verified Reporter";
        buttonText = "👉 पूरी खबर यहाँ पढ़ें &raquo;";
      }
    } else if (videoId && typeof videoId === "string") {
      const cleanVideoId = decodeURIComponent(videoId).trim().replace(/[/?#].*$/, "");
      targetUrl = `${baseUrl}/?videoId=${encodeURIComponent(cleanVideoId)}`;
      const video = await fetchDocument("videos", cleanVideoId);
      if (video) {
        const rawTitle = (video.title || "Video Bulletin").trim();
        title = `🎥 ${rawTitle} | Public Tak Video`;
        description = cleanText(video.description || video.title, 200) || "यह ब्रेकिंग वीडियो रिपोर्ट Public Tak App पर देखें।";
        if (video.thumbnailUrl && typeof video.thumbnailUrl === "string") {
          image = video.thumbnailUrl.trim();
        }
        ogType = "video.other";
        authorName = video.authorName || "Public Tak Reporter";
        buttonText = "👉 पूरा वीडियो यहाँ देखें &raquo;";
      }
    } else if (userId && typeof userId === "string") {
      const cleanUserId = decodeURIComponent(userId).trim().replace(/[/?#].*$/, "");
      targetUrl = `${baseUrl}/?userId=${encodeURIComponent(cleanUserId)}`;
      const user = await fetchDocument("users", cleanUserId);
      if (user) {
        title = `👤 ${user.name || "Public Reporter"} | Public Tak App`;
        description = cleanText(user.bio, 200) || `${user.name || "Public Reporter"} की ताज़ा खबरें व रिपोर्ट Public Tak App पर देखें।`;
        if (user.profilePicUrl && typeof user.profilePicUrl === "string") {
          image = user.profilePicUrl.trim();
        }
        ogType = "profile";
        buttonText = "👉 रिपोर्टर प्रोफ़ाइल देखें &raquo;";
      }
    }

    const safeTitle = escapeHtml(title);
    const safeDesc = escapeHtml(description);
    const safeImage = escapeHtml(image);
    const safeTargetUrl = escapeHtml(targetUrl);
    const safeAuthor = escapeHtml(authorName);
    const imageMimeType = getImageMimeType(image);

    const html = `<!DOCTYPE html>
<html lang="hi" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  
  <!-- Primary Meta Tags -->
  <title>${safeTitle}</title>
  <meta name="title" content="${safeTitle}">
  <meta name="description" content="${safeDesc}">
  <link rel="canonical" href="${safeTargetUrl}">
  <link rel="image_src" href="${safeImage}">
  <link rel="icon" type="image/png" href="${DEFAULT_LOGO}">
  
  <!-- Open Graph / WhatsApp / Facebook / Telegram -->
  <meta property="og:site_name" content="Public Tak App">
  <meta property="og:type" content="${ogType}">
  <meta property="og:url" content="${safeTargetUrl}">
  <meta property="og:title" content="${safeTitle}">
  <meta property="og:description" content="${safeDesc}">
  <meta property="og:image" content="${safeImage}">
  <meta property="og:image:secure_url" content="${safeImage}">
  <meta property="og:image:type" content="${imageMimeType}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:alt" content="${safeTitle}">
  <meta property="og:locale" content="hi_IN">
  <meta property="article:author" content="${safeAuthor}">

  <!-- Twitter / X Cards -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:site" content="@PublicTakApp">
  <meta name="twitter:title" content="${safeTitle}">
  <meta name="twitter:description" content="${safeDesc}">
  <meta name="twitter:image" content="${safeImage}">
  <meta name="twitter:image:alt" content="${safeTitle}">

  <!-- Fast client redirect for real human users -->
  <meta http-equiv="refresh" content="0;url=${safeTargetUrl}">
  <script>
    if (typeof window !== 'undefined' && window.location) {
      window.location.replace("${safeTargetUrl}");
    }
  </script>

  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 16px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Devanagari", sans-serif;
      background-color: #0f172a;
      color: #f8fafc;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    .card {
      background: #1e293b;
      border-radius: 20px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
      max-width: 460px;
      width: 100%;
      overflow: hidden;
      border: 1px solid #334155;
    }
    .thumb-wrap {
      width: 100%;
      height: 240px;
      overflow: hidden;
      background: #000;
      position: relative;
    }
    .thumb-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .badge {
      position: absolute;
      top: 12px;
      left: 12px;
      background: #dc2626;
      color: white;
      font-size: 11px;
      font-weight: 800;
      padding: 4px 10px;
      border-radius: 9999px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    .content {
      padding: 20px;
    }
    h1 {
      font-size: 18px;
      line-height: 1.4;
      margin: 0 0 10px 0;
      color: #ffffff;
      font-weight: 800;
    }
    .author {
      font-size: 12px;
      color: #94a3b8;
      margin-bottom: 12px;
    }
    p {
      font-size: 14px;
      line-height: 1.6;
      color: #cbd5e1;
      margin: 0 0 20px 0;
    }
    .btn {
      display: block;
      width: 100%;
      text-align: center;
      background: linear-gradient(135deg, #dc2626, #b91c1c);
      color: #ffffff;
      text-decoration: none;
      padding: 14px 20px;
      border-radius: 12px;
      font-weight: 800;
      font-size: 15px;
      box-shadow: 0 4px 14px rgba(220,38,38,0.4);
      transition: opacity 0.2s;
    }
    .btn:hover {
      opacity: 0.95;
    }
    .footer-note {
      text-align: center;
      font-size: 11px;
      color: #64748b;
      margin-top: 14px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="thumb-wrap">
      <img src="${safeImage}" alt="${safeTitle}" width="1200" height="630" />
      <span class="badge">Public Tak News</span>
    </div>
    <div class="content">
      <h1>${safeTitle}</h1>
      <div class="author">रिपोर्टर: ${safeAuthor}</div>
      <p>${safeDesc}</p>
      <a href="${safeTargetUrl}" class="btn">${buttonText}</a>
      <div class="footer-note">Public Tak App – आपकी खबर, आपकी पहचान</div>
    </div>
  </div>
</body>
</html>`;

    res.set({
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=300, s-maxage=600",
      "Access-Control-Allow-Origin": "*",
    });

    return res.status(200).send(html);
  } catch (error) {
    console.error("Error in ssrServer function:", error);
    return res.redirect(302, `${BASE_URL}/`);
  }
});
